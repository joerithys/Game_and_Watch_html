// Get the element you want displayed in fullscreen mode: 
var elem = document.documentElement;

// adjust the full screen button to default when the exit of the full screen detected
if (document.addEventListener) {
	document.addEventListener('fullscreenchange', exitHandler, false);
	document.addEventListener('mozfullscreenchange', exitHandler, false);
	document.addEventListener('MSFullscreenChange', exitHandler, false);
	document.addEventListener('webkitfullscreenchange', exitHandler, false);
}

//when page loaded provide a functional "open full screen" button on the proper place as default
$(document).ready(function () {
	FullScreenIconAdd();	// add default full screen icon to click on
	FullScreenIconSet();	// position the full screen icon
	$("#full_screen_button").hover(	// darken the "open full screen" button when hovered over with mouse pointer
		function() {$("#full_screen_img").attr("src","img/case/full_screen/full_screen_hover.png");},
		function() {$("#full_screen_img").attr("src","img/case/full_screen/full_screen.png");
	});
});

// exit fullscreen 
function CloseFullScreen () {
	//exitHandler();	// adjust the full screen button to default
	// exit full screen
	if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document.webkitExitFullscreen) { // Safari 
		document.webkitExitFullscreen();
	} else if (document.msExitFullscreen) { // IE11 
		document.msExitFullscreen();
	};
};

// adjust the full screen button to default
function exitHandler () {
	// html lines for "open full screen" button and function call
	var strOpen = '<a data-tooltip="set to full screen" onmousedown="OpenFullScreen();"><img id="full_screen_img" alt="Press to show on full screen.." SRC="img/case/full_screen/full_screen.png" name="screen"></a>';
	if (!document.webkitIsFullScreen && !document.mozFullScreen && !document.msFullscreenElement) {
		$("#full_screen_button").html(strOpen);	// set the full screen button to "open full screen"
		$("#full_screen_button").hover(	// darken "open full screen" button when hovered over with mouse pointer
			function() {$("#full_screen_img").attr("src","img/case/full_screen/full_screen_hover.png");},
			function() {$("#full_screen_img").attr("src","img/case/full_screen/full_screen.png");
		});
		fullScreen = 0;	// full screen not active
	};
};

// add full screen icon to click on
function FullScreenIconAdd () {
	// html lines for creating the "open full screen" button and function call
	var strAdd = '<div id="full_screen_button"><a data-tooltip="set to full screen" onmousedown="OpenFullScreen();"><img id="full_screen_img" alt="Press to show on full screen.." SRC="img/case/full_screen/full_screen.png" name="screen"></a></div>';
	$("#game").append(strAdd); // add the html lines for creating the "open full screen" button and function call to the game
};

// position the full screen icon
function FullScreenIconSet () {
	$("#full_screen_button").css('position','absolute');
	$("#full_screen_button").css('left','40px');
	$("#full_screen_button").css('top','663px');
};

// set page to fullscreen 
function OpenFullScreen () {
	// html lines for "exit full screen" button and function
	var strClose = '<a data-tooltip="exit full screen" onmousedown="CloseFullScreen();"><img id="full_screen_img" alt="Press to exit full screen.." SRC="img/case/full_screen/exit_full_screen.png" name="screen"></a>';
	$("#full_screen_button").html(strClose);	// set html lines for "exit full screen" button and function
	$("#full_screen_button").hover(	// darken "exit full screen" button when hovered over with mouse pointer
		function() {$("#full_screen_img").attr("src","img/case/full_screen/exit_full_screen_hover.png");},
		function() {$("#full_screen_img").attr("src","img/case/full_screen/exit_full_screen.png");
	});
	fullScreen = 1;	// fullscreen active
	// activate full screen
	if (elem.requestFullscreen) {
		elem.requestFullscreen();
	} else if (elem.webkitRequestFullscreen) { // Safari 
		elem.webkitRequestFullscreen();
	} else if (elem.msRequestFullscreen) { // IE11 
		elem.msRequestFullscreen();
	};
};
