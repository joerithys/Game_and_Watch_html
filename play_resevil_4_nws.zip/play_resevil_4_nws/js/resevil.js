//Product:			G&W Resident Evil 4 : Chainsaw Maniac HTML - New Wide Screen (Nintendo) Simulator
//Version:			1.1
//Started:			19.10.2022
//Last update:		06.08.2023
//Author			Flyzy (Joeri Thys)
//Programmer		Flyzy (Joeri Thys)
//Original Capcom Co. Ltd (feedback@capcom.com)

//Credits:
//Design, layout and artwork by Capcom

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var blinkSpeed = 150;  // blinking speed for failure indication
var blinkID;	// ID for timeout blinking failure
var blinkerID;	// ID for timeout faster blinking 
var blinker;		// number of blinks
var maniacBlinkPos;		// position of blinking maniac

var demo = false;	   // indicates if demo is running or not
var demoID;	 // ID for timeout demo autostart and  run

var acl = false;	// for showing acl pictures, all if "ACL" is pressed twice fast
var aclID;	// ID to view all pictures @ fast double click
var blink = 5;	// times to run a blink function
var fullScreen = 0;	// no full screen view
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameID;	// ID for timeout of game sequence
var gameOver = 0;	// game is not over

var gameSpeedMax = 300;	// maximum speed for game sequence timer

var gameSpeed = 500;	// speed for game sequence timer
var highScore = new Array();	// to remember the highest score played for both games since opened in the browser
var killerMoveDemo = 0;	// killer not moving @ demo
var 	killerKilled = 0;	// killer not killed
var life = 0;   // number of lives left
var maniac = new Array();	// for all maniac posotions
var ManiacsLastLine = 0;	// position where a maniac got thrue
var pause = false;	
var pos;		// position killer
var posPrev;		// previous position killer
var knives;		// knives left to use before having to get new ones
var zoomed = 1;		// for default the screen is auto adapted to window size

// reset pressed keys to none pressed
var AKeyPressed = false;	// indicates if a previuos hit "of the game A" key was already pressed to avoid double entries
var BKeyPressed = false;	// indicates if a previuos hit of the "game A" key was already pressed to avoid double entries
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var RKeyPressed = false;	// indicates if a previuos hit of the "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;	// indicates if a previuos hit of the "TIME" key was already pressed to avoid double entries

var prefSound = 1;	  // sound setting : 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var score = 0;	// score (all beneath 100) at init

var alarm = false;	// alarm not running
var alarmID;	// ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = true;	 // for indicationif alarm is set on or off
var alarmSetting = false;	   // if alarm is at set mode to make changes

var prefAlarmMin = 0;	// last saved alarm setting minutes
var prefAlarmHour = 0;	// last saved alarm setting hours

var timeID;	 // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
	codeCurrent = e.keyCode;		// for reading game keys
	e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
	switch (e.key) {
		case "1": case "a": case "A":	 // if "1", "a" or "A" pressed
			// show game A button pressed
			document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';	 
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!BKeyPressed) { // if no other key is pressed
				MainGameA(); // show high score @ play Game A after button release
				AKeyPressed = true;
			};
			break;
		case "2": case "b": case "B":	 // if "2", "b" or "B" pressed
			// show game B button pressed
			document.images['Game B'].src = 'img/case/buttons/grey_2_flat.png';	// show pressed button on screen
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!AKeyPressed) { // if no other key is pressed
				MainGameB(); // show high score and get ready to play Game B
				BKeyPressed = true;
			};
			break;
		case "d": case "D": case "ArrowLeft":	// left keys
			// show left button pressed
			document.images['Move Left'].src = 'img/case/buttons/left_flat.png';	 
			LeftPressed();	  // function to move left
			keyPressed = true;
			break;
		case "k": case "K": case "ArrowRight":	// right keys
			// show right button pressed
			document.images['Move Right'].src = 'img/case/buttons/right_flat.png';	 
			RightPressed();	 // function to move right
			keyPressed = true;
			break;
		case "r": case "R":	 // if "r" or "R" pressed
			// show acl button pressed
			document.images['Acl'].src = 'img/case/buttons/acl_push.png';
			RKeyPressed = true;
			ClearPressedKeys();	// ignore and clear all other keys that are pressed
			TotalReset(); // show full sprites
			break;
		case "t": case "T":	 // if "t" or "T" pressed
			// show time button pressed
			document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
			if (!AKeyPressed&&!RKeyPressed&&!TKeyPressed) {
				ClearPressedKeys();	// ignore and clear all other keys that are pressed
				MainTime(); // show time & demo
				TimeShowOnScreen(prefAlarmMin, prefAlarmHour);	// show required time and indicators on screen from alarm
				TKeyPressed = true;
			};
			break;
		case "w": case "W":	 // if "w" or "W" pressed
			// show alarm button pressed
			document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainAlarm(); // set alarm
			break;
		//test case buttons 
		case "+":	// "+"-numpadkey
			if (vlm<1) {
				vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
				preVlm = vlm;   // current voluem becomes previus set @ next change of volume
			};
			if (vlm==0.01)  SetSound(true);	// show sound turned on
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "-":	// "-"-key
			if (vlm>0) {
				vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
				preVlm = vlm;   // current voluem becomes previus set @ next change of volume
			};
			if (vlm==0) SetSound(false);	// show sound turned off
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "/":	// "/"-key
			if (vlm==0.3) vlm = 0.03
			else vlm = 0.3;
			PrefSoundShow();	// show volume indicator on screen for testing purposes if set
			break;
		case "s": case "S":	 // if "s" or "S" pressed
			// swich sound on/off for testing purposes
			PrefSound ();
			break
		case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
			prefSoundShow = !prefSoundShow;	 // show/hide indicator
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case ")": case String.fromCharCode(219):	// ")"-key
			zoomed = zoomed?0:1;	// toggle auto zoom function on/off
			$(function () {
				CheckSizeZoom()	// calculate size and position for autozoom if set or get default if not set
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);	// autozoom to calculated size and position/default
			break;
		case "!":	// toggle full/normal screen
			if (!fullScreen) {
				OpenFullScreen();
			} else {
				CloseFullScreen();
			};
		default:
	};
	//console.log("You pressed e.keyCode : " + e.keyCode + " <==> %c '" + e.key + "'"+(life?(" %c lives left = "+life):" %c")+" ","background-color:green; color:gold; font-weight:bold;","background-color:white; color:black;","	 --	 fullScreen = "+fullScreen);
}, false);

window.addEventListener("keyup", function (e) {
	// game and arrow keys
	switch (e.key) {
		case "1": case "a": case "A":	 // if "1", "a" or "A" released
			// show game A button default
			document.images['Game A'].src = 'img/case/buttons/grey_1.png';  
			if (AKeyPressed) MainGameAGo(); // start running Game A
			AKeyPressed = false;
			break;
			AKeyPressed = false;
		case "2": case "b": case "B":	 // if "2", "b" or "B" released
			// show game B button default
			document.images['Game B'].src = 'img/case/buttons/grey_2.png';	 // show game B button default
			if (BKeyPressed) MainGameBGo(); // play Game A
			BKeyPressed = false;
			break;
		case "d": case "D": case "ArrowLeft":	// left key released
			// show left button default
			document.images['Move Left'].src = 'img/case/buttons/left.png';	 
			keyPressed = false;
			break;
		case "k": case "K": case "ArrowRight":	// right key released
			// show right button default
			document.images['Move Right'].src = 'img/case/buttons/right.png';	 
			keyPressed = false;
			break;
		case "r": case "R":	 // if "r" or "R" pressed
			// show acl button default
			document.images['Acl'].src = 'img/case/buttons/acl.png';
			RKeyPressed = false;
			break;
		case "t": case "T":	 // if "t" or "T" released
			// show time button default
			document.images['Time'].src = 'img/case/buttons/grey_3.png';
			if (TKeyPressed) TimeShowOnScreen(min, hour);	// show required time and indicators on screen from current time
			TKeyPressed = false;
			break;
		case "w": case "W":	 // if "w" or "W" pressed
			// show alarm button default
			document.images['Alarm'].src = 'img/case/buttons/acl.png';
			break;
		default: 
	};
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

// if reviewing this tab, refresh screen
$(window).focus(function(){
	//focus log code
	console.log("---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          "+(gameOver?"screen not refreshed because GAME OVER !!!%c%c":"%c SCREEN REFRESHED ! %c"),
				"background-color:red; color:white; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"background-color:turquoise; color:blue; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"background-color:green; color:white; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"background-color:purple; color:white; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"     ---"); 	// color test
	if (demo) FiguresScreenShowCurrent(); // show current screen status from bottom to top
});


//when page loaded focus on game 
$(document).ready(function () {
	Beep();
	PlaySound("click_wav", vlm);	// click sound (for waking up some browsers' sound play if neccesary)
	$(function () {	// autozoom @ start
		CheckSizeZoom()	// calculate size and position for autozoom
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);	// autozoom to calculated size
	$("#game").focus(); // get focus on the game
	highScore[1] = 0;	// highest score game A
	highScore[2] = 0;	// highest score game B
	PicPreload();	// this function preloads all images to make them ready for use
	knives = 3;	// all the knives are available
	MainPicturesShow();	// show default figures
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	console.log("\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39 --- %c "+today+" %c --- %c welcome to this Game & Watch simmulator, have fun! ", 
				"background-color:red; color:white; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"background-color:lime; color:orangered; font-weight:bold;",
				" ---"); 	// color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually go to the left
function GoLeft () {
	if (!pause&&((game!=1&&pos>1)||pos>2)) {	// if not totally left
		if ((game!=1)&&(!knives&&pos==6)) {	// if killer comes back from taking new knives on the right
			knives = 3;	// all the knives are available
			KnivesShow();	// show the knives that are available
			KnivesGetLeftRightHide();	// hide the knives reload left & right
		} else {	// if killer takes new knives on the left
			if ((game!=1)&&(!knives&&pos==2)) PlaySound("get_knives_wav", vlm);		// sound of getting new set of knives
		};
		posPrev = pos;	// remember current position
		pos--;	// go position to the left
		KillerShow();	// show killer @ current position 
		ManiacHitCheck();	// check if a maniac is hit with the killers knife
	};
};

// actually go to the right
function GoRight () {
	if (!pause&&((game!=1&&pos<6)||pos<5)) {	// if not totally right
		if((game!=1)&&(!knives&&pos==1)) {	// if killer comes back from taking new knives on the left
			knives = 3;	// all the knives are available
			KnivesShow();	// show the knives that are available
			KnivesGetLeftRightHide();	// hide the knives reload left & right
		} else {	// if killer takes new knives on the right
			if ((game!=1)&&(!knives&&pos==5)) PlaySound("get_knives_wav", vlm);		// sound of getting new set of knives
		};
		posPrev = pos;		// remember current position
		pos++;	// go position to the right
		KillerShow();	// show killer @ current position
		ManiacHitCheck();	// check if a maniac is hit with the killers knife
	};
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
	if (game==1||game==2) {	// if game playing
		GoLeft();	// go position to the left
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmHour++;	// add an from hour alarm setting
			if (prefAlarmHour==24) prefAlarmHour = 0;	// addng an hour to 23 gets 0
			AlarmShowNum();	// show alarm time
		};
	};
};

// left button or -key pressed
function LeftPressed () {
	if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) { // if game still running or alarm being set
		Left();	// go left @ game or change alarm hour or minutes if alarm is being set
		keyPressed = true;
	};
};

// make an array
function MakeArray (size) {
	this.length = size;
	for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
	if (name) document.images[id].src = name;	// if picture given assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
	if (game==1||game==2) {	// if game playing
		GoRight ();	// go position to the right
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmMin++;	// add a minute to alarm time
			if (prefAlarmMin==60) prefAlarmMin=0;	// adding a minute to 59 gets 0
			AlarmShowNum();	// show alarm time
		};
	};
};

// right button or -key pressed
function RightPressed () {
	if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) {  // if game still running or alarm being set
		Right();	// go right @ game or change alarm hour or minutes if alarm is being set
		keyPressed = true;
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
	alarmStateIndPre = new Image();
	alarmStateIndPre.src = "img/screen/alarmStateInd.png";	// to show if alarm is set on or off
	bellDownPre = new Image();
	bellDownPre.src = "img/screen/bellDown.png";	// to show ringing bell in down-state @ alarm
	bellPre = new Image();
	bellPre.src = "img/screen/bell.png";	// to show bell man @ alarm
	bellUpPre = new Image();
	bellUpPre.src = "img/screen/bellUp.png";	// to show ringing bell in up-state @ alarm
	maniacPre = new Array();
	for (i=1 ; i<19 ; i++) { 	// to show the 18 maniac locations
		maniacPre[i] = new Image();
		maniacPre[i].src = "img/screen/evil_"+eval(i)+".png";
	};
	killerPre = new Array();
	for (i=1 ; i<7 ; i++) { 	// to show the 6 killer locations
		killerPre[i] = new Image();
		killerPre[i].src = "img/screen/killer_"+eval(i)+".png";
	};
	killerDeadPre = new Array();
	for (i=1 ; i<7 ; i++) { 	// to show the 6 deheaded killer locations
		killerDeadPre[i] = new Image();
		killerDeadPre[i].src = "img/screen/killerDead_"+eval(i)+".png";
	};
	killerKnifePre = new Array();
	for (i=2 ; i<6 ; i++) { 	// to show the 4 killer with knife locations
		killerKnifePre[i] = new Image();
		killerKnifePre[i].src = "img/screen/killer_"+eval(i)+"_knife.png";
	};
	knifePre = new Array();
	for (i=1 ; i<4 ; i++) { 	// to show the available knives left to use
		knifePre[i] = new Image();
		knifePre[i].src = "img/screen/knife.png";
	};
	knifeGetLeftPre = new Array();
	for (i=1 ; i<4 ; i++) { 	// to show the 3 left knives to grab locations
		knifeGetLeftPre[i] = new Image();
		knifeGetLeftPre[i].src = "img/screen/knifeGetLeft_"+eval(i)+".png";
	};
	knifeGetRightPre = new Array();
	for (i=1 ; i<4 ; i++) { 	// to show the 3 right knives to grab locations
		knifeGetRightPre[i] = new Image();
		knifeGetRightPre[i].src = "img/screen/knifeGetRight_"+eval(i)+".png";
	};
	nullPre = new Image();
	nullPre.src = "img/null.gif";	// empty picture to hide any figure
	numPre = new Array();
	for (i=1 ; i<11 ; i++) { 	// to show the 10 digital numbers
		numPre[i] = new Image();
		numPre[i].src = "img/screen/num"+eval(i-1)+".png";
	};
	numColonPre = new Image();
	numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
	soundOnPre = new Image();
	soundOnPre.src = "img/case/buttons/butOn.png";	// to show sound button in on-state
	soundOffPre = new Image();
	soundOffPre.src = "img/case/buttons/butOff.png";	// to show sound button in off-state
};

// erase all figures
function AllPicturesClear () {
	AlarmShow();	  // show if alarm is set on or not
	PicShow("Bell", nullPre.src);	// hide the bell man @ alarm
	PicShow("BellDown", nullPre.src);	// hide ringing bell in down-state @ alarm 
	PicShow("BellUp", nullPre.src); // hide ringing bell in up-state @ alarm
	for (i=1 ; i<19 ; i++) PicShow("Maniac"+eval(i)+"", nullPre.src); 	// hide the 18 resident evil locations
	KillerHide();	// hide all killers
	for (i=2 ; i<6 ; i++) PicShow("KillerKnife"+eval(i)+"", nullPre.src)	// hide the killers knife
	KnivesHide();	// hide all available knives
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src); // hide all score/time/alarm numbers
	KnivesGetLeftRightHide();	// hide the knives reload left & right
	PicShow("NumColon", nullPre.src);	// hide the time/alarm colon
	PicShow("NumLives", nullPre.src);	// hide the number of lives left
};

// show all figures
function AllPicturesShow () {
	MainFiguresShow(); 	// show all alarm, maniac & killer related figures
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
	PicShow("NumColon", numColonPre.src);	// ":"
	PicShow("NumLives", numPre[9].src);	   // "8" (lives left))
};

// show current screen status from bottom to top
function FiguresScreenShowCurrent () {
	if (blinkID) {
		clearTimeout(blinkID);  // stop blink timer 1
		blinkID = null;	// reset blink ID 1
	};
	if (blinkerID) {
		clearTimeout(blinkerID);  // stop blink timer 2
		blinkerID = null;		// reset blink ID 2
	};
	AllPicturesClear();	// erase all figures
	killerKilled = 0;	// killer not killed
	if (knives<1) KnivesGetLeftRightShow();	// show the knives reload left & right
	KillerShow();	// show killer @ current position
	KnivesShow();	// show the available knives
	ManiacsShow();	// show current descending maniacs
;	TimeShow();	// show current time
};

// hide all killers
function KillerHide () {
	for (i=1 ; i<7 ; i++) {	// all 6 killer positions
		PicShow("Killer"+eval(i)+"", nullPre.src); 	// hide the killer
	};
	for (i=2 ; i<6 ; i++) {	// all 4 possible knife positions
		PicShow("KillerKnife"+eval(i)+"", nullPre.src); 	// hide the killers knife
	};
};

// show killer @ current position
function KillerShow (p) {
	KillerHide();	// hide all killers
	if (!p) {	// if no position given
		p = pos;	// take current position
	};
	if (killerKilled) {	// if killer got killed
		PicShow("Killer"+eval(p)+"", killerDeadPre[p].src); 	// show the headless unarmed killer
	} else { 
		PicShow("Killer"+eval(p)+"", killerPre[p].src); 	// show the unarmed killer
	};
	if (knives>0 && p>1 && p<6) PicShow("KillerKnife"+eval(p)+"", killerKnifePre[p].src)	// if armed, show the killers knife
};

// hide the knives reload left & right 
function KnivesGetLeftRightHide () {
	for (i=1 ; i<4 ; i++) PicShow("KnifeGetLeft"+eval(i)+"", nullPre.src); 	// hide the left 3 knives stock
	for (i=1 ; i<4 ; i++) PicShow("KnifeGetRight"+eval(i)+"", nullPre.src); 	// hide the right 3 knives stock
};

// show the knives reload left & right
function KnivesGetLeftRightShow () {
	for (i=1 ; i<4 ; i++) PicShow("KnifeGetLeft"+eval(i)+"", knifeGetLeftPre[i].src); 	// show the left 3 knives stock
	for (i=1 ; i<4 ; i++) PicShow("KnifeGetRight"+eval(i)+"", knifeGetRightPre[i].src); 	// show the right 3 knives stock
};

// hide all available knives
function KnivesHide () {
	for (i=1 ; i<4 ; i++) PicShow("Knife"+eval(i)+"", nullPre.src); 	// hide all three available knives
};

// show the available knives
function KnivesShow () {
	KnivesHide();	// hide all available knives
	for (i=1 ; i<(knives+1) ; i++) PicShow("Knife"+eval(i)+"", knifePre[i].src); 	// show the knives still available
};

// show default pictures as @ start of the game
function MainPicturesGame (ind) {
	AllPicturesClear();	// erase all figures
	if (!demo) {	// if demo not running
		PicShow("Num4", numPre[1].src);	 // 0 score
		PicShow("NumColon", nullPre.src);	// hide the ":" figure
		PicShow("NumLives", numPre[4].src);	   // show indication there are 3 lives left
	};
	KillerShow();	// show killer @ current position
	if (ind!=1) {	// if not running game A 
		for (i=1 ; i<4 ; i++) PicShow("Knife"+eval(i)+"", knifePre[i].src); 	// show all three available knives
	};
};

// show all alarm, maniac & killer related figures
function MainFiguresShow () {
	PicShow("AlarmStateInd", alarmStateIndPre.src);	// show the alarm state indicator
	PicShow("Bell", bellPre.src);	// show bell man @ alarm
	PicShow("BellDown", bellDownPre.src);	// show ringing bell in down-state @ alarm
	PicShow("BellUp", bellUpPre.src);	// show ringing bell in up-state @ alarm
	for (i=1 ; i<19 ; i++) PicShow("Maniac"+eval(i)+"", maniacPre[i].src); 	// show the 18 maniacs
	for (i=1 ; i<7 ; i++)  {	// all 6 killer positions
		PicShow("Killer"+eval(i)+"", killerPre[i].src); 	// show the unarmed killer
	};
	for (i=2 ; i<6 ; i++)  {	// all 4 possible knife positions
		PicShow("KillerKnife"+eval(i)+"", killerKnifePre[i].src)	// show the killers knife
	};
	KnivesGetLeftRightShow();	// show the knives reload left & right
	KnivesShow();	// show the knives that are available
};

// show all figures & "12:00"
function MainPicturesShow () {
	MainFiguresShow(); 	// show all alarm, maniac & killer related figures
	PicShow("Num1", numPre[2].src);	 // 1
	PicShow("Num2", numPre[3].src);	 // 2
	PicShow("Num3", numPre[1].src);	 // 0
	PicShow("Num4", numPre[1].src);	 // 0
	PicShow("NumColon", numColonPre.src);	// ":"
	PicShow("NumLives", numPre[1].src);	   // "0" (lives left)
};

// show current descending maniacs
function ManiacsShow () {
	for (i=16 ; i>0 ; i--) {	// all descending maniacs position
		if (maniac[i]) {		// if maniac present @ this position
				PicShow("Maniac"+eval(i)+"", maniacPre[i].src); 	// show the maniac @ this position
		};
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
	GameReset();	// clear gameID's
	pause = true;
	TimerReset(); // stop the counter to show the current time
};

// ignore and clear all other keys that are pressed
function ClearPressedKeys () {
	AKeyPressed = false;
	BKeyPressed = false;
	keyPressed = false;
	TKeyPressed = false;
};	
// clear gameID's
function GameReset () {
	if (blinkID) { // if  blinking triggered
		clearTimeout(blinkID);  // stop blink timer 1
		blinkID = null;	// reset blink ID 1
	};
	if (blinkerID) { // if  blinking assistent triggered
		clearTimeout(blinkerID);  // stop blink timer 2
		blinkerID = null;	// reset blink ID 2
	};
	if (demoID) {     // if demo was planned or running
		window.clearTimeout(demoID);	// stop demo sequence from starting (again)
		demoID = null;	// reset demo ID
	};
	if (gameID) {     // if game was planned or running
		clearTimeout(gameID);	// stop the game
		gameID = null;	// reset game ID
	};
};

// clear all pictures & variables
function ResetAll () {
	AllStop();  // stop game if playing and reset all ID's
	alarmSetting = false;	   // stop rsetting alarm
	game = 9;   // 9-idle;
	gameOver = 0;	// no game is over
	gameSpeed = 500;	// speed for game sequence timer
	life = 0;	// no lives left
	pause = false;
	AllPicturesClear ();	// erase all figures
};

// stop showing current time
function TimerReset () {
	if (timeID) {	// if time running
		clearTimeout(timeID);	// stop time timer
		timeID = null;	// reset time ID
	};
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
	PlaySound("click_wav", vlm);	// click sound for pushing the reset button
	demo = false;
	game = 0;   // 0-no-game-acl-pictures;
	if (alarm) TimeAlarmOff();	// stop alarm if running
	AlarmReset();	// reset all alarm settings
	ResetAll(); // clear all pictures & variables
	if (acl) AllPicturesShow()	// show all figures & "88:88" if "acl" clicked twice fast
	else MainPicturesShow(); // show all figures & "12:00"
	acl = true; // indicates "acl" already clicked
	if (alarmID) {     // if alarm was planned or running
		clearTimeout(alarmID); // stop the alarm timer
		alarmID = null;	// reset alarm ID
	};
	aclID = window.setTimeout("acl = false;", 130);	 // show all pictures if "acl" clicked twice in 130 milliseconds
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// calculate next positioned figures to calculatePos (mostly sequence)
function CalculatePos (calculatePos) {
	var dir	= Math.floor(2*Math.random());	// move left or right down to next position
	switch (calculatePos) {
		case 1 :
			if (dir) calculatePos = 4	// move left-down
			else calculatePos = 5;		// move right down
			break;
		case 2 :
			if (dir) calculatePos = 5	// move left-down
			else calculatePos = 6;		// move right down
			break;
		case 3 :
			if (dir) calculatePos = 6	// move left-down
			else calculatePos = 7;		// move right down
			break;
		case 4 :
			if (dir) calculatePos = 8	// move left-down
			else calculatePos = 9;		// move right down
			break;
		case 5 :
			if (dir) calculatePos = 9	// move left-down
			else calculatePos = 10;		// move right down
		   break;
		case 6 :
			if (dir) calculatePos = 10	// move left-down
			else calculatePos = 11;		// move right down
			break;
		case 7 :
			if (dir) calculatePos = 11	// move left-down
			else calculatePos = 12;		// move right down
			break;
		case 8 :
			calculatePos =  13;			// move down
			break;
		case 9 :
			if (dir) calculatePos = 13	// move left-down
			else calculatePos = 14;		// move right down
			break;
		case 10 :
			if (dir) calculatePos = 14	// move left-down
			else calculatePos = 15;		// move right down
			break;
		case 11 :
			if (dir) calculatePos = 15	// move left-down
			else calculatePos = 16;		// move right down
			break;
		case 12 :
			calculatePos =  16;			// move down
			break;
		case 13 :
			calculatePos =  17;			// move down and game over and dehead killer
			break;
		case 14 :
			calculatePos =  17;			// move down and game over and dehead killer
			break;
		case 15 :
			calculatePos =  18;			// move down and game over and dehead killer
			break;
		case 16 :
			calculatePos =  18;			// move down and game over and dehead killer
			break;
		default:
	};
	return calculatePos;	// anounce next calculated position
};

// show demo
function Demo () {
	if (demoID) {	// if demo still planned to start stop that plan to avoid double run
		clearTimeout(demoID);
		demoID = null;
	};
	AllPicturesClear();	// erase all figures
	GameSet();	 // default game settings and figures
	killerMoveDemo = "r";	// default killer direction move to the right
	ManiacsClear();	// clear all downcomming maniacs
	ManiacSet(); // set random maniac on top row
	KillerShow();	// show killer @ current position
	TimeShow();	// show current time
	demoID = window.setTimeout("DemoRun()", 1000);	// next step after a second  
};

// next demo step
function DemoRun () {
	if (!pause) {
		if (killerMoveDemo=="l") {		// if killer direction move is left
			if ((pos>1&&!knives)||pos>2) GoLeft()	// if not @ left or @ left and need new knives, go left
			else {
				GoRight();		// go right instead
				killerMoveDemo="r";	// killer direction move is right now
			};
		} else {
			if ((pos<6&&!knives)||pos<5) GoRight()	// if not @ right or @ right and need new knives, go right
			else {
				GoLeft();	// go left instead
				killerMoveDemo="l";		// killer direction move is left now
			};
		};
	} else {
		KillerShow();	// show killer @ current position
		pause = false;
	};
	if (!ManiacsPresent()) {	// if  there are no maniacs present
		ManiacSet() // set random maniac on top row
	} else {
		ManiacsMove();	// move all present maniacs one row lower
	};
	demoID = window.setTimeout("DemoRun()", 1000);	// next step after a second  
};

// next move of game
function GameGo () {
	var maniacsPresent = ManiacsPresent();	// count all present maniacs
	if (gameID) {
		clearTimeout(gameID);	// stop the game's possible double call
		gameID = null;
	};
	if (!pause) {
		PlaySound("evil_move_wav", vlm);	// sound of maniac moving
		if (!ManiacsPresent()) {	// if  there are maniacs present
			ManiacSet(); // set random maniac on top row
		} else {
			ManiacsMove();	// move all present maniacs one row lower
			if (maniacsPresent<2&&ManiacsLastLine>3&&score>9) {	// if no or 1 maniacs descending after a score of 10 points descending
				ManiacSet(); // set random maniac on top row
			}
		};
		gameID = window.setTimeout("GameGo()", gameSpeed);	// next step in gameSpeed milliseconds
	}; 
};

// resume game after pause for killer getting killed
function GameGoNext () {
	if (game==1||game==2) {	 // if game a or b running
		if (gameID) {
			clearTimeout(gameID);	// reset ID for next step to prevent double call
			gameID = null;
		};
		if (life>0) {   // if at least one life left
			pause = false;	  // undo pause
			KillerShow();	// show killer @ current position
			GameGo();	// next move of game
		} else MainGameOver();	// game over, and start demo after a minute  
	};
};

// default game settings and figures
function GameSet (ind) {
	ResetAll();		// clear all pictures & variables
	ManiacsClear();	// clear all downcomming maniacs
	ManiacThruClear();	// clear the maniac that got thru
	killerKilled = 0;	// killer not killed
	knives = 3;	// all the knives are available
	life = 3;	// number of lives left
	pos = 1;	// player starts @ 1st position
	posPrev = 1;	// player previous position @ 1st position
	score = 0;  // reset score
	MainPicturesGame(ind);	// show default pictures @ start of the game & show score
};

// let killer blink if killed
function KillerBlink () {	
	if (gameID) {
		clearTimeout(gameID);	// stop the game timer
		gameID = null;	// reset game ID
	};
	if (blinkID) {
		window.clearTimeout(blinkID);  // stop previous blink timer 1
		blinkID = null;	// reset blink ID 1
	};
	if (blinkerID) {
		clearTimeout(blinkerID);  // stop previous blink timer 2
		blinkerID = null;	// reset blink ID 2
	};
	blinkSpeed = gameSpeed/4;		// set blinking speed according to current game speed
		if (blinker<10) {	// number of blinking the killer
			KillerHide();	// hide all killers
			blinkerID = window.setTimeout('KillerShow();', blinkSpeed/2); // show delayed killer @ current position
			blinkID = window.setTimeout('KillerBlink()', blinkSpeed);	// next blink of killer @ current position
		} else {
			if (life) {		// if lives left
				KillerHide();// hide all killers
				killerKilled = 0;	// killer not killed
			} else {
				KillerShow();	// show killer @ last position
			};
			if (!demo) {		// if demo not running
				ManiacsClear();	// clear all downcomming maniacs
				if (life>0) ManiacThruHide();	// hide the maniac that got thru if lives left
				KillerShow();	// show killer @ current position
				gameID = window.setTimeout("pause = false; GameGoNext();", gameSpeed);	// start running game again in gameSpeed milliseconds
			};
		};
	blinker++;	  // count blinking
};

// button pressed to play game A
function MainGameA () {
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (game!=1&&game!=2) {   // if not already game A or B playing
		demo = false;		// once this key is hit, the demo is turned off
		GameSet(1); // default game A settings and figures
		gameSpeed = 900;	   // in milliseconds
		gameSpeedMax = 120;	// maximum speed for game sequence 
		if (demoID) {
			clearTimeout(demoID);   // prevent demo from restarting if planned
			demoID = null;
		};
		HighScoreShow(1);		// show highest score since this browser tab was opened
	};
};

// "game A" button released so actually play game A
function MainGameAGo () {
	if (game!=1&&game!=2) {   // if not already game A or B playing
		if (gameID) {
			clearTimeout(gameID);	// stop the game's possible double call
			gameID = null;
		};
		game = 1; // game A
		pause = false;
		ScoreShow(score);		// show current score
		gameID = window.setTimeout("GameGo()", gameSpeed);	// start running game in gameSpeed milliseconds
	};
};

// button pressed to play game B
function MainGameB () {
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (game!=1&&game!=2) {   // if not already game A or B playing
		demo = false;		// once this key is hit, the demo is turned off
		GameSet(2); // default game B settings and figures
		gameSpeed = 900;	   // in milliseconds
		gameSpeedMax = 120;	// maximum speed for game sequence
		if (demoID) {
			clearTimeout(demoID);   // prevent demo from restarting if planned
			demoID = null;
		};
		HighScoreShow(2);		// show highest score since this browser tab was opened
	};
};

// "game B" button released so actually play game B
function MainGameBGo () {
	if (game!=1&&game!=2) {   // if not already game A or B playing
		if (gameID) {
			clearTimeout(gameID);	// stop the game's possible double call
			gameID = null;
		};
		game = 2; // game B
		pause = false;
		ScoreShow(score);		// show current score
		gameID = window.setTimeout("GameGo()", gameSpeed);	// start running game in gameSpeed milliseconds
	};
};

// stop game if running + start demo after a minute  
function MainGameOver () {
	console.log("-----	%c G A M E	 O V E R %c	-----","background-color:red; color:yellow; font-weight:bold;","background-color:tr; color:black; font-weight:bold;");
	gameOver = 1;	
	if (demoID) {
		clearTimeout(demoID);	// stop the game
		demoID = null;
	};
	AllStop();  // stop game if playing and reset all ID's
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	game = 9;   // 9-idle;
};

// let maniac blink @ killed position
function ManiacBlink (maniacBlinkPos) {	
	if (blinkID) {
		window.clearTimeout(blinkID);  // stop blink timer 1
		blinkID = null;	// reset blink ID 1
	};
	if (blinkerID) {
		clearTimeout(blinkerID);  // stop previous blink timer 2
		blinkerID = null;	// reset blink ID 2
	};
	blinkSpeed = gameSpeed/4;
	if (blinker<2) {	// number of blinking the misses
		PicShow("Maniac"+eval(maniacBlinkPos)+"", nullPre.src);	// hide killed Maniac			
		blinkerID = window.setTimeout('PicShow("Maniac"+eval('+maniacBlinkPos+')+"", maniacPre['+maniacBlinkPos+'].src);', blinkSpeed/2);	// reshow killed Maniac delayed
		blinkID = window.setTimeout("ManiacBlink("+maniacBlinkPos+");", blinkSpeed);	// repeat delayed
	} else {
		PicShow("Maniac"+eval(maniacBlinkPos)+"", nullPre.src);	// hide killed Maniac
	};
	blinker++;	  // count blinking
};

// check if position of bottom maniac is intercepted by killer or not
function ManiacHit () {
	if (pos<6&&pos>1&&(knives>0&&maniac[(pos+11)])) return (pos+11);		// if maniac opposes killer, return kill position
};

// check if a maniac is hit with the killers knife
function ManiacHitCheck () {
	var maniacPosHit = ManiacHit();	// check if position of bottom maniac is intercepted by killer or not
	if (maniacPosHit) {	// if position of bottom maniac is intercepted by killer
		blinker = 0;	// reset blinking counter
		if (!demo) {	// if demo not running
			ScoreAdd(1);	// one point gained
		};
		blinkID = window.setTimeout("PlaySound('evil_killed_wav', vlm); ManiacBlink("+maniacPosHit+");", (gameSpeed/4));	// let maniac blink @ killed position
		maniac[maniacPosHit] = 0;	// remove killed maniac
		if (game!=1) {		// if not game A running
			knives--;	// one less knive available to use
			KnivesShow();	// show the knives that are still available
		};
		if (knives<1) KnivesGetLeftRightShow();	// if no available knives left, show the knives reload left & right
		KillerShow();	// show killer @ current position
	} else {
		if (ManiacThru()) {	// f a maniac got thru
			killerKilled = 1;	// killer is killed
			blinker = 0;	// reset blinking counter
			if (!demo) {	// if demo not running
				if (life>0) life--;	// one life lost
				PicShow("NumLives", numPre[(life+1)].src);	   // show # lives left
			};
			if (life) PlaySound("killer_killed_wav", vlm)	// if lives left, play sound of killer getting killed
			else PlaySound("killer_killed_all_wav", vlm);	// sound of last killer getting killed
			KillerBlink();		// let killed killer blink
			pause = true;
		};
	};
};

// clear all descending maniacs
function ManiacsClear () {
	for (i=1 ; i<17 ; i++) { 	// the 16 descending maniac locations
		maniac[i] = 0;		// erase maniac @ that location
		PicShow("Maniac"+eval(i)+"", nullPre.src); 	// hide the maniac @ that location
	};
};

// set random maniac on top row
function ManiacSet () {
	var maniacPos = Math.floor(3*Math.random()+1);	// randomise position maniac between 1 and 3 maximum
	maniac[maniacPos] = 1;		// put maniac @ calculated position
	PicShow("Maniac"+eval(maniacPos)+"", maniacPre[maniacPos].src); 	// show the maniac @ calculated position
};

// hide all maniacs
function ManiacsHide () {
	for (i=1 ; i<19 ; i++) { 	// all 18 maniac locations
		PicShow("Maniac"+eval(i)+"", nullPre.src); 	// hide the maniac @ this position
	};
};

// move all present maniacs one row lower
function ManiacsMove () {
	var maniacPos;	// maniacs move right or left down
	ManiacsHide(); // hide all maniacs
	for (i=18 ; i>0 ; i--) {		// all maniacs
		if (maniac[i]) {		// if maniac present @ this location
			maniac[i] = 0;	// erase maniac @ this location
			if (i<17) {		// if maniac is descending one
				maniacPos = CalculatePos(i);	// randomise position move maniac right or left down
				maniac[maniacPos] = 1;	// put the maniac @ next position
				PicShow("Maniac"+eval(maniacPos)+"", maniacPre[maniacPos].src); 	// show the maniac @ next position
				ManiacHitCheck();	// check if a maniac is hit with the killers knife
			};
		};
	};
};

// count all present maniacs
function ManiacsPresent () {
	var maniacsPresent = 0;	// no maniacs counted yet
	ManiacsLastLine = 0;	// lowest maniac present to determine if second maniac may descend simultaniously
	for (i=18 ; i>0 ; i--) {
		if (maniac[i]) {		// if maniac present @ this location
			maniacsPresent++;	// count maniac
			ManiacsLastLine = ManiacsLastLine?ManiacsLastLine:i;		// lowest maniac present if none recorded before
		};
	};
	return maniacsPresent;
};

// check if a maniac got thru
function ManiacThru () {
	return (maniac[17]||maniac[18]);	// if a maniac present @ position 17 or 18, he got thru
};

// clear the maniac that got thru
function ManiacThruClear () {
	maniac[17] = 0;	// erase maniac @ location 17
	maniac[18] = 0;	// erase maniac @ location 18
};

// hide the maniac that got thru
function ManiacThruHide () {
	PicShow("Maniac17", nullPre.src);	// hide maniac @ location 17
	PicShow("Maniac18", nullPre.src);	// hide maniac @ location 18
};

// show leading zeroes
function n(n){
	return n>9?""+n:"0"+n;
};

// speeds up the game with given value
function SpeedUp (speed) {
	if (gameSpeed>gameSpeedMax) gameSpeed -= speed; // if not @ max speed, speed up
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

