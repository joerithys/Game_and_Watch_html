/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow (i) {
	ScoreShow(highScore[i]);
};

// add certain points to score
function ScoreAdd (points) {
	for (var a=0 ; a<points ; a++) {
		score++;
	};
	if (score>highScore[game]) highScore[game] = score;	   // if passed highscore @ of this game, set new highscore
	switch(true) {	// set gamespeed according to score
		case (score>200):
			gameSpeed=(score%10)?gameSpeed:(gameSpeed-1)>gameSpeedMax?(gameSpeed-1):gameSpeedMax;
			break;
		case (score>160):
			gameSpeed=(score%8)?gameSpeed:(gameSpeed-1)>gameSpeedMax?(gameSpeed-1):gameSpeedMax;
			break;
		case (score>130):
			gameSpeed=(score%6)?gameSpeed:(gameSpeed-1)>gameSpeedMax?(gameSpeed-1):gameSpeedMax;
			break;
		case (score>110):
			gameSpeed=(score%4)?gameSpeed:(gameSpeed-1)>gameSpeedMax?(gameSpeed-1):gameSpeedMax;
			break;
		case (score>100):
			gameSpeed=(score%2)?gameSpeed:(gameSpeed-1)>gameSpeedMax?(gameSpeed-1):gameSpeedMax;
			break;
		case (score>90):
			gameSpeed-=1;
			break;
		case (score>75):
			gameSpeed-=2;
			break;
		case (score>30):
			gameSpeed-=3;
			break;
		case (score>20):
			gameSpeed-=5;
			break;
		case (score>15):
			gameSpeed-=7;
			break;
		case (score>8):
			gameSpeed-=10;
			break;
		case (score>6):
			gameSpeed-=13;
			break;
		case (score>4):
			gameSpeed-=16;
			break;
		case (score>2):
			gameSpeed-=20;
			break;
		default:
			gameSpeed-=30;
	};
	ScoreShow(score);
};

// hide score from screen
function ScoreHide () {
	$("#Num1").addClass("hidden");
	$("#Num2").addClass("hidden");
	$("#Num3").addClass("hidden");
	$("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
	$("#Num1").removeClass("hidden");
	$("#Num2").removeClass("hidden");
	$("#Num3").removeClass("hidden");
	$("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
	if (scoreTS>999) 	// first digit
		if (Math.floor((scoreTS/1000)%10)==0) PicShow("Num1", nullPre.src)
		else PicShow("Num1", numPre[Math.floor((scoreTS/1000)%10)+1].src);
	else PicShow("Num1", nullPre.src);
	if (scoreTS>99) 	// secons digit
		if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0) PicShow("Num2", nullPre.src)
		else PicShow("Num2", numPre[Math.floor(scoreTS%1000/100)+1].src);
	else PicShow("Num2", nullPre.src);
	if (scoreTS>9)  	// third digit
		if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0  && Math.floor(scoreTS%100/10)==0) PicShow("Num3", nullPre.src)
		else PicShow("Num3", numPre[Math.floor(scoreTS%100/10)+1].src);
	else PicShow("Num3", nullPre.src);
	PicShow("Num4", numPre[(scoreTS%10)+1].src);	// fourth digit
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
