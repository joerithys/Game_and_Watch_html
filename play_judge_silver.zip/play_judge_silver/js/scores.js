/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// check & show highest score on screen
function HighScoreShow (game) {
	pause = true;
	PicShow("Num1", nullPre.src);
	PicShow("Num2", nullPre.src);
	if (highScore[game]<10) PicShow("Num3", nullPre.src)
	else PicShow("Num3", numPre[Math.floor(highScore[game]%100/10)+1].src);
	PicShow("Num4", numPre[(highScore[game]%10)+1].src);
};

// add certain points to score
function ScoreAdd (man, points) {
	var score = man=="left"?scoreLeft:scoreRight	// take winner's current score
	var highScorePrev = highScore[game];	// previous highest score of this game
	var highScoreNew;	// potential highest score
	if (points) {	// if point(s) are to be added
		for (var a=0 ; a<points ; a++) {
			if (score<99) man=="left"?scoreLeft++:scoreRight++;	// if winning man didn't reache 99 points yet, add one to it
			score++;
		};
		ScoreShow();
	    if (scoreLeft>98||scoreRight>98) {	// if a man reached 99 points (or higher)
			score = 99;	// in case function added to much to score
			highScoreNew = scoreLeft<scoreRight?scoreLeft:scoreRight;	// potential highest score = loser's score
		    if (game!=1||scoreLeft<scoreRight)	// if computer didn't win
				highScore[game] = (((highScorePrev<highScoreNew))?highScorePrev:highScoreNew);	// set new if current score lower than recorded
			MainGameOver();
		};
	};
};

// hide score
function ScoreHide () {
	for (var i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// translate score to the digits on screen
function ScoreShow () {
	if ((game==1||game==2)&&scoreLeft<10) PicShow("Num1", nullPre.src)
	else PicShow("Num1", numPre[Math.floor(scoreLeft%100/10)+1].src);
	PicShow("Num2", numPre[(scoreLeft%10)+1].src);
	if ((game==1||game==2)&&scoreRight<10) PicShow("Num3", nullPre.src)
	else PicShow("Num3", numPre[Math.floor(scoreRight%100/10)+1].src);
	PicShow("Num4", numPre[(scoreRight%10)+1].src);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
