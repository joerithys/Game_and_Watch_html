//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
    // if blinking still running, kill it
    PlaySound("click_", vlm);	// click sound for push button
    if (game!=4||!demo) {      
		ResetAll();	// clear all pictures & variables
		StopAllSound();
        MainTimeStart(); // show current time & demo
    };
};
	
// show current time & demo
function MainTimeStart () {
    demo = true;     // to show demo
    sequence = 0;    // start sequence
    MainPicturesShow();	// show default start pictures of  the men
    $("#Hour_txt").removeClass("hidden");		
    $("#Minute_txt").removeClass("hidden");		
    TimerShow(0);	// hide all remaining timer blocks
    game = 4;	// clock running
    Demo();	// show current time
};

// sequential judge movements for demo time clock
function ShowTime (seq) {
    switch (seq) {
        case 1 : 
			ManRightHitting();
            break;
        case 2 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        case 3 : 
			ManLeftDodging();
			manLeftDodge = true;
			ManRightHitting();
            break;
        case 4 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        case 5 : 
			ManLeftHitting();
            break;
        case 6 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        case 7 : 
			ManRightDodging();
			manRightDodge = true;
			ManLeftHitting();
            break;
        case 8 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        case 9 : 
			ManRightHitting();
			ManLeftHitting();
            break;
        case 10 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        case 11 : 
			ManLeftDodging();
			ManRightDodging();
            break;
        case 12 : 
			ManLeftReady ();
			ManRightReady ();
            break;
        default :
    };
};

// show current time
function Demo () {
    Time();	// get current time
    TimeShowOnScreen();
    ShowTime(sequence); // sequential judge movements for demo time clock
    if (sequence<12) sequence++
    else sequence = 1;
    demoID = window.setTimeout("Demo()", 1000);     // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen () {
    // set integer to time digits
    if (hour<10) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
    PicShow("Num2", numPre[(hour%10)+1].src);
    PicShow("Num3", numPre[Math.floor(min/10)+1].src);
    PicShow("Num4", numPre[(min%10)+1].src);
};

// get current time
function Time () {
    today = new Date();
    hour = today.getHours();
    min = today.getMinutes();
    sec = today.getSeconds();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions
