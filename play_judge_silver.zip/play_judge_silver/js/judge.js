//Product:			Judge HTML - Silver Screen (Nintendo) Simulator
//Version:			1.1
//Started:			08.09.2022
//Last update:		01.03.2023
//Author:			Flyzy (Joeri Thys a.k.a. the Mandajoerilan)
//Programmer	    Flyzy (Joeri Thys)
//Original G&W:		Nintendo Co. Ltd

//Credits:
//Design, layout and artwork by Lee Robson (hydef)
//Based on scans by Sean Riddle
//Colour background by DarthMarino

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling

var acl = false;	// for showing acl full if pressed twice fast
var aclID;	// ID to reset acl variable
var color = false;	// indicator to show/hide colored background
var computerID;		// for timing computer move
var firstManMove;	// which man moved first
var game = 0;   // 0-no-game-all-pictures; 1-gameA; 2-gameB; 3-game-over; 4-clock; 
var gameCaseColor = "p";	// color of the case "g" for japanese green version "p" for english purple version
var gameID;	// ID for timeout game sequence
var gameOverSeq = 0;
var gameSpeed;	// speed for game sequence timer
var hitID;	// ID for hit delay untill end of previous sound
var judge = false;	// false : not judged yet , "l" : left highest number , "r" : right highest number , "e" : equal numbers
var loser = "none";	// no loosing man yet
var manBlinking = 0;	// number of times the looser will blink
var manLeftDodge = false;	// man on the left didn't dodg yet
var manRightDodge = false;	// man on the right didn't dodge yet
var manLeftDone = false;	// man on the left didn't make move yet
var manRightDone = false;	// man on the right didn't make move yet
var manLeftHit = false;	// man on the left didn't hit yet
var manLeftHitDelay = false;	// man on the left didn't hit yet after right man wrongly hit
var manRightHit = false;	// man on the right didn't hit yet
var manRightHitDelay = false;	// man on the right didn't hit yet after left man wrongly hit
var manNumLeft;	// number the left man presents
var manNumRight;	// number the right man presents
var manMoveTimeLeft = 0;	// couple of seconds time to make move each run
var manMoveTimeLeftID;	// ID for opponent to make a valid hit after faulty hit
var manMoveTimeLeftCountID	// ID for count down manMoveTimeLeft
var manLeftMoveID;	// ID for the left man's movements
var manRightMoveID;	// ID for the right man's movements
var noPlay = 5;	// counts down as long as no reaction is registered
var otherManMovedBefore = 0;	// to indicate the other player/computer already made a move
var timerLegs = "down";	// animation position legs awaiting timer 
var zoomed = 1;		// default screen auto adapted to window size

var keyPressed = false;	// indicates if a previuos key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var highScore = new Array();	// for highest scores for games a & b
var scoreLeft = 0;	// score left man at start
var scoreRight = 0;	// score right man at start
var sequence = 1;	// for demo timer

var timeID;     // ID timer blocks counting down, game over timing and blinking of looser
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables


//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading names & game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    if (game==1 || game==2) noPlay = game==1?10:5;	// if game playing, register reaction o key stroke
	switch (e.key) {
        case "e": case "E":	// left up key
            // show left upper button pressed
            document.images['Left Up'].src = 'img/case/buttons/'+gameCaseColor+'/1_flat.png';	// show pressed button on screen
            LeftUpperKeyPressed();	//	make left mat hit
            break;
        case "d": case "D":	// left down key
            // show left lower button pressed
            document.images['Left Down'].src = 'img/case/buttons/'+gameCaseColor+'/3_flat.png';	// show pressed button on screen
            LeftLowerKeyPressed();	// make left man dodge
            break;
        case "o": case "O":	// right up key
            // show right upper button pressed
            document.images['Right Up'].src = 'img/case/buttons/'+gameCaseColor+'/2_flat.png';	// show pressed button on screen
			RightUpperKeyPressed();	// make right man hit
           break;
        case "k": case "K":	// right down key
            // show right lower button pressed
            document.images['Right Down'].src = 'img/case/buttons/'+gameCaseColor+'/4_flat.png';	// show pressed button on screen
            RightLowerKeyPressed();	// make right man dodge
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game A button pressed
            document.images['Game A'].src = 'img/case/buttons/'+gameCaseColor+'/grey_1_flat.png';	// show pressed button on screen
            if (!keyPressed) MainGameA(); // show high score and get ready to play Game A
            keyPressed = true;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" pressed
            // show game B button pressed
            document.images['Game B'].src = 'img/case/buttons/'+gameCaseColor+'/grey_2_flat.png';	// show pressed button on screen
            if (!keyPressed) MainGameB(); // show high score and get ready to play Game B
            keyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
			document.images['aclButton'].src = 'img/case/buttons/acl_push.png';	// show pressed button on screen
            TotalReset(); // show full sprites
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/'+gameCaseColor+'/grey_3_flat.png';	// show pressed button on screen
            MainTime(); // show time & demo
            break;
        //test case buttons
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            SetSoundVolume();
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;	// set/unset showing volume indicator on screen
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case String.fromCharCode(233): case "Control" :	// "Ctrl"-key
            if (e.shiftKey) {	// "shift" key also pressed for setting color of the game case 
				gameCaseColor = gameCaseColor=="p"?"g":"p";	// switch color of the game casing to green/purple
				CasePicsPreload();	// show the chosen gema case color on screen
			} else {	// "shift" key not pressed for setting background image of the game 
				color = !color;     // indicator to show/hide colored background
				InlayShow();	// switch background black/color				
			};
            break;
        case ")": case String.fromCharCode(219):	// ")"-key
            zoomed = zoomed?0:1;	// toggle auto zoom function on/off
			$(function () {
				CheckSizeZoom()	// calculate size and position for autozoom if set or get default if not set
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);	// autozoom to calculated size and position/default
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> %c '" + e.key + "'"+(otherManMovedBefore?(" %c manMoveTimeLeft = "+manMoveTimeLeft):" %c")+" ","background-color:green; color:gold; font-weight:bold;","background-color:white; color:black;");
}, false);

window.addEventListener("keyup", function (e) {
    // game And arrow keys
    switch (e.key) {
        case "e": case "E":	// left up key released
            // show left upper button default
            document.images['Left Up'].src = 'img/case/buttons/'+(gameCaseColor=="p"?"P":"G")+'/1.png';	// show unpressed button on screen
            break;
        case "f": case "F":	// left down key released
            // show left lower button default
            document.images['Left Down'].src = 'img/case/buttons/'+gameCaseColor+'/3.png';	// show unpressed button on screen
            break;
        case "o": case "O":	// right up key released
            // show right upper button default
            document.images['Right Up'].src = 'img/case/buttons/'+gameCaseColor+'/2.png';	// show unpressed button on screen
            break;
        case "k": case "K":	// right down key released
            // show right lower button default
            document.images['Right Down'].src = 'img/case/buttons/'+gameCaseColor+'/4.png';	// show unpressed button on screen
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/buttons/'+gameCaseColor+'/grey_1.png';     // show game A button default
            MainGameAGo(); // play Game A
            keyPressed = false;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" released
            document.images['Game B'].src = 'img/case/buttons/'+gameCaseColor+'/grey_2.png';     // show game B button default
            MainGameBGo(); // play Game A
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['aclButton'].src = 'img/case/buttons/acl.png';     // show acl button default
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/'+gameCaseColor+'/grey_3.png';	// show unpressed button on screen
            break;
        default:
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
    PlaySound("click_", vlm);	// click sound for waking up some browsers' sound play
	$(function () {	// autozoom @ start
		CheckSizeZoom()	// calculate size and position for autozoom
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);	// autozoom to calculated size
	$("#Judge").focus(); // set focus on the game
	PicPreload();	// this function preloads all images to make them ready for use
	highScore[1] = 99;	// lowest counterscore game A
	highScore[2] = 99;	// lowest counterscore game B
	console.log("@ $(document).ready() : highScore[A] = "+highScore[1]+"  :  highScore[B] = "+highScore[2]);
	MainPicturesShow(); // show all main figures, men, hammer up, legs & number arm down
	MainPicturesNums();	// show default starting time numbers
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
    console.log("\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39 --- %c "+today+" %c --- %c welcome to this Game & Watch simmulator, and have fun! ", 
				"background-color:red; color:white; font-weight:bold;",
				"background-color:none; color:black; font-weight:bold;",
				"background-color:lime; color:orangered; font-weight:bold;",
				" ---"); 	// color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	left upper key was pressed
function LeftUpperKeyPressed () {
	if (!demo&&judge&&!manLeftDone) {	// if demo not running and move possible
		if (game==2) ManLeftHitting()    // if time to react in game B for left man
		else ManRightHitting();    // if time to react in game A for right man
	};
};

// left lower key was pressed
function LeftLowerKeyPressed () {
	if (!demo&&judge&&!manLeftDone) {	// if demo not running and move possible
		if (game==2) ManLeftDodging()    // if time to react in game B for left man
		else ManRightDodging();    // if time to react in game A for right man
	};
};

// hide all left man figures
function ManLeftHide () {
    $("#ManLeft").addClass("hidden");
    $("#ManLeftHammerBack").addClass("hidden");
    $("#ManLeftHammerHit").addClass("hidden");
    $("#ManLeftNumArmDown").addClass("hidden");  
    $("#ManLeftNumArmUp").addClass("hidden");
    $("#ManLeftLeftLegUp").addClass("hidden");
    $("#ManLeftLeftLegDown").addClass("hidden");
    $("#ManLeftRightLegUp").addClass("hidden");
    $("#ManLeftRightLegDown").addClass("hidden");
    $("#ManLeftDodge").addClass("hidden");
    $("#Num1Big").addClass("hidden");
};


// unhide all left man figures
function ManLeftUnhide () {
    $("#ManLeft").removeClass("hidden");
    $("#ManLeftHammerBack").removeClass("hidden");
    $("#ManLeftHammerHit").removeClass("hidden");
    $("#ManLeftNumArmDown").removeClass("hidden");  
    $("#ManLeftNumArmUp").removeClass("hidden");
    $("#ManLeftLeftLegUp").removeClass("hidden");
    $("#ManLeftLeftLegDown").removeClass("hidden");
    $("#ManLeftRightLegUp").removeClass("hidden");
    $("#ManLeftRightLegDown").removeClass("hidden");
    $("#ManLeftDodge").removeClass("hidden");
    $("#Num1Big").removeClass("hidden");
};

// hide all man right figures
function ManRightHide () {
    $("#ManRight").addClass("hidden");
    $("#ManRightHammerBack").addClass("hidden");
    $("#ManRightHammerHit").addClass("hidden");
    $("#ManRightNumArmDown").addClass("hidden");
    $("#ManRightNumArmUp").addClass("hidden");
    $("#ManRightLeftLegUp").addClass("hidden");
    $("#ManRightLeftLegDown").addClass("hidden");
    $("#ManRightRightLegUp").addClass("hidden");
    $("#ManRightRightLegDown").addClass("hidden");
    $("#ManRightDodge").addClass("hidden");
    $("#Num2Big").addClass("hidden");
};

// unhide all man right figures
function ManRightUnhide () {
    $("#ManRight").removeClass("hidden");
    $("#ManRightHammerBack").removeClass("hidden");
    $("#ManRightHammerHit").removeClass("hidden");
    $("#ManRightNumArmDown").removeClass("hidden");
    $("#ManRightNumArmUp").removeClass("hidden");
    $("#ManRightLeftLegUp").removeClass("hidden");
    $("#ManRightLeftLegDown").removeClass("hidden");
    $("#ManRightRightLegUp").removeClass("hidden");
    $("#ManRightRightLegDown").removeClass("hidden");
    $("#ManRightDodge").removeClass("hidden");
    $("#Num2Big").removeClass("hidden");
};

//	right upper key was pressed
function RightUpperKeyPressed () {
	if (!demo&&judge&&!manRightDone) {	// if demo not running and move possible
		ManRightHitting();    // if time to react in game A or B for right man
	 };
};

//	right lower key was pressed
function RightLowerKeyPressed () {
	if (!demo&&judge&&!manRightDone) {	// if demo not running and move possible
		ManRightDodging();    // if time to react in game A or B for right man
	};
};

// show/hide figure "name" on screen @ place "id"
function PicShow (id, name) {
    if (name) document.images[id].src = name;
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions


//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// this function preloads all case images and show them according to color choice (purple or green)
function CasePicsPreload () {
    bkgnd = "./img/case/IP-05"+(gameCaseColor=="p"?"P":"G")+".png";	// set game case filename according to choice
    $("#game").css("background-image","url("+bkgnd+")");	// show chosen case on screen
	document.images['Left Up'].src = 'img/case/buttons/'+gameCaseColor+'/1.png';     // show left up button default
	document.images['Right Up'].src = 'img/case/buttons/'+gameCaseColor+'/2.png';     // show right up button default
	document.images['Left Down'].src = 'img/case/buttons/'+gameCaseColor+'/3.png';     // show left down button default
	document.images['Right Down'].src = 'img/case/buttons/'+gameCaseColor+'/4.png';     // show right down button default
	document.images['Game A'].src = 'img/case/buttons/'+gameCaseColor+'/grey_1.png';     // show game A button default
	document.images['Game B'].src = 'img/case/buttons/'+gameCaseColor+'/grey_2.png';     // show game B button default
	document.images['Time'].src = 'img/case/buttons/'+gameCaseColor+'/grey_3.png';     // show time button default
    soundOnPre.src = "img/case/buttons/"+gameCaseColor+"/butOn"+".png";	// to show sound button in on-state
    soundOffPre.src = "img/case/buttons/"+gameCaseColor+"/butOff"+".png";	// to show sound button in off-state
	PrefSoundSettings();	// show sound on/off indication according to settings
};

// this function preloads all images
function PicPreload () {
    inlayPre = new Image();
    inlayPre.src = "img/screen/inlay.png";	// to show background
    inlayColPre = new Image();
    inlayColPre.src = "img/screen/inlay_c.png";	// to show background surrounding in color
    manLeftPre = new Image();
    manLeftPre.src = "img/screen/man1.png";	// to show the left man's body
    manLeftHammerBackPre = new Image();
    manLeftHammerBackPre.src = "img/screen/man1_hammer_back.png";	// to show the left man's backwards arm and hammer
    manLeftHammerHitPre = new Image();
    manLeftHammerHitPre.src = "img/screen/man1_hammer_hit.png";	// to show the left man's hitting arm and hammer
    manLeftNumArmDownPre = new Image();
    manLeftNumArmDownPre.src = "img/screen/man1_num_arm_down.png";	// to show the left man's number arm down
    manLeftNumArmUpPre = new Image();
    manLeftNumArmUpPre.src = "img/screen/man1_num_arm_up.png";	// to show the left man's number arm and number up
    manLeftLeftLegUpPre = new Image();
    manLeftLeftLegUpPre.src = "img/screen/man1_left_leg_up.png";	// to show the left man's left leg up
    manLeftLeftLegDownPre = new Image();
    manLeftLeftLegDownPre.src = "img/screen/man1_left_leg_down.png";	// to show the left man's left leg down
    manLeftRightLegUpPre = new Image();
    manLeftRightLegUpPre.src = "img/screen/man1_right_leg_up.png";	// to show the left man's right leg up
    manLeftRightLegDownPre = new Image();
    manLeftRightLegDownPre.src = "img/screen/man1_right_leg_down.png";	// to show the left man's right leg down
    manLeftDodgePre = new Image();
    manLeftDodgePre.src = "img/screen/man1_dodge.png";	// to show left man dodging
    manRightPre = new Image();
    manRightPre.src = "img/screen/man2.png";	// to show the right man body
    manRightHammerBackPre = new Image();
    manRightHammerBackPre.src = "img/screen/man2_hammer_back.png";	// to show the right man's backwards arm and hammer
    manRightHammerHitPre = new Image();
    manRightHammerHitPre.src = "img/screen/man2_hammer_hit.png";	// to show the right man's hitting arm and hammer
    manRightNumArmDownPre = new Image();
    manRightNumArmDownPre.src = "img/screen/man2_num_arm_down.png";   // to show the right man's number arm down
    manRightNumArmUpPre = new Image();
    manRightNumArmUpPre.src = "img/screen/man2_num_arm_up.png";	// to show the right man's number arm and number up
    manRightLeftLegUpPre = new Image();
    manRightLeftLegUpPre.src = "img/screen/man2_Left_leg_up.png";	// to show the right man's left leg up
    manRightLeftLegDownPre = new Image();
    manRightLeftLegDownPre.src = "img/screen/man2_left_leg_down.png";	// to show the right man's left leg down
    manRightRightLegUpPre = new Image();
    manRightRightLegUpPre.src = "img/screen/man2_right_leg_up.png";	// to show the right man's right leg up
    manRightRightLegDownPre = new Image();
    manRightRightLegDownPre.src = "img/screen/man2_right_leg_down.png";	// to show the right man's right leg down
    manRightDodgePre = new Image();
    manRightDodgePre.src = "img/screen/man2_dodge.png";	// to show right man dodging
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numBigPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 judging numbers
        numBigPre[i] = new Image();
        numBigPre[i].src = "img/screen/num"+eval(i-1)+"_big.png";
    };
    soundOnPre = new Image();	// for CasePicsPreload()
    soundOffPre = new Image();	// for CasePicsPreload()
    timerBlockPre = new Image();
    timerBlockPre.src = "img/screen/timer_block.png";	// to show the timer blocks
    CasePicsPreload();	// this function preloads all case images to make them ready for use
};

// hide all figures
function AllPicturesClear () {
    PicShow("ManLeft", nullPre.src);
    PicShow("ManRight", nullPre.src);
    PicShow("ManLeftHammerBack", nullPre.src);
    PicShow("ManLeftHammerHit", nullPre.src);
    PicShow("ManLeftNumArmDown", nullPre.src);  
    PicShow("ManLeftNumArmUp", nullPre.src);
    PicShow("ManLeftLeftLegUp", nullPre.src);
    PicShow("ManLeftLeftLegDown", nullPre.src);
    PicShow("ManLeftRightLegUp", nullPre.src);
    PicShow("ManLeftRightLegDown", nullPre.src);
    PicShow("ManLeftDodge", nullPre.src);
    PicShow("ManRightHammerBack", nullPre.src);
    PicShow("ManRightHammerHit", nullPre.src);
    PicShow("ManRightNumArmDown", nullPre.src);
    PicShow("ManRightNumArmUp", nullPre.src);
    PicShow("ManRightLeftLegUp", nullPre.src);
    PicShow("ManRightLeftLegDown", nullPre.src);
    PicShow("ManRightRightLegUp", nullPre.src);
    PicShow("ManRightRightLegDown", nullPre.src);
    PicShow("ManRightDodge", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
    for (i=1 ; i<3 ; i++) PicShow("Num"+eval(i)+"Big", nullPre.src);
    TimerShow(0);	// show 0 pieces of timer blocks
};

// show all figures
function AllPicturesShow () {
    PrefSoundSettings();	// show sound on/off indication according to settings
    MainPicturesShow();	// show all main figures, men, hammer up, legs & number arm down
	// show all other arms, legs and dodging men
    PicShow("ManLeftHammerHit", manLeftHammerHitPre.src);
    PicShow("ManLeftNumArmUp", manLeftNumArmUpPre.src);
    PicShow("ManLeftLeftLegUp", manLeftLeftLegUpPre.src);
    PicShow("ManLeftRightLegUp", manLeftRightLegUpPre.src);
    PicShow("ManLeftDodge", manLeftDodgePre.src);
    PicShow("ManRightHammerHit", manRightHammerHitPre.src);
    PicShow("ManRightNumArmUp", manRightNumArmUpPre.src);
    PicShow("ManRightLeftLegUp", manRightLeftLegUpPre.src);
    PicShow("ManRightRightLegUp", manRightRightLegUpPre.src);
    PicShow("ManRightDodge", manRightDodgePre.src);
	// show all numbers as "8"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);
    for (i=1 ; i<3 ; i++) PicShow("Num"+eval(i)+"Big", numBigPre[9].src);
	// show "hour" and "minute" tekst
    $("#Hour_txt").removeClass("hidden");		
    $("#Minute_txt").removeClass("hidden");		
    TimerShowFull();	// show all 3 timer blocks
};

// show/hide colored background
function InlayShow () {
    color?PicShow("Inlay", inlayColPre.src):PicShow("Inlay", inlayPre.src);	
};

// show default pictures as @ start of the game
function MainPicturesGame () {
    MainPicturesShow ();	// show all main figures, men, hammer up, legs & number arm down
    $("#Hour_txt").addClass("hidden");		
    $("#Minute_txt").addClass("hidden");
	ScoreShow();	
};

// show default starting time numbers
function MainPicturesNums () {
	PicShow("Num1", numPre[2].src);     // 1
	PicShow("Num2", numPre[3].src);     // 2
	PicShow("Num3", numPre[1].src);     // 0
	PicShow("Num4", numPre[1].src);     // 0
};

// show all main figures, men, hammer up, legs & number arm down
function MainPicturesShow () {
	PrefSoundSettings();	// show sound on/off indication according to settings
	AllPicturesClear();	// hide all figures
	ManLeftReady();	// show left man in starting position
	ManRightReady();	// show right man in starting position
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
	if(manBlinking<1||(game!=1 && game!=2)) {	// after last time blinking or if game has been stoppped
		window.clearTimeout(computerID);	// stop automated moves
		computerID = null;
		if (game<3) {	// if game still running or "ACL" button pressed
			window.clearTimeout(demoID);	// stop demo from starting (again)
			demoID = null;
		};
		if(!manBlinking||(game!=1 && game!=2)) {	// if loser stopped blinking or if game has been stoppped
			window.clearTimeout(gameID);	// stop the game
			gameID = null;
		};
		ManMoveTimeLeftCountClear();
		window.clearTimeout(manLeftMoveID);	// stop left man's movement
		manLeftMoveID = null;
		window.clearTimeout(manMoveTimeLeftID);	// stop waiting for counter move after bad hit
		manMoveTimeLeftID = null;
		window.clearTimeout(manMoveTimeLeftCountID);	// stop count down time left to react
		manMoveTimeLeftCountID = null;
		window.clearTimeout(manRightMoveID);	// stop right man's movement
		manRightMoveID = null;
		TimerReset();       // stop previous timer blocks counting down
	} else if (game==1||game==2){
		timeID = window.setTimeout("AllStop()", 100);	// wait untill blinking looser done
	};
};

// clear gameID, game parameters & scores
function GameReset () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
	GameTurnReset();	// reset all game parameters for next turn
    scoreLeft = 0;	
    scoreRight = 0;	
};

// clear all pictures & variables
function ResetAll () {
    game = 0; // no-game-all-pictures
    AllStop();  // stop game if playing and reset all ID's
    AllPicturesClear ();        // hide all figures and show timer if game A
	GameParametersReset();	// reset all game parameters
	ManLeftUnhide();	// unhide all left man figures
	ManRightUnhide();	// unhide all right man figures
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    ResetAll(); // clear all pictures & variables
	StopAllSound();
    if (acl) {
    	AllPicturesShow()	// show all figures
    	highScore[1] = 99;
    	highScore[2] = 99;
	} else {
		MainPicturesShow(); // show all main figures, men, hammer up, legs & number arm down
		MainPicturesNums();	// show default starting time numbers
	};
	acl = true;	// to trigger AllPicturesShow()	(show all figures)
	aclID = window.setTimeout("acl = false;", 130);	// if double pressed "ACL" fast enough trigger AllPicturesShow()	(show all figures)
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions


//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// computer makes his move
function computerMove () {
	if (judge=="r") ManLeftDodging()	// dodge if number is lowest
	else ManLeftHitting();		// else hit
	if(!manRightDone) {
		noPlay--;	// count down that no reaction is registered
		loser = "right";
		manLeftDone = false;	// computer (not left man) made move, right man didn't, no moves registered
	} else {
		manLeftDone = true;	// computer (not left man) made move, right man too, no moves left
	};	
};

// start game A
function GameA () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
		MainPicturesShow();	// show all main figures, men, hammer up, legs & number arm down
        TimerShow(0); // hide timer blocks
        HighScoreShow(1);       // show highest score for game A
    };
};

// start game B
function GameB () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
		MainPicturesShow();	// show all main figures, men, hammer up, legs & number arm down
        TimerShow(0); // hide timer blocks
        // HighScoreShow(2);       // show highest score for game B (not in the physical game)
        ScoreShow(); 
     };
};

// next turn of game
function GameGoNext () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
	GameTurnReset();	// reset all game parameters for next turn
	gameID = window.setTimeout("GameGo()", 200);    // next move of game in 400 milliseconds
};

// next move of game
function GameGo () {
	if (!demo) {	// if demo not running/started
		timerLegs = "down";
		if (game==1) gameSpeed = SetSpeed();	// new speed for sequence game A
		TimerReset();   // stop previous timer blocks counting down
		if (game==1) TimerPreset(4)	// count down "times" times with leg animation before showing all timer blocks for game A
		else { 
			PlaySound("block_", vlm);
			TimerShowFull();	// show all 3 timer blocks
			timeID = window.setTimeout("TimerStart(1)", gameSpeed);	// show timer counting down with 3 timer blocks in gamespeed milliseconds
		};
	};
};

// common settings games
function GameSet () {
    ResetAll();	// clear all pictures & variables
    score = 0;  // reset score
	GameReset();	// clear gameID, game parameters & scores
};

// reset all game parameters
function GameParametersReset () {
	firstManMove = "none";	// no man made first move yet
	judge = false;	// no numbers set yet
	loser = "none";	// no loosing man yet
	manBlinking = 0;	// no man blinking @ the moment
	otherManMovedBefore = 0;	// no man moved before
	manLeftDodge = false;	// man on the left not dodging
	manRightDodge = false;	// man on the right not dodging
	manLeftDone = false;	// man on the left made no move
	manRightDone = false;	// man on the right made no move
	manLeftHit = false;	// man on the left didn't hit yet
	manLeftHitDelay = false;	// man on the left didn't hit yet after right man wrongly hit
	manRightHit = false;	// man on the right didn't hit yet
	manRightHitDelay = false;	// man on the right didn't hit yet
	which = "none";
};

// reset all game parameters and set pictures for next turn
function GameTurnReset () {
	GameParametersReset();	// reset all game parameters for next turn
	MainPicturesGame();	// show default pictures as @ start of the game
};

// put numbers up and get ready to make a move
function Judge () {
	if (manMoveTimeLeftID) {	// prevent blinking from starting twice if previous triggerd
		clearTimeout(manMoveTimeLeftID);
		manMoveTimeLeftID = null;
		manMoveTimeLeft = 0;	// no more time left to make counter hit after wrong hit opponent
	};
	if (computerID) {
		window.clearTimeout(computerID);	// stop computer from making move if planned
		computerID = null;
	};
	manMoveTimeLeft = 2;	// couple seconds of time to make move each run
	manMoveTimeLeftID = window.setTimeout("ManMoveTimeLeftCount();", 1000);	// count down seconds of time to make move
	PlaySound("numsup_", vlm);
	ShowNumbers();	// randomise and put up each man's number 
	if (manNumLeft<manNumRight) {
		judge = "r"	// if right man holds highest number
	} else {
		if (manNumLeft>manNumRight) {
			judge = "l"	// if left man holds highest number
		} else {
			if (manNumLeft==manNumRight) {
				judge = "e";	// if both numbers are equal
			} else {
				judge = false;	// Judge() wrongly called
			};
		};
	};
	if (game==1) {	// if playing game A
		computerID  = window.setTimeout("computerMove()", (gameSpeed*1.4));	// let computer make his move after some milliseconds
	};
};

// button pressed to start game A
function MainGameA () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
		PlaySound("click_", vlm);	// click sound for push button
		if (demoID) {   // prevent demo from continuing or (re)starting if planned
			clearTimeout(demoID);
			demoID = null;
		};
		demo = false;		// the demo is turned off
		noPlay = 10;	// times not responding to judge before game ends automatically
		GameA();    // start game A
    };
};

// "game A" button released so actually play game A
function MainGameAGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
		GameSet(); // variables reset
        game = 1; // game A
        ScoreShow();
		gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};


// button pressed to start game B
function MainGameB () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
		PlaySound("click_", vlm);	// click sound for push button
		if (demoID) {   // prevent demo from continuing or (re)starting if planned
			clearTimeout(demoID);
			demoID = null;
		};
		demo = false;		// the demo is turned off
		noPlay = 5;	// times not responding to judge before game ends automatically
		GameB();    // start game B
    };
};

// "game B" button released so actually play game B
function MainGameBGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // variables reset
        game = 2; // game B
        gameSpeed = 845;
        ScoreShow();
		gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// stop game if running + clear all
function MainGameOver () {
	TimerReset();       // stop previous timer blocks counting down
	if(manBlinking==-1) {	// after last time blinking
		game = 3;	// game over
		AllStop();	// stop game if playing and reset all ID's
		GameParametersReset ();
		judge = "none";
		StopAllSound();
		PlaySound("gameover_", vlm);
		demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	} else {
		timeID = window.setTimeout("MainGameOver()", 100);	// wait untill blinking looser done
	};
};

// let loosing man blink
function ManBlinking (which) {
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
	if (which!="none"&&!demo) {
		if (manMoveTimeLeftID) {	// prevent blinking from starting twice if previous triggerd
			clearTimeout(manMoveTimeLeftID);
			manMoveTimeLeftID = null;
			manMoveTimeLeft = 0;	// no more time left to make counter hit after wrong hit opponent
		};
		if (manLeftDone&&manRightDone&&soundEnded) {	// if all players made their move and all sounds ended
			if (manBlinking==0) {
				manBlinking = 11;	// 5 times hide & 5 times unhide
			};
			if (which=="left"||which=="both") {	// left man blinking or both
				if (manBlinking % 2) ManLeftHide()	// @ odd times hide left man
				else ManLeftUnhide();	// @ even times unhide left man
			};
			if (which=="right"||which=="both") {	// right man blinking or both
				if (manBlinking % 2) ManRightHide()	// @ odd times hide right man
				else ManRightUnhide();	// @ even times unhide right man
			};
			manBlinking--;	// indicates next sequence
			if (manBlinking>1) manMoveTimeLeftID = window.setTimeout("ManBlinking('"+which+"')", (manBlinking%2?250:150))	// if man not done blinking next step in 300ms
			else {	// @ end
				manBlinking = -1;	// indicates blinking of loser already done for this round to avoid double call
				ManLeftUnhide(); // show left man
				ManRightUnhide();	// show right man
				if ((game==1||game==2)&&noPlay>0) {	// if game A or B still playing : start next game turn in a seconds
					gameID = window.setTimeout("GameGoNext()", 200);    // continue game in 400 milliseconds
				} else {
					if (!demo) {
						AllStop();  // stop game if playing and reset all ID's
						GameParametersReset();	// reset all game parameters
						demoID = window.setTimeout("MainTimeStart()", 3000);	// clear all pictures & variables & start demo after a few seconds  
					};				
				};				
			}
		} else if (!soundEnded) {	// if a sound is still playing
			manMoveTimeLeftID = window.setTimeout("ManBlinking('"+which+"')", 100);	// wait untill all players and move sound done
		};
	};
};

// left man dodges to the left
function ManLeftDodging () {
	if (!otherManMovedBefore) {	// if other man didn't make a move first
		if ((!manLeftDone&&manMoveTimeLeft)||demo) {	// if left man hasn't moved yet & there is still time to make a move or demo is running
			if (!manRightDone) {
				firstManMove = "left";
			} else {
				if (!demo) ManMoveTimeLeftCountClear();	// stop count down time left to make a move				
			};
			manLeftDodge = true;	// indicates left man dodged
			manLeftDone = true;	// left man made his move
			// hide current shown left man
			PicShow("ManLeft", nullPre.src);
			PicShow("ManLeftHammerBack", nullPre.src);
			PicShow("ManLeftHammerHit", nullPre.src);
			PicShow("ManLeftNumArmDown", nullPre.src);
			PicShow("ManLeftNumArmUp", nullPre.src);
			PicShow("ManLeftLeftLegUp", nullPre.src);
			PicShow("ManLeftLeftLegDown", nullPre.src);
			PicShow("ManLeftRightLegUp", nullPre.src);
			PicShow("ManLeftRightLegDown", nullPre.src);
			// show left dodging man
			PicShow("ManLeftDodge", manLeftDodgePre.src);
			if (!demo) manLeftMoveID = window.setTimeout("ManMovedFirst();", 20);	// little delay to be able to react @ the same time 
		};
	} else {
		MenDone();	// no more moves possible
	};
};

// right man dodges to the right
function ManRightDodging () {
	if (!otherManMovedBefore) {	// if other man didn't make a move first
		if ((!manRightDone&&manMoveTimeLeft)||demo) {	// if right man hasn't moved yet & there is still time to make a move or demo is running
			if (!manLeftDone) {
				firstManMove = "right";	// if left man hasn't moved yet right man moved first
			} else {
				if (!demo) ManMoveTimeLeftCountClear();	// stop count down time left to make a move				
			};
			manRightDodge = true;	// indicates right man dodged
			manRightDone = true;	// right man made his move
			// hide current shown right man
			PicShow("ManRight", nullPre.src);
			PicShow("ManRightHammerBack", nullPre.src);
			PicShow("ManRightHammerHit", nullPre.src);
			PicShow("ManRightNumArmDown", nullPre.src);
			PicShow("ManRightNumArmUp", nullPre.src);
			PicShow("ManRightLeftLegUp", nullPre.src);
			PicShow("ManRightLeftLegDown", nullPre.src);
			PicShow("ManRightRightLegUp", nullPre.src);
			PicShow("ManRightRightLegDown", nullPre.src);
			// show right dodging man
			PicShow("ManRightDodge", manRightDodgePre.src);
			if (!demo) manRightMoveID = window.setTimeout("ManMovedFirst();", 20);	// little delay to be able to react @ the same time 
		};
	} else {
		MenDone();	// no more moves possible
	};
};

// let left man hit right man
function ManLeftHitting () {
	if ((!manLeftDone&&manMoveTimeLeft&&!manLeftHitDelay)||demo) {	// if left man hasn't moved yet & there is still time to make a move or demo is running
		if (soundEnded) {	// if there's no sound playing and right man isn't hitting 
			if (!manRightDone) {
				if (judge=="r") manRightHitDelay = true;	// if computer has highes number he can hit after right man wrongly hit
				firstManMove = "left";	// if right man didn't move first, left is first to move
			} else {
				if (!demo) ManMoveTimeLeftCountClear();	// stop count down time left to make a move				
			};
			manLeftHit = true;	// indicates left man tried to hit
			manLeftDone = true;	// left man made his move
			PicShow("ManLeftHammerBack", nullPre.src);	// hide the left man's backwards arm and hammer
			PicShow("ManLeftHammerHit", manLeftHammerHitPre.src);	// show the left man's hitting arm and hammer
			if (!manRightDodge) {	// if the right man didn't dodge first
				if (judge!="r"||demo) {	// if demo running or right man hasn't got highest number
					// let right man's legs go up
					PicShow("ManRightLeftLegUp", manRightLeftLegUpPre.src);
					PicShow("ManRightLeftLegDown", nullPre.src);
					PicShow("ManRightRightLegUp", manRightRightLegUpPre.src);
					PicShow("ManRightRightLegDown", nullPre.src);		
				};
				if (!demo) manLeftMoveID = window.setTimeout("ManMovedFirst();", 20);	// little delay to be able to react @ the same time 
			};
		} else {	// if a sound is still playing
			hitID = window.setTimeout("ManLeftHitting()", 100);	// wait untill all sound done playing or computer waits untill right man wrongly hitting
		};
	} else {
		if (manLeftHitDelay) hitID = window.setTimeout("ManLeftHitting()", 200);	// computer waits untill right man done wrongly hitting
	};
};

// let right man hit left man
function ManRightHitting () {
	if ((!manRightDone&&manMoveTimeLeft&&!manRightHitDelay&&!(game==1&&firstManMove=="left"))||demo) {	// if right man hasn't moved yet & there is still time to make a move or demo is running
		if (soundEnded) {	// if there's no sound playing
			if (!manLeftDone) {
				if (judge=="l") manLeftHitDelay = true;	// if computer has highes number he can hit after right man wrongly hit
				firstManMove = "right";	// if left man didn't move first, right is first to move
			} else {
				if (!demo) ManMoveTimeLeftCountClear();	// stop count down time left to make a move				
			};
			manRightHit = true;	// indicates right man tried to hit
			manRightDone = true;	// right man made his move
			PicShow("ManRightHammerBack", nullPre.src);	// hide the right man's backwards arm and hammer
			PicShow("ManRightHammerHit", manRightHammerHitPre.src);	// show the right man's hitting arm and hammer
			if (!manLeftDodge) {	// if the left man didn't dodge first
				if (judge!="l"||demo) {	// if demo running or left man hasn't got highest number
					// let left man's legs go up
					PicShow("ManLeftLeftLegUp", manLeftLeftLegUpPre.src);
					PicShow("ManLeftLeftLegDown", nullPre.src);
					PicShow("ManLeftRightLegUp", manLeftRightLegUpPre.src);
					PicShow("ManLeftRightLegDown", nullPre.src);		
				};
				if (!demo) manRightMoveID = window.setTimeout("ManMovedFirst();", 20);	// little delay to be able to react @ the same time 
			};
		} else {	// if a sound is still playing
			hitID = window.setTimeout("ManRightHitting()", 100);	// wait untill all sound done playing
		};
	} else {
		if (manRightHitDelay) hitID = window.setTimeout("ManRightHitting()", 200);	// computer waits untill right man done wrongly hitting
	};
};

// count down time left to make a move
function ManMoveTimeLeftCount () {
	ManMoveTimeLeftCountClear();
	if (manMoveTimeLeft>0) {	// if time left for move
		manMoveTimeLeftCountID = window.setTimeout("manMoveTimeLeft--; ManMoveTimeLeftCount();", 800);	// count down next second
	} else {	// if time is up for game B
		if (!manLeftDone&&!manRightDone) {	// if no player made a move
			if (game==2) {		// if no man made a move @ game B
				MenDone();	// no more moves possible
				PlaySound("miss_", vlm);	// miss sound
				loser = "both";
			} else {
				if (!(game==1&&judge!="r"&&manRightHit)) manLeftDone = true;	// no more move for left man
				manRightDone = true;	// no more move for right man
			};
			noPlay--;	// count down that no reaction is registered
		} else {
			manLeftDone = true;	// no more move allowed
			manRightDone = true;	// no more move allowed
		};
		if (manBlinking<1) ManBlinking((loser!="none"||game==1)?loser:"both");	// if game A or someone reacted @ game B, loser blinks, else both
	};
};

// stop count down time left to make a move
function ManMoveTimeLeftCountClear () {
	if (manMoveTimeLeftCountID) {
		clearTimeout(manMoveTimeLeftCountID);
		manMoveTimeLeftCountID = null;
	};
};

// show judging according to who made a move first
function ManMovedFirst () {	
	if (computerID) {
		window.clearTimeout(computerID);	// stop computer from making move if planned
		computerID = null;
	};
	if (manMoveTimeLeft) {	// to avoid double call when moved simultaneously
		if (firstManMove=="left") {	// left man made first move
			if (game==1||manRightDone) manMoveTimeLeft = 0;	// if computer made move or right man moved as well, no time left for counter move
			if (judge=="r") {	// if right man has highest number
				if (manLeftDodge||(manRightDodge&&!manLeftHit)) {	// if left man made good dodge or right man made wrong dodge without counter hit
					MenDone();	// no more moves possible
					loser = "right";	// right man will blink
					PlaySound("miss_", vlm);	// "miss" sound 
					ScoreAdd ("left", 2);	// left man gets 2 points
				} else {	// left man should have dodged, but hit instead
					loser = "left";	// left man will blink
					if (manRightHit){	// if right man hit within time
						MenDone();	// no more moves possible
						if (manLeftHit&&otherManMovedBefore) PlaySound("compgoodhit_", vlm)	// if left man already hit, "computer made good hit"-sound
						else PlaySound("playergoodhit_", vlm);	// player made good hit sound when hit together
						ScoreAdd ("right", 3);	// right man gets 3 points	
						if (manLeftHit&&!otherManMovedBefore) ScoreAdd ("right", 2);	// right man gets 2 points if not yet added & left man hit too, but wrongly
					} else {	// if right man didn't hit within time
						if (game==2&&manMoveTimeLeft) {	// if time left for move opponent
							ManMoveTimeLeftCountClear();
							manMoveTimeLeftCountID = window.setTimeout("ManMoveTimeLeftCount();", 500);	// count down next half second
						}
						PlaySound("miss_", vlm);	// "miss" sound
						if (manRightDodge) {	// if right man dodged
							loser = "both";	// both men will blink
							MenDone();	// no more moves possible
						} else {
							loser = "left";	// right man will blink
							ScoreAdd ("right", 2);	// right man gets 2 points
						};
						if (score>98) MenDone();	// no more moves possible
					};
					if (manLeftHit&&!otherManMovedBefore) {	// if left man wrongly hit and right man hasn't made move yet
						manRightHitDelay = false;
						if (manRightDone) {
							manRightDone = false;	// allows opponent to make delayed move after wrong hit
							manMoveTimeLeft = 1;	// gives opponent some time to make delayed move after wrong hit
						};
					};
				};
			} else {	// right man doesn't have highest number
				if (judge=="l") {	// if left man has highest number
					MenDone();	// no more moves possible
					if (manLeftHit) {	// if left man hit
						if (manRightDodge){	// if right man dodged in time
							loser = "left";	// left man will blink
							PlaySound("miss_", vlm);// "miss" sound
							ScoreAdd ("right", 2);	// right man gets 2 points
						} else {
							loser = "right";	// right man will blink
							if (game==1) {
								PlaySound("compgoodhit_", vlm);	// computer made good hit sound
							} else {
								PlaySound("playergoodhit_", vlm)	// if no previous sound is playing, player made good hit sound
							};
							ScoreAdd ("left", 3);	// left man gets 3 points
							if (manRightHit&&!otherManMovedBefore) ScoreAdd ("left", 2);	// left man gets 2 points if not yet added & right man hit too, but wrongly
						};
					} else {	// left man didn't hit
						PlaySound("miss_", vlm);// "miss" sound
						if (manRightHit) {	// if right man didn't dodge in time
							loser = "both";	// both men will blink
						} else {
							loser = "left";	// left man will blink
							ScoreAdd ("right", 2);	// right man gets 2 points						
						};
					};
				} else {	// left man hasn't got highest number
					if (judge=="e") {	// if both men have equal numbers
						MenDone();	// no more moves possible
						if (manLeftDodge) {	// left man made wrongly dodge
							PlaySound("miss_", vlm);// "miss" sound
							if (manRightDodge||manRightHit) {	// if right man dodged wrongly too or hit too late
								loser = "both";	// both men will blink
							} else {
								loser = "left";	// left man will blink
								ScoreAdd ("right", 1);	// right man gets 1 point if he didn't make a move
							}  
						} else { // left man made hit
							if (manRightDodge) {	// if right man wrongly dodged
								loser = "both";	// both man will blink because hitting man hit too late
								PlaySound("miss_", vlm);	// "miss" sound
							} else {	// left man has hit and right man didn't dodge
								ScoreAdd ("left", 3);	// left man gets 3 points
								if (manRightHit) {	// if right man has hit too
									loser = "both";	// both men will blink
									PlaySound("playergoodhit_", vlm);	// player made good hit sound
									ScoreAdd ("right", 3);	// right man gets 3 points too	
								} else {
									loser = "right";	// right man will blink
									if (game==1) PlaySound("compgoodhit_", vlm);	// computer made good hit sound
									else PlaySound("playergoodhit_", vlm);	// player made good hit sound
								};					
							};
						};			
					};
				};
			};
		} else {	// right man made first move 
			if (manLeftDone) manMoveTimeLeft = 0;	// if left man moved as well, timing is same so no time left for counter move
			if (judge=="l") {	// left man has highest number
				if (manRightDodge||(manLeftDodge&&!manRightHit)) {	// right man made good dodge or left man made wrong dodge without counter hit
					MenDone();	// no more moves possible
					loser = "left";	// left man will blink
					if (game==1) PlaySound("playergoodhit_", vlm)	// sound of good player hit
					else PlaySound("miss_", vlm);	// "miss" sound
					ScoreAdd ("right", 2);	// right man gets 2 points		
				} else {	// right man should have dodged, but hit instead
					loser = "right";	// right man will blink
					if (manLeftHit){	// if left man has hit
						MenDone();	// no more moves possible
						if (game==1&&!otherManMovedBefore) PlaySound("miss_", vlm)	// computer won @ simultatious hit, miss sound @ game A
						else if (manLeftHit&&otherManMovedBefore) PlaySound("compgoodhit_", vlm)	// if no sound already playing, computer made good hit sound
						else PlaySound("playergoodhit_", vlm);	// player made good hit sound when hit together
						ScoreAdd ("left", 3);	// left man gets 3 points	
					} else {	// left man hasn't hit
						PlaySound("miss_", vlm);	// "miss" sound 
						if (manLeftDodge) {	// if left man dodged
							loser = "both";	// both men will blink
							MenDone();	// no more moves possible
						} else {
							if (game==2&&manMoveTimeLeft) {	// if time left for move opponent
								ManMoveTimeLeftCountClear();
								manMoveTimeLeftCountID = window.setTimeout("ManMoveTimeLeftCount();", 500);	// count down next half second
							}
							loser = "right";	// right man will blink
							ScoreAdd ("left", 2);	// left man gets 2 points	
						};
						if (manMoveTimeLeft) {	// if run time not yet over 
							if (game==1) {	// if game A playing
								computerID  = window.setTimeout("computerMove()", (500));	// computer makes move in half a second
							} else 
								if (score>98) MenDone();	// no more moves possible
						} else {	// runtime is over
							MenDone();	// no more moves possible
						};
					};
					if (manRightHit&&!otherManMovedBefore) {	 // if left man wrongly hit and right man hasn't made move yet
						manLeftHitDelay = false;
						if (manLeftDone) {
							manLeftDone = false;	// allows opponent to make delayed move after wrong hit
							manMoveTimeLeft = 1;	// gives opponent some time to make delayed move after wrong hit
						};
					};
				};
			} else {	// left man doesn't have highest number
				if (judge=="r") {	// if right man has highest number
					MenDone();	// no more moves possible
					if (manRightHit) {	// if right man has hit
						if (manLeftDodge){	// if left man dodged in time
							loser = "right";	// right man will blink
							PlaySound("miss_", vlm);// "miss" sound
							ScoreAdd ("left", 2);	// left man gets 2 points
						} else {	// left man didn't dodge in time
							loser = "left";	// left man will blink
							PlaySound("playergoodhit_", vlm);	// player made good hit sound
							ScoreAdd ("right", 3);	// right man gets 3 points
							if (manLeftHit&&!otherManMovedBefore) ScoreAdd ("right", 2);	// right man gets 2 points if not yet added & left man hit too, but wrongly
						};
					} else {	// right man dodged
						PlaySound("miss_", vlm);// "miss" sound
						if (manLeftHit){	// if left man hit wrongly
							loser = "both";	// both men will blink
						} else {
							loser = "right";	// right man will blink
							ScoreAdd ("left", 2);	// left man gets 2 points
						};
					};
				} else {	// right man hasn't got highest number
					if (judge=="e") {	// both men have equal numbers
						MenDone();	// no more moves possible
						if (manRightDodge) {	// if right man made wrongly dodge
							PlaySound("miss_", vlm);// "miss" sound
							if (manLeftDodge||manLeftHit) {	// if left man made wrongly dodge too or hit too late
								loser = "both";
							} else {
								loser = "right";	// right man will blink
								ScoreAdd ("left", 1);	// left man gets 1 point if he didn't make a move
							};
						} else {	// right man made a hit
							if (manLeftDodge) {	// if left man made wrongly dodge
								loser = "both";	// both man will blink because hitting man hit too late
								PlaySound("miss_", vlm);	// "miss" sound
							} else {	
								PlaySound("playergoodhit_", vlm);	// player made good hit sound
								ScoreAdd ("right", 3);	// right man gets 3 points
								if (manLeftHit) {	// if left man made a hit too
									loser = "both";	// both men will blink
									ScoreAdd ("left", 3);	// left man hits in time too	
								} else {
									loser = "left";	// left man will blink
								};
							};
						};	
					};
				};
			};
		};
	};
	if (manBlinking<1) {	// if blinking not already running
		if (!manMoveTimeLeft||game==3||score>98) {	// if opponent has no time left to make good hit or game is over
			if (game==2) manLeftDone = 1;	// no more move for left man
			manRightDone = 1;	// no more move for right man
			manMoveTimeLeftID = window.setTimeout("ManBlinking('"+loser+"');", 10);	// give opponent some reaction time
		};
	};
	if (!(manRightDone&&manLeftDone)) otherManMovedBefore = 1;	// only one man moved yet
};
//-------------------------------------------------------------------------------------------------------------

// show left man in starting position
function ManLeftReady () {
    manLeftDodge = false;	// no dodge yet
    manLeftHit = false;	// not hit yet
    PicShow("ManLeft", manLeftPre.src);	// show the left man's body
    PicShow("ManLeftHammerBack", manLeftHammerBackPre.src);	// show the left man's backwards arm and hammer
    PicShow("ManLeftHammerHit", nullPre.src);	 // hide the left man's hitting arm and hammer
    PicShow("ManLeftNumArmDown", manLeftNumArmDownPre.src);	// show the left man's number arm down
    PicShow("ManLeftNumArmUp", nullPre.src);	// hide the left man's number arm and number up
    PicShow("ManLeftLeftLegUp", nullPre.src);	// hide the left man's left leg up
    PicShow("ManLeftLeftLegDown", manLeftLeftLegDownPre.src);	// show the left man's left leg down
    PicShow("ManLeftRightLegUp", nullPre.src);	// hide the left man's right leg up
    PicShow("ManLeftRightLegDown", manLeftRightLegDownPre.src);	// show the left man's right leg down
    PicShow("ManLeftDodge", nullPre.src);	// hide the left man dodging
};

// show right man in starting position
function ManRightReady () {
    manRightDodge = false;	// no dodge yet
    manRightHit = false;	// not hit yet
    PicShow("ManRight", manRightPre.src);	// show the right man's body
    PicShow("ManRightHammerBack", manRightHammerBackPre.src);	// show the right man's backwards arm and hammer
    PicShow("ManRightHammerHit", nullPre.src);	// hide the right man's hitting arm and hammer
    PicShow("ManRightNumArmDown", manRightNumArmDownPre.src);    	// show the right man's number arm down
    PicShow("ManRightNumArmUp", nullPre.src);	// hide the right man's number arm and number up
    PicShow("ManRightLeftLegUp", nullPre.src);	// hide the right man's left leg up
    PicShow("ManRightLeftLegDown", manRightLeftLegDownPre.src);	// show the right man's left leg down
    PicShow("ManRightRightLegUp", nullPre.src);	// hide the right man's right leg up
    PicShow("ManRightRightLegDown", manRightRightLegDownPre.src);	// show the right man's right leg down
    PicShow("ManRightDodge", nullPre.src);	// hide the right man dodging
};

// end of attempt time, no more moves possible
function MenDone () {
	manLeftDone = true;	// no more move possible for left man
	manRightDone = true;	// no more move possible for right man
	manMoveTimeLeft = 0;	// no more time left to make a move
};

// show leading zeroes
function n(n) {
    return n>9?""+n:"0"+n;
};

// 
function randomNumber (min, max) { // min and max included 
  return Math.floor(Math.random() * (max - min + 1) + min)
};

// set speed for sequence game A
function SetSpeed () {
	var speed;	// speed indicator
	speed = randomNumber (1, 8);	// randomize speed indicator
	// translate speed indicator to milliseconds
	switch (speed) {
		case 1 :
			speed = 263;
			break;
		case 2 :
			speed = 316;
			break;
		case 3 :
			speed = 369;
			break;
		case 4 :
			speed = 420;
			break;
		case 5 :
			speed = 473;
			break;
		case 6 :
			speed = 526;
			break;
		case 7 :
			speed = 576;
			break;
		case 8 :
			speed = 631;
			break;
		default:
	};
	return speed;
};

// randomise and put up each man's number
function ShowNumbers () {
	manNumLeft = randomNumber(0, 9);	// number the left man presents from 0 to 9
	manNumRight = randomNumber(0, 9);	// number the right presents from 0 to 9
	// put up downwards arms and show the numbers 
	PicShow("ManLeftNumArmDown", nullPre.src);   
	PicShow("ManLeftNumArmUp", manLeftNumArmUpPre.src);
	PicShow("ManRightNumArmDown", nullPre.src);   
	PicShow("ManRightNumArmUp", manRightNumArmUpPre.src);
	PicShow("Num1Big", numBigPre[(manNumLeft+1)].src);
	PicShow("Num2Big", numBigPre[(manNumRight+1)].src);
};

// count down "times" times with leg animation before showing all timer blocks for game A
function TimerPreset (times) {
    if (times) {	// if count down still running
    	PlaySound("leg_", vlm);
    	if (timerLegs=="up") {	// if men's legs are up
    		timerLegs = "down";	// indicate them as being down
			// put the legs down
			PicShow("ManLeftLeftLegUp", nullPre.src);
			PicShow("ManLeftLeftLegDown", manLeftLeftLegDownPre.src);
			PicShow("ManRightRightLegUp", nullPre.src);
			PicShow("ManRightRightLegDown", manRightRightLegDownPre.src);		
    	} else {	// men's legs are down
    		timerLegs = "up";	// indicate them as being up
			// pull the legs up
			PicShow("ManLeftLeftLegUp", manLeftLeftLegUpPre.src);
			PicShow("ManLeftLeftLegDown", nullPre.src);
			PicShow("ManRightRightLegUp", manRightRightLegUpPre.src);
			PicShow("ManRightRightLegDown", nullPre.src);		
    	};
     	timeID = window.setTimeout("TimerPreset("+(times-1)+")", gameSpeed);// count down "times-1" times with leg animation before showing all timer blocks for game A in gametime milliseconds
   } else {		// timer not running
    	PlaySound("block_", vlm);
		TimerReset();       // stop previous timer blocks counting down
		TimerShowFull();	// show all 3 timer blocks
		timeID = window.setTimeout("TimerStart(1)", gameSpeed);	// show timer counting down with 3 timer blocks in gamespeed milliseconds
	};
};

// stop previous timer blocks counting down
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};

// hide all but "count" number of timer blocks
function TimerShow (count) {
    for (i=1 ; i<(4-count) ; i++) PicShow("TimerBlock"+eval(i), nullPre.src);
};

// show all 3 timer blocks
function TimerShowFull () {
    for (i=1 ; i<4 ; i++) PicShow("TimerBlock"+eval(i), timerBlockPre.src);
};

// show timer counting down with 4-i timer blocks
function TimerStart (i) {
    PicShow("TimerBlock"+eval(i), nullPre.src);     // hide next timer block
    if (i<3) { // if timer blocks left
		PlaySound("block_", vlm);
        timeID = window.setTimeout('TimerStart ('+(eval(i+1))+')', gameSpeed) // hide next timer block in gamespeed milliseconds
    } else {
        TimerReset();       // stop previous timer blocks counting down
        Judge();	// put numbers up and get ready to make a move
    };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

