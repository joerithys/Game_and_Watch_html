//Product:	Covid19 HTML - Silver Screen (Nintendo) Simulator
//Version:	1.1
//Started:	1.08.2020
//Last update:	18.03.2021
//Author:	Flyzy (Joeri Thys)
//Original G&W:	Nintendo Co. Ltd
//Credits:
//Design, layout and artwork by Lee Robson (hydef)
//Based on scans by Sean Riddle
//Colour background by DarthMarino


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;	   // indicates if demo is running or not
var demoID;	 // ID for timeout demo autostart after last handling
var fireSec = 1;		// sequence for the flames on top of the building
var sequence = 0;	   // game sequence of the falling jumpers

var acl = false;	// for showing acl pictures, all if pressed twice fast
var aclID;	// ID to view all pictures @ fast double click
var caught = new Array();  // array of caught jumpers @ the 3 places
var color = false;		   // indicator to show/hide colored background
var fiveHundredTopper = 0;	// calculated hundreds over fivehundred in score
var flamesID;	// for moving flames during game
var flamesSpeed = 500;	// for speed moving flames during game
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 2-gameB; 3-game-over; 4-clock; 
var gameID;	// ID for timeout game sequence
var gameSpeedMax;	// maximum speed for game sequence timer
var gameSpeedMin;	// maximum speed for game sequence timer
var gameSpeed;	// speed for game sequence timer
var highScore = new Array();	// for highest scores for games a & b
var jumperGap	// gap between jumpers (2-22)
var jumperGapMax;	// maximum gap between jumpers according to score
var jumperGapMin = 1;	// minimum gap between jumpers according to score
var jumpersMoved;		 // number of jumpers moved @ a catching point 
var jumperPresent = new Array();  // array of all jumper positions presence
var life = 3;   // number of lives left
var maxJumpersPresent; // maximum alowed jumpers present on screen @ that time
var missed;	 //	  indicating missed jumper, game paused
var pause = false;	
var pauseID;	// ID to pause the game temporarily (pause stopper)
var pos;		// position firemen
var score = 0;	// score (all beneath 100) at init
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var keyLeft = false;
var keyRight = false;
var keyPressed = false;	// indicates if a previuos key was already pressed to avoid double entries

var prefSound = 1;	  // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var timeID;	 // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var vlm = 1;			// sound volume 0.01-1
var preVlm = vlm;	   // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables


//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
	codeCurrent = e.keyCode;		// for reading game keys
	e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
	switch (e.key) {
		case "1": case"a": case"A":	 // if "1", "a" or "A" pressed
			// show game a button pressed
			document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';	 
			if (!keyPressed) MainGameA(); // play Game A
			keyPressed = true;
			break;
		case "2": case"b": case"B":	 // if "2", "b" or "B" pressed
			// show game b button pressed
			document.images['Game B'].src = 'img/case/buttons/grey_2_flat.png';	 
			if (!keyPressed) MainGameB(); // play Game B
			keyPressed = true;
			break;
		case "e": case "E": case "ArrowLeft":	// left key
			// show left button pressed
			document.images['Move Left'].src = 'img/case/buttons/left_flat.png';	 
			Left();	// if no key already pressed go left
			keyPressed = true;
			break;
		case "o": case "O": case "ArrowRight":	// right key
			// show right button pressed
			document.images['Move Right'].src = 'img/case/buttons/right_flat.png';	 
			Right();	// if no key already pressed show right arm up
			keyPressed = true;
			break;
		case"r": case"R":	 // if "r" or "R" pressed
			// show acl button pressed
			document.images['aclButton'].src = 'img/case/buttons/acl_push.png';
			TotalReset(); // show full sprites
			break;
		case"t": case"T":	 // if "t" or "T" pressed
			// show time button pressed
			document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
			MainTime(); // show time & demo
			break;
		// test case buttons
		case "+":	// "+"-numpadkey
			if (vlm<1) {
				vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
				preVlm = vlm;
			};
			if (vlm==0.01)  SetSound(true);	// show sound turned on
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "-":	// "-"-key
			if (vlm>0) {
				vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
				preVlm = vlm;
			};
			if (vlm==0) SetSound(false);	// show sound turned off
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "@": case "é": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
			prefSoundShow = !prefSoundShow;
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case String.fromCharCode(233): case "Control" :	// "Ctrl"-key
			color = !color;	 // indicator to show/hide colored background
			InlayShow();	// switch background black/color
			break;
		case ")": case String.fromCharCode(219):
			zoomed = zoomed?0:1;
			$(function () {
				CheckSizeZoom()
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);
			break;
		default:
	};
	//console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function (e) {
	// game and arrow keys
	switch (e.key) {
		case "1": case"a": case"A":	 // if "2", "b" or "B" released
			document.images['Game A'].src = 'img/case/buttons/grey_1.png';	 // show game a button default
			MainGameAGo(); // play Game A
			keyPressed = false;
			break;
		case "2": case"b": case"B":	 // if "2", "b" or "B" released
			document.images['Game B'].src = 'img/case/buttons/grey_2.png';	 // show game b button default
			MainGameBGo(); // play Game A
			keyPressed = false;
			break;
		case "e": case "E": case "ArrowLeft":	// left key released
			// show left button default
			document.images['Move Left'].src = 'img/case/buttons/left.png';	 
			keyPressed = false;
			break;
		case "o": case "O": case "ArrowRight":	// right key released
			// show right button default
			document.images['Move Right'].src = 'img/case/buttons/right.png';	 
			keyPressed = false;
			break;
		case"r": case"R":	 // if "r" or "R" pressed
			document.images['aclButton'].src = 'img/case/buttons/acl.png';	 // show acl button default
			break;
		case"t": case"T":	 // if "t" or "T" released
			document.images['Time'].src = 'img/case/buttons/grey_3.png';	 // show time button default
			break;
		default:
	};
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
	$(function () {
		CheckSizeZoom();
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);
	$("#Fire").focus(); // get focus on the game
	PicPreload();	// this function preloads all images to make them ready for use
	TotalReset();	// clear all and reset all on going to default and show default figures
});

//standard game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually go to the left
function GoLeft () {
	if (pos>1) {	// if not totally left
		pos--;	// go position to the left
		FireMenShow(pos);	// show man @ current position
		// if jumper @ same place as firemen
		if ((jumperPresent[5]&&pos==1)||(jumperPresent[13]&&pos==2)||(jumperPresent[19]&&pos==3)) {
			// if firemen not too late @ catch not yet registered
			if (!missed&&!caught[pos]) PlaySound("catch_", vlm);	// sound jumper bouncing
			caught[pos] = true; // indicate jumper @ position caught
		};	
	};
};

// actually go to the right
function GoRight () {
	if (pos<3) {	// if not totally right
		pos++;	// go position to the right
		FireMenShow(pos);	// show man @ current position
		// if jumper @ same place as firemen
		if ((jumperPresent[5]&&pos==1)||(jumperPresent[13]&&pos==2)||(jumperPresent[19]&&pos==3)) {
			// if firemen not too late @ catch not yet registered
			if (!missed&&!caught[pos]) PlaySound("catch_", vlm);	// sound jumper bouncing
			caught[pos] = true; // indicate jumper @ position caught
		};	
	};
};

// left button or -key pressed
function Left () {
	if (game==1 || game==2) {	// if game A or B playing
		GoLeft();	// go position to the left
	};
};

// right up button or -key pressed
function Right () {
	if (game==1 || game==2) {	// if game A or B playing
		GoRight ();	// go position to the right
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard game functions


//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
	ambuPre = new Image();
	ambuPre.src = "img/screen/ambu.png";	// to show ambulance
	ambuLightPre = new Image();
	ambuLightPre.src = "img/screen/ambuLight.png";	// to show flashlight on ambulance
	fallenPre = new Array();
	for (i=1 ; i<4 ; i++) fallenPre[i] = new Image();
	for (i=1 ; i<4 ; i++) fallenPre[i].src = "img/screen/fallen"+eval(i)+".png";	// to show fallen jumper @ position "i"
	firePre = new Array();
	for (i=1 ; i<4 ; i++) firePre[i] = new Image();
	for (i=1 ; i<4 ; i++) firePre[i].src = "img/screen/fire"+eval(i)+".png";	// to show fire flame @ position "i"
	fireMenPre = new Array();
	for (i=1 ; i<4 ; i++) fireMenPre[i] = new Image();
	for (i=1 ; i<4 ; i++) fireMenPre[i].src = "img/screen/fireMen"+eval(i)+".png";	// to show firemen @ position "i"
	inlayPre = new Image();
	inlayPre.src = "img/screen/inlay.png";	// to show building
	inlayColPre = new Image();
	inlayColPre.src = "img/screen/inlay_c.png";	// to show building surrounding in color
	jumperPre = new Array();
	for (i=1 ; i<23 ; i++) jumperPre[i] = new Image();
	for (i=1 ; i<23 ; i++) jumperPre[i].src = "img/screen/jumper"+eval(i)+".png";	// to show jumper @ position "i"
	missPre = new Image();
	missPre.src = "img/screen/miss.png";	// to show missed jumpers (angels)
	nullPre = new Image();
	nullPre.src = "img/null.gif";	// empty picture to hide any figure
	numPre = new Array();
	for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
		numPre[i] = new Image();
		numPre[i].src = "img/screen/num"+eval(i-1)+".png";
	};
	numColonPre = new Image();
	numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
	soundOnPre = new Image();
	soundOnPre.src = "img/case/buttons/butOn.png";	// to show sound button in on-state
	soundOffPre = new Image();
	soundOffPre.src = "img/case/buttons/butOff.png";	// to show sound button in off-state*/
};

// hide all fallen jumpers
function AllFallenHide () {
	for (i=1 ; i<4 ; i++) PicShow("Fallen"+eval(i)+"", nullPre.src);	
};

// show all fallen jumpers
function AllFallenShow () {
	for (i=1 ; i<4 ; i++) PicShow("Fallen"+eval(i)+"", fallenPre[i].src);
};

// hide all fire flames
function AllFireHide () {
	for (i=1 ; i<4 ; i++) PicShow("Fire"+eval(i)+"", nullPre.src);	
};

// show all fire flames
function AllFireShow () {
	for (i=1 ; i<4 ; i++) PicShow("Fire"+eval(i)+"", firePre[i].src);
};

// hide all firemen
function AllFireMenHide () {
	for (i=1 ; i<4 ; i++) PicShow("FireMen"+eval(i)+"", nullPre.src);	
};

// show all firemen
function AllFireMenShow () {
	for (i=1 ; i<4 ; i++) PicShow("FireMen"+eval(i)+"", fireMenPre[i].src);
};

// hide all bouncing jumpers
function AllJumpersHide () {
	for (i=1 ; i<23 ; i++) PicShow("Jumper"+eval(i)+"", nullPre.src);	
};

// show all bouncing jumpers
function AllJumpersShow () {
	for (i=1 ; i<23 ; i++) PicShow("Jumper"+eval(i)+"", jumperPre[i].src);
};

// hide all missed jumpers (angels)
function AllMissedHide () {
	for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);	
};

// show all missed jumpers (angels)
function AllMissedShow () {
	for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
};

// hide all figures
function AllPicturesClear () {
	AllFallenHide();
	AllFireHide();
	AllFireMenHide();
	AllJumpersHide();
	PicShow("AmbuLight", nullPre.src);	   // hide flash light on ambulance
	AllMissedHide();		// hide all mised jumpers (angels)
	PicShow("NumColon", nullPre.src);	// hide ":" between hours & seconds
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);	// hide all numbers
};

// show all figures & "88:88"
function AllPicturesShow () {
	MainPicturesShow();
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
};

// show fire flame @ current position
function FireShow (pos) {
	AllFireHide();	// hide all fire flames
	PicShow("Fire"+pos+"", firePre[pos].src);	// show body
};

// show firemen @ current position
function FireMenShow (pos) {
	AllFireMenHide();
	PicShow("FireMen"+pos+"", fireMenPre[pos].src);	// show body
};

// show/hide colored background
function InlayShow () {
	color?PicShow("Inlay", inlayColPre.src):PicShow("Inlay", inlayPre.src);	
};

// show all present jumpers
function JumpersShow () {
	for (y=1 ; y<23 ; y++) {	 // check the whole jumper sequence & show the present
		if (jumperPresent[y]) PicShow("Jumper"+eval(y)+"", jumperPre[y].src)
		else PicShow("Jumper"+eval(y)+"", nullPre.src);
	};	
};

// show default pictures as @ start of the game
function MainPicturesGame () {
	AllFireShow();	  // show all fire flames on top of the building 
	PicShow("Fire"+eval(fireSec)+"", nullPre.src);	  // hide one flame again @ "fireSec" place
	PicShow("FireMen1", fireMenPre[1].src);	 // show firemen @ first place
};

// show firemen in center & ambulance
function MainPicturesDefault () {
	PicShow("Ambu", ambuPre.src);	   // show ambulance
	PicShow("FireMen2", fireMenPre[2].src);	 // show firemen in center
};

// clear screen & show firemen in center & ambulance
function MainPicturesReDefault () {
	AllPicturesClear();	 // hide all figures
	MainPicturesDefault();	  // show firemen in center & ambulance
};

// show all figures & "12:00"
function MainPicturesShow () {
	MainPicturesDefault();	// show firemen in center & ambulance
	PicShow("AmbuLight", ambuLightPre.src);	 // to show flashlight on ambulance
	AllFallenShow();
	AllFireShow();
	AllFireMenShow();
	AllJumpersShow();
	AllMissedShow();
	PicShow("NumColon", numColonPre.src);	   // ":"
	PicShow("Num1", numPre[2].src);	 // 1
	PicShow("Num2", numPre[3].src);	 // 2
	PicShow("Num3", numPre[1].src);	 // 0
	PicShow("Num4", numPre[1].src);	 // 0
};

// show/hide figure on screen
function PicShow (id, name) {
	if (name) document.images[id].src = name;	// if picture given assign it to the figure
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them


//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich sound on/off; dont preload here
function PrefSound () {
	prefSound = !prefSound;	 // on/off
	PrefSoundEval();	// Show sound settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
	if (!prefSound) { // if sound is set to "off" 
		preVlm = vlm;   // remember last sound volume
		vlm = 0;		// set volume to 0
	} else {
		if (preVlm==0) preVlm = 0.01; // if no previous volume, set to minimum
		vlm = preVlm;   // set volume to "on"
	};
	PrefSoundSettings();	// show sound on/off indication
	PrefSoundShow();	// show volume indicator on screen for testing purposes
	PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
	var vlmTxt = "";	// empty sound volume indicator picture
	$("#SoundStateInd").html("");	// empty/hide volume indicator
	if (prefSoundShow) {	  // if volume indicator is set to show
		if (vlm>0.00999) {
			for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
			$("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
		} else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	} else {
		$("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	};
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
	if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
	else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// swich sound on/off; dont preload here
function SetSound (setting) {
	prefSound = setting;		// on true/false
	PrefSoundSettings();	// show sound on/off indication
	PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
	StopSound("fall_", vlm);
	StopSound("catch_", vlm);
	StopSound("missed_", vlm);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions


//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
	GameReset();	// clear gameID & pauseID
	if (aclID) {
		window.clearTimeout(aclID);	// ID for timeout left arm up reset
		aclID = null;
	};
	if (demoID) {
		window.clearTimeout(demoID);	// stop demo from starting (again)
		demoID = null;
	};
	pause = true;
	TimerReset(); // stop the counter to show the current time
};

// reset jumper catch indications @ position
function CaughtReset (p) {
	caught[p] = false;  // reset caught jumper on position p
	missed = 0; // no new missed jumper
	pause = false;	  // undo pause and continue game
};

// reset caught jumper indications @ all positions
function CaughtResetAll () {
	for (i=1 ; i<4 ; i++) caught[i] = false;  // reset caught jumper on all positions
	missed = 0; // no new missed jumpers
	pause = false;	  // undo pause
};

// clear gameID & pauseID
function GameReset () {
	if (gameID) {
		clearTimeout(gameID);	// stop the game
		gameID = null;
	};
	if (pauseID) {
		clearTimeout(pauseID);  // stop pause stopper
		pauseID = null;
	};
};

// clear all jumper positions
function JumpersReset () {
	for (j=0 ; j<23 ; j++) jumperPresent[j] = 0;
};

// clear all pictures & variables
function ResetAll () {
	AllStop();  // stop game if playing and reset all ID's
	AllPicturesClear();		// hide all figures
	CaughtResetAll();
	fireSec = 1;		// sequence for the flames on top of the building set in starting position
	if (flamesID) {
		clearTimeout(flamesID);	// stop the flames from animating
		flamesID = null;
	};
	game = 0;   // no-game-all-pictures
	JumpersReset();
	sequence = 0;	   // game sequence of the falling jumpers reset
};

// stop showing current time
function TimerReset () {
	if (timeID) {
		clearTimeout(timeID);
		timeID = null;
	};
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
	ResetAll(); // clear all pictures & variables
	if (acl) AllPicturesShow()	// show all pictures if "acl" clicked twice fast
	else MainPicturesShow(); // show all figures & "12:00"
	acl = true; // indicates "acl" already clicked
	aclID = window.setTimeout("acl = false;", 130);	 // ID to show all pictures if "acl" clicked twice in 130 milliseconds
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions


//show/hide score
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// check & show highest score on screen
function HighScoreShow (game) {
	pause = true;
	highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
	ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

// hide score
function ScoreHide () {
	for (var i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// translate current score to the digits on screen
function ScoreShow (score) {
	if (score>999) 
		if (Math.floor((score/1000)%10)==0) PicShow("Num1", nullPre.src)
		else PicShow("Num1", numPre[Math.floor((score/1000)%10)+1].src);
	else PicShow("Num1", nullPre.src);
	if (score>99) 
		if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0) PicShow("Num2", nullPre.src)
		else PicShow("Num2", numPre[Math.floor(score%1000/100)+1].src);
	else PicShow("Num2", nullPre.src);
	if (score>9)  
		if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0  && Math.floor(score%100/10)==0) PicShow("Num3", nullPre.src)
		else PicShow("Num3", numPre[Math.floor(score%100/10)+1].src);
	else PicShow("Num3", nullPre.src);
	PicShow("Num4", numPre[(score%10)+1].src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end show/hide score


//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
	// if not already clock running or to prevent MainTime to run before failed flag_05-sound ended
	if (game!=4) {	  
		StopAllSound();
		ResetAll();	// clear all pictures & variables
		PlaySound("click_", vlm);	// click sound for push button
		MainTimeStart(); // show current time & demo
	};
};
	
// show current time & demo
function MainTimeStart () {
	ResetAll(); // clear all pictures & variables
	MainPicturesDefault();	// show firemen in center & ambulance
	//MainPicturesReDefault();	// clear screen & show firemen in center & ambulance
	demo = true;	 // to show demo
	game = 4;	// clock running
	pos = 2;	// middle position man
	TimeShow();	// show current time
	demoID = window.setTimeout("Demo()", 1000);	// next step after a second  
};

// get current time
function Time () {
	today = new Date();
	hour = today.getHours();
	min = today.getMinutes();
	sec = today.getSeconds();
};

// show current time
function TimeShow () {
	TimerReset(); // stop previuos counter to show the current time to avoid double function run
	Time();	// get current time
	TimeShowOnScreen();
	timeID = window.setTimeout("TimeShow()", 1000);	 // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen () {
	// set integer to time digits
	if (hour<10) PicShow("Num1", nullPre.src)
	else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
	PicShow("Num2", numPre[(hour%10)+1].src);
	PicShow("Num3", numPre[Math.floor(min/10)+1].src);
	PicShow("Num4", numPre[(min%10)+1].src);
	PicShow("NumColon", numColonPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions
	
//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show demo
function Demo () {
	PicShow("RythmMen", nullPre.src);	// hide indicator 4 auto
	if (demoID) {	// if demo still planned to start stop that plan to avoid double run
		clearTimeout(demoID);
		demoID = null;
	};
	AllFireShow();	  // show all fire flames
	PicShow("Fire"+eval(fireSec)+"", nullPre.src);		// set the flames on top of the building in next order
	if (fireSec<3) fireSec++		// newt sequence for the flames on top of the building
	else fireSec = 1;		// sequence for the flames on top of the building set in starting position
	if (sequence<23) sequence++	   // next game sequence of the falling jumpers
	else sequence = 1;  // or first if sequence finished
	if (sequence==9||sequence==16) GoRight();   // go right @ certain jumper positions
	if (sequence==1||sequence==21) GoLeft();   // go left @ certain jumper positions
	// moving one jumper at the tima & flash light on ambulance @ the end
	if (sequence>1) PicShow("Jumper"+eval(sequence-1)+"", nullPre.src); // hide jumperon previous position
	if (sequence>22) {
		PicShow("AmbuLight", ambuLightPre.src);	   // last game sequence of the falling jumpers is the flash light on the ambulance
	} else {
		PicShow("Jumper"+eval(sequence)+"", jumperPre[sequence].src);   // show jumpre on next position
		PicShow("AmbuLight", nullPre.src);	  // hide the flash light on the ambulance
	};
	demoID = window.setTimeout("Demo()", 1000);	// next step after a second  
};

// if firemen missed a jumper
function Failed () {
	PlaySound("missed_", vlm);	// sound missed jumper hitting ground
	PicShow("Miss"+eval(4-life)+"", missPre.src);	// next pic of angel per missed jumper in top right corner
	PicShow("Fallen"+eval(missed)+"", fallenPre[missed].src);	// pic of missed jumper hitting ground
	life--; // one life less
	AllStop();	  // stop game if playing and reset all ID's
	if (JumpersPresent()<1) {	// if no jumper present
		jumperPresent[0] = 1;	// new jumper appeares
		jumperGap = JumperGap();	// calculate gap before next jumper appeares
	};
	pause = true;	// pause the game during miss indications
};

// next move of flame animation
function FlamesGo () {
	AllFireShow();	  // show all fire flames
	PicShow("Fire"+eval(fireSec)+"", nullPre.src);		// hide the flame on "fireSec" position
	if (fireSec<3) fireSec++		// next sequence for the flames on top of the building
	else fireSec = 1;		// or back in starting position
	flamesID = window.setTimeout("FlamesGo()", flamesSpeed);	// next step in flamesSpeed milliseconds
};

// present game A & its high score
function GameA () {
	if (game!=1 && game!=2) {   // if not already game A or B playing
		GameSet(); // variables reset
		gameSpeed = 200;	   // in milliseconds
		gameSpeedMax = 120;	// maximum speed for game sequence timer
		HighScoreShow(1);	   // show highest score for game a
	};
};

// present game B & its high score
function GameB () {
	if (game!=1 && game!=2) {   // if not already game A or B playing
		GameSet(); // variables reset
		gameSpeed = 130;	   // in milliseconds
		gameSpeedMax = 130;	// maximum speed for game sequence timer
		HighScoreShow(2);	  // show highest score for game b
	};
};

// next move of game
function GameGo () {
	if (!pause) {
		if (sequence<3) sequence++	  // next group of jumpers to move
		else sequence = 1;	  // or back to first group of jumpers to move
		JumpersMove();  // move this group of jumpers
		JumpersShow();  // show moved jumpers
	};
	gameID = window.setTimeout("GameGo()", gameSpeed);	// next step in gameSpeed milliseconds
};

// resume game after missed jumper
function GameGoNext () {
	CaughtReset(missed);		// reset jumper catch indications @ last missed position
	if (game==1||game==2) {	 // if game a or b running
		if (gameID) {
			clearTimeout(gameID);	// reset ID for next step to prevent double call
			gameID = null;
		};
		if (life>0) {   // if at least one life left
			AllFallenHide();	// hide previous fallen jumpers
			gameID = window.setTimeout("GameGo()", gameSpeed);	// next step in gameSpeed milliseconds
		} else demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	};
};

// common settings games
function GameSet () {
	PlaySound("click_", vlm);	// click sound for push button
	ResetAll();	// reset all screen settings
	// variables reset
	jumperGap = 22;	 // first gap between jumpers set @ maximum
	jumperPresent[0] = 1;	// first jumper set
	life = 3;	// number of lives left
	missed = false;	 // no jumper missed
	PicShow("Ambu", nullPre.src);	   // hide ambulance (for a second)
	pos = 1;	// firemen start @ first position ready to catch first jumper
	score = 0;  // reset score
	MainPicturesGame();	// set game to start situation according to settings
};

// determint how big the gap is gonna be between jumpers
function JumperGap () {
	var jumperGapMaxCalc;	// maximum calculated jumper gap refference
	// calculate hundreds over fivehundred in score
	fiveHundredTopper = (Math.floor((score%1000)/100)-4)<0?0:((Math.floor((score%1000)/100)-4));
	jumperGapMaxCalc = 10 - game - fiveHundredTopper - Math.floor(score%100/35);		// determin maximum gap between jumpers
	jumperGapMax = (jumperGapMaxCalc<jumperGapMin?jumperGapMin:jumperGapMaxCalc);	   // stay above the minimum
	if ((game==1&&score%100<5&&score<600) || (game==2&&score<3))  {	 // if time for all jumpers off the screen
		newJumperGap = 22;
	} else {
		newJumperGap = Math.floor(jumperGapMax*Math.random()+2);		// randomise gap between 2 and calculated maximum
	};
	return newJumperGap;
};

// jumpers moving up one position
function JumpersMove () {
	var jumperGapRef;	// first calculated referrence for jumperGep
	jumpersMoved = 0;	// no jumpers moved @ catching point
	if (score==0&&!JumpersPresent()) PicShow("Ambu", ambuPre.src);	   // show ambulance é start game
	if (!pause) {
		switch (sequence) {	// determin which part jumpers to move @ this sequence between building-catch_positions-ambulance
			case 1 :
				first = 0;
				last = 5;
				break;
			case 2 : 
				first = 13;
				last = 19;
				break;
			case 3 :
				first = 5;
				last = 13;
				break;
			default:
		};
		for (i=last ; i>first ; i--) { // from last to first of part jumpers
			var x = (last==5?i+19:26);	// for jumper positions after firemen position 3 (move same sequence as pos 0-5)
			if (jumperPresent[i-1]) jumpersMoved++;	 // add jumper if present before position 20 to move 
			if (jumperPresent[x-1] && x<25) jumpersMoved++;	 // add jumper if present after position 19 to move 
			if (i==(first+1)&&jumperPresent[first]) {	// if jumper @ catch position 1 or 2 is about to move
				// if firemen too late
				if ((first==5&&!caught[1])||(first==13&&!caught[2])) {
					jumperPresent[i] = 0;	// no jumper @ the next position because he fell
					missed = (first==5?1:first==13?2:3); // determin the position where a jumper was missed
				// if firemen caught jumper
				} else {
					jumperPresent[i] = jumperPresent[(i-1)];	// if firemen not too late, jumper moves on
					missed = 0;	// no "miss" position
				};
			} else jumperPresent[i] = jumperPresent[(i-1)];	// copy from previous jumper state
			if (x>0 && (x==(20)&&jumperPresent[19])) {	// if jumper @ catch position 3 is about to move 
				// if firemen too late
				if (!caught[3]) {
					jumperPresent[x] = 0;	//	no jumper @ next place because he fell
					missed = 3; // miss @ 3th place
				// if firemen caught jumper
				} else {
					jumperPresent[x] = jumperPresent[(x-1)];	// move jumper x-1 to x
					missed = 0;	// no "miss" position
				};
			} else jumperPresent[x] = jumperPresent[(x-1)];	// if firemen not too late, jumper moves on
			if (jumperPresent[23]) {	// if moving jumper is @ end of sequence
				if (x==23) {	// if time to move last jumper
					PicShow("AmbuLight", ambuLightPre.src);	// show flash light on ambulance
					ScoreAdd(1);	// one point earned for safely rescuing the jumper all the way to the ambulance
				};
			} else {
				PicShow("AmbuLight", nullPre.src);	// hide flash light on ambulance
			};
		};
		if ((jumperGap==0) || ((JumpersPresent()<1)&&score>4)) {	// if there's no gap between jumpers or only one jumpers after 4 points
			if (JumpersPresent()<maxJumpersPresent) {   // if more jumpers allowed @ the time
				jumperPresent[0] = 1;	// add one jumper
				jumperGap = JumperGap();		// calculate standard gap before new jumper added
			} else {
				if (game==1&&score>350) {	   // if score more than 350 @ game A
					jumperGap = Math.floor((17-game-fiveHundredTopper)*Math.random()) + 2;	  // calculate alternate gap before new jumper added (minimum 2 = & space inbetween)
				} else {
					jumperGapRef = JumperGap()-Math.floor(score%1000/100)-1;	  // calculate alternate gap refference before new jumper added
					jumperGap = (jumperGapRef<2?2:jumperGapRef);		// alternate gap before new jumper added no less than 2
				};
			};
		};
		jumperPresent[first] = 0;	   // first jumper is gone bacause he moved to next position
		if (last==5) jumperPresent[19] = 0;
		if (jumpersMoved) {	// if jumpers moved @ catching point check if there are jumpers caughed or missed
			// if firemen @ right place @ right time
			if (jumperPresent[last]&&((last==5&&pos==1)||(last==13&&pos==2)||(last==19&&pos==3))) {
				caught[(last==5?1:last==13?2:3)] = true;	// indicate the position of the caught jumper
				if (!missed) PlaySound("catch_", vlm);	//	sound jumper bounce
			// if firemen NOT @ right place @ NOT the right time
			} else {
				caught[(last==5?1:last==13?2:3)] = false;		// indicate the position of the fallen jumper
				if (!missed) PlaySound("fall_", vlm);	// sound fallen jumper
			}
			if (missed) {	// jumper not caught by firemen
				Failed();	// if firemen missed a jumper
				gameID = window.setTimeout("GameGoNext()", (gameSpeed*10));		// go on with game in gameSpeed x 10 milliseconds
			};
		};
	};
	if (sequence==1) {
		jumperGap--;	// # start sequence decrease gap because of position 0 not visible
	};
};

// count the number of jumpers present
function JumpersPresent () {
	var jumpersPresent = 0;	 // none counted
	for (j=1 ; j<23 ; j++) {	// check the whole jumper sequence & count the present
		if (jumperPresent[j]) jumpersPresent++;
	};
	if (missed && (jumpersPresent>0)) jumpersPresent--; // don't count the missed jumpers
	return jumpersPresent;
};

// button pressed to play game A
function MainGameA () {
	if (demo) {
		demo = false;		// once this key is hit, the demo is turned off
		if (demoID) {   // prevent demo from restarting if planned
			clearTimeout(demoID);
			demoID = null;
		};
	};
	GameA();	// present game A & its high score
};

// "game A" button released so actually play game A
function MainGameAGo () {
	if (game!=1 && game!=2) {   // if not already game A or B playing
		game = 1; // game A
		pause = false;
		ScoreShow(score);
		gameID = window.setTimeout("GameGo()", 500);	// start next game step in half a second
		flamesID = window.setTimeout("FlamesGo()", flamesSpeed);	// next step in flamesSpeed milliseconds
	};
};

// button pressed to play game B
function MainGameB () {
	if (demo) {
		demo = false;		// once this key is hit, the demo is turned off
		if (demoID) {   // prevent demo from restarting if planned
			clearTimeout(demoID);
			demoID = null;
		};
	};
	GameB();	// present game B & its high score
};

// "game B" button released so actually play game B
function MainGameBGo () {
	if (game!=1 && game!=2) {   // if not already game A or B playing
		game = 2; // game B
		ScoreShow(score);
		pause = false;
		gameID = window.setTimeout("GameGo()", 500);	// start next game step in half a second
		flamesID = window.setTimeout("FlamesGo()", flamesSpeed);	// next step in flamesSpeed milliseconds
	};
};

// stop game if running + clear all
function MainGameOver () {
	AllStop();  // stop game if playing and reset all ID's
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

// show leading zeroes
function n(n){
	return n>9?""+n:"0"+n;
};

// add certain points to score
function ScoreAdd (points) {
	var speed;  // level of speed in/decrease according to score
	var supp;   // speed suppliment
	for (var a=0 ; a<points ; a++) score++;	 // add given number of points to score
	if (game==1) {	  // game A 
		speed = 10;
		if (score%50==0) SpeedUp(speed); // speed up every 50 points;
	} else {	// game B
		speed = -5;	 // slow down
		if (score%100==0) {	 // every 100 points
			if (Math.floor(score/100)%2==0) supp = 15   // every 200 points invrease speed extra
			else if (score==100) supp = 0  // no speed suppliment
				else supp = -5; // slow down if not @ 100 points
		} else {
			if ((score%1000==5)||(score%1000==10)) {	// @ 5 or 10 points every 1000
				if (score>999) supp = (score-score%1000)/200 // 5 x number of thousends in score
				else supp = 0;  // no speed suppliment
			} else if (score%1000==20||(score%1000==30&&score>1000)) supp = 0	// @ 20 or 30 (+1000) points every 1000
				else speed = 0; // no speed change
		};
		if (speed) {	// if speed change
			speed += supp;	  // add speed suppliment
			SpeedUp(speed); // speedup game with "speed" value;
		};
	};
	ScoreShow(score);   // show current score
	highScore[game] = (((highScore[game]>score))?highScore[game]:score);		// if current score higheer than recorded, record
	if (score==15||score%10) SetMaxJumpersPresent();	// determin maximum jumpers present every 10 & @15 point
};

// determin max numbers of jumpers present @ once according to score
function SetMaxJumpersPresent () {
	if (game==1) {	  // for gamen A
		if ((score%1000)<15) maxJumpersPresent = 2
		else if ((score%1000)<180) maxJumpersPresent = 3
			else if ((score%1000)<330) maxJumpersPresent = 4
				else if ((score%1000)<480) maxJumpersPresent = 5
					else if ((score%1000)<650) maxJumpersPresent = 6
						else if ((score%1000)<850) maxJumpersPresent = 7
							else maxJumpersPresent = 8;
	} else {	// for game B
		if ((score%1000)<10) maxJumpersPresent = 2
		else if ((score%1000)<70) maxJumpersPresent = 3
			else if ((score%1000)<100) maxJumpersPresent = 4
				else if ((score%1000)<350) maxJumpersPresent = 5
					else if ((score%1000)<500) maxJumpersPresent = 6
						else if ((score%1000)<700) maxJumpersPresent = 7
							else maxJumpersPresent = 8;
		maxJumpersPresent += ((score-score%1000)/1000); // add one every 1000 points
	};
}

// speeds up the game with given value & staying below maximum speed
function SpeedUp (speed) {
	if ((game==1)&&((gameSpeed>gameSpeedMax)||(speed<0))) gameSpeed = (gameSpeed-speed<gameSpeedMax)?gameSpeedMax:(gameSpeed-speed); // if not @ max speed, speed up
	if (game==2) gameSpeed -= speed; // patternised speed in scoreAdd()
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions