/*------------------------------------------------------------------time------------------------------------------------------------------*/

var timeID;   // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
  
//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// "time" is pressed, stop all and show time
function MainTime () {
  if (gameID) {
    clearTimeout(gameID);  // stop the game if running
    gameID = null;
  };
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (!demo) {    // if MainTimes demo not yet running 
    AllPicturesClear();    // hide all figures
    ResetAll();  // clear all pictures & variables
    StopAllSound();
    PlaySound("click_wav", vlm);  // click sound for push button
    if (!TKeyPressed) MainTimeStart(); // show current time & demo if auto started
  };
  AlarmShow();    // show alarm indication
  AlarmShowNum();  // show alarm time
};
  
// show current time & demo
function MainTimeStart () {
  if (!demo) {    // if MainTimes demo not yet running 
    demo = true;   // to show demo
    game = 4;  // clock running
    alarmSetting = false;    // alarm is not being set
    TimeShow();  // show current time
    Demo();   // run demo
  };
};

// get current time
function Time () {
  today = new Date();
  hour = today.getHours();
  min = today.getMinutes();
  sec = today.getSeconds();
};

// stop showing current time
function TimerReset () {
  if (timeID) {  // if time running
    clearTimeout(timeID);  // stop time timer
    timeID = null;  // reset time ID
  };
};

// show current time
function TimeShow () {
  TimerReset();    // stop showing current time
  Time();  // get current time
  if (!$('#ButTime:active').length&&!TKeyPressed) {  // if time button no longer pressed (else show alarm time)
    TimeShowOnScreen(min, hour);  // show the current time
  }; 
  timeID = window.setTimeout("TimeShow()", 1000);   // next second...
};

// show required time and indicators on screen from parameters
function TimeShowOnScreen(min, hour) {
  // set integer to time digits
  if (hour<10) PicShow("Num1", nullPre.src)
  else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
  PicShow("Num2", numPre[(hour%10)+1].src);
  PicShow("Num3", numPre[Math.floor(min/10)+1].src);
  PicShow("Num4", numPre[(min%10)+1].src);
  PicShow("NumColon", numColonPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions

