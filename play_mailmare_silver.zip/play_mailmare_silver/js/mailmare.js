//Product:  Mailmare HTML - Silver Screen (Nintendo) Simulator
//Version:  1.1
//Started:  06.10.2025
//Last update:  07.01.2026
//Author:  Flyzy (Joeri Thys)
//Original G&W:  Nintendo Co. Ltd
//Credits:
//Programming  :                                           Joeri Thys ( Flyzy ) 
//Design :                                                      Glimglam
//Layout and artwork :                                   Glimglam, Nintendo & Joeri Thys ( Flyzy ) 
//                                                                   Based on scans by Sean Riddle

// || \\


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var blinkSpeed = 500;    // blinking speed for bonus
var blinkID;    // ID for timeout blinking score

var box = new Array();
for (num=1 ; num<7 ; num++) box[eval(num)] = 0;
var boxDir = new Array();
var boxMiss = 0;

var game = 0;    // 0-no game-all pictures; 1-gameA; 2-gameB; 3-game over; 4-clock; 
var gameID;    // ID for timeout game sequence
var gameResetID;
var gameSpeedMinimum = 550;  // minimum speed for game sequence
var gameSpeedMaximum = 250;    // maximum speed for game sequence
var gameSpeed;    // speed for game sequence

var life = 3;
var miss;    // number of lives left
var missID;    // ID for miss animation
var missSequence;    // sequence for miss animation
var ponyFlyDir = "Right";    // direction of flying pony
var ponyFlyPos = 1;    // position of flying pony
var pos;    // position of catching pony

var AKeyPressed = false;    // indicates if a previoushit "of the game A" keyboard key was already pressed to avoid double entries
var BKeyPressed = false;    // indicates if a previoushit of the "game B" keyboard key was already pressed to avoid double entries
var keyLeftPressed = false;
var keyRightPressed = false;
var keyPressed = false;  // indicates if a previouskey was already pressed to avoid double entries
var TKeyPressed = false;  // indicates if a previoustime key was already pressed to avoid double entries
var WKeyPressed = false;   // indicates if a previoushit of the "ALARM" key was already pressed to avoid double entries

var zoomed = 1;    // default screen auto adapted to window size

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables


// Disable Double-Tap Zoom on Mobile Browser
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$('.no-zoom').bind('touchend', function(e) {
  e.preventDefault();
  // no code here. 
  $(this).click();
  // This line still calls the standard click event, in case the user needs to interact with the element that is being clicked on, but still avoids zooming in cases of double clicking.
});

document.addEventListener('dblclick', function(event) {
    event.preventDefault();
}, { passive: false });

(function($) {  // IOS
  $.fn.nodoubletapzoom = function() {
    $(this).bind('touchstart', function preventZoom(e) {
      var t2 = e.timeStamp
        , t1 = $(this).data('lastTouch') || t2
        , dt = t2 - t1
        , fingers = e.originalEvent.touches.length;
      $(this).data('lastTouch', t2);
      if (!dt || dt > 500 || fingers > 1) return; // not double-tap
      e.preventDefault(); // double tap - prevent the zoom
      // also synthesize click events we just swallowed up
      $(this).trigger('click').trigger('click');
    });
  };
})(jQuery);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// End Disable Double-Tap Zoom on Mobile Browser


//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
  codeCurrent = e.keyCode;    // for reading names & game keys
  e.preventDefault();    // prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
  switch (e.key) {
    case "1": case"a": case"A":   // if "1", "a" or "A" pressed
      document.images['Game A'].src = 'img/case/buttons/butset_in.png';
      if (!keyPressed) MainGameA(); // play Game A
      keyPressed = true;
      break;
    case "2": case"b": case"B":   // if "2", "b" or "B" pressed
      document.images['Game B'].src = 'img/case/buttons/butset_in.png';
      if (!keyPressed) MainGameB(); // play Game B
      keyPressed = true;
      break;
    case "d": case "D": case "ArrowLeft":  // left keys
      // show left button pressed
      document.images['Move Left'].src = 'img/case/buttons/curl_in.png';   
      LeftPressed();    // function to move left
      keyPressed = true;
      break;
    case "k": case "K": case "ArrowRight":  // right keys
      // show right button pressed
      document.images['Move Right'].src = 'img/case/buttons/curr_in.png';   
      RightPressed();   // function to move right
      keyPressed = true;
      break;
    case"r": case"R":   // if "r" or "R" pressed
      // show acl button pressed
      document.images['aclButton'].src = 'img/case/buttons/acl_push.png';
      TotalReset(); // show full sprites
      break;
    case"t": case"T":   // if "t" or "T" pressed
      // show time button pressed
      document.images['Time'].src = 'img/case/buttons/butset_in.png';
      TKeyPressed = true;
      MainTime();     // "time" is pressed, stop all and show time
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button pressed
      document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
      if (!keyPressed&&/*!RKeyPressed&&*/!TKeyPressed&&!WKeyPressed) MainAlarm(); // set alarm if no other key pressed
      WKeyPressed = true;   // indicates if a previoushit of the "ALARM" key was already pressed to avoid double entries
      break;
    // test case buttons
    case "+":  // "+"-numpadkey
      if (vlm<1) {
        vlm = (parseFloat(vlm) + 0.01).toFixed(2);  // increase volume for test purposes
        preVlm = vlm;    // remember set volume
        if (vlm==0.01)  SetSound(true);  // show sound turned on if previous turned off
      };
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "-":  // "-"-key
      if (vlm>0) {
        vlm = (parseFloat(vlm) - 0.01).toFixed(2);  // decrease volume for test purposes
        preVlm = vlm;    // remember set volume
      };
      if (vlm==0) SetSound(false);  // show sound turned off
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "/":  // "/"-key
      if (vlm==0.3) vlm = 0.03
      else vlm = 0.3;
      PrefSoundShow();  // show volume indicator on screen for testing purposes if set
      break;
    case "g": case "G":   // if "g" or "G" pressed
      // swich sound on/off for testing purposes
      PrefSound();
      break
    case "n": case "N":   // if "v" or "N" pressed
      // hide/show sound switch for testing purposes
      SoundSwitch();
      break
    case "@": case String.fromCharCode(233):  // mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
      prefSoundShow = !prefSoundShow;
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case ")": case String.fromCharCode(219):
      zoomed = zoomed?0:1;
      $(function () {
        CheckSizeZoom();
        $('#divWrap').css('visibility', 'visible');
      });
      $(window).resize(CheckSizeZoom);
      break;
    default:
  };
  // console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function (e) {
  // game and arrow keys
  switch (e.key) {
    case "1": case"a": case"A":   // if "1", "a" or "A" released
      document.images['Game A'].src = 'img/case/buttons/butset.png'; 
      MainGameAGo(); // play Game A
      keyPressed = false;
      break;
    case "2": case"b": case"B":   // if "2", "b" or "B" released
      MainGameBGo(); // play Game B
      document.images['Game B'].src = 'img/case/buttons/butset.png';
      keyPressed = false;
      break;
    case "d": case "D": case "ArrowLeft":  // left key released
      // show left button default
      document.images['Move Left'].src = 'img/case/buttons/curl.png';   
      keyPressed = false;
      break;
    case "k": case "K": case "ArrowRight":  // right key released
      // show right button default
      document.images['Move Right'].src = 'img/case/buttons/curr.png';   
      keyPressed = false;
      break;
    case"r": case"R":   // if "r" or "R" pressed
      document.images['aclButton'].src = 'img/case/buttons/acl.png';   // show acl button default
      break;
    case"t": case"T":   // if "t" or "T" released
      document.images['Time'].src = 'img/case/buttons/butset.png';
      TKeyPressed = false;
      MainTimeStart();    // show current time & demo
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button default
      document.images['Alarm'].src = 'img/case/buttons/acl.png';
      WKeyPressed = false;   // indicates if a previous hit of the "ALARM" key was already pressed to avoid double entries
      break;
    default:
  };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly


// if reviewing this tab, refresh screen
$(window).focus(function(){
  //focus log code
  console.log("---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          %c SCREEN REFRESHED ! %c",
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:turquoise; color:blue; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:green; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:purple; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "     ---");   // color test
});

//when page loaded focus on game 
$(document).ready(function () {
  $(function () {
    CheckSizeZoom();
    $('#divWrap').css('visibility', 'visible');
  });
  $(window).resize(CheckSizeZoom);
  $("#game").focus(); // get focus on the game
  PicPreload();  // this function preloads all images according to the blur setting
  TotalReset();  // set game to standard settings and show all figures
  console.log("\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39 --- %c "+today+" %c --- %c welcome to this Game & Watch simmulator, have fun! ", 
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:lime; color:orangered; font-weight:bold;",
        " ---");   // color test
  SoundSwitch();    // hide sound switch
});


//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// actually go to the left
function GoLeft () {
  if (pos>1) {  // if not totally left
    PlaySound("pony_move_wav", vlm);
    posPrev = pos;  // remember current position
    PicShow("PonyCatch"+pos+"", nullPre.src);    // hide catching pony @ previous position
    pos--;  // go position to the left
    PicShow("PonyCatch"+pos+"", ponyCatchPre[pos].src);    // show catching pony @ new position
  };
};

// actually go to the right
function GoRight () {
  if (pos<4) {  // if not totally right
    PlaySound("pony_move_wav", vlm);
    posPrev = pos;    // remember current position
    PicShow("PonyCatch"+pos+"", nullPre.src);    // hide catching pony @ previous position
    pos++;  // go position to the right
    PicShow("PonyCatch"+pos+"", ponyCatchPre[pos].src);    // show catching pony @ new position
  };
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
  if (game==1||game==2) {  // if game playing
    GoLeft();  // go position to the left
  } else {
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmHour++;  // add an from hour alarm setting
      if (prefAlarmHour==24) prefAlarmHour = 0;  // addng an hour to 23 gets 0
      AlarmShowNum();  // show alarm time
    };
  };
};

// left button or -key pressed
function LeftPressed () {
  if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) { // if game still running or alarm being set
    Left();  // go left @ game or change alarm hour or minutes if alarm is being set
    keyPressed = true;
  };
};

// make an array
function MakeArray (size) {
  this.length = size;
  for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
  if (name) document.images[id].src = name;  // if picture given assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
  if (game==1||game==2) {  // if game playing
    GoRight ();  // go position to the right
  } else {
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmMin++;  // add a minute to alarm time
      if (prefAlarmMin==60) prefAlarmMin=0;  // adding a minute to 59 gets 0
      AlarmShowNum();  // show alarm time
    };
  };
};

// right button or -key pressed
function RightPressed () {
  if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) {  // if game still running or alarm being set
    Right();  // go right @ game or change alarm hour or minutes if alarm is being set
    keyPressed = true;
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions


//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// hide all figures
function AllPicturesClear () {
  MainPicturesClear();  // hide all main figures  
  PicShow("AlarmStateInd", nullPre.src);   // bell hide sounding alarm 
  PicShow("NumColon", nullPre.src);    // hide time separator
  PicShow("Game1", nullPre.src);    // hide game A indicator
  PicShow("Game2", nullPre.src);    // hide game B indicator
  for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);    // hide miss indications
  PicShow("MissText", nullPre.src);    // hide miss text
  for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);    // hide the nuimbers
};

// show all figures
function AllPicturesShow () {
  MainPicturesShow();    // show all main figures
  PicShow("AlarmStateInd", bellFullPre.src);   // bell show full sounding alarm
  PicShow("NumColon", numColonPre.src);    // show time separator
  PicShow("Game1", gamePre[1].src);    // show game A indicator
  PicShow("Game2", gamePre[2].src);    // show game B indicator
  for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);    // show miss indication
  PicShow("MissText", misstextPre.src);    // show miss text
  for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);    // "8"
};

// hide all main figures
function MainPicturesClear () {
  PicShow("BoxMiss1Glass", nullPre.src);    // hide broken glass of first crashed box
  PicShow("BoxDropped1", nullPre.src);    // hide left dropped boxes
  PicShow("BoxDropped2", nullPre.src);    // hide right dropped boxes
  BoxesHideAll()    // hide the falling boxes
  for (i=1 ; i<5 ; i++) PicShow("Pony"+eval(i)+"", nullPre.src);    // hide the wandering ponies
  for (i=1 ; i<5 ; i++) PicShow("PonyCatch"+eval(i)+"", nullPre.src);    // hide the catching ponies
  for (i=1 ; i<6 ; i++) PicShow("PonyFly"+eval(i)+"", nullPre.src);    // hide the flying ponies
  PicShow("PonyFlyMissLeft", nullPre.src);    // hide the flying pony @ left miss side
  PicShow("PonyFlyMissRight", nullPre.src);    // hide the flying pony @ right miss side
  PicShow("PonyHit1", nullPre.src);    // hide the left hit pony
  PicShow("PonyHit2", nullPre.src);    // hide the right hit pony
  PicShow("PonyWhistle", nullPre.src);    // hide the whistling pony
};

// show all figures
function MainPicturesShow () {
  for (i=1 ; i<6 ; i++) PicShow("BoxMiss"+eval(i)+"", boxMissPre[i].src);    // show the miss boxes
  PicShow("BoxMiss1Glass", boxMiss1GlassPre.src);    // show broken glass of first crashed box
  PicShow("BoxDropped1", boxDroppedPre);    // show left dropped boxes
  PicShow("BoxDropped2", boxDroppedPre);    // show right dropped boxes
  BoxesShowAll()     // show the falling boxes
  PoniesShow();    // show the wandering ponies
  for (i=1 ; i<5 ; i++) PicShow("PonyCatch"+eval(i)+"", ponyCatchPre[i].src);    // show the catching ponies
  for (i=1 ; i<6 ; i++) PicShow("PonyFly"+eval(i)+"", ((i<2|| i>4)?ponyFlyPre[i].src:(i%2)?ponyFlyFullPre1.src:ponyFlyFullPre2.src));    // show the flying ponies
  PicShow("PonyFlyMissLeft", ponyFlyMissLeftFullPre.src);    // show the flying pony @ left miss side
  PicShow("PonyFlyMissRight", ponyFlyMissRightFullPre.src);    // show the flying pony @ right miss side
  PicShow("PonyHit1", ponyHitPre1Full.src);    // show the left hit pony
  PicShow("PonyHit2", ponyHitPre2Full.src);    // show the right hit pony
  PicShow("PonyWhistle", ponyWhistleFullPre.src);    // show the whistling pony
};

// this function preloads all images
function PicPreload () {
  alarmStateIndPre = new Image();  // left bell for indicating alarm
  alarmStateIndPre.src = "img/screen/bell_ind.png";
  bellDownPre = new Image();  // bell right, stick down sounding alarm
  bellDownPre.src = "img/screen/bell_down.png";
  bellFullPre = new Image();  // bell full alarm pictures
  bellFullPre.src = "img/screen/bell_full.png";
  bellIndPre = new Image();  // bell indicating alarm
  bellIndPre.src = "img/screen/bell_ind.png";
  bellPonyPre = new Image();  // bell pony 
  bellPonyPre.src = "img/screen/bell_pony.png";
  bellUpPre = new Image();  // bell left, stick up sounding alarm
  bellUpPre.src = "img/screen/bell_up.png";
  boxMissPre = new Array();
  for (i=1 ; i<6 ; i++) {    // to show crashing boxes
    boxMissPre[i] = new Image();
    boxMissPre[i].src = "img/screen/box_miss_"+eval(i)+".png";
  };
  boxMiss1GlassPre = new Image();    // to show broken glass of first crashed box
  boxMiss1GlassPre.src = "img/screen/box_miss_1_glass.png";
  boxDroppedPre = new Image();  // to show the dropped boxes
  boxDroppedPre =  "img/screen/box_dropped.png";
  // all falling boxes
  boxPre = new Array();
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<5 ; j++) {     // the rows
      boxPre[eval(i*10+j)] = new Image();
      boxPre[eval(i*10+j)].src =  "img/screen/box"+eval(i*10+j)+".png";
    };
  };
  ponyPre = new Array();    
  for (i=1 ; i<5 ; i++) {
    ponyPre[i] = new Image();  // to show the wandering ponies
    ponyPre[i].src = "img/screen/pony_"+eval(i)+".png";
  };
  pony4DrinkPre = new Image();  // to show fourth wandering pony drinking
  pony4DrinkPre.src = "img/screen/pony_4_drink.png";
  ponyCatchPre = new Array();
  for (i=1 ; i<5 ; i++) {
    ponyCatchPre[i] = new Image();  // to show the catching ponies
    ponyCatchPre[i].src = "img/screen/pony_catch_"+eval(i)+".png";
  };
  ponyFlyFullPre1 = new Image();  // to show the full flying ponies
  ponyFlyFullPre1.src = "img/screen/pony_fly_full_1.png";
  ponyFlyFullPre2 = new Image();  // to show the full flying ponies, wings in opposite directions
  ponyFlyFullPre2.src = "img/screen/pony_fly_full_2.png";
  ponyFlyPre = new Array();
  ponyFlyPre[1] = new Image();  // to show the flying pony left
  ponyFlyPre[1].src = "img/screen/pony_fly_1.png";
  ponyFlyPre[5] = new Image();  // to show the flyng pony right
  ponyFlyPre[5].src = "img/screen/pony_fly_5.png";
  ponyFlyLeftDownPre = new Image();  // to show the left flying ponies, wings down
  ponyFlyLeftDownPre.src = "img/screen/pony_fly_left_down.png";
  ponyFlyLeftUpPre = new Image();  // to show the left flying ponies, wings up
  ponyFlyLeftUpPre.src = "img/screen/pony_fly_left_up.png";
  ponyFlyMissLeftPre = new Image();  // to show flying pony @ left miss position
  ponyFlyMissLeftPre.src = "img/screen/pony_fly_miss_left.png";
  ponyFlyMissLeftFullPre = new Image();  // to showfull flying pony @ left miss position
  ponyFlyMissLeftFullPre.src = "img/screen/pony_fly_miss_left_full.png";
  ponyFlyMissRightPre = new Image();  // to show flying pony @ right miss position
  ponyFlyMissRightPre.src = "img/screen/pony_fly_miss_right.png";
  ponyFlyMissRightFullPre = new Image();  // to show full flying pony @ right miss position
  ponyFlyMissRightFullPre.src = "img/screen/pony_fly_miss_right_full.png";
  ponyFlyRightDownPre = new Image();  // to show the right flying ponies, wings down
  ponyFlyRightDownPre.src = "img/screen/pony_fly_right_down.png";
  ponyFlyRightUpPre = new Image();  // to show the right flying ponies, wings up
  ponyFlyRightUpPre.src = "img/screen/pony_fly_right_up.png";
  ponyHitPre1 = new Image();  // to show the left hit pony
  ponyHitPre1.src = "img/screen/pony_hit_1.png";
  ponyHitPre1Full = new Image();  // to show full left hit pony
  ponyHitPre1Full.src = "img/screen/pony_hit_1_full.png";
  ponyHitPre2 = new Image();  // to show the right hit pony
  ponyHitPre2.src = "img/screen/pony_hit_2.png";
  ponyHitPre2Full = new Image();  // to show full right pony
  ponyHitPre2Full.src = "img/screen/pony_hit_2_full.png";
  ponyWhistlePre = new Image();  // to show the whistlng pony
  ponyWhistlePre.src = "img/screen/pony_whistle.png";
  ponyWhistleFullPre = new Image();  // to show full whistling ponies
  ponyWhistleFullPre.src = "img/screen/pony_whistle_full.png";
  gamePre = new Array();
  for (i=1 ; i<3 ; i++) {
    gamePre[i] = new Image();  // to show which game is playing, a or b
    gamePre[i].src = "img/screen/game"+eval(i)+".png";
  };
  inlayPre = new Image();
  inlayPre.src = "img/screen/inlay.png";  // to show the colored background
  missPre = new Image();  // to show the missed boxes
  missPre.src = "img/screen/miss_box.png"; 
  misstextPre = new Image();  // text "MISS" 
  misstextPre.src = "img/screen/miss.png";
  nullPre = new Image();  // empty picture to hide any figure
  nullPre.src = "img/null.gif";
  numPre = new Array();   // to show the 10 numbers
  for (i=1 ; i<11 ; i++) {
    numPre[i] = new Image();
    numPre[i].src = "img/screen/num"+eval(i-1)+".png";
  };
  numColonPre = new Image();  // to show time splitter colon
  numColonPre.src = "img/screen/num_colon.png";
  soundOnPre = new Image();  // to show sound button in on-state
  soundOnPre.src = "img/case/buttons/butOn"+".png";
  soundOffPre = new Image();  // to show sound button in off-state
  soundOffPre.src = "img/case/buttons/butOff"+".png";
};

// show all wandering ponies
function PoniesShow () {
  for (i=1 ; i<5 ; i++) PicShow("Pony"+eval(i)+"", ponyPre[i].src);
};

// show flying pony @ current position
function PonyFlyShow (flyPos) {
  if (!flyPos) flyPos = ponyFlyPos;    // if no given fly position use preset fly position
  for (i=1 ; i<6 ; i++) PicShow("PonyFly"+eval(i)+"", nullPre.src);    // hide all flying ponies
  PicShow("PonyFly"+eval(flyPos)+"", ((flyPos<2||flyPos>4)?ponyFlyPre[flyPos].src:(!(flyPos%2))?"img/screen/pony_fly_"+((ponyFlyDir=="Left")?"left_down":"right_up")+".png":"img/screen/pony_fly_"+((ponyFlyDir=="Left")?"left_up":"right_down")+".png"));    // show flying pony @ current place
};

// blink fourth wandering pony drinking
function PonyHitBlink (blinkPlace) {
  blinkPlace-=1;
  if (blinkID) { // if  blinking triggered
    clearTimeout(blinkID);  // stop blink timer 
    blinkID = null;  // reset blink ID 
  };
  if (blinkPlace) {
    PicShow("Pony"+eval(blinkPlace)+"", nullPre.src);    // hide the wandering pony
    blinkID = window.setTimeout('PicShow("Pony'+eval(blinkPlace)+'", ponyPre['+blinkPlace+'].src);', blinkSpeed);    // show drinking pony after blink speed time
  } else {
    PicShow("BoxMiss1", nullPre.src);    // hide broken glass of first crashed box
    blinkID = window.setTimeout('PicShow("BoxMiss1", boxMissPre[1].src);', blinkSpeed);    // show drinking pony after blink speed time
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them


//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// stop game & demo animation id's
function AllStop () {
  if (blinkID) { // if  blinking triggered
    clearTimeout(blinkID);  // stop blink timer 1
    blinkID = null;  // reset blink ID 1
  };
  if (demoID) {     // if demo was planned or running
    window.clearTimeout(demoID);  // stop demo sequence from starting (again)
    demoID = null;  // reset demo ID
  };
  if (gameID) {     // if game was planned or running
    clearTimeout(gameID);  // stop the game
    gameID = null;  // reset game ID
  };
  if (missID) {     // if game was planned or running
    clearTimeout(missID);  // stop the game
    missID = null;  // reset game ID
  };
  if (timeID) {     // if game was planned or running
    clearTimeout(timeID);  // stop the game
    timeID = null;  // reset game ID
  };
};

// reset game parameters
function GameReset () {
  if (gameID) {     // if game was planned or running
    clearTimeout(gameID);  // stop the game
    gameID = null;  // reset game ID
  };
  for (num=1 ; num<7 ; num++) if (box[eval(num)]>14||(game!=1&&game!=2)) box[eval(num)] = 0;    // clear falling boxes but leave first row if game playing
  boxMIss = 0;    // no missed box yet
  missSequence = 0;    // start of miss animation
  pause = false;
};

// remove all misses & "MISS" text
function MissClear () {
  miss = 0;    // reset misses
  MissHide();    // hide number of misses
  MissTextHide ();    // hide miss text
};

// reset all screen settings
function ResetAll () {
  AllStop();    // stop game & demo animation
  GameReset();    // reset game parameters
  TimerReset();    // stop showing current time
};

// reset speed according to the current score
function SpeedReset () {
  gameSpeed = gameSpeedMinimum - Math.round(score%1000/5) - Math.floor(score/50) - Math.floor(score/1000);    // calculate
  if (gameSpeed<gameSpeedMaximum) gameSpeed = gameSpeedMaximum;    // no faster than maximum speed
};

// "ACL" is pressed to clear any game and reset all on going to default and show all figures
function TotalReset () {
  game = 0;    // acl, no game, all pictures
  ResetAll();    // reset all screen settings
  AllPicturesShow();  // show all main figures
  demo = 0;    // indicates if demo is running or not
  if (demoID) {     // if demo was planned or running
    window.clearTimeout(demoID);  // stop demo sequence from starting (again)
    demoID = null;  // reset demo ID
  };
  demoID = window.setTimeout("MainTime()", 120000);  // start demo after 2 minutes  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions


//show/hide different pieces of the game
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// check & show highest score on screen
function HighScoreShow (game) {
  pause = true;
  highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
  ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

//Show game starting situation on screen
function MainPicturesGame () {
  PicShow("Game"+game+"", gamePre[game].src);    // show game A/B indicator
  PicShow("PonyCatch"+pos+"", ponyCatchPre[pos].src);    // show catching pony @ current place
  PoniesShow();    // show the wandering ponies
  PonyFlyShow(ponyFlyPos);    // show flying pony @ current position
  ScoreShow(score);    // show current score on screen
};

// show the manual on screen
function ManualShow () {
  document.location.href="manual/mailmare_silver_manual.pdf";
}
// hide misses
function MissHide () {
  for (var i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);   // number of possible misses hiding
};

// show misses
function MissShow () {
  for (var i=1 ; i<4 ; i++) {    // number of possible misses
    if (i<=miss) PicShow("Miss"+eval(i)+"", missPre.src)
    else  PicShow("Miss"+eval(i)+"", nullPre.src);
  };
};

// hide "MISS" text
function MissTextHide () {
  PicShow("MissText", nullPre.src);
};

// show "MISS" text
function MissTextShow () {
  PicShow("MissText", misstextPre.src);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end show different pieces of the game


//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// let flying pony drop a box
function BoxDrop () {
  var dropDone = 0;    // no box dropped yet
  switch (ponyFlyPos) {   // check if position of flying pony allows to drop a box
    case 2 :  // flying pony @ second place
      if (ponyFlyDir=="Left"&&game==2) {    // if pony flying to the left @ game b running because of bounce
        box[boxNum] = 11;    // dropped box @ first position
        boxDir[boxNum] = ponyFlyDir;    // dropped box gets same direction as flying pony
        dropDone++;    // state box was dropped
      } ;
      break;
    case 3 :     // flying pony @ third place
      if (ponyFlyDir=="Right") {    // if pony flying to the right
        box[boxNum] = 11;    // dropped box @ first position
      } else {
        box[boxNum] = 12    // dropped box @ second position
        // else dropDone = -1;
      };
      boxDir[boxNum] = ponyFlyDir;    // dropped box gets same direction as flying pony
      dropDone++;    // state box was dropped
      break;
    case 4 :     // flying pony @ fourth place
      if (ponyFlyDir=="Right") {    // if pony flying to the right
        box[boxNum] = 12;    // dropped box @ second position
      } else {
        box[boxNum] = 13;    // dropped box @ third position
      };
      boxDir[boxNum] = ponyFlyDir;    // dropped box gets same direction as flying pony
      dropDone++;    // state box was dropped
      break;
    case 5 :     // flying pony @ fifth place
      if (ponyFlyDir=="Right"&&game==2) {    // if pony flying to the right and game b running because of bounce
        box[boxNum] = 13;    // dropped box @ third position
        boxDir[boxNum] = ponyFlyDir;    // dropped box gets same direction as flying pony
        dropDone++;    // state box was dropped
      };      
      break;
    default:
      break;
  };
  BoxesShow();    // show current boxes present
  if (dropDone) {    // if a box dropped
    if (boxNum<7) boxNum++    // prepare next box variable for next dropping box
    else boxNum = 1;     // prepare first box variable for next dropping box
  };
};

// let boxes go one position down
function BoxesGo () {
  BoxesMove();  // box falling
  if (sequence==2) {    // every other move
    if (gameSpeed>350) SpeedUp(2)  // let box fall much faster
    else SpeedUp(1);  // let box fall faster
  };
};

// hide all falling boxes
function BoxesHide () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<5 ; j++) {     // the rows
      PicShow("Box"+eval(i*10+j)+"", nullPre.src);   // hide present dropping box
    };
  };
};

// hide all falling boxes
function BoxesHideAll () {
  for (i=1 ; i<6 ; i++) PicShow("BoxMiss"+eval(i)+"", nullPre.src);    // hide the miss boxes
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<5 ; j++) {     // the rows
      PicShow("Box"+eval(i*10+j)+"", nullPre.src);   // hide present dropping box
    };
  };
};

// hide all fallen missed boxes
function BoxesHideMissed () {
  if (boxMiss) {
    PicShow("BoxMiss"+eval(boxMiss)+"", nullPre.src);    // hide the missed box
    boxMiss = 0;    // reset miss
  };
};

// boxes falling
function BoxesMove () {
  boxMIss = 0;    // no missed box yet
  BoxesHideMissed();    // hide all fallen missed boxes
  for (boxNumb=1 ; boxNumb<7 ; boxNumb++) {
    if (box[boxNumb]) {
        switch (box[boxNumb]) {    // evaluate place of falling box
          case 11 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 22;
            } else {
              box[boxNumb] = 21;
            } ;
            break;
          case 12 : 
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 23;
            } else {
              box[boxNumb] = 22;
            };
            break;
          case 13 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 24;
            } else {
              box[boxNumb] = 23;
            };
            break;
          case 21 :
            box[boxNumb] = 31;    // set next position to box
            boxDir[boxNumb] = "Right";    // change direction of this box after bounce
            break;
          case 22 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 32;
            } else {
              box[boxNumb] = 31;
            };
            break;
          case 23 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 33;
            } else {
              box[boxNumb] = 32;
            };
            break;
          case 24 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 34;
            } else {
              box[boxNumb] = 33;
            };
            break;
          case 31 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 42;
            } else {
              box[boxNumb] = 41;
            } ;
            break;
          case 32 :
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 43;
            } else {
              box[boxNumb] = 42;
            };
            break;
          case 33 : 
            // set next position to box according to direction
            if (boxDir[boxNumb]=="Right") {
              box[boxNumb] = 44;
            } else {
              box[boxNumb] = 43;
            };
            break;
          case 34 :
            box[boxNumb] = 44;    // set next position to box
            boxDir[boxNumb] = "Left";    // change direction of this box after bounce
            break;         
          case 41 :
            if (pos==1) {    // if catching pony @ same place
            	  ScoreAdd(1);    // add point to score
            } else {
              miss++;    // add miss
              // calculate miss position according to direction
              if (boxDir[boxNumb]=="Right") {
                boxMiss = 2;
              } else {
                boxMiss = 1;
              };
              Miss(boxMiss);    // miss calculated place
            };
            box[boxNumb] = 0;    // hide last box @ previous place
            break;
          case 42 :
            if (pos==2) {    // if catching pony @ same place
            	  ScoreAdd(1);    // add point to score
            } else {
              miss++;    // add miss
              // calculate miss position according to direction
              if (boxDir[boxNumb]=="Right") {
                boxMiss = 3;
              } else {
                boxMiss = 2;
              };
              Miss(boxMiss);    // miss calculated place
            };
            box[boxNumb] = 0;    // hide last box @ previous place
            break;
          case 43 : 
            if (pos==3) {    // if catching pony @ same place
            	  ScoreAdd(1);    // add point to score
            } else {
              miss++;    // add miss
              // calculate miss position according to direction
              if (boxDir[boxNumb]=="Right") {
                boxMiss = 4;
              } else {
                boxMiss = 3;
              };
              Miss(boxMiss);    // miss calculated place
            };
            box[boxNumb] = 0;    // hide last box @ previous place
            break;
          case 44 : 
            if (pos==4) {    // if catching pony @ same place
            	  ScoreAdd(1);    // add point to score
            } else {
              miss++;    // add miss
              // calculate miss position according to direction
              if (boxDir[boxNumb]=="Right") {
                boxMiss = 5;
              } else {
                boxMiss = 4;
              };
              Miss(boxMiss);    // miss calculated place
            };
            box[boxNumb] = 0;    // reset last box for re-use
            break;
        default:
          break;
      };    
    };
  };
  BoxesShow();    // show current boxes present
};

// check how many box are falling
function BoxesPresent () {
  var presentV = 0;    // no present boxes counted yet
  for (place=1 ; place<7 ; place++) {    // if box present
    if (box[place]) presentV++;    // count box
  };
  return presentV;   // return the counted number of falling box
};

// show current falling boxes present
function BoxesShow () {
  BoxesHideAll();    // hide boxes @ previous place
  for (boxNumbr=1 ; boxNumbr<7 ; boxNumbr++) {
    if (box[boxNumbr]) {
      PicShow("Box"+eval(box[boxNumbr])+"", boxPre[eval(box[boxNumbr])].src);   // show present dropping box
    };
  };
  if (boxMiss) PicShow("BoxMiss"+eval(boxMiss)+"", boxMissPre[boxMiss].src);    // show the miss box @ miss place
};

// show all falling boxes
function BoxesShowAll () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<5 ; j++) {     // the rows
      PicShow("Box"+eval(i*10+j)+"", boxPre[eval(i*10+j)].src);   // show present dropping box
    };
  };
};

// set game A
function GameA () {
  if (game!=1 && game!=2) {    // if no game playing yet
    GameSet();    // common game settings
    gameSpeed = gameSpeedMinimum;  // speed for game sequence
  };
};

// set game B
function GameB () {
  if (game!=1 && game!=2) {    // if no game playing yet
    GameSet();    // common game settings
    gameSpeed = gameSpeedMinimum;  // speed for game sequence
  };
};

// initiate game
function GameGo () {
  var boxRandom;    // randomise dropping of a box
  var boxesPresent = BoxesPresent();    // chech if there are still boxes falling
  if (game!=3&&!pause) {    // if not game over
    if (score<200) boxRandom =  getRandomInt(game+1)    // randomise dropping of a box according to game slower first 200 points
    else boxRandom =  getRandomInt(game+2);    // randomise dropping of a box according to game faster after 200 points
    if (gameID) {     // if game was planned or running
      clearTimeout(gameID);  // stop the game
      gameID = null;  // reset game ID
    };
    BoxesGo();    // let boxes go one position down
    PonyFlyGo();    // let flying pony move to next position
    if (boxRandom||!BoxesPresent()) {    // if random drop or no falling boxes present
      BoxDrop();    // let flying pony drop a box
    };
    if (sequence==1) PicShow("Pony4", pony4DrinkPre.src);    // drinking pony starts dringing @ beginning of cycle
    if (sequence==4) PicShow("Pony4", ponyPre[4].src);    // drinking pony stops dringing @ fourth sequence of cycle
    if (sequence<7) sequence++    // next sequence if not end of cycle
    else sequence = 1;    // else reset cycle
    gameID = window.setTimeout("GameGo()", gameSpeed);   // if not game over keep game going
  };
};

// resume game
function GameGoNext () {
  if (missID) {     // if game was planned or running
    clearTimeout(missID);  // stop the game
    missID = null;  // reset game ID
  };
  GameReset();    // reset game parameters
  MissShow();    // show currens number of misses
  PoniesShow();    // show all wandering en drinking ponies
  PicShow("PonyCatch"+pos+"", ponyCatchPre[pos].src);    // show catching pony @ current position
  gameID = window.setTimeout("GameGo()", 100);   // start next game step in 100 milliseconds
};

// common game settings
function GameSet () {
  ResetAll();  // reset all screen settings
  AllPicturesClear();  // hide all main figures
  boxNum = 1;    // first falling box
  HighScoreShow(game);    // show highest score for game a or b
  miss = 0;    // no misses yet
  missSequence = 0;    // start of miss animation
  ponyFlyPos = 1;    // flying pony starts @ first position
  pos = 2;    // catching pony starts @ second position
  score = 0;    // no score yet
  sequence = 1;   // start sequence of flying pony
};

// get random number from 0 to max
function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

// button pressed to play game A
function MainGameA () {
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (demoID) {     // if demo was planned or running
      window.clearTimeout(demoID);  // stop demo sequence from starting (again)
      demoID = null;  // reset demo ID
    };
    demo = false;    // once this key is hit, the demo is turned off
    ResetAll();  // reset all screen settings
    GameA();    // set paarameters for game A
  };
};

// "game A" button released so actually play game A
function MainGameAGo () {
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (gameID) {     // if game was planned or running
      clearTimeout(gameID);  // stop the game
      gameID = null;  // reset game ID
    };
    game = 1; // game A
    MainPicturesGame();  // show game starting situation 
    pause = false;
    gameID = window.setTimeout("GameGo()", 500);  // start next game step in half a second
  };
};

// button pressed to play game B
function MainGameB () {
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (demoID) {     // if demo was planned or running
      window.clearTimeout(demoID);  // stop demo sequence from starting (again)
      demoID = null;  // reset demo ID
    };
    demo = false;    // once this key is hit, the demo is turned off
    gameSpeedMinimum-=50;    // game B goes faster
    ResetAll();  // reset all screen settings
    GameB();    // set parameters for game B
  };
};

// "game B" button released so actually play game B
function MainGameBGo () {
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (gameID) {     // if game was planned or running
      clearTimeout(gameID);  // stop the game
      gameID = null;  // reset game ID
    };
    game = 2; // game B
    MainPicturesGame();  // show game starting situation 
    pause = false;
    gameID = window.setTimeout("GameGo()", 500);  // start next game step in half a second
  };
};

// stop demo if running + clear all
function MainGameOver () {
  ResetAll();  // reset all screen settings
  game = 3; // game over indication
  if (demoID) {     // if demo was planned or running
    window.clearTimeout(demoID);  // stop demo sequence from starting (again)
    demoID = null;  // reset demo ID
  };
  MissShow();    // show currens number of misses
  PlaySound("game_over_wav", vlm);
  demoID = window.setTimeout("MainTime()", 120000);    // start demo & show current time in two minutes
};

// show miss animation
function Miss (missPos) {  
  if (game==1||game==2) {    // pause game if running
    pause = true;
  };
  if (missID) {     // if game was planned or running
    clearTimeout(missID);  // stop the game
    missID = null;  // reset game ID
  };
  switch (missSequence) {
    case 1 :     // 
      PonyHitBlink(missPos);    // let hit pony blink once
      PlaySound("pony_hit_wav", vlm);
      break;
    case 2 :     // 
      PonyHitBlink(missPos);    // let hit pony blink once
      PlaySound("pony_hit_wav", vlm);
      break;
    case 3 :     // 
      PlaySound("pony_hit_wav", vlm);
      for (i=1 ; i<6 ; i++) PicShow("PonyFly"+eval(i)+"", nullPre.src);    // hide flying pony
      PicShow("BoxMiss"+eval(missPos)+"", nullPre.src);    // hide hitting box
      if (missPos>1) {    // if not window got hit
        PicShow("Pony"+eval(missPos-1)+"", nullPre.src);    // hide hit pony
        if (missPos<4) {
          PicShow("PonyFlyMissLeft", ponyFlyMissLeftPre.src);    // if one of first three ponies got hit, show flying pony panicking @ the right
          PicShow("BoxDropped1", boxDroppedPre);    // if one of first three ponies got hit, show fallen box @ the left
        } else {
          PicShow("PonyFlyMissRight", ponyFlyMissRightPre.src);    // else, show flying pony panicking @ the right
          PicShow("BoxDropped2", boxDroppedPre);    // else, show fallen box @ the right
        };
        if (missPos<5) PicShow("PonyHit1", ponyHitPre1.src);    // if drinking pony got hit, show second hit pony
        else PicShow("PonyHit2", ponyHitPre2.src);    // else, show second hit pony
      } else {    // if window got hit
        PicShow("BoxMiss1", nullPre.src);    // hide broken glass of first crashed box
        PicShow("BoxMiss1Glass", boxMiss1GlassPre.src);    // show glass from first box hitting window
        PicShow("PonyWhistle", ponyWhistlePre.src);    // show the whistling pony
      };
      break;
    case 4 :     // 
      PlaySound("pony_yell_wav", vlm);
      if (missPos>1) {    // if not window got hit
        if (missPos<4) {
          PicShow("PonyFlyMissLeft", ponyFlyMissLeftFullPre.src);    // if one of first three ponies got hit, show flying pony full panicking @ the right
        } else {
          PicShow("PonyFlyMissRight", ponyFlyMissRightFullPre.src);    // else, show flying pony full panicking @ the right
        };
        if (missPos<5) PicShow("PonyHit1", ponyHitPre1Full.src);    // if drinking pony got hit, show full second hit pony
        else PicShow("PonyHit2", ponyHitPre2Full.src);    // else, show second hit pony
      } else {    // if window got hit
        PicShow("BoxMiss1Glass", nullPre.src);    // hide glass from first box hitting window
        PicShow("PonyWhistle", ponyWhistleFullPre.src);    // show the whistling pony
      };
      break;
    case 5 :     // 
      if (missPos>1) {    // if not window got hit
        if (missPos<4) {
          PicShow("PonyFlyMissLeft", ponyFlyMissLeftPre.src);    // if one of first three ponies got hit, show flying pony panicking @ the right
        } else {
          PicShow("PonyFlyMissRight", ponyFlyMissRightPre.src);    // else, show flying pony panicking @ the right
        };
        if (missPos<5) PicShow("PonyHit1", ponyHitPre1.src);    // if drinking pony got hit, show second hit pony
        else PicShow("PonyHit2", ponyHitPre2.src);    // else, show second hit pony
      } else {    // if window got hit
        PicShow("BoxMiss1Glass", boxMiss1GlassPre.src);    // show glass from first box hitting window
        PicShow("PonyWhistle", ponyWhistlePre.src);    // show the whistling pony
      };
      break;
    case 6 :     // 
      PlaySound("pony_yell_wav", vlm);
      if (missPos>1) {    // if not window got hit
        if (missPos<4) {
          PicShow("PonyFlyMissLeft", ponyFlyMissLeftFullPre.src);    // if one of first three ponies got hit, show flying pony full panicking @ the right
        } else {
          PicShow("PonyFlyMissRight", ponyFlyMissRightFullPre.src);    // else, show flying pony full panicking @ the right
        };
        if (missPos<5) PicShow("PonyHit1", ponyHitPre1Full.src);    // if drinking pony got hit, show full second hit pony
        else PicShow("PonyHit2", ponyHitPre2Full.src);    // else, show second hit pony
      } else {    // if window got hit
        PicShow("BoxMiss1Glass", nullPre.src);    // hide glass from first box hitting window
        PicShow("PonyWhistle", ponyWhistleFullPre.src);    // show the whistling pony
      };
      break;
    case 7 :     // 
      if (miss<3) MainPicturesClear();    // clear screen if not game over
      break;
    default:
      break;
  };
  missSequence++;    // next animation sequence
  if (missSequence<8) {
    missID = window.setTimeout("Miss("+missPos+")", 1000)    // continue if not finished
  } else {
    if (game==1||game==2) {    // if game A or B running
      if (miss<3) GameGoNext()    // continue game if less than three misses
      else MainGameOver();    // else stop game
    };
  };
};

// let flying pony move to next position
function PonyFlyGo() {
  if (ponyFlyDir=="Right") {    // if pony going right
    if (ponyFlyPos<5) {    // if not @ end range
      ponyFlyPos+=1;    // let flying pony go one position to the right
    } else {
      ponyFlyDir = "Left"    // change direction
      if (game==2) ponyFlyPos-=1;    // let flying pony go one position to the left @ game b
    };
  } else {    // if pony going left
    if (ponyFlyPos>1) {    // if not @ end range
      ponyFlyPos-=1;    // let flying pony go one position to the left
    } else {
      ponyFlyDir = "Right"    // change direction
      if (game==2) ponyFlyPos+=1;    // let flying pony go one position to the right @ game b
    };
  };
  PonyFlyShow(ponyFlyPos);    // show flying pony @ current position
};

// speeds up the game with given value
function SpeedUp (speed) {
  if ((gameSpeed>gameSpeedMaximum) && !demo) gameSpeed -= speed; 
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions
