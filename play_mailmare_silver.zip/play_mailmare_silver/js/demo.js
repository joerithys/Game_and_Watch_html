//demo functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var demo = 0;      // indicates if demo is running or not
var demoID;    // ID for timeout demo autostart after last handling

// start demo
function Demo () {
  StopAllSound();
  GameReset();
  sequence = 0; // sequal of demo
  demo = 1;  // indicates demo is running
  game = 4;  // clock & demo shown
  gameSpeed = 1000;    // demo speed @ 1 second per move
  ponyFlyPos = 1;    // starting position of catching pony
  pos = 2;    // starting position of catching pony
  demoID = window.setTimeout("DemoRun()", gameSpeed);  // next step after a second  
};

// run demo's next move
function DemoRun () {
  var ponyFlyDirVal = (ponyFlyDir=="Left"?-1:1);
  if (demoID){
    clearTimeout(demoID);
    demoID = null;
  }
  if (sequence<24) sequence++
  else sequence = 1;
  switch (sequence) {
    case 1 :   // 
      MainPicturesShow(); 
      break;
    case 2 :  // 
      MainPicturesClear();
      PoniesShow();
      PicShow("Pony4", pony4DrinkPre.src);
      PonyFlyShow(ponyFlyPos);
      PicShow("PonyCatch2", ponyCatchPre[2].src);
      break;
    case 3 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box11", boxPre[11].src);
      break;
    case 4 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box11", nullPre.src);
      PicShow("Box22", boxPre[22].src);
      break;
    case 5 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box13", boxPre[13].src);
      PicShow("Box22", nullPre.src);
      PicShow("Box32", boxPre[32].src);
      PicShow("Pony4", ponyPre[4].src);
      GoRight();
      break;
    case 6 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box13", nullPre.src);
      PicShow("Box32", nullPre.src);
      PicShow("Box24", boxPre[24].src);
      PicShow("Box43", boxPre[43].src);
      break;
    case 7 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box24", nullPre.src);
      PicShow("Box43", nullPre.src);
      PicShow("Box34", boxPre[34].src);
      break;
    case 8 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Pony4", pony4DrinkPre.src);
      PicShow("Box34", nullPre.src);
      PicShow("Box12", boxPre[12].src);
      PicShow("Box44", boxPre[44].src);
      GoRight();
      break;
    case 9 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box12", nullPre.src);
      PicShow("Box44", nullPre.src);
      PicShow("Box11", boxPre[11].src);
      PicShow("Box22", boxPre[22].src);
      GoLeft();
      break;
    case 10 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box11", nullPre.src);
      PicShow("Box22", nullPre.src);
      PicShow("Box21", boxPre[21].src);
      PicShow("Box31", boxPre[31].src);
      GoLeft();
      break;
    case 11 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box21", nullPre.src);
      PicShow("Box41", boxPre[41].src);
      PicShow("Pony4", ponyPre[4].src);
      GoLeft();
      break;
    case 12 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box31", nullPre.src);
      PicShow("Box41", nullPre.src);
      PicShow("Box11", boxPre[11].src);
      PicShow("Box42", boxPre[42].src);
      GoRight();
      break;
    case 13 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box11", nullPre.src);
      PicShow("Box42", nullPre.src);
      PicShow("Box12", boxPre[12].src);
      PicShow("Box22", boxPre[22].src);
      break;
    case 14 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box12", nullPre.src);
      PicShow("Box22", nullPre.src);
      PicShow("Box23", boxPre[23].src);
      PicShow("Box32", boxPre[32].src);
      GoRight();
      break;
    case 15 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Pony4", pony4DrinkPre.src);
      PicShow("Box23", nullPre.src);
      PicShow("Box32", nullPre.src);
      PicShow("Box33", boxPre[33].src);
      PicShow("Box43", boxPre[43].src);
      break;
    case 16 :     // n
      PonyFlyShow(ponyFlyPos);
      PicShow("Box33", nullPre.src);
      PicShow("Box43", nullPre.src);
      PicShow("Box44", boxPre[44].src);
     break;
    case 17 :     // 
      PonyFlyShow(ponyFlyPos);
      PicShow("Box44", nullPre.src);
      PicShow("BoxMiss5", boxMissPre[5].src);
      GoRight();
      break;
    case 18 :     // 
      missSequence = 1;
      Miss(5);
      break;
    case 24 :     // 
      pos = 2;
      ponyFlyPos = 0;    // position of flying pony
      break;
    default:
      break;
  };
  if ((ponyFlyPos+ponyFlyDirVal)<6&&(ponyFlyPos+ponyFlyDirVal)>0) ponyFlyPos+=ponyFlyDirVal    // 
  else {
    ponyFlyDir = ponyFlyDir=="Left"?"Right":"Left";    //
    if (ponyFlyDir=="Right") ponyFlyPos-=ponyFlyDirVal;    //
  };
  demoID = window.setTimeout("DemoRun()", gameSpeed);  // next step after a second  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end figure functions
