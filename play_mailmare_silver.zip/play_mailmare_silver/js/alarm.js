/*------------------------------------------------------------------alarm------------------------------------------------------------------*/

var alarm = false;    // alarm not running
var alarmID;    // ID for alarm ringing animation
var alarmOffID;     // ID to turn alarm off after some time
var alarmOn = false;    // for indication if alarm is set on or off      
var alarmRinging = false;    // to prevent alarm going off again after turning off
var alarmSetting = false;    // if alarm is at set mode to make changes
var prefAlarmMin = 0;    // last saved alarm setting minutes
var prefAlarmHour = 0    // last saved alarm setting hours

//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all alarm settings
function AlarmClear () {
  if (alarmID) {
    clearTimeout(alarmID);   // if alarm was planned or running, stop sequence
    alarmID = null;
  };
  if (alarmOffID) {
    clearTimeout(alarmOffID);   // if alarm was planned or running, stop sequence
    alarmOffID = null;
  };
};

// reset all alarm settings
function AlarmReset () {
  AlarmClear();
  alarm = false;  // alarm not running
  alarmOn = true;   // for indicationif alarm is set on or off      
  alarmRinging = false;  // to prevent alarm going off again after turning off
  alarmSetting = false;     // if alarm is at set mode to make changes
//  alarmSet = "h";   // setting alarm hoors (h) or minutes (m) @ NO cursor +
  alarmSet = "m";   // setting alarm hoors (h) @ cursor +
  prefAlarmMin = 0;  // last saved alarm setting minutes
  prefAlarmHour = 0;  // last saved alarm setting hours
};

// show alarm time & on/off indication
function AlarmShow (ind) {
  if (ind) {
    AlarmShowNum();  // show alarm time
    if (ind=="on") {
      alarmOn = true;
      PicShow("AlarmStateInd",  alarmStateIndPre.src); // show left bell for indicating alarm
    } else {
      alarmOn = false;
      PicShow("AlarmStateInd", nullPre.src); // hide left bell for indicating alarm
    };
  } else {
    if (!alarmOn && game!=9) {
      PicShow("AlarmStateInd", nullPre.src); // hide left bell for indicating alarm
    } else {
      PicShow("AlarmStateInd",  alarmStateIndPre.src); // show left bell for indicating alarm
    };
  };
};

// show alarm time setting
function AlarmShowNum () {
  TimeShowOnScreen(prefAlarmMin, prefAlarmHour);  // show required alarm time and indicators on screen
};

// set the alarm
function MainAlarm () {
  AllPicturesClear();  // hide all main figures
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (demoID) {
    clearTimeout(demoID);   // if demo was planned or running, stop sequence
    demoID = null;
  };
  if (!alarmSetting) {
    ResetAll();  // clear all pictures & variables
    alarm = false;  // alarm is not currently running
    keys = 7;  // alarm is been set
    demo = false;    // once the alarm key is hit, the demo is turned off
    PlaySound("click_wav", vlm);  // click sound for push button
    alarmSetting = true;    // alarm is being set
  };
  if (game!=5) {
    game = 5; // set alarm (on)
    AlarmShow("on");  // show alarm time & on indication
    TimeAlarmBackground();  // function runs all the time and checks the alarm on the background
  } else {
    game = 8; // set alarm (off)
    AlarmShow("off");  // show alarm time & off indication
  };  
  demoID = setTimeout("MainTime()", 300000);  // start demo after 5 minutes
};

// check if its time for alarm
function TimeAlarm () {
  Time();  // get current time
  var alarmTime;
  if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) { 
    AlarmClear();
    alarm = true;
    // set start alarm at start next minute
    alarmTime = 60000-(sec*1000);
    // alarm rings at start next minute
    alarmID = setTimeout("TimeAlarmGo()", alarmTime);
    // stop alarm 30 seconds after start
    alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000)); // turn alarm off after half a minute
  };
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
  if (alarmOn) {    
    TimeAlarm();  // check if its time for alarm if alarmOn
    setTimeout("TimeAlarmBackground()", 30000)  ;     // check every half minute
  }; 
};

// alarm rings
function TimeAlarmGo () {
  AlarmClear();
  Time();  // get current time
  if ((sec%2)==1) {  // let bell ring indicator go up and down @ alarm
    PicShow("AlarmStateInd", bellDownPre.src);    // bell right, stick down sounding alarm
    if (game!=1) PlaySoundEvenIfDemo("alarm_wav", vlm);// play sound "name" @ "vol" volume if sound is on, even if demo is playing
  } else {
    PicShow("AlarmStateInd", bellUpPre.src);    // bell left, stick up sounding alarm
  }
  alarmID = setTimeout("TimeAlarmGo()", 1000);    // repeat after a second
};

// turn running alarm off
function TimeAlarmOff () {
  AlarmClear();
  alarm = false;
  if (game==0) {  // if acl show all bell figures
    PicShow("AlarmStateInd", bellFullPre.src);    // bell full alarm pictures
  } else {
    PicShow("AlarmStateInd", nullPre.src);    // no alarm indication
  };
};
//end time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
