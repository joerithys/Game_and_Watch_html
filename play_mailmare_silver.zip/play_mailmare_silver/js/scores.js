/*------------------------------------------------------------------scores------------------------------------------------------------------*/

var highScore = new Array();  // to remember the highest score played for both games since opened in the browser
highScore[1] = 0;    // highest score of game A
highScore[2] = 0;    // highest score of game B
var points;    // resting points to add
var score = 0;  // score (all beneath 100) at init
var scoreBlinkID  // ID for blinking score
var scoreID  // ID for counting score

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// add certain points to score
function ScoreAdd (points) {
  if (game==1||game==2) {    // if game A or B runniong
    if (scoreID) {     // if score count was planned or running
      window.clearTimeout(scoreID);  // stop the score count
      scoreID = null;  // reset score count ID
    };
    if (points) {    // if points needed to be add
      PlaySound("score_add_wav", vlm)  // sound  for adding a point to score   
      score++;    // add point to score
      points--;    // one point less to add
      scoreID = window.setTimeout("ScoreAdd ("+points+");", 85);    // next point to be add
    } else {
      if (score>highScore[game]) highScore[game] = score;     // if passed highscore @ of this game, set new highscore
    };
    ScoreShow(score);    // show current resulted score
  };
};

// let score blink while score over 300 and no miss lost
function ScoreBlink () {
  if (game==1 || game==2) {  // game a or b running
    if (pointsBonus) {    // bonus for reaching 300/500 without any misses
      ScoreHide();    // hide the score
      scoreBlinkID = window.setTimeout("ScoreShow(score)", blinkSpeed);    // show the score
      scoreBlinkID = window.setTimeout("ScoreBlink()", 2*blinkSpeed);    // repeat
    } else ScoreShow(score);    // show the score
  };
};

// hide score from screen
function ScoreHide () {
  $("#Num1").addClass("hidden");
  $("#Num2").addClass("hidden");
  $("#Num3").addClass("hidden");
  $("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
  $("#Num1").removeClass("hidden");
  $("#Num2").removeClass("hidden");
  $("#Num3").removeClass("hidden");
  $("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
  PicShow("NumColon", nullPre.src);    // hide time separator
  if (scoreTS>999)   // first digit
    if (Math.floor((scoreTS/1000)%10)==0) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor((scoreTS/1000)%10)+1].src);
  else PicShow("Num1", nullPre.src);
  if (scoreTS>99)   // secons digit
    if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0) PicShow("Num2", nullPre.src)
    else PicShow("Num2", numPre[Math.floor(scoreTS%1000/100)+1].src);
  else PicShow("Num2", nullPre.src);
  if (scoreTS>9)    // third digit
    if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0  && Math.floor(scoreTS%100/10)==0) PicShow("Num3", nullPre.src)
    else PicShow("Num3", numPre[Math.floor(scoreTS%100/10)+1].src);
  else PicShow("Num3", nullPre.src);
  PicShow("Num4", numPre[(scoreTS%10)+1].src);  // fourth digit
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
