//Product:	Covid19 HTML - Silver Screen (Nintendo) Simulator
//Version:	1.1
//Started:	16.06.2020
//Last update:	08.08.2020
//Author:	Flyzy (Joeri Thys)
//Original G&W:	Nintendo Co. Ltd
//Credits:
//Design, layout and artwork by Lee Robson (hydef)
//Based on scans by Sean Riddle
//Colour background by DarthMarino


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling
var hitting = 0;	// hitting status demo 0:not_hitting - 1:hitting - 2:back

var acl = false;	// for showing acl pictures, all if pressed twice fast
var aclID;	// ID to view all pictures @ fast double click
var color = false;           // indicator to show/hide colored background
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 2-gameB; 3-game-over; 4-clock; 
var gameID;	// ID for timeout game sequence
var gameResetID;        // ID for return hit hammer after 0,3 sec stationary
var gameSpeedMaximum = 300;	// maximum speed for game sequence timer
var gameSpeed;	// speed for game sequence timer
var hitID;      // for small hitting delay, enough to first show arm up when hitting after move
var life = 3;   // number of lives left
var missedID;   //      ID for crawling back timing after missed mole
var missed;     //      indicating missed mole, game paused, no hitting popssible
var molePresent = new Array();  // array of first places of rows to check if mole is present @ any row
var moleHit = false;    // indicates if a surfaced mole is hit
var moleHitID;  //	ID to reset the row when mole is hit or 
var moleHittablePos;    // mole to be hit left or right of the man
var molesAtOnce;        // normal sequence of max number of moles allowed to surface @ once
var molesAtOnceGame;        // actual game sequence of max number of moles allowed to surface @ once
var molesPresent;   // indicates hoiw many moles currently moving
var moleSurfaced;       // indicates if a mole has surfaced
var pause = false;	
var pauseID;	// ID to pause the game temporarily (pause stopper)
var pos;        // position man
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var keyLeft = false;
var keyRight = false;
var keyPressed = false;	// indicates if a previuos key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var highScore = new Array();	// for highest scores for games a & b
var score = 0;	// score (all beneath 100) at init
var scorePrev;	// score (all beneath 100) at init

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables


//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading names & game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "e": case "E": case "ArrowLeft":	// left key
            // show left upper button pressed
            document.images['Move Left'].src = 'img/case/buttons/left_flat.png';     
            Left();    // if no key already pressed go left
            keyPressed = true;
            break;
        case "o": case "O": case "ArrowRight":	// right key
            // show right upper button pressed
            document.images['Move Right'].src = 'img/case/buttons/right_flat.png';     
            Right();    // if no key already pressed show right arm up
            keyPressed = true;
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game a button pressed
            document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';     
            if (!keyPressed) MainGameA(); // play Game A
            keyPressed = true;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" pressed
            // show game b button pressed
            document.images['Game B'].src = 'img/case/buttons/grey_2_flat.png';     
            if (!keyPressed) MainGameB(); // play Game B
            keyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
            document.images['aclButton'].src = 'img/case/buttons/acl_push.png';
            TotalReset(); // show full sprites
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
            MainTime(); // show time & demo
            break;
        //test case buttons
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case String.fromCharCode(233): case "Control" :	// "Ctrl"-key
            color = !color;     // indicator to show/hide colored background
            InlayShow();	// switch background black/color
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "e": case "E": case "ArrowLeft":	// left key released
            // show left upper button default
            document.images['Move Left'].src = 'img/case/buttons/left.png';     
            keyPressed = false;
            break;
        case "o": case "O": case "ArrowRight":	// right key released
            // show right upper button default
            document.images['Move Right'].src = 'img/case/buttons/right.png';     
            keyPressed = false;
            break;
        case "1": case"a": case"A":     // if "2", "b" or "B" released
            document.images['Game A'].src = 'img/case/buttons/grey_1.png';     // show game b button default
            MainGameAGo(); // play Game A
            keyPressed = false;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" released
            document.images['Game B'].src = 'img/case/buttons/grey_2.png';     // show game b button default
            MainGameBGo(); // play Game B
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['aclButton'].src = 'img/case/buttons/acl.png';     // show acl button default
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/grey_3.png';
            break;
        default:
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
    $(function () {
        CheckSizeZoom();
        $('#divWrap').css('visibility', 'visible');
    });
    $(window).resize(CheckSizeZoom);
    $("#game").focus(); // get focus on the game
    PicPreload();	// this function preloads all images to make them ready for use
    MainPicturesShow();	// show default figures
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually go to the left
function GoLeft () {
    if (pos>1) {	// if not totally left
        pos--;	// go position to the left
        ManShow(pos);	// show man @ current position
    };
};

// actually go to the right
function GoRight () {
    if (pos<3) {	// if not totally right
        pos++;	// go position to the right
        ManShow(pos);	// show man @ current position
    };
};

// left button or -key pressed
function Left () {
    if (game==1 || game==2) {	// if game A or B playing
        GoLeft();	// go position to the left
        if (hitID) {
            clearTimeout(hitID);	// reset ID for small hitting delay if exists
            hitID = null;
        };
        if (MoleHittable(pos)=="Left" && !pause) {	// if surfaced mole hittable @ the left of the man
            hitID = window.setTimeout("HitLeft(pos)", 10);	// hit with left hammer
        } else if (MoleHittable(pos)=="Right" && !pause) {	// if surfaced mole hittable @ the right of the man
            hitID = window.setTimeout("HitRight(pos)", 10);	// hit with right hammer
        };
    };
};

// right up button or -key pressed
function Right () {
    if (game==1 || game==2) {	// if game A or B playing
        GoRight ();	// go position to the right
        if (hitID) {
            clearTimeout(hitID);	// reset ID for small hitting delay if exists
            hitID = null;
        };
        if (MoleHittable(pos)=="Left" && !pause) {	// if surfaced mole hittable @ the left of the man
            hitID = window.setTimeout("HitLeft(pos)", 10);	// hit with left hammer
        } else if (MoleHittable(pos)=="Right" && !pause) {	// if surfaced mole hittable @ the right of the man
            hitID = window.setTimeout("HitRight(pos)", 10);	//hit with right hammer
        };
    };
};

// show man @ current position
function ManShow (pos) {
    AllMenHide();
    PicShow("Man"+pos+"", manPre[pos].src);	// show body
    PicShow("LeftArmUp"+pos+"", leftArmUpPre[pos].src);	// show left arm up
    PicShow("RightArmUp"+pos+"", rightArmUpPre[pos].src);	// show right arm up
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;	// if picture given assign it to the figure
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions


//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    inlayPre = new Image();
    inlayPre.src = "img/screen/inlay.png";	// to show building
    inlayColPre = new Image();
    inlayColPre.src = "img/screen/inlay_c.png";	// to show building surrounding in color
    manPre = new Array();
    for (i=1 ; i<4 ; i++) manPre[i] = new Image();
    for (i=1 ; i<4 ; i++) manPre[i].src = "img/screen/man"+eval(i)+".png";	// to show the man's body @ position "i"
    leftArmDownPre = new Array();
    for (i=1 ; i<4 ; i++) leftArmDownPre[i] = new Image();
    for (i=1 ; i<4 ; i++) leftArmDownPre[i].src = "img/screen/leftArmDown"+eval(i)+".png";	// to show the left arm down @ position "i"
    leftArmUpPre = new Array();
    for (i=1 ; i<4 ; i++) leftArmUpPre[i] = new Image();
    for (i=1 ; i<4 ; i++) leftArmUpPre[i].src = "img/screen/leftArmUp"+eval(i)+".png";	// to show the left arm up @ position "i"
    rightArmDownPre = new Array();
    for (i=1 ; i<4 ; i++) rightArmDownPre[i] = new Image();
    for (i=1 ; i<4 ; i++) rightArmDownPre[i].src = "img/screen/rightArmDown"+eval(i)+".png";	// to show the right arm down @ position "i"
    rightArmUpPre = new Array();
    for (i=1 ; i<4 ; i++) rightArmUpPre[i] = new Image();
    for (i=1 ; i<4 ; i++) rightArmUpPre[i].src = "img/screen/rightArmUp"+eval(i)+".png";	// to show the right arm up @ position "i"
    missPre = new Image();
    missPre.src = "img/screen/miss.png";	// to show missed moles
    molePre = new Array();
    moleHillPre = new Array();
    for (i=1 ; i<6 ; i++) { 	// to show the 5 surfaced moles
        molePre[i] = new Image();
        molePre[i].src = "img/screen/mole"+eval(i)+".png";
        for (j=1 ; j<4 ; j++) { 	// to show their according mole hills
            moleHillPre[(i*10+j)] = new Image();
            moleHillPre[(i*10+j)].src = "img/screen/mole"+eval(i)+"Hill"+eval(j)+".png";
        };
    };
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
    soundOnPre = new Image();
    soundOnPre.src = "img/case/buttons/butOn"+".png";	// to show sound button in on-state
    soundOffPre = new Image();
    soundOffPre.src = "img/case/buttons/butOff"+".png";	// to show sound button in off-state
};

// hide all men & arms
function AllMenHide () {
    for (i=1 ; i<4 ; i++) PicShow("Man"+eval(i)+"", nullPre.src);	
    for (i=1 ; i<4 ; i++) PicShow("LeftArmUp"+eval(i)+"", nullPre.src);
    for (i=1 ; i<4 ; i++) PicShow("LeftArmDown"+eval(i)+"", nullPre.src);
    for (i=1 ; i<4 ; i++) PicShow("RightArmUp"+eval(i)+"", nullPre.src);
    for (i=1 ; i<4 ; i++) PicShow("RightArmDown"+eval(i)+"", nullPre.src);
};

// hide all figures
function AllPicturesClear () {
    AllMoleHillsHide();
    AllMenHide();
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
    for (i=1 ; i<6 ; i++) PicShow("Mole"+eval(i)+"", nullPre.src);
    PicShow("NumColon", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// hide all molehills
function AllMoleHillsHide () {
    for (i=1 ; i<6 ; i++) { 	        // the rows
        for (j=1 ; j<4 ; j++) { 	// the lines
            PicShow("Mole"+eval(i)+"Hill"+eval(j)+"", nullPre.src);
        };
    };
};

// show all molehills
function AllMoleHillsShow () {
    for (i=1 ; i<6 ; i++) {		// the rows
        for (j=1 ; j<4 ; j++) { 	// the lines
            PicShow("Mole"+eval(i)+"Hill"+eval(j)+"", moleHillPre[(i*10+j)].src);
        };
    };
};

// show all figures
function AllPicturesShow () {
    AllMoleHillsShow();
    for (i=1 ; i<4 ; i++) PicShow("Man"+eval(i)+"", manPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("LeftArmDown"+eval(i)+"", leftArmDownPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("LeftArmUp"+eval(i)+"", leftArmUpPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("RightArmDown"+eval(i)+"", rightArmDownPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("RightArmUp"+eval(i)+"", rightArmUpPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    for (i=1 ; i<6 ; i++) PicShow("Mole"+eval(i)+"", molePre[i].src);
    PicShow("NumColon", numColonPre.src);	// ":"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
};

// show/hide colored background
function InlayShow () {
    color?PicShow("Inlay", inlayColPre.src):PicShow("Inlay", inlayPre.src);	
};

// show all mole figures, middle man, arms up, and "12:00"
function MainPicturesShow () {
    MainPicturesDefault();	// show man in center holding arms up
    AllMoleHillsShow();
    PicShow("NumColon", numColonPre.src);       // ":"
    PicShow("Num1", numPre[2].src);     // 1
    PicShow("Num2", numPre[3].src);     // 2
    PicShow("Num3", numPre[1].src);     // 0
    PicShow("Num4", numPre[1].src);     // 0
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    for (i=1 ; i<6 ; i++) PicShow("Mole"+eval(i)+"", molePre[i].src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them


//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich sound on/off; dont preload here
function PrefSound () {
    prefSound = !prefSound;
    PrefSoundEval();    // Show sound settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
    if (!prefSound) { // if sound is set to "off" 
        preVlm = vlm;   // remember last sound volume
        vlm = 0;        // set volume to 0
    } else {
        if (preVlm==0) preVlm = 0.01; // if no previous volume, set to minimum
        vlm = preVlm;   // set volume to "on"
    };
    PrefSoundSettings();	// show sound on/off indication
    PrefSoundShow();	// show volume indicator on screen for testing purposes
    PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
    var vlmTxt = "";    // empty sound volume indicator picture
    $("#SoundStateInd").html("");	// empty/hide volume indicator
    if (prefSoundShow) {      // if volume indicator is set to show
        $("#SoundStateIndBkgnd").removeClass("hidden");		
        if (vlm>0.00999) {
            for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
            $("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
        } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    } else {
        $("#SoundStateIndBkgnd").addClass("hidden");
        $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
    if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
    else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// swich sound on/off; dont preload here
function SetSound (setting) {
    prefSound = setting;
    PrefSoundSettings();	// show sound on/off indication
    PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
    StopSound("hit_", vlm);
    StopSound("moleOut_", vlm);
    StopSound("moleMove_", vlm);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions


//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
    GameReset();    // clear gameID, gameResetID & pauseID
    window.clearTimeout(aclID);	// ID for timeout left arm up reset
    aclID = null;
    window.clearTimeout(demoID);	// stop demo from starting (again)
    demoID = null;
    window.clearTimeout(hitID);	// reset ID for small hitting delay if exists
    hitID = null;
    window.clearTimeout(missedID);	// stop any crawling back moles 
    missedID = null;
    window.clearTimeout(moleHitID);	//  stop showing changes or mole hit check after last mole hitting
    moleHitID = null;
    pause = false;
    TimerReset(); // stop the counter to show the current time
};

// clear gameID, gameResetID & pauseID
function GameReset () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop return hit hammer after 0,3 sec stationary
        gameResetID = null;
    };
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause stopper
        pauseID = null;
    };
};

// remove all moles & mole hills
function MolesReset () {
    for (t=1 ; t<6 ; t++) {
        MolesRowReset(t);// remove mole & mole hills from row
    };
    MolesShow();
};

// remove mole & mole hills from row
function MolesRowReset (row) {
    for (u=1 ; u<5 ; u++) {	// from all positions in row
        molePresent[(row*10+u)] = false;	// remove mole/hill from position
    }
    if (game==1 || game==2) {
        if (!MoleHittable(pos)) moleHitID = window.setTimeout("MolesShow()", 300)   // show current moles after 0,3 sec
        else moleHitID = window.setTimeout("MolesShow()", 30);   // show current moles after 0,03 sec if @ other side mole has surfaced
    };
    moleHit = false;
    pause = false;
};

// clear all pictures & variables
function ResetAll () {
    AllStop();  // stop game if playing and reset all ID's
    AllPicturesClear ();        // hide all figures and show timer if game A
    MolesReset();	// remove mole & mole hills from row
    game = 0;   // no-game-all-pictures
    hitting = 0;        // reset demo hitting indicator
    missed = false;
    moleSurfaced = false;       // reset possible surfaced mole
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    ResetAll(); // clear all pictures & variables
    if (acl) AllPicturesShow()    // show all pictures if "acl" clicked twice fast
    else MainPicturesShow(); // show all mole figures, man in the middle, arms up & "12:00" 
    acl = true; // indicates "acl" already clicked
    aclID = window.setTimeout("acl = false;", 130);     // ID to show all pictures if "acl" clicked twice fast
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions


//show/hide score
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// check & show highest score on screen
function HighScoreShow (game) {
    pause = true;
    highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
    ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

// erase score
function ScoreHide () {
    for (var i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// translate current score to the digits on screen
function ScoreShow (score) {
    if (score>999) 
        if (Math.floor((score/1000)%10)==0) PicShow("Num1", nullPre.src)
        else PicShow("Num1", numPre[Math.floor((score/1000)%10)+1].src);
    else PicShow("Num1", nullPre.src);
    if (score>99) 
        if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0) PicShow("Num2", nullPre.src)
        else PicShow("Num2", numPre[Math.floor(score%1000/100)+1].src);
    else PicShow("Num2", nullPre.src);
    if (score>9)  
        if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0  && Math.floor(score%100/10)==0) PicShow("Num3", nullPre.src)
        else PicShow("Num3", numPre[Math.floor(score%100/10)+1].src);
    else PicShow("Num3", nullPre.src);
    PicShow("Num4", numPre[(score%10)+1].src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end show/hide score


//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
    // if not already clock running or to prevent MainTime to run before failed flag_05-sound ended
    if (game!=4) {   
        StopAllSound();
        PlaySound("click_", vlm);	// click sound for push button
        MainTimeStart(); // show current time & demo
    };
};
	
// show current time & demo
function MainTimeStart () {
    ResetAll(); // clear all pictures & variables
    MainPicturesReDefault();	// show default start pictures of Vermin
    demo = true;     // to show demo
    game = 4;	// clock running
    pos = 2;    // middle position man
    TimeShow();	// show current time
    Demo();     // run demo
};

// show current time
function TimeShow () {
    TimerReset(); // stop previuos counter to show the current time to avoid double function run
    Time();	// get current time
    TimeShowOnScreen();
    timeID = window.setTimeout("TimeShow()", 1000);     // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen () {
    // set integer to time digits
    if (hour<10) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
    PicShow("Num2", numPre[(hour%10)+1].src);
    PicShow("Num3", numPre[Math.floor(min/10)+1].src);
    PicShow("Num4", numPre[(min%10)+1].src);
    PicShow("NumColon", numColonPre.src);
};

// get current time
function Time () {
    today = new Date();
    hour = today.getHours();
    min = today.getMinutes();
    sec = today.getSeconds();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions
	
//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show demo
function Demo () {
    if (demoID) {	// if demo still planned to start stop that plan to avoid double run
        clearTimeout(demoID);
        demoID = null;
    };
    if (MolesPresent()) {
        if (hitting==1) {	// arm needs to lift after hit
            window.setTimeout("Lift"+MoleHittable(pos)+"(pos)",0);
            hitting = 0;	// no hitting
            // if surfaced mole is hit, start new one @ the other side
            if (MoleHittable(pos)=="Left") molePresent[51] = true;	
            else molePresent[11] = true;
            MoleHit();	// mole has been hit, define row hit mole & reset that row
        } else {
            if (MoleHittable(pos)) {	// if mole left or right hittable
                window.setTimeout("Hit"+MoleHittable(pos)+"(pos)",0);	// hit with hammer left or right
                hitting++;	// next step is lift hammer again
            } else MolesMove();
        };
    } else molePresent[11] = true;	// start first mole left in the beginning
    MolesShow();
    // automated moves according to position man & surfacing mole
    if (molePresent[12] && !(!molePresent[13] && pos==2)) GoLeft();
    if (molePresent[52] && !(!molePresent[53] && pos==2)) GoRight();
    demoID = window.setTimeout("Demo()", 1000);	// next step after a second  
};

// if mole surfaced without getting hit
function Failed (moleOutRow) {
    if (moleOutRow!=moleHit) {	// if row not previous hit podition to avoid double fail
        missed = true;
        PlaySound("moleOut_", vlm);	// missed mouse came out
        AllStop();      // stop game if playing and reset all ID's
        life--; // one life less
        pause = true;	// pause the game
        Missed(moleOutRow);	// let missed mole crowl back to victory @ add to missed box
    };
};

// play game A
function GameA () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // variables reset
        gameSpeed = 1000;       // in milliseconds
        scorePrev = 9;  // previous set score trigger for moles present sequence
        HighScoreShow(1);       // show highest score for game a
    };
};

// play game B
function GameB () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // variables reset
        gameSpeed = 650;       // in milliseconds
        scorePrev = 6;  // previous set score trigger for moles present sequence
        HighScoreShow(2);       // show highest score for game a
    };
};

// next move of game
function GameGo () {
    var molePos;        // possible position of next upcomming mole
    var molesPresentAtOnce ;
    var newMole = false;        // molePos isn't an actual mole empty position or position 3 @ game a (never a mole there in this game)
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (!pause) {
        PlaySound("moleMove_", vlm);	// mouse moving
        MolesMove();
        molesPresent = MolesPresent();  // to avoid unnessesary multiple function call
        molesPresentAtOnce = MolesPresentAtOnce();      // define how many moles at once allowed
        if ((molesPresentAtOnce>=molesPresent) || !molesPresent) {      // if mole must be added
            do {        // find empty place to set mole
                molePos = Math.floor(5*Math.random())+1;
            } while((molePresent[(molePos*10+1)] || (game==1&&molePos==3)) && !missed);
            if (!missed && !NewMolesDelay()) newMole = true;	// if no mole hit or to be delayed place new mole		
        };
        if (newMole) molePresent[(molePos*10+1)] = true;        // place new mole @ empty place
        MolesShow();
        gameID = window.setTimeout("GameGo()", gameSpeed);    // next step in gameSpeed milliseconds
    };
};

// resume game after missed mole
function GameGoNext () {
    if (hitID) {
        clearTimeout(hitID);	// reset ID for small hitting delay if exists
        hitID = null;
    };
    GameReset(); // clear gameID, gameResetID & pauseID
    molesPresent = MolesPresent();  // to avoid unnessesary multiple function call
    pause = false;      // undo pause
    if (!demo && moleSurfaced) { // if not demo check if not already a mole surfaced
        if (MoleHittable(pos)=="Left") hitID = window.setTimeout("HitLeft(pos)", 10);
        else if (MoleHittable(pos)=="Right")hitID = window.setTimeout("HitRight(pos)", 10);
    };
    gameID = window.setTimeout("GameGo()", gameSpeed);        // go on with game in gameSpeed milliseconds
};

// common settings games
function GameSet () {
    PlaySound("click_", vlm);	// click sound for push button
    ResetAll();	// reset all screen settings
    // variables reset
    life = 3;	// number of lives left
    missed = false;     // no mole missed
    moleHit = false;	// not mole hit
    molesAtOnce = 0;    // no more than 0 moles @ once for new mole to be added
    molesAtOnceGame = 0;
    pos = 2;	// man starts in the middle
    score = 0;  // reset score
    MainPicturesGame();	// set game to start situation 
};

// hit surfaced mole on the left of man
function HitLeft (pos) {
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop previous return hit hammer after 0,3 sec stationary
        gameResetID = null;
    };
    if (hitID) {
        clearTimeout(hitID);	// reset ID for small hitting delay if exists
        hitID = null;
    };
    PicShow("RightArmUp"+eval(pos)+"", rightArmUpPre[pos].src);
    PicShow("RightArmDown"+eval(pos)+"", nullPre.src);
    // lift left arm in case not yet done
    PicShow("LeftArmUp"+eval(pos)+"", nullPre.src);
    PicShow("LeftArmDown"+eval(pos)+"", leftArmDownPre[pos].src);
    if (!demo) MoleHit();	// mole has been hit, define row hit mole & reset that row
};

// hit surfaced mole on the right of man
function HitRight (pos) {
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop previous return hit hammer after 0,3 sec stationary
        gameResetID = null;
    };
    if (hitID) {
        clearTimeout(hitID);	// reset ID for small hitting delay if exists
        hitID = null;
    };
    PicShow("LeftArmUp"+eval(pos)+"", leftArmUpPre[pos].src);
    PicShow("LeftArmDown"+eval(pos)+"", nullPre.src);
    // lift right arm in case not yet done
    PicShow("RightArmUp"+eval(pos)+"", nullPre.src);
    PicShow("RightArmDown"+eval(pos)+"", rightArmDownPre[pos].src);
    if (!demo) MoleHit();	// mole has been hit, define row hit mole & reset that row
};

// lift left arm after hit
function LiftLeft (pos) {
    PicShow("LeftArmUp"+eval(pos)+"", leftArmUpPre[pos].src);
    PicShow("LeftArmDown"+eval(pos)+"", nullPre.src);
};

// lift right arm after hit
function LiftRight (pos) {
    PicShow("RightArmUp"+eval(pos)+"", rightArmUpPre[pos].src);
    PicShow("RightArmDown"+eval(pos)+"", nullPre.src);
};

// button pressed to play game A
function MainGameA () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
        if (demoID) {   // prevent demo from restarting if planned
            clearTimeout(demoID);
            demoID = null;
        };
    };
    GameA();    // play game A
};

// "game A" button released so actually play game A
function MainGameAGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 1; // game A
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// button pressed to play game B
function MainGameB () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
        if (demoID) {   // prevent demo from restarting if planned
            clearTimeout(demoID);
            demoID = null;
        };
    };
    GameB();    // play game B
};

// "game B" button released so actually play game B
function MainGameBGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 2; // game B
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// stop game if running + clear all
function MainGameOver () {
    AllStop();  // stop game if playing and reset all ID's
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

// show default pictures as @ start of the game
function MainPicturesGame () {
    MainPicturesReDefault();	// show man in center holding arms up
    ScoreShow(score);
};

// show man in center holding arms up
function MainPicturesDefault () {
    PicShow("Man2", manPre[2].src);
    PicShow("LeftArmUp2", leftArmUpPre[2].src);
    PicShow("RightArmUp2", rightArmUpPre[2].src);
};

// show man in center holding arms up after clearing all pictures
function MainPicturesReDefault () {
    AllPicturesClear();     // hide all figures
    MainPicturesDefault();      // show man in center holding arms up
};

// missed surfaced mole
function Missed (moleOutRow) {
    pause = true;
    if (missedID) {
        clearTimeout(missedID);	// stop any remaining crawling back moles 
        missedID = null;
    };
    if (molePresent[(moleOutRow*10+4)]) {
        molePresent[(moleOutRow*10+5)] = false;
        molePresent[(moleOutRow*10+4)] = false;
        //      ("Showing Mole row 4 & 5 , line 5 crawling back to missed box...  --  molePresent["+(moleOutRow*10+5)+"] = "+molePresent[(moleOutRow*10+5)]+"  --  molePresent["+(moleOutRow*10+4)+"] = "+molePresent[(moleOutRow*10+4)]);
    } else for (u=1 ; u<4 ; u++) molePresent[(moleOutRow*10+u)] = molePresent[(moleOutRow*10+u+1)];
    MolesShow();  
    PlaySound("moleMove_", vlm);	// mouse moving
    // if still crawling back, repeat, else continue game
    if (molePresent[(moleOutRow*10+1)]) missedID = window.setTimeout("Missed("+moleOutRow+")", 1000)	// next step after a second 
    else {
        MissedShow();	// show missed mole in the box
        if (life>0) missedID = window.setTimeout("GameGoNext()", 1000)	// next step after a second
        else demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute if no lives left
    };
};

// show missed mole in the box
function MissedShow () {
    for (i=1 ; i<(4-life) ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    missed = false;	// reset missed indication to resume or end game
};

// mole has been hit, define row hit mole & reset that row
function MoleHit () {
    // define position row to hit mole
    moleHittablePos = MoleHittable(pos);
    if (moleHittablePos=="Left") row = pos
    else row = pos + 2;
    if (!moleHit && !missed) {
        moleHit = row;	// to check if no double fail
        MolesRowReset(row)	// remove mole & according hills
        if (!demo)  {
            ScoreAdd(1);	// add score and lift arm after 300 ms
            gameResetID = window.setTimeout("Lift"+moleHittablePos+"(pos)", 300);
        };
    };
    PlaySound("hit_", vlm);	// hitting a mouse
    moleHittablePos = false;	// reset indicator
};

// get position of surfacing mole left or right of the man's position
function MoleHittable (pos) {
    var moleHittable = false;
    if (!moleHit) {
        if (molePresent[(pos*10+4)] && !molePresent[(i*10+5)]) moleHittable = "Left";
        if (molePresent[(pos*10+24)] && !molePresent[(i*10+25)]) moleHittable = "Right";
        return moleHittable;
    } else moleHitID = window.setTimeout("MoleHittable(pos)", 10);
};

// gives place where mole surfaced
function MoleOut () {
    var moleOut = false;
    moleSurfaced = false;
    for (i=5 ; i>0 ; i--) { 
        if (molePresent[(i*10+5)]) moleOut = i;         // position of escaped mole
        else if (molePresent[(i*10+4)]) moleSurfaced = i;    // position of surfaced mole
    };
    return moleOut;
};

// moles moving up one position
function MolesMove () {
    var moleOut = false;
    if (!pause) {
        if (hitID) {
            clearTimeout(hitID);	// reset ID for small hitting delay if exists
            hitID = null;
        };
        for (i=5 ; i>0 ; i--) { 
            for (j=5 ; j>1 ; j--) molePresent[(i*10+j)] = molePresent[(i*10+j-1)];	// copy from lower mole state
        };
        if (!demo) {
            moleOut = MoleOut();	// indicates if a mole surfaced
            if (moleOut!=moleHit) {	// if surfaced mole is not hit in time
                AllStop();
                pause = true;
                Failed(moleOut);	// let mole crawl back further to victory
            } else {	// if surfaced mole is to hit left or right
                if (MoleHittable(pos)=="Left") hitID = window.setTimeout("HitLeft(pos)", 100);
                else if (MoleHittable(pos)=="Right")hitID = window.setTimeout("HitRight(pos)", 100);
            };
        };
    };
};

// count the number of moles present
function MolesPresent () {
    var molesPresent = 0;
    for (i=1 ; i<6 ; i++) {
        if (molePresent[(i*10+1)]) molesPresent++;
    };
    if (moleSurfaced) molesPresent--;
    return molesPresent;
};

// define how many moles at once allowed according to moles-present sequence
function MolesPresentAtOnce (){
    if (score==scorePrev) {     // if score reached previous set score trigger
        // shift the moles-present sequence
        if (molesAtOnce<2) molesAtOnce++
        else molesAtOnce = 0;
        scorePrev+=7-(game==2?(molesAtOnce<2?1:2):molesAtOnce); // calculate next previous set score trigger
    };
    molesAtOnceGame = molesAtOnce;      // set moles at once as moles-present sequence for game a
    if ((game==2)&&(score>2)&&(molesAtOnceGame<2)) molesAtOnceGame++;   // recalculate if game b
    return molesAtOnceGame;
};

// show all moles and hills present
function MolesShow () {
    for (i=1 ; i<6 ; i++) { 
        for (j=1 ; j<5 ; j++) { 
            if (j==4)   // moles
                if (molePresent[(i*10+j)]) PicShow("Mole"+eval(i)+"", molePre[i].src);
                else PicShow("Mole"+eval(i)+"", nullPre.src);
            else {	// mole hills
                if (molePresent[(i*10+j)]) PicShow("Mole"+eval(i)+"Hill"+eval(j)+"", moleHillPre[(i*10+j)].src)
                else PicShow("Mole"+eval(i)+"Hill"+eval(j)+"", nullPre.src);
            };
        };
    };	
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// check if 1 mole present & max 2 moles allowed, keep 1 position in between, delay if not
function NewMolesDelay () {
    var moleDelay = true;
    if (molesAtOnceGame==1 && molesPresent) {   // if two moles allowed, and already one present
        for (i=1 ; i<6 ; i++) { 
            // if in a row a mole hill is present half way && not surfaced, no delay necessary
            if (molePresent[(i*10+3)] && !moleSurfaced)  moleDelay = false;
        };
    } else moleDelay = false;
    return moleDelay;    
};

// add certain points to score
function ScoreAdd (points) {
    for (var a=0 ; a<points ; a++) score++;     // add given number of points to score
    if (game==1 && score==10) SpeedUp(350)	// let moles go faster after 10 points @ game a
    else if (score%50==0) {     // every 50 points let moles go faster, depending on current game speed
        if (gameSpeed>500) SpeedUp(100)	// let moles go faster 
        else {
            if (gameSpeed>440) SpeedUp(40)
            else {
                if (gameSpeed>400) SpeedUp(20)
                else {
                    if (gameSpeed>360) SpeedUp(10)
                    else  SpeedUp(5);
                };
            };
        };
    };
    ScoreShow(score);
    highScore[game] = (((highScore[game]>score))?highScore[game]:score);        // if current score higheer than recorded, record
};

// speeds up the game with given value
function SpeedUp (speed) {
    if (gameSpeed>gameSpeedMaximum) gameSpeed -= speed; // if not @ max speed, speed up
};

// stop showing current time
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions