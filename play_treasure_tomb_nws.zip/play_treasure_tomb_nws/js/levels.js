/*------------------------------------------------------------------levels------------------------------------------------------------------*/

var events = new Array();  // for all current events
var eventsCount;  // to count the added events
// var exit;  // to indicate if exit is open or closed
var exitBlockedSpider;   // exit blocked by attacking spider
var gold = new Array();  // for all gold positions
var hero = new Array();  // for all Hero positions
for (i=0 ; i<44 ; i++) {     // the lines
  hero[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    hero[i][j] = 0;
  };
};
var heroPlatform; // indicates HeroPlatform present
var laby = new Array();  // for labyrinth walls (0 = no wall, 1 = wall, 2 = wall with key lock)
for (i=0 ; i<44 ; i++) {     // the lines
  laby[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    laby[i][j] = 0;
  };
};
var lastLine;  // last line of labyrinth
var lastRow;  // last row of labyrinth
var levels = 25;    // number of levels
var line;  // current line of labyrinth
var row;  // current row of labyrinth
var lockHor = new Array();  // for all horizontal lock positions
for (i=0 ; i<44 ; i++) {     // the lines
  lockHor[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    lockHor[i][j] = 0;
  };
};
var lockVert = new Array();  // for all vertical lock positions
for (i=0 ; i<44 ; i++) {     // the lines
  lockVert[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    lockVert[i][j] = 0;
  };
};
var mapActive;    // to indicate the side map is active, you can look around the labyrinth now
var mapReceived;    // to indicate the side map is received
var mapHero;    // to indicate the top map is present to be grabbed by the hero
var moon;    // to indicate the moon is present
var platforms;    // to count the present platforms
var platformActive = new Array();    // indicates platform with certain number is active or not
var platformDir = new Array();    // indicates which direction platform with certain number has
var platformSeq = new Array();    // indicates which sequence platform with certain number has
var posx = 1;        // current horizontal row position hero
var posxLevStart;        // horizontal position row hero @ start of current level or level screen part
var posy = 1;        // current vertical line position hero
var posyLevStart;        // vertical linne position hero @ start of current level or level screen part
var pyramidSmallLine = new Array();    // to indicate a certain small line under the pyramid is present
var posxLever = new Array();  // for all lever row positions
var posyLever = new Array();  // for all lever line positions
var posxPlatform = new Array();  // for all moving platforms row positions
var posyPlatform = new Array();  // for all moving platforms line positions
var posxScorpion = new Array();  // for all scorpion row positions
var posyScorpion = new Array();  // for all scorpion line positions
var scorpions // present scorpions counted
var screenLineSetHero = 0;    // line of laby segment where the hero stays during active map
var screenRowSetHero = 0;    // row of laby segment where the hero stays during active map
var screenLineSetMap;    // line of laby segment where the map appeares
var screenRowSetMap;    // row of laby segment where the map appeares
var screenLineSetSnakeDiamond;    // lineset in which diamond snake is present
var screenLineSetSpiderBig;    // lineset in which exit blocking spider is present
var screenRowSetSnakeDiamond;    // rowset in which diamond snake is present
var screenRowSetSpiderBig;    // rowset in which exit blocking spider is present
var screenLineSetVase = new Array();    //  lineset in which a certain artifact vase is present
var screenRowSetVase = new Array();    // rowset in which a certain artifact vase is present
var snakeDiamond;    // diamond snake present on this level
var snakeDiamondDone;    // diamond snake present on this level defeated
var switchBase = new Array();  // for all switch base positions
for (i=0 ; i<44 ; i++) {     // the lines
  switchBase[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    switchBase[i][j] = 0;
  };
};
var switchDown = new Array();  // for all switch down positions
for (i=0 ; i<44 ; i++) {     // the lines
  switchDown[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    switchDown[i][j] = 0;
  };
};
var switchUp = new Array();  // for all switch up positions
for (i=0 ; i<44 ; i++) {     // the lines
  switchUp[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    switchUp[i][j] = 0;
  };
};
var sun;    // to indicate the sun is present
var vase = new Array();    // to indicate certain vase is present
var vases;    // number of vases present
var vaseArtifact = new Array();    // artifact hidden in certain vase 1=amulet or 2=ankh key
var wallHor = new Array();  // for all horizontal walls positions
for (i=0 ; i<44 ; i++) {     // the lines
  wallHor[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    wallHor[i][j] = 0;
  };
};
var wallVert = new Array();  // for all vertical walls positions
for (i=0 ; i<44 ; i++) {     // the lines
  wallVert[i] = new Array();
  for (j=1 ; j<80 ; j++) {     // the rows
    wallVert[i][j] = 0;
  };
};

// add events for a platform
function AddEvent (posyLever, posxLever, platformNumber1, platformNumber2) {
  eventsCount++;    // nummer of events
  events[eventsCount] = new Array();    // for event parameters
  events[eventsCount][1] = posyLever;    // line position of this lever
  events[eventsCount][2] = posxLever;    // row position of this lever
  events[eventsCount][3] = platformNumber1;    // main platform number to switch
  events[eventsCount][4] = platformNumber2;    // secondary platform number to switch
};

  // put the map in the labyrinth sector with given line & row
function AddMapHero (line,row,received)  {
  screenLineSetMap = line;    // line of laby segment
  screenRowSetMap = row;    // row of laby segment
  mapHero = 1;    // the top map is present to be grabbed by the hero on this level
  mapReceived = received?1:0;    // map received from top or not
};

// add moving platform
function AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive) {
  platforms++;    // count platform
  platformActive[platforms] = pactive;    // indicates if platform is active
  platformDir[platforms] = pdir;    // moving direction for this platform platform
  platformSeq[platforms] = pseq;    // moving sequence for this platform platform
  posxPlatform[platforms] = platx;    // row position for this platform platform
  posyPlatform[platforms] = platy;    // line position for this platform platform
  posxLever[platforms] = levx;    // row lever position for this platform platform
  posyLever[platforms] = levy;    // line lever position for this platform platform
  if (!(laby[platx][platy]% 8>3)) {    // if no horizontal wall present yet
    laby[platx][platy] = eval(laby[platx][platy]) + 4;    // add horizontal wall @ this place
  };
};

// add row to labyrinth
function AddRow (row) {
  const a = row.match(/[^,\s]+/g);     // removes all spaces & commas to be able to determin the row length
  var screenLineSetNew;    // for possible new segment line set
  var screenRowSetNew;    // for possible new segment row set
  lastLine++;  // last line of labyrinth up
  line++;    // current line up
  lastRow = (a.length)>lastRow?(a.length):lastRow;      // last row of labyrinth counting from position 1
  for (j=0 ; j<a.length ; j++) {     // the rows
    laby[line][(j+1)] = a[j];    // add next element from row to line
    if (a[j]%128>63) gold++;    // add gold if present
  };
  screenLineSetNew = parseInt((lastLine-1)/4);    // 4 lines per screen segment for possible new one
  screenRowSetNew = parseInt((lastRow-1)/5);    // 5 rows per screen segment for possible new one
  screenLineSetLast = screenLineSetLast<screenLineSetNew?screenLineSetNew:screenLineSetLast;    // set new segment line set if its bigger than the current one
  screenRowSetLast = screenRowSetLast<screenRowSetNew?screenRowSetNew:screenRowSetLast;    //  set new segment row set if its bigger than the current one
};

// put the diamond snake in the labyrinth sector with given line & row
  function AddSnakeDiamond (line,row) {
  screenLineSetSnakeDiamond = line;    // line of laby segment where present
  screenRowSetSnakeDiamond = row;    // row of laby segment where present
  snakeDiamond = 1;    // diamond snake present on this level
  snakeDiamondDone = 0;    // diamond snake not defeated yet
};

// put the blocking exit spider in the labyrinth sector with given line & row
  function AddSpiderBig (line,row) {
  screenLineSetSpiderBig = line;    // line of laby segment where present
  screenRowSetSpiderBig = row;    // row of laby segment where present
  exitBlockedSpider = 1;    // blocking exit spider present on this level
};

// put the vase in the labyrinth sector with given line & row with 1=amulet or 2=ankh key
function AddVase (line,row,artifact,vaseProgress) {
  vases++;    // new vase added
  vaseArtifact[vases] = artifact;    // set artifact in vase (1=amulet or 2=ankh key)
  screenLineSetVase[vases] = line;    // line of laby segment where present
  screenRowSetVase[vases] = row;    // row of laby segment where present
  vase[vases] = vaseProgress?4:1;    // vase present on this level, or just the content if progress is set
};

// check moving platforms animation and controls
function EventsCheck () {
  for (p=1; p<(eventsCount+1); p++) {    // for every event
    if (events[p][2]==posy&&events[p][1]==posx) {    // if event position reached
      if (laby[events[p][2]][events[p][1]]%255>127) {    // if lever is up
        platformActive[events[p][3]] = 0;    // main platform inactive
        if (events[p][4]) platformActive[events[p][4]] = 1;    // secondary platform is active
      } else {
        if (laby[events[p][2]][events[p][1]]%512>254) {    // if lever is down
          if (events[p][4]) platformActive[events[p][4]] = 0;    // secondary platform is inactive
          if (!(laby[posxPlatform[events[p][3]]][posyPlatform[events[p][3]]]% 8>3)) {  // if no platform present yet
            laby[posxPlatform[events[p][3]]][posyPlatform[events[p][3]]] = eval(laby[posxPlatform[events[p][3]]][posyPlatform[events[p][3]]]) + 4;    // add platform on screen 
          };
        } else {  // for the platforms activated when entering it's segment
          platformActive[events[p][4]] = 1;    // secondary platform is active
        };
        platformActive[events[p][3]] = 1;    // main platform is active
      };
    };
  };
};

// create level 1
function Level1Create ()  {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024*/
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
  
  AddRow('5,4,4,4,4     ,1');
  AddRow('1,0,0,0,0     ,1');
  AddRow('1,0,0,0,64   ,1');
  AddRow('17,0,0,5,4   ,0');
  
  AddRow('4,4,4,0,0     ,0');

};

// create second level
function Level2Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
  
  AddRow('5,69,7,4,4   ,4,4,4,4,4         ,1');
  AddRow('1,4,4,4,4     ,5,4,0,0,1025   ,1');
  AddRow('1,0,0,1,0     ,0,0,0,5,0         ,1');
  AddRow('1,0,1,4,36   ,4,4,4,0,640     ,1');

  AddRow('4,4,0,4,4     ,4,4,4,4,4         ,0');
  
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(10, 4, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(0, 0, 3, 4, 1, -2, 1);
  AddPlatform(10, 4, 8, 4, 1, -2, 0);
};
  
// create third level
function Level3Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level
  
  AddRow('5,4,4,4,68     ,1');
  AddRow('5,0,644,1,4   ,1');
  AddRow('1,0,4,0,0       ,1');
  AddRow('1,640,1,0,0   ,1');

  AddRow('4,4,4,4,4       ,0');
  
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(2, 4, 1);
  AddEvent(3, 2, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(2, 4, 1, 2, 1, -2, 0);
  AddPlatform(3, 2, 4, 4, 1, -2, 0);
};

// create fourth level
function Level4Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level
  
  AddRow('5,4,4,4,4     ,1');
  AddRow('5,0,0,0,0     ,1');
  AddRow('1,0,0,0,0     ,1');
  AddRow('1,0,0,0,0     ,1');

  AddRow('1,0,0,0,0     ,1');
  AddRow('1,0,0,0,0     ,1');
  AddRow('1,0,0,0,0     ,1');
  AddRow('1,0,0,0,64   ,1');

  AddRow('1,0,0,0,4     ,0');
  
};

// create fifth level
function Level5Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
  
  AddRow('5,5,4,644,5     ,1');
  AddRow('1,644,1,69,0   ,1');
  AddRow('1,4,0,4,0         ,1');
  AddRow('645,1,0,0,0     ,1');

  AddRow('4,4,4,4,4         ,0');
  
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(1, 4, 1);
  AddEvent(2, 2, 2, 1);
  AddEvent(4, 1, 3, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(1, 4, 1, 4, 1, -2, 0);
  AddPlatform(2, 2, 3, 5, 1, 2, 0);
  AddPlatform(4, 1, 5, 5, 1, 2, 0);
};

// create sixth level
function Level6Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
  
  // put the snake diamond in the labyrinth sector with given line & row
  AddSnakeDiamond (0,0);    
  
  AddRow('5,4,4,4,4         ,1');
  AddRow('1,0,0,0,1024   ,3');
  AddRow('1,0,0,0,5         ,0');
  AddRow('1,0,0,5,0         ,0');

  AddRow('4,4,4,0,0         ,0');

};

// create eight level
function Level7Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 5;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
   
  // put the snake diamond in the labyrinth sector with given line & row
  AddSpiderBig (0,0);  
 
  AddRow('5,4,4,4,4         ,1');
  AddRow('3,0,0,0,0         ,1');
  AddRow('4,1025,0,0,0   ,1');
  AddRow('0,4,1,0,0         ,1');

  AddRow('0,0,4,4,4         ,0');
  
};

// create eight level
function Level8Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // line start position hero for this level
  posyLevStart = 4;  // row start position hero for this level
  
  AddRow('5,4,4,644,5     ,1');
  AddRow('1,644,1,69,0   ,1');
  AddRow('1,4,0,5,0         ,1');
  AddRow('1,640,1,0,0     ,1');

  AddRow('4,4,4,4,4         ,0');
  
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(2, 4, 1);
  AddEvent(2, 2, 2, 1);
  AddEvent(4, 1, 3, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(2, 4, 1, 5, 1, 2, 0);
  AddPlatform(2, 2, 3, 5, 1, 2, 0);
  AddPlatform(4, 1, 5, 5, 1, 2, 0);
};

// create nineth level
function Level9Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 2;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level
  
  AddRow('5,4,7,4,68         ,5,644,69,4,4   ,1');
  AddRow('1,4,5,1028,1     ,1,4,4,1,4         ,1');
  AddRow('5,0,0,36,1         ,5,4,0,1,4         ,1');
  AddRow('5,4,4,4,1024     ,1,0,0,4,1         ,1');

  AddRow('13,5,4,4,1028   ,1,4,4,4,1         ,1');
  AddRow('1,1,0,4,4           ,4,68,5,0,1       ,1');
  AddRow('1,1,0,4,4           ,4,36,1,4,1       ,1');
  AddRow('1,1,0,0,4           ,5,4,7,0,1         ,1');

  AddRow('1,1029,4,4,3     ,3,4,1029,4,1   ,1');
  AddRow('1,4,0,4,4           ,5,0,5,0,1         ,1');
  AddRow('1,0,0,0,64         ,1,4,0,4,0         ,1');
  AddRow('5,32,0,32,4       ,5,0,36,0,644   ,1');

  AddRow('4,4,4,4,4           ,4,4,4,4,4         ,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(7, 1, 5);
  AddEvent(10, 12, 6);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(0, 0, 6, 4, 1, -1, 1);
  AddPlatform(0, 0, 3, 7, 1, -1, 1);
  AddPlatform(0, 0, 2, 8, 1, -1, 1);
  AddPlatform(0, 0, 2, 11, 1, 1, 1);
  AddPlatform(7, 1, 10, 2, 1, -1, 0);
  AddPlatform(10, 12, 10, 12, 1, -2, 0);
};

// create tenth level
function Level10Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 16;  // line start position hero for this level
  
  AddRow('69,7,4,1028,1095   ,1');
  AddRow('5,36,0,4,4               ,1');
  AddRow('1,4,4,4,0                 ,1');
  AddRow('1093,3,0,0,0           ,1');

  AddRow('5,4,68,4,0               ,1');
  AddRow('1,0,36,0,0               ,1');
  AddRow('1,5,4,4,1                 ,1');
  AddRow('1,0,0,64,0               ,1');

  AddRow('1,4,4,4,4                 ,1');
  AddRow('1,0,0,0,32               ,1');
  AddRow('1,4,4,4,4                 ,1');
  AddRow('1,0,0,0,36               ,1');

  AddRow('1,4,4,4,4                 ,1');
  AddRow('37,0,0,0,0               ,1');
  AddRow('5,4,4,4,0                 ,1');
  AddRow('1,0,0,0,36               ,1');

  AddRow('4,4,4,4,4                 ,0');
 
  // AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(1, 8, 1, 2);
  AddEvent(1, 12, 3, 4);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(0, 0, 1, 8, 2, -2, 0);
  AddPlatform(0, 0, 5, 8, 2, 2, 0);
  AddPlatform(0, 0, 1, 10, 1, 1, 0);
  AddPlatform(0, 0, 5, 12, 1, 1, 0);
};

// create eleventh level
function Level11Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 7;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level
  
  // AddVase (line,row,artifact,vaseProgress) 
  AddVase (0,0,1);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken
  
  AddRow('5,4,4,4,4             ,5,4,4,4,4           ,4,4,4,4,4     ,1');
  AddRow('1,4,0,0,0             ,5,0,0,0,640       ,1,0,0,0,1     ,1');
  AddRow('5,0,0,0,0             ,1,4,1,5,4           ,5,0,0,0,1     ,1');
  AddRow('1,4,0,0,1             ,4,1,641,65,0     ,0,4,0,0,1     ,1');

  AddRow('5,4,0,0,4             ,1,4,5,4,4           ,5,4,4,0,1     ,1');
  AddRow('1,0,4,0,0             ,0,0,0,1,644       ,1,0,0,4,1     ,1');
  AddRow('65,0,0,4,0           ,5,0,4,0,4           ,1,0,4,0,1     ,1');
  AddRow('5,4,36,36,36       ,32,36,1,0,0       ,0,4,0,0,1     ,1');

  AddRow('1,4,4,4,4             ,5,4,0,4,644       ,1,4,4,69,0   ,1');
  AddRow('1,0,0,0,0             ,5,0,0,0,704       ,5,0,0,4,1     ,1');
  AddRow('1,0,0,0,0             ,1,0,0,0,4           ,1,4,0,0,1     ,1');
  AddRow('65,32,32,32,32   ,0,32,32,32,32   ,33,0,4,0,0   ,1');

  AddRow('4,4,4,4,4             ,4,4,4,4,4           ,4,4,4,4,4     ,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(10, 10, 1);
  AddEvent(10, 9, 2);
  AddEvent(10, 2, 3);
  AddEvent(10, 6, 4);
  AddEvent(8, 4, 5);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(10, 10, 10, 11, 1, -2, 0);
  AddPlatform(10, 9, 6, 10, 2, 1, 0);
  AddPlatform(10, 2, 6, 2, 2, 1, 0);
  AddPlatform(10, 6, 8, 7, 1, 2, 0);
  AddPlatform(8, 4, 8, 5, 1, -2, 0);

};

// create twelfth level
function Level12Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 15;  // row start position hero for this level
  posyLevStart = 12;  // line start position hero for this level

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (1,2,2);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  AddRow('0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0           ,0');
  AddRow('0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0           ,0');
  AddRow('0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0           ,0');
  AddRow('5,4,4,4,4     ,4,4,4,4,4     ,4,4,1,0,0           ,0');

  AddRow('13,4,4,4,4   ,4,4,4,4,4     ,1029,0,4,4,4     ,1');
  AddRow('1,0,0,0,0     ,0,0,0,0,64   ,5,0,0,4,1           ,1');
  AddRow('65,0,0,0,0   ,0,0,0,0,4     ,1,0,0,0,1           ,1');
  AddRow('5,0,0,0,0     ,0,0,0,0,0     ,1,640,1,69,0     ,3');

  AddRow('5,0,4,4,4     ,4,4,4,4,0     ,1029,5,5,5,4     ,1');
  AddRow('1,0,32,0,0   ,0,0,0,0,4     ,5,5,5,1,0           ,1');
  AddRow('1,0,5,4,4     ,4,4,4,4,0     ,1,641,1,1,644   ,1');
  AddRow('65,4,0,0,0   ,32,0,0,0,1   ,0,0,0,0,644       ,1');

  AddRow('4,4,4,4,4     ,4,4,4,4,4     ,0,0,0,4,4           ,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(12, 8, 1);
  AddEvent(15, 12, 2);
  AddEvent(12, 11, 3);
  AddEvent(15, 11, 4, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(12, 8, 13, 9, 1, -2, 0);
  AddPlatform(15, 12, 13, 10, 2, -2, 0);
  AddPlatform(12, 11, 11, 10, 2, 2, 0);
  AddPlatform(15, 11, 12, 10, 1, 2, 0);
  AddPlatform(0, 0, 2, 6, 1, 1, 1);
  AddPlatform(0, 0, 9, 7, 2, -1, 1);
  AddPlatform(0, 0, 2, 8, 1, 1, 1);
  
};

// create eleventh level
function Level13Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 2;  // line start position hero for this level

  // AddVase (line,row,artifact, vaseProgress)  
  AddVase (1,1,1);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  // add mapHero (line,row)  
  AddMapHero (0,0);    // put the map in the labyrinth sector with given line and row

  AddRow('0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0   ,1');
  AddRow('0,4,0,4,0         ,0,0,4,0,0         ,5,4,4,5,0   ,1');
  AddRow('5,1,5,1,5         ,5,4,1,5,1         ,1,0,0,1,4   ,1');
  AddRow('1,1,1,1,1         ,1,0,1,1,1         ,1,0,0,5,0   ,1');

  AddRow('1,1,1,1,1         ,1,0,1,1,1         ,1,0,5,0,5   ,1');
  AddRow('1,1,1,1,1         ,1,0,1,1,1         ,1,5,0,5,0   ,1');
  AddRow('1,1,1,1,1         ,1,0,1,1,1         ,5,0,5,0,0   ,1');
  AddRow('1,737,1,97,1   ,1,0,1665,1,1   ,3,5,0,0,0   ,1');
  
  AddRow('4,4,4,4,4        ,4,4,4,4,4          ,4,4,4,4,4   ,0');
      
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(2, 8, 1);
  AddEvent(8, 8, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(2, 8, 2, 9, 2, 2, 0);
  AddPlatform(8, 8, 8, 9, 1, 2, 0);

};

// create fourteenth level
function Level14Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 2;  // line start position hero for this level

  AddRow('0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0   ,0,0,0,0,0   ,0,0,64,0,0   ,0,0,0,0,0       ,0,64,32,64,0   ,1024,0,0,0,0   ,0,0,32,0,64     ,1');
  AddRow('0,0,0,0,0     ,0,5,1,0,32   ,5,1,0,0,0   ,0,0,0,0,0   ,0,0,4,0,0     ,0,0,0,0,0       ,0,4,4,4,0         ,0,0,0,0,0         ,0,0,4,4,4         ,1');
  AddRow('5,1,0,0,5     ,5,0,4,4,4     ,1,0,0,0,0   ,5,1,0,5,1   ,5,4,4,4,4     ,4,1,0,0,5       ,4,4,4,4,4         ,4,1,5,1,0         ,5,0,32,0,704   ,1');
  AddRow('1,33,0,0,1   ,1,0,0,0,0     ,1,0,0,0,0   ,1,1,5,0,4   ,0,0,0,0,0     ,0,33,0,64,1   ,0,0,0,0,0         ,0,33,12,0,5     ,0,0,4,4,4         ,1');

  AddRow('0,4,4,4,0     ,0,0,0,0,0     ,0,0,0,0,0   ,0,4,0,0,0   ,0,0,0,0,0     ,0,4,4,4,0       ,0,0,0,0,0         ,0,4,4,4,0         ,0,0,0,0,0         ,0');
      
  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(45, 3, 1);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(45, 3, 44, 2, 1, 2, 0);    // 1
  AddPlatform(0, 0, 3, 3, 2, 1, 1);        // 2
  AddPlatform(0, 0, 12, 5, 2, -2, 1);    // 3
  AddPlatform(0, 0, 13, 1, 2, 2, 1);      // 4
  AddPlatform(0, 0, 14, 5, 2, -2, 1);    // 5
  AddPlatform(0, 0, 15, 1, 2, 2, 1);      // 6
  AddPlatform(0, 0, 28, 3, 1, 2, 1);      // 7

};

// create fifteenth level
function Level15Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 12;  // line start position hero for this level

  AddRow('1,0,0,0,0   ,0,0,0,0,0       ,0,0,0,0,0           ,0,0,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,0,0,0,0,0       ,0,0,0,0,0           ,0,0,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,0,0,0,0,0       ,0,0,0,0,0           ,0,0,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,0,0,0,0,0       ,0,0,1024,0,32   ,0,0,0,0,0   ,0,0,0,0,0, 1');

  AddRow('1,0,0,0,0   ,0,0,0,5,4       ,4,4,4,4,1           ,0,0,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,0,0,5,0,0       ,0,0,0,0,4           ,1,0,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,0,5,0,0,0       ,0,0,0,0,0           ,4,3,0,0,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,0,0   ,5,0,0,0,0       ,0,0,0,0,0           ,0,4,1,0,0   ,0,0,0,0,0, 1');

  AddRow('1,0,0,0,5   ,5,4,4,4,100   ,1,0,0,0,0           ,0,0,4,1,0   ,0,0,0,0,0, 1');
  AddRow('1,0,0,5,0   ,5,0,0,0,100   ,1,0,0,0,0           ,0,0,0,4,1   ,0,0,0,0,0, 1');
  AddRow('1,0,5,0,0   ,5,0,0,0,644   ,1025,0,0,0,0     ,0,0,0,0,4   ,1,0,0,0,0, 1');
  AddRow('1,5,0,0,0   ,1,4,4,644,1   ,7,4,4,4,4           ,4,4,4,4,0   ,4,1,0,0,0, 1');

  AddRow('5,4,4,4,4   ,4,4,4,4,4       ,4,4,4,4,4           ,4,4,4,4,4   ,4,4,4,4,4, 0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(9, 12, 1);
  AddEvent(10, 11, 2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(9, 12, 9, 12, 1, -2, 0);    // 1
  AddPlatform(10, 11, 7, 12, 2, -2, 0);    // 1

};

// create sixteenth level
function Level16Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 18;  // row start position hero for this level
  posyLevStart = 10;  // line start position hero for this level

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (4,0,2);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  // add mapHero (line,row)  
  AddMapHero (4,0);    // put the map in the labyrinth sector with given line and row
  
  // put the snake diamond in the labyrinth sector with given line & row
  AddSnakeDiamond (4,4);    
  
  AddRow('0,0,0,0,0   ,0,0,0,0,0       ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,0,0       ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,0,5       ,1028,4,1,0,0   ,0,0,0,0,0         ,0,0,0,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,0,1       ,68,1,4,1,0       ,0,0,0,0,0         ,0,0,0,0,0         ,0');

  AddRow('0,0,0,0,0   ,0,0,0,0,1       ,5,0,1,1,0         ,0,0,0,0,0         ,0,0,0,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,0,1       ,1,4,1,7,4         ,4,4,68,1,0       ,0,0,0,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,0,5       ,4,640,1,5,4     ,4,4,1029,4,4   ,4,4,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,5,0       ,5,4,0,4,4         ,4,4,1024,5,4   ,4,1,1,0,0         ,0');

  AddRow('0,0,0,0,0   ,0,0,0,1,5       ,0,5,4,68,4       ,5,4,1025,1,0   ,0,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,1,1       ,4,0,0,4,0         ,4,4,3,7,4         ,4,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,1,5       ,1,0,0,0,640,    ,5,4,13,4,4       ,1,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,1,1       ,1,0,0,0,4         ,5,68,1,69,4     ,0,1,1,0,0         ,0');

  AddRow('0,0,0,0,0   ,0,0,0,1,1       ,1,0,0,0,0         ,1,4,0,4,4         ,1,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,0,1,644   ,1,0,0,0,0         ,5,4,0,0,0         ,1,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,5,0,4       ,1,0,4,0,640     ,1,0,0,0,0         ,1,1,1,0,0         ,0');
  AddRow('0,0,0,0,0   ,0,0,1,4,4       ,4,4,4,4,4         ,1,0,0,0,64       ,1,1,5,4,4         ,1');

  AddRow('5,4,4,4,4   ,1,0,4,4,4       ,5,4,4,4,0         ,1,0,0,4,644     ,1,0,640,1,0     ,1');
  AddRow('0,0,0,0,0   ,1,0,0,0,0       ,1,4,4,4,644     ,1,0,0,0,68       ,1029,1,5,4,0   ,3');
  AddRow('5,1,0,0,0   ,1,0,0,0,0       ,1,0,0,0,5         ,0,0,0,4,4         ,0,4,0,0,4         ,1');
  AddRow('1,4,1,0,0   ,4,1,0,0,0       ,1,0,0,4,0         ,1,36,0,32,0     ,0,32,0,0,0       ,1');

  AddRow('4,4,4,1,4   ,4,4,4,4,4       ,4,5,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4         ,0');
  AddRow('0,0,0,4,4   ,4,4,4,4,4       ,4,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0         ,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(12, 7, 1);
  AddEvent(15, 11, 2);
  AddEvent(15, 15, 3);
  AddEvent(15, 18, 4); 
  AddEvent(20, 17, 5);
  AddEvent(23, 17, 6);
  AddEvent(10, 14, 7);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(12, 7, 10, 7, 1, -2, 0);        // 1
  AddPlatform(15, 11, 15, 12, 2, -1, 0);    // 2
  AddPlatform(15, 15, 13, 15, 1, -2, 0);    // 3
  AddPlatform(15, 18, 11, 21, 2, -2, 0);    // 4
  AddPlatform(20, 17, 17, 20, 1, 1, 0);      // 5
  AddPlatform(23, 17, 22, 19, 2, -2, 0);    // 6
  AddPlatform(10, 14, 9, 16, 1, -2, 0);      // 7
  
};

// create seventeenth level
function Level17Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 12;  // line start position hero for this level

  // add mapHero (line,row)  
  AddMapHero (3,0);    // put the map in the labyrinth sector with given line and row

  AddRow('5,4,4,4,4         ,4,4,4,4,4               ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4     ,5');
  AddRow('1,4,4,1,5         ,1028,1,4,1,0         ,4,0,5,0,1         ,0,5,0,1,4         ,1,0,5,4,4     ,1');
  AddRow('5,0,1,4,1         ,4,5,0,1,5               ,0,4,1,4,1         ,4,1,4,5,0         ,5,0,1,4,0     ,1');
  AddRow('1,4,5,0,5         ,0,1,4,1,1               ,5,0,5,0,4         ,0,5,0,1,4         ,1,4,4,0,0     ,1');

  AddRow('5,0,1,4,1         ,4,5,0,1,1               ,1,4,1029,4,5   ,4,0,4,5,0         ,5,4,4,4,0     ,1');
  AddRow('1,4,4,1,4         ,0,1,4,1,1               ,5,0,5,0,1         ,0,4,0,1,4         ,0,4,4,4,4     ,1');
  AddRow('5,0,1,5,0         ,1028,5,0,1025,1   ,1,4,1,4,1         ,4,0,4,5,0         ,5,4,4,4,0     ,1');
  AddRow('1,4,1,5,4         ,4,1,4,1,1               ,5,0,5,0,1         ,0,4,0,1,4         ,1,4,4,4,4     ,1');

  AddRow('5,0,1,1,4         ,1,4,1,0,1               ,1,4,1,4,1         ,4,0,4,5,0         ,5,7,71,5,0   ,1');
  AddRow('1,4,1025,5,0   ,5,0,5,0,1               ,5,0,5,0,1         ,0,4,0,1,4         ,1,7,7,1,4     ,1');
  AddRow('5,0,1,1,4         ,1,4,1,4,1               ,0,4,1,4,1         ,4,0,4,5,0         ,5,7,3,5,0     ,1');
  AddRow('1,4,0,4,0         ,5,0,1028,1025,1   ,1029,0,5,0,0   ,0,4,0,1,1028   ,1,7,7,3,4     ,1');

  AddRow('4,4,4,4,4         ,4,4,4,4,4               ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4     ,0');

};

// create eightteenth level
function Level18Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 3;  // line start position hero for this level

  AddRow('1,1,0,0,0   ,0,0,0,640,1   ,0,1024,0,0,0   ,0,0,0,1024,0   ,0,0,0,3,67     ,0,0,0,0,0         ,1');
  AddRow('1,1,0,0,0   ,0,0,0,4,0       ,0,4,0,0,0         ,0,0,0,4,0         ,0,0,0,4,4       ,0,0,0,0,0         ,1');
  AddRow('1,4,1,0,0   ,0,0,4,0,0       ,0,0,4,0,5         ,4,4,1,0,4         ,0,0,0,0,0       ,0,0,0,0,0         ,1');
  AddRow('4,1,4,4,4   ,4,4,4,4,36     ,4,4,4,4,0         ,4,1,4,4,4         ,4,12,4,4,36   ,4,4,1028,4,4   ,1');

  AddRow('0,4,4,4,4   ,4,4,4,4,4       ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4       ,4,4,4,4,4         ,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(9, 1, 1);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(9, 1, 23, 4, 1, -2, 0);        // 1  
  
};

// create nineteenth level
function Level19Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 12;  // line start position hero for this level

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (2,1,0);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  AddRow('0,0,0,0,0         ,0,0,0,0,0   ,0,0,0');
  AddRow('0,0,0,0,0         ,0,0,0,0,0   ,0,0,0');
  AddRow('0,0,0,0,0         ,0,0,0,0,0   ,0,0,0');
  AddRow('0,0,0,0,0         ,0,0,5,4,4   ,4,1,0');

  AddRow('0,0,0,0,0         ,0,5,0,5,4   ,1,0,1');
  AddRow('0,0,0,0,0         ,0,1,4,1,0   ,1,0,1');
  AddRow('0,0,0,0,0         ,0,5,0,1,0   ,1,0,1');
  AddRow('0,0,0,0,0         ,0,1,4,5,4   ,4,1,1');

  AddRow('5,4,4,1028,4   ,1,4,0,1,4   ,1,0,1');
  AddRow('1,0,0,7,4         ,0,0,4,5,0   ,1,0,1');
  AddRow('1,0,0,7,4         ,4,4,4,0,5   ,1,0,1');
  AddRow('1,0,0,7,4         ,4,4,4,4,0   ,4,64,1');

  AddRow('4,4,4,4,4         ,4,4,4,4,4   ,4,4,0');

  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(0, 0, 3, 13, 1, -2, 1);        // 1
  
};

// create twentieth level
function Level20Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (1,0,1);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (2,3,2);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  AddRow('5,4,4,4,4           ,7,4,4,4,4           ,7,4,4,4,4               ,7,4,4,4,4           ,1,0,0');
  AddRow('1029,4,0,4,36   ,1029,0,4,36,5   ,37,4,1024,5,4       ,37,64,5,0,32     ,1,0,0');
  AddRow('69,4,4,4,4         ,4,4,4,4,0           ,4,4,4,1,0               ,4,4,1,4,4           ,1,0,0');
  AddRow('5,0,0,0,0,          ,0,0,5,4,4           ,4,1,0,0,0               ,0,0,1,4,32         ,1,0,0');

  AddRow('33,33,33,33,1   ,1,4,0,5,100       ,1,0,0,0,0               ,4,4,5,4,0           ,1,0,0');
  AddRow('33,33,33,33,1   ,5,0,0,0,4           ,0,0,0,0,0               ,0,0,1,0,32         ,1,0,0');
  AddRow('33,33,33,97,1   ,0,4,33,36,36     ,36,36,36,36,100   ,5,0,1,4,4           ,1,0,0');
  AddRow('97,97,97,1,0     ,68,1,4,4,4         ,4,4,4,4,4               ,1,1028,1,4,32   ,1,0,0');

  AddRow('1,0,0,0,4           ,37,100,3,5,0     ,37,36,44,36,36     ,5,4,4,4,0           ,1,0,0');
  AddRow('1,0,0,4,0           ,33,36,1,1,4       ,33,32,36,32,32     ,33,0,0,0,36       ,1,0,0');
  AddRow('1,0,0,5,4           ,32,32,1,5,0       ,33,32,32,36,96     ,5,4,0,4,4           ,1,0,0');
  AddRow('1025,0,4,65,0   ,1,32,0,0,4         ,4,4,4,4,4               ,0,0,0,0,0           ,0,4,1');

  AddRow('4,4,4,4,4           ,4,4,0,4,4           ,4,4,4,4,4               ,4,4,4,4,4           ,4,0,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(0, 0, 1, 5, 2, -1, 1);         // 2
  AddPlatform(0, 0, 8, 13, 1, -2, 1);       // 3
  
};

// create twenty first level
function Level21Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 17;  // row start position hero for this level
  posyLevStart = 4;  // line start position hero for this level

  AddRow('0,0,5,4,4     ,4,4,4,4,4         ,4,4,4,4,4           ,7,4,1028,4,4   ,7,4,4,4,4           ,4,4,4,4,4           ,4,4,4,1,0');
  AddRow('0,0,1,4,4     ,1028,5,5,4,4   ,4,4,4,4,4           ,7,0,4,1,4         ,1031,36,5,4,4   ,4,4,4,4,4           ,4,4,1,1,0');
  AddRow('0,0,1,5,4     ,4,0,1,0,1029   ,0,5,4,37,1028   ,3,5,640,5,4     ,7,4,4,4,4           ,4,4,4,1,0           ,0,0,1,1,0');
  AddRow('0,0,1,1,0     ,0,0,1,1,4         ,4,1029,5,4,4     ,7,16,4,0,4       ,7,4,4,5,4           ,4,4,1,1,0           ,0,0,1,1,0');

  AddRow('0,69,0,1,0   ,0,69,0,1,0       ,0,1,0,68,5         ,4,4,5,5,4         ,4,4,1,1,0           ,0,0,1,1,0           ,0,69,0,1,0');
  AddRow('0,4,1,1,0     ,0,4,1,1,0         ,0,4,1,5,0           ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0           ,0,4,1,1,0');
  AddRow('0,0,1,68,1   ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0         ,0,5,0,1,0           ,0,69,0,1,0         ,0,0,1,1028,1');
  AddRow('0,0,1,5,0     ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0         ,0,4,1,1,0           ,0,4,1,1,0           ,0,0,1,5,0');

  AddRow('0,0,1,68,1   ,0,69,0,1,0       ,0,69,0,1,0         ,0,0,1,1,0         ,0,0,1,68,1         ,0,1029,0,68,1   ,0,69,0,1,0');
  AddRow('0,0,1,5,0     ,0,4,1,1,0         ,0,4,1,1,0           ,0,0,1,1,0         ,0,0,1,5,0           ,0,4,1,5,0           ,0,4,1,1,0');
  AddRow('0,0,1,1,0     ,0,0,1,68,1       ,0,0,1,68,1         ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0           ,0,0,1,1,0');
  AddRow('0,0,1,1,0     ,0,0,1,5,0         ,0,0,1,5,0           ,0,0,1,1,0         ,0,0,1,1028,1     ,0,0,1,1,0           ,0,0,1,1,0');

  AddRow('0,0,1,68,1   ,37,4,0,1,0       ,0,0,1,68,1         ,0,0,1,1,0         ,0,0,1,5,0           ,0,0,1,4,4           ,4,36,1,68,1');
  AddRow('0,0,1,5,0     ,4,4,1,1,0         ,0,0,1,5,0           ,0,0,1,1,0         ,0,69,0,1,0         ,0,0,1,5,4           ,4,4,1,5,0');
  AddRow('0,0,1,1,0     ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0         ,0,4,1,1,0           ,0,0,1,1,0           ,0,0,1,1,0');
  AddRow('0,0,1,1,0     ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0         ,0,0,1,1,0           ,0,0,1,1,0           ,0,0,1,1,0');

  AddRow('0,0,1,4,4     ,4,4,0,4,4         ,4,4,0,4,4           ,4,4,0,4,4         ,4,4,0,4,4           ,4,4,0,4,4           ,4,4,0,1,0');
  AddRow('0,0,4,4,4     ,4,4,4,4,4         ,4,4,4,4,4           ,4,4,1,5,4         ,4,4,4,4,4           ,4,4,4,4,4           ,4,4,4,0,0');
  AddRow('0,0,0,0,0     ,0,0,0,0,0         ,0,0,0,0,0           ,0,0,4,0,0         ,0,0,0,0,0           ,0,0,0,0,0           ,0,0,0,0,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(18, 3, 1);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(18, 3, 18, 5, 1, -2, 0);        // 1
  
};

// create twenty second level
function Level22Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 2;  // row start position hero for this level
  posyLevStart = 5;  // line start position hero for this level

  AddRow('0,0,0,0,0         ,0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0         ,0,0,0,0');
  AddRow('0,0,0,0,0         ,0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0         ,0,0,0,0');
  AddRow('0,0,0,0,0         ,0,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0         ,0,0,0,0');
  AddRow('0,0,0,0,5         ,4,4,4,4,4     ,4,4,4,4,4     ,4,4,4,4,4         ,4,4,4,1');

  AddRow('5,20,4,4,65     ,1,0,0,0,64   ,0,0,0,0,0     ,64,0,0,0,0       ,1,5,0,1');
  AddRow('1,5,4,4,4         ,1,0,0,32,4   ,0,0,0,64,0   ,4,0,0,64,0       ,1,1,4,1');
  AddRow('1,1,0,0,0         ,1,64,0,4,0   ,0,0,32,4,0   ,0,0,0,4,0         ,1,5,0,1');
  AddRow('1,1,0,0,5         ,1,4,0,0,0     ,0,0,4,0,0     ,0,0,0,0,5         ,0,1,4,1');

  AddRow('1,1,0,5,0         ,1,0,0,64,0   ,0,64,0,0,0   ,0,64,0,0,641   ,1,5,0,1');
  AddRow('1,1,5,0,0         ,1,0,0,4,0     ,0,4,0,0,0     ,0,4,0,0,4         ,1,1,4,1');
  AddRow('1,5,0,1024,0   ,1,0,0,0,0     ,0,0,0,0,0     ,0,0,0,0,0         ,0,4,0,1');
  AddRow('1,0,0,0,0         ,5,4,5,5,4     ,4,4,5,5,4     ,4,4,5,5,4         ,5,0,4,1');

  AddRow('4,4,4,4,13       ,4,4,0,4,36   ,4,4,0,4,36   ,4,4,0,4,36       ,0,5,4,0');
  AddRow('0,0,0,0,4         ,4,4,4,4,4     ,4,4,4,4,4     ,4,4,4,4,4         ,4,0,0,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(20, 9, 1);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(20, 9, 22, 5, 1, -1, 0);        // 1
    
};

// create twenty third level
function Level23Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level

  AddRow('21,1028,4,1,0   ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0           ,0,0');
  AddRow('4,4,1,1,0           ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0           ,0,0');
  AddRow('0,0,1,1,0           ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0           ,0,0');
  AddRow('0,0,1,1,0           ,0,0,0,0,0         ,0,0,0,0,0         ,0,0,0,0,0           ,0,0');

  AddRow('5,4,641,5,4       ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4           ,1,0');
  AddRow('1,0,12,0,0         ,0,64,0,0,64     ,0,0,64,0,0       ,0,64,0,0,1024   ,1,0');
  AddRow('1,0,0,0,0           ,0,4,0,0,4         ,0,0,4,0,0         ,0,4,0,0,0           ,1,0');
  AddRow('5,32,0,32,0       ,0,32,0,32,0     ,0,32,0,32,0     ,0,0,0,0,0           ,1,0');

  AddRow('5,4,4,4,4           ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,641,5,4       ,1,0');
  AddRow('1,64,0,0,1024   ,64,0,64,0,64   ,0,64,0,64,0     ,0,64,12,0,0       ,1,0');
  AddRow('1,4,0,0,0           ,4,0,4,0,4         ,0,4,0,4,0         ,0,4,0,0,0           ,1,0');
  AddRow('1,0,0,0,0           ,0,32,0,32,0     ,32,0,32,0,32   ,0,32,0,32,4       ,1,0');

  AddRow('5,4,641,5,4       ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4           ,1,0');
  AddRow('1,0,12,0,64       ,0,64,0,64,0     ,64,0,64,0,64   ,0,0,64,0,0         ,4,1');
  AddRow('1,0,0,0,4           ,0,4,0,4,0         ,4,0,4,0,4         ,0,0,4,0,0           ,65,1');
  AddRow('5,32,0,0,32       ,0,32,0,32,0     ,32,0,32,0,0     ,32,0,0,32,0       ,5,0');

  AddRow('4,4,4,4,4           ,4,4,4,4,4         ,4,4,4,4,4         ,4,4,4,4,4           ,0,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(3, 5, 1);
  AddEvent(18, 9, 2);
  AddEvent(3, 13, 3);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(3, 5, 1, 8, 1, 1, 0);                // 1
  AddPlatform(18, 9, 20, 12, 2, -1, 0);        // 2
  AddPlatform(3, 13, 1, 16, 1, 1, 0);              // 3
  
};

// create twenty fourth level
function Level24Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 2;  // row start position hero for this level
  posyLevStart = 2;  // line start position hero for this level

  // AddVase (lineSector,rowSector,artifact,vaseProgress)  
  AddVase (2,0,2,0);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken
  AddVase (3,0,1,0);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken
  AddVase (4,1,2,1);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  // AddMapHero (line,row,received)
  AddMapHero (0,0,0);    // put the map in the labyrinth sector with given line and row
  
  // put the snake diamond in the labyrinth sector with given line & row
  AddSnakeDiamond (4,1);    
     
  // put the snake diamond in the labyrinth sector with given line & row
  AddSpiderBig (0,2);  

  AddRow('645,5,36,4,68,  4,5,4,4,1,        5,4,4,4,4,        1');
  AddRow('0,0,4,4,5,          0,1,4,65,1,      3,5,0,5,0,        1');
  AddRow('4,5,0,0,1,          4,5,0,4,5,        4,0,1029,1,4,  1');
  AddRow('0,1,0,0,5,          0,1025,5,0,1,  5,4,0,4,0,        1');

  AddRow('1,0,5,4,0,          4,5,0,4,1,        1,4,4,4,4,        1');
  AddRow('1,1,1,0,4,          0,1,4,1,0,        3,0,1,0,644,    1');
  AddRow('1,1,1,4,0,          32,0,1,4,0,      1,1,1,0,0,        1');
  AddRow('1,1,1,4,4,          4,4,0,4,4,        0,1,1,0,1,        1');

  AddRow('1,1,1028,5,0,    5,4,0,1,0,        0,1,1,0,1,        1');
  AddRow('1,1,5,0,4,          1,1029,0,3,0,  68,1,1,0,1,      1');
  AddRow('1,1,1,4,0,          1,4,0,1,0,        68,1,1,0,1,      1');
  AddRow('1,1,69,0,0,        4,3,0,1,0,        4,640,1,0,1,    1');

  AddRow('1,1,4,7,4,          4,4,4,0,0,        0,4,3,0,0,        1');
  AddRow('1,1,5,4,4,          4,4,0,0,0,        0,0,1,0,1,        1');
  AddRow('1,1,1,0,0,          0,4,640,1,0,    4,1060,1,0,1,  1');
  AddRow('1,1,641,1,0,      4,5,0,1,4,        4,4,1,0,1,        1');

  AddRow('1,673,5,4,0,      4,0,1029,4,4,  1029,0,1,1,1,  1');
  AddRow('1,4,0,0,0,          1029,4,4,4,0,  7,69,0,641,1,  1');
  AddRow('68,4,0,644,1,    0,0,4,4,68,      5,5,640,1,1,    1');
  AddRow('68,32,0,0,0,      0,4,4,4,4,        4,3,4,4,0,        1');

  AddRow('4,4,0,4,0,          4,4,4,4,4,        4,4,4,4,0,        0');
  AddRow('1,0,0,0,0,          0,0,0,0,0,        0,0,0,0,0,        0');
  AddRow('1,0,4,0,0,          0,0,0,0,0,        0,64,641,1,0,  0');
  AddRow('1,4,0,0,0,          0,0,0,0,0,        0,5,4,0,0,        0');
  
  AddRow('4,0,0,0,0,          0,0,0,0,0,        0,0,0,0,0,        0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(1, 1, 1);
  AddEvent(2, 17, 2);
  AddEvent(4, 19, 3);
  AddEvent(3, 16, 4);
  AddEvent(13, 23, 5);
  AddEvent(15, 6, 6);
  AddEvent(13, 19, 7);
  AddEvent(14, 18, 8);
  AddEvent(12, 12, 9);
  AddEvent(8, 15, 10);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(1, 1, 4, 2, 1, 2, 0);              // 1
  AddPlatform(2, 17, 2, 18, 2, -2, 0);        // 2
  AddPlatform(4, 19, 3, 23, 1, -2, 0);        // 3
  AddPlatform(3, 16, 7, 15, 1, 1, 0);          // 4
  AddPlatform(13, 23, 2, 24, 2, 1, 0);        // 5
  AddPlatform(15, 6, 15, 6, 1, 2, 0);          // 6
  AddPlatform(13, 19, 13, 20, 2, -2, 0);    // 7
  AddPlatform(14, 18, 14, 20, 1, -2, 0);    // 8
  AddPlatform(12, 12, 11, 9, 2, -2, 0);      // 9
  AddPlatform(8, 15, 9, 17, 2, -2, 0);        // 10
 
};

// create twenty fifth level
function Level25Create () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  posxLevStart = 8;  // row start position hero for this level
  posyLevStart = 24;  // line start position hero for this level

  // AddVase (line,row,artifact,vaseProgress)  
  AddVase (6,11,2,1);    // put the vase in the labyrinth sector with given line & row with artifact 1=amulet or 2=ankh key and vase progress 0=complete or 1=broken

  // AddMapHero (line,row,received)
  AddMapHero (0,0,1);    // put the map in the labyrinth sector with given line and row
     
  // put the snake diamond in the labyrinth sector with given line & row
  AddSpiderBig (7,4);  

  AddRow('4,4,4,4,4  ,4,4,4,4,4        ,4,4,4,4,4          ,4,4,4,4,4    ,4,4,4,4,4        ,4,4,4,4,4    ,4,4,4,4,4        ,4,4,4,4,4        ,4,4,4,4,4                    ,4,4,4,4,4      ,5,4,4,4,1060        ,4,4,4,4,4              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,5,4,0,0,4              ,0,4,4,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,1,0,0,0,0              ,1,0,0,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,1,4,640,641,641  ,1,0,0,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');

  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,5,4,1,0        ,0,0,0,0,1    ,1,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,4,4,4,4,4              ,0,0,0,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,5,0,0,4,1        ,0,0,0,0,1    ,1,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,4,4,4,4,0        ,0,0,0,0,1    ,1,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,0,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,1    ,1,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,0,0              ,1,0,0,0,5      ,0,5,4,0,0    ,0,0,0,0,0    ,1,0');

  AddRow('1,0,0,0,0  ,0,1,0,1,0        ,0,1,1,1,0          ,0,0,0,0,0    ,0,5,5,1,0        ,0,0,0,0,3    ,1,0,0,0,0        ,0,0,1,0,0        ,0,0,64,37,1                ,0,0,1,0,4      ,5,37,1,37,5          ,1,0,0,0,0              ,1,0,0,5,0      ,5,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,0,0,0  ,0,4,5,0,0        ,0,4,5,0,0          ,0,1,0,1,0    ,0,4,5,0,0        ,0,0,0,0,1    ,0,0,0,0,0        ,0,0,1,0,1028  ,4,5,4,4,5                    ,4,0,1,4,0      ,1,4,5,5,0              ,1,0,0,0,0              ,33,32,5,0,5  ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,0,0,0  ,0,0,1031,0,0  ,0,4,1025,0,0    ,0,12,5,0,0  ,1024,4,5,0,0  ,0,0,0,0,1    ,1025,0,0,0,0  ,0,0,5,4,1        ,0,1025,1024,1024,1  ,5,4,1,0,4      ,4,1,65,3,7            ,0,0,0,0,0              ,7,4,0,5,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,0,0,0  ,0,4,1,0,0        ,0,0,5,0,0          ,0,4,5,0,0    ,0,0,1,0,0        ,0,0,0,0,1    ,5,0,0,0,0        ,0,0,1,0,1        ,0,3,0,0,3                    ,3,0,3,4,0      ,37,37,37,37,37    ,1,0,0,0,640          ,5,4,4,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');

  AddRow('5,4,0,4,4  ,4,4,4,4,4        ,4,13,1036,5,4  ,4,4,4,4,4    ,5,653,5,4,4    ,4,4,4,13,5  ,1,5,4,4,4        ,4,5,5,4,4        ,4,4,4,4,4                    ,4,4,4,4,4      ,4,4,4,4,4              ,4,4,4,5,5              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,0,0,0,0,0        ,0,4,4,0,0          ,0,0,0,0,0    ,4,4,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,4,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,4,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,1024,0,0,0,0  ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');

  AddRow('1,4,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,4,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,1    ,1,1,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,0,0,0,0,0        ,4,1,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,1,4    ,640,1,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,1              ,0,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');

  AddRow('1,4,0,0,0  ,0,0,0,0,0        ,5,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,4,4    ,5,647,1,0,0    ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,5,4,4,0,4              ,1,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,0,0,0,0,0        ,1,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,4,4,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,641,1,0,0,0          ,1,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,4,0,0,0  ,0,0,0,0,0        ,1,0,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,1,0,0,0,0              ,1,0,0,0,0      ,0,1,0,0,0    ,0,0,0,0,0    ,1,0');
  AddRow('1,0,4,0,0  ,0,0,0,1095,4  ,7,1,0,0,0          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,1061,1024,0,0,0  ,1,0,0,0,0      ,0,1,0,0,32  ,0,64,0,0,0  ,4,1');

  AddRow('4,4,4,4,4  ,4,4,4,4,4        ,1025,4,1,0,0    ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,4,4,4,5,4              ,1,0,0,0,0      ,0,4,4,4,4    ,4,4,4,4,4    ,1,1');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,4,1025,4,1,0    ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,5,0              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,1,1');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,4,1,4,1          ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,1,4              ,1,0,0,0,0      ,0,0,0,0,0    ,0,0,0,0,0    ,1,1');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,4,1,4          ,1,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0    ,0,0,0,0,0        ,0,0,0,0,0        ,0,0,0,0,0                    ,0,0,0,0,0      ,0,0,0,0,0              ,0,0,0,4,1              ,4,1,0,0,5      ,4,4,4,4,4    ,4,4,4,4,4    ,0,1');

  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,4,1          ,4,1,0,0,0    ,5,4,4,5,4        ,0,5,1,1,0    ,5,5,1,5,1        ,5,0,4,5,0        ,4,5,0,1,1                    ,5,0,5,1,5      ,0,0,0,0,0              ,0,0,0,0,4              ,4,0,0,0,1      ,5,4,4,4,4    ,4,4,4,4,4    ,4,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,4          ,1,4,1,0,0    ,0,0,0,1,0        ,0,5,1,1,0    ,1,1,1,1,1        ,4,1,0,1,0        ,0,1,0,5,1                    ,5,0,5,1,5      ,0,0,0,0,0              ,0,0,0,0,0              ,0,0,0,0,1      ,1,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,4,1,4,1,0    ,5,0,0,1,0        ,0,0,0,4,0    ,0,0,0,4,0        ,4,0,0,0,0        ,0,0,0,0,0                    ,4,0,0,0,4      ,0,0,5,1,0              ,0,0,0,0,0              ,0,0,0,0,1      ,1,0,0,0,0    ,0,0,0,0,0    ,0,0');
  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,4,1,4,4    ,4,4,0,4,4        ,4,4,4,4,4    ,4,4,4,4,4        ,4,4,4,4,4        ,4,4,4,4,4                    ,36,4,4,4,4    ,4,4,0,4,4              ,4,4,4,4,4              ,4,4,4,4,0      ,1,0,0,0,0    ,0,0,0,0,0    ,0,0');

  AddRow('0,0,0,0,0  ,0,0,0,0,0        ,0,0,0,0,0          ,0,0,4,4,4    ,4,4,4,4,4        ,4,4,4,4,4    ,4,4,4,4,4        ,4,4,4,4,4        ,4,4,4,4,4                    ,4,4,4,4,4      ,4,4,4,4,4              ,4,4,4,4,4              ,4,4,4,4,4      ,0,0,0,0,0    ,0,0,0,0,0    ,0,0');

  //AddEvent (posyLever, posxLever, platformNumber1, platformNumber2);
  AddEvent(22, 13, 1);
  AddEvent(32, 21, 2);
  AddEvent(31, 20, 3);
  AddEvent(53, 4, 4);
  AddEvent(54, 4, 5);
  AddEvent(55, 4, 6);
  AddEvent(56, 22, 7);
  AddEvent(60, 12, 8);
  // AddPlatform(levy, levx, platy, platx, pseq, pdir, pactive)
  AddPlatform(22, 13, 21, 13, 1, -2, 0);    // 1
  AddPlatform(32, 21, 37, 13, 2, -2, 0);    // 2
  AddPlatform(31, 20, 31, 21, 1, -2, 0);    // 3
  AddPlatform(53, 4, 52, 4, 1, 1, 0);          // 4
  AddPlatform(54, 4, 52, 2, 1, 1, 0);          // 5
  AddPlatform(55, 4, 51, 2, 2, 2, 0);          // 6
  AddPlatform(56, 22, 59, 25, 2, -2, 0);    // 7
  AddPlatform(60, 12, 59, 13, 1, -2, 0);    // 8

};

// indicate level progress under the pyramid
function LevelIndicate () {
  var progress = Math.floor(level/4)+1;    // game progress by pyramid line indication
  for (i=1 ; i<(progress+1) ; i++) PicShow("PyramidSmallLine"+eval(i)+"", PyramidSmallLinePre[i].src);   // show lines under the pyramid according to game progress
};

// create end screen
function LevelOutLoad () {
  //gcWallVert = 1,gcLockVert = 2,gcWallHorz = 4,gcLockHorz = 8,gcHero = 16,gcScorpion = 32, gcGold = 64,
  //gcSwitchUp = 128,gcSwitchDown = 256,gcSwitchBase = 512,gcKey = 1024
  game = 0;    // no game running
  heroExtern = 0;
  LabyClear();    // empty the labyrinth
  lastLine = 1;  // last line of labyrinth starts from position 1
  lastRow = 0;  // last row of labyrinth
  life = 0;    // no lives left to schow
  line = 0;  // current line of labyrinth
  lineShift = 0;    // screen not shifted vertically yet
  posx = 1;  // current row position hero
  posy = 1;  // current line position hero
  posxLevStart = 1;  // row start position hero for this level
  posyLevStart = 1;  // line start position hero for this level
  row = 1;  // current row of labyrinth
  AllPicturesClear();    // erase all figures from screen
  // set screen
  AddRow('0,0,0,0,1');
  AddRow('5,1,1,1,5');
  AddRow('4,32,4,0,4');
  AddRow('4,4,4,4,4');
  // end set screen
  EventsCreate();    // create scorpions animation
  FiguresScreenShowCurrent()    // show current screen
  pause = false;
  GameGo();    // to start scorpion animation
};

// show current level on screen
function ShowCurrentLevelPart (lineShift, rowShift) {
  var labyVal;    // for current screen part
  if (platforms) AllPicturesScreenClear();    // if demo or platforms present clear all labyrinth figures & hero
  else AllPicturesLabyrinthClear();    // else clear all labyrinth figures
  lineShift = lineShift?lineShift:0;    // set line shift if present
  rowShift = rowShift?rowShift:0;    // set row shift if present
  for (i=1 ; i<6 ; i++) {     // the lines on screen
    for (j=1 ; j<7 ; j++) {     // the rows on screen
      labyVal = laby[(i+screenLineSet*4+ lineShift)][(j+screenRowSet*5+rowShift)];    // calculate current screen part
      if ((labyVal%2)&&i<5) PicShow("WallVert"+eval(i*10+j)+"", WallVertPre.src);    // show the present of of 24 vertical walls    //gcWallVert = 1,
      if ((labyVal%4>1)&&i<5) PicShow("LockVert"+eval(i*10+j)+"", LockVertPre.src);   // show the present of 24 vertical wall locks    //gcLockVert = 2,
      if ((labyVal%8>3)&&j<6)  PicShow("WallHor"+eval(i*10+j)+"", WallHorPre.src);   // show the present of 25 horizontal walls    //gcWallHorz = 4,
      if ((labyVal%16>7)&&j<6) PicShow("LockHor"+eval(i*10+j)+"", LockHorPre.src)   // show the lpresent of 25 horizontal locks    //gcLockHorz = 8,
      if ((labyVal%64>31)&&i<5&&j<6) PicShow("Scorpion"+eval(i*10+j)+"", ((i+j)%2)?ScorpionRightPre.src:ScorpionLeftPre.src);   // show the present of 20 Scorpions    //gcScorpion = 32,
      if ((labyVal%128>63)&&i<5&&j<6) PicShow("Gold"+eval(i*10+j)+"", GoldPre.src);    // show the present of 20 gold rocks  //gcGold = 64
      if ((labyVal%255>127)&&i<5&&j<6) PicShow("SwitchUp"+eval(i*10+j)+"", SwitchUpPre.src);   // show the present of 20 up switches    //gcSwitchUp = 128,
      if ((labyVal%512>254)&&i<5&&j<6) PicShow("SwitchDown"+eval(i*10+j)+"", SwitchDownPre.src);   // show the present of 20 down switches    //gcSwitchDown = 256,
      if ((labyVal%1024>511)&&i<5&&j<6) PicShow("SwitchBase"+eval(i*10+j)+"", SwitchBasePre.src);   // show the present of 20 switch bases    //gcSwitchBase = 512,
      if ((labyVal>1023)&&i<5&&j<6) PicShow("Key"+eval(i*10+j)+"", KeyPre.src);    // show the present of 20 Keys    //gcKey = 1024
    };
  };
  if (!shiftPause&&(!mapActive||(mapActive&&(screenLineSet==screenLineSetHero&&screenRowSet==screenRowSetHero)))) HeroShow();    // show hero during a screen shift only when in sector where hero is present
  if (!demo) LevelIndicate();     // if demo not running show game progress indicator 
}; 

/*
	  //gcWallVert = 1,                                       (labyVal%2)
      //gcLockVert = 2,                   3                (labyVal%4>1)
      //gcWallHorz = 4,                   7                (labyVal%8>3)     
      //gcLockHorz = 8,                15                (labyVal%16>7)
      //gcHero = 16,                     31                (labyVal%32>15)
      //gcScorpion = 32,               63                (labyVal%64>31)
      //gcGold = 64,                    127                (labyVal%128>63)
      //gcSwitchUp = 128,           255                (labyVal%255>127)
      //gcSwitchDown = 256,      511                (labyVal%512>254)
      //gcSwitchBase = 512,      1023                (labyVal%1024>511)
      //gcKey = 1024                                        (labyVal>1023)
      //gcSwitchBase = 640              ?
*/
  
