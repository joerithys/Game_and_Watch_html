/*------------------------------------------------------------------alarm------------------------------------------------------------------*/

var alarm = false;  // alarm not running
var alarmID;  // ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = false;   // for indicationif alarm is set on or off
var alarmSetting = false;     // if alarm is at set mode to make changes

var prefAlarmMin = 0;  // last saved alarm setting minutes
var prefAlarmHour = 0;  // last saved alarm setting hours

//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all alarm settings
function AlarmReset () {
  window.clearTimeout(alarmID);  // stop running alarm sound from repeating
  alarmID = null;
  window.clearTimeout(alarmOffID);  // stop running timer to turn off alarm @ running
  alarmOffID = null;
  alarm = false;  // alarm not running
  alarmOn = false;   // for indication if alarm is set on or off      
  alarmRinging = false;  // to prevent alarm going off again after turning off
  alarmSetting = false;     // if alarm is at set mode to make changes
  prefAlarmMin = 0;  // last saved alarm setting minutes
  prefAlarmHour = 0;  // last saved alarm setting hours
};

// show alarm time & on/off indication
function AlarmShow (ind) {
  if (ind) {
    AlarmShowNum();  // show alarm time
    if (ind=="on") {
      alarmOn = true;
      PicShow("AlarmStateInd", AlarmStateIndPre.src); // show alarm indicator on screen
    } else {
      alarmOn = false;
      PicShow("AlarmStateInd", nullPre.src); // hide alarm indicator on screen
    };
  } else {
    if (!alarmOn && game!=9) {
      PicShow("AlarmStateInd", nullPre.src); // hide alarm indicator on screen
    } else {
      PicShow("AlarmStateInd", AlarmStateIndPre.src); // show alarm indicator on screen
    };
  };
};

// show alarm time setting
function AlarmShowNum () {
  TimeShowOnScreen(prefAlarmMin, prefAlarmHour);  // show required time and indicators on screen from alarm
};

// set the alarm
function MainAlarm () {
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (demoID) {
    clearTimeout(demoID);   // if demo was planned or running, stop sequence
    demoID = null;
  };
  if (!alarmSetting) {
    ResetAll();  // clear all pictures & variables
    alarm = false;  // alarm is not currently running
    keys = 7;  // alarm is been set
    demo = false;    // once the alarm key is hit, the demo is turned off
    PlaySound("click_wav", vlm);  // click sound for push button
    alarmSetting = true;    // alarm is being set
  };
  if (game!=5) {
    game = 5; // set alarm (on)
    AlarmShow("on");  // show alarm time & on indication
    TimeAlarmBackground();  // function runs all the time and checks the alarm on the background
  } else {
    game = 8; // set alarm (off)
    AlarmShow("off");  // show alarm time & off indication
  };  
  demoID = setTimeout("MainTimeStart()", 300000);  // start demo after 5 minutes
};

// check if its time for alarm
function TimeAlarm () {
  Time();  // get current time
  var alarmTime;
  if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) {     // if it's a minute before alarm is to be run
    alarm = true;   // alarm to be run
    // set start alarm at start next minute
    alarmTime = 60000-(sec*1000);    // calculate start of next minute
    // alarm rings at start next minute
    alarmID = setTimeout("TimeAlarmSet()", alarmTime);    //  run alarm @ start of next minute
    // stop alarm 30 seconds after start
    alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000)); // turn alarm off after half a minute
  };
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
  if (alarmOn) {    
    TimeAlarm();  // check if its time for alarm if alarmOn
    setTimeout("TimeAlarmBackground()", 30000)  ;     // check every half minute
  }; 
};

// run alarm @ start of next minute
function TimeAlarmSet () {
    PicShow("HeroDiamond", HeroDiamondPre.src);  // show HeroDiamond
    PicShow("BellHandDown", BellHandDownPre.src);  // show other arm of bellringer
    TimeAlarmGo();    //  run alarm
};

// alarm rings
function TimeAlarmGo () {
  Time();  // get current time
  if ((sec%2)==1) {  // let bell ring indicator go up and down @ alarm
    PicShow("BellUp", nullPre.src);    // hide bell in up position
    PicShow("BellDown", BellDownPre.src);    // show bell in down position
    if (game!=1) PlaySoundEvenIfDemo("alarm_wav", vlm);    // play sound "name" @ "vol" volume if sound is on, even if demo is playing
  } else {
    PicShow("BellUp", BellUpPre.src);    // show bell in up position
    PicShow("BellDown", nullPre.src);    // hide bell in down position
  }
  alarmID = setTimeout("TimeAlarmGo()", 1000);    // repeat after a second
};

// turn running alarm off
function TimeAlarmOff () {
  if (alarmID) {
    clearTimeout(alarmID);   // if alarm was planned or running, stop sequence
    alarmID = null;
  };
  alarm = false;
  PicShow("HeroDiamond", nullPre.src);  // hide HeroDiamond
  PicShow("BellHandDown", nullPre.src);  // hide other arm of bellringer
  PicShow("BellUp", nullPre.src);    // hide bell in up position
  PicShow("BellDown", nullPre.src);    // hide bell in down position
};
//end time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
