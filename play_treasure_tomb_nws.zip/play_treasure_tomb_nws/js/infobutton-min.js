/*------------------------------------------------------------------info button------------------------------------------------------------------*/

// start on page load
$(document).ready(function() {
    $("#Info_bottom_txt").click(function() {
        switchInfo("#Info_button","#Info_bottom");	// hide info button when clicked on and show info tag
    });
    $("#Info_button").hover(	// darken info button when hovered over with mouse pointer
        function() {$("#info_button_img").attr("src","img/case/info_hover.png");},
        function() {$("#info_button_img").attr("src","img/case/info.png");
    });
});

// show a tag
function showInfo(el){
    $(el).removeClass("gone");
}

// hide an tag
function hideInfo(el){
    $(el).addClass("gone");
}

// switch between two tags
function switchInfo(el1,el2){
    showInfo(el1);
    hideInfo(el2);
    $("#Manual").focus(); // get focus on the info text
}

