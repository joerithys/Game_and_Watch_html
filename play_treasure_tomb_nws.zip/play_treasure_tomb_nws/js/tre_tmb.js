//Product:             Treasure Tomb HTML - New Wide Screen (Nintendo) Simulator
//Version:             1.1
//Started:              19.06.2023
//Last update:       16.05.2025
//Author               LuCiD Dreams (https://negerman.home.xs4all.nl/luciddreams/)
//Programmer       Flyzy (Joeri Thys)

//Credits:
//Design, layout and artwork by Andy (https://www.deviantart.com/steelegg)
//Case design based on scans by Sean Riddle
//Manual front page background by ArtOfDayDay (https://www.etsy.com/be/shop/ArtOfDayDay)

// || \\

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// var attackID;  // ID for timeout hero attacking
var blinkID;  // ID for timeout blinking hero
var blinkNum;  // number of blinks preset
var blinkSpeed = 500;  // speed of blink animation

var demo = false;     // indicates if demo is running or not
// var demoStart = true;     // indicates if demo is going to start to run 
var demoID;   // ID for timeout demo autostart and run
var demoSequence;    // for demo animation

var acl = false;  // for showing acl pictures, all if "ACL" is pressed twice fast
var aclID;  // ID to view all pictures @ fast double click
var eventsID;  // ID for timeout searching & creating all events
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameID;  // ID for timeout of game sequence
// var gameSetID;  // ID for 
var gameOver = 0;  // game is not over
var gold;  // number of gold rocks present

var gameSpeed = 750;  // speed for game sequence timer
var heroAttackID;    // ID for hero attacking snake or spider
var heroAttacking;    // hero is attacking snake or spider
var heroExtern;    // hero on the ouitside fighting a monster  0=false , 1=snake , 2=spider , 3=grab map
var invincible;    // if the amulet is aquired, the hero can not be harmed by the scorpions
var jumpID;  // ID for jump & land animation
var jumping;  // to prevent multiple simultanious jumps
var jumpMoved;  // to limit one move each jumpland
var keyHold;  // number of keys holding
var level;    // current level
var levelDone;    // current level done
var levelDoneID    // ID for level done animation
// var levelID;    // ID for small delay ending current level
var levelNew = false;  // new level started, all figures need to be reset
var life = 0;   // number of lives left
var mapBlinkID;    // ID for letting map blink if active
var miss = false;  
var pause = false;  

var pMoveCount;    // odd (1) - even (2) sequence @ platforms turn for moving
var scorpionDirPrev = new Array();    // for all scorpion's previous moving direction left (-1), boxed and no direction (0) or right (1)
var scorpionDir = new Array();    // for all scorpion's current moving direction left (-1), boxed and no direction (0) or right (1)
var scorpionsID;    // for scorpions move delay
var screenLineSet = 0;    // indicates which line set (of 4 lines per segment) of the labyrinth is shown on screen
var screenLineSetLast = 0;    // indicates which line set (of 4 lines per segment) of the labyrinth is the last to be shown on screen
var screenRowSet = 0;    // indicates which row set (of 5 rows per segment) of the labyrinth is shown on screen
var screenRowSetLast = 0;    // indicates which row set (of 5 rows per segment) of the labyrinth is the last to be shown on screen
var screenShifted;    // indicates how many positions the labyrinth shifted in the according direction on the screen
var screenShiftID;    // ID for timeout shifting screen
var shiftPause = false;    // to pause the neccesary processes during screen shift
var snakeAttack;    // to indicate the snake attack has been initiated
var snakeAttackID;    // ID for timeout snake attack 
var snakeHitID;    // ID for timeout stone hitting snake gone delay 
var snakeDir;    // snake attack direction
var snakeHit;    // snake hit count
var snakePos;    // snake position 1-3 during snake attack
var spiderAttack;    // spider position 1-3 during spider attack
var spiderAttackID;    // ID for timeout spider attack 
var spiderHitID;    // ID for timeout stone hitting spider delay 
var spiderHit;    // spider hit count
var spiderPos;    // spider position 1-3 during spider attack
var starBlink;    // for blinking diamond snake hit stars animation

// reset pressed keys to none pressed
var AKeyPressed = false;  // indicates if a previuos hit "of the game A" key was already pressed to avoid double entries
var BKeyPressed = false;  // indicates if a previuos hit of the "game B" key was already pressed to avoid double entries
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var keyPressedID; // ID for slower continues movements
var RKeyPressed = false;  // indicates if a previuos hit of the "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;  // indicates if a previuos hit of the "TIME" key was already pressed to avoid double entries

// reset pressed keys to none pressed
var keyDown = false;
var keyUp = false;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

// Disable Double-Tap Zoom on Mobile Browser
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$('.no-zoom').bind('touchend', function(e) {
  e.preventDefault();
  // Add your code here. 
  $(this).click();
  // This line still calls the standard click event, in case the user needs to interact with the element that is being clicked on, but still avoids zooming in cases of double clicking.
});

(function($) {
  $.fn.nodoubletapzoom = function() {
    $(this).bind('touchstart', function preventZoom(e) {
      var t2 = e.timeStamp
        , t1 = $(this).data('lastTouch') || t2
        , dt = t2 - t1
        , fingers = e.originalEvent.touches.length;
      $(this).data('lastTouch', t2);
      if (!dt || dt > 500 || fingers > 1) return; // not double-tap
      e.preventDefault(); // double tap - prevent the zoom
      // also synthesize click events we just swallowed up
      $(this).trigger('click').trigger('click');
    });
  };
})(jQuery);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// End Disable Double-Tap Zoom on Mobile Browser

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
  codeCurrent = e.keyCode;    // for reading game keys
  e.preventDefault();    // prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
  switch (e.key) {
    case "1": case "a": case "A":   // if "1", "a" or "A" pressed
      // show game A button pressed
      document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';   
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!BKeyPressed) { // if no other key is pressed
        MainGameA(); // show high score @ play Game A after button release
        AKeyPressed = true;
      };
      break;
    case "2": case "b": case "B":   // if "2", "b" or "B" pressed
      // show game B button pressed
      document.images['Game B'].src = 'img/case/buttons/grey_2_flat.png';  // show pressed button on screen
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!AKeyPressed) { // if no other key is pressed
        MainGameB(); // show high score and get ready to play Game B
        BKeyPressed = true;
      };
      break;
    case "d": case "D": case "ArrowRight":  // right keys
      // show left button pressed
      document.images['Move Right'].src = 'img/case/buttons/curr_in.png';   
      RightPressed();    // function to move right
      break;
    case "e": case "E": case "ArrowUp":  // up keys
      // show left button pressed
      document.images['Move Up'].src = 'img/case/buttons/curu_in.png';   
      UpPressed();    // function to move up
      keyPressed = true;
      break;
    case "s": case "S": case "ArrowLeft":  // left keys
      // show left button pressed
      document.images['Move Left'].src = 'img/case/buttons/curl_in.png';   
      LeftPressed();    // function to move left
      break;
    case "x": case "X": case "ArrowDown":  // down keys
      // show left button pressed
      document.images['Move Down'].src = 'img/case/buttons/curd_in.png';   
      DownPressed();    // function to unlock a locked wall down
      keyPressed = true;
      break;
    case " ":   // space key
      // show use button pressed
      document.images['Use'].src = 'img/case/buttons/use_flat.png';   
      UsePressed();   // to activate the function to perform a jump, unlock locked wall above, attack a creature or deactivate active map
      keyPressed = true;
      break;
    case "r": case "R":   // if "r" or "R" pressed
      // show acl button pressed
      document.images['Acl'].src = 'img/case/buttons/acl_push.png';
      RKeyPressed = true;
      ClearPressedKeys();  // ignore and clear all other keys that are pressed
      TotalReset(); // show full sprites
      break;
    case "t": case "T":   // if "t" or "T" pressed
      // show time button pressed
      document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
      TKeyPressed = true;
      if (!demo) {
        MainTime();     // initiate demo 
      };
      TimeShowOnScreen(prefAlarmMin, prefAlarmHour);    // show set alarm time 
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button pressed
      document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainAlarm(); // set alarm
      break;
    //test case buttons 
    case "+":  // "+"-numpadkey
      if (vlm<1) {
        vlm = (parseFloat(vlm) + 0.01).toFixed(2);  // increase volume for test purposes
        preVlm = vlm;   // current voluem becomes previus set @ next change of volume
      };
      if (vlm==0.01)  SetSound(true);  // show sound turned on
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "-":  // "-"-key
      if (vlm>0) {
        vlm = (parseFloat(vlm) - 0.01).toFixed(2);  // decrease volume for test purposes
        preVlm = vlm;   // current voluem becomes previus set @ next change of volume
      };
      if (vlm==0) SetSound(false);  // show sound turned off
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "/":  // "/"-key
      if (vlm==0.3) vlm = 0.03
      else vlm = 0.3;
      prefSound = 1;
      PrefSoundShow();  // show volume indicator on screen for testing purposes if set
      PrefSoundSettings();  // show sound on/off indication
      break;
    case "g": case "G":   // if "g" or "G" pressed
      // swich sound on/off for testing purposes
      PrefSound();
      break
    case "n": case "N":   // if "v" or "N" pressed
      // swich sound on/off for testing purposes
      SoundSwitch();
      break
    case "@": case String.fromCharCode(233):  // mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
      prefSoundShow = !prefSoundShow;   // show/hide indicator
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case ")": case String.fromCharCode(219):  // ")"-key
      zoomed = zoomed?0:1;  // toggle auto zoom function on/off
      $(function () {
        CheckSizeZoom()  // calculate size and position for autozoom if set or get default if not set
        $('#divWrap').css('visibility', 'visible');
      });
      $(window).resize(CheckSizeZoom);  // autozoom to calculated size and position/default
      break;
    case "!":  // toggle full/normal screen
      if (!fullScreen) {
        OpenFullScreen();
      } else {
        CloseFullScreen();
      };
      break;
    default:
  };
  // console.log("You pressed e.keyCode : " + e.keyCode + " <==> %c '" + e.key + "'"+(life?(" %c lives left = "+life):" %c")+" ","background-color:green; color:gold; font-weight:bold;","background-color:white; color:black;","   --   fullScreen = "+fullScreen);
}, false);

window.addEventListener("keyup", function (e) {
  // game and arrow keys
  switch (e.key) {
    case "1": case "a": case "A":   // if "1", "a" or "A" released
      // show game A button default
      document.images['Game A'].src = 'img/case/buttons/grey_1.png';  
      if (AKeyPressed) MainGameAGo(); // start running Game A
      AKeyPressed = false;
      break;
      AKeyPressed = false;
    case "2": case "b": case "B":   // if "2", "b" or "B" released
      // show game B button default
      document.images['Game B'].src = 'img/case/buttons/grey_2.png';   // show game B button default
      if (BKeyPressed) MainGameBGo(); // play Game A
      BKeyPressed = false;
      break;
    case "d": case "D": case "ArrowRight":  // left keys
      // show right button released
      document.images['Move Right'].src = 'img/case/buttons/curr.png';   
      keyPressed = false;
      break;
    case "e": case "E": case "ArrowUp":  // up keys
      // show up button released
      document.images['Move Up'].src = 'img/case/buttons/curu.png';   
      keyPressed = false;
      break;
    case "s": case "S": case "ArrowLeft":  // right keys
      // show left button released
      document.images['Move Left'].src = 'img/case/buttons/curl.png';   
      keyPressed = false;
      break;
    case "x": case "X": case "ArrowDown":  // down keys
      // show down button released
      document.images['Move Down'].src = 'img/case/buttons/curd.png';   
      keyPressed = false;
      break;
    case " ":   // space key
      // show use button released
      document.images['Use'].src = 'img/case/buttons/use.png';   
      keyPressed = false;
      break;
    case "r": case "R":   // if "r" or "R" released
      // show acl button default
      document.images['Acl'].src = 'img/case/buttons/acl.png';
      RKeyPressed = false;
      break;
    case "t": case "T":   // if "t" or "T" released
      // show time button default
      document.images['Time'].src = 'img/case/buttons/grey_3.png';
      if (!demo&&TKeyPressed) {
      	TimeShowOnScreen(min, hour);  // show required time and indicators on screen from current time
        MainTimeStart();     // start initiated demo 
      };
      TKeyPressed = false;
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button default
      document.images['Alarm'].src = 'img/case/buttons/acl.png';
      break;
   default: 
  };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

// if reviewing this tab, refresh screen
$(window).focus(function(){
  //focus log code
  console.log("---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          "+(gameOver?"screen not refreshed because GAME OVER !!!%c%c":"%c SCREEN REFRESHED ! %c"),
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:turquoise; color:blue; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:green; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:purple; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "     ---");   // color test
  if (demo) FiguresScreenShowCurrent(); // show current screen status from bottom to top
});


//when page loaded focus on game 
$(document).ready(function () {
  Beep();    // play beep sound to set sound
  PlaySound("click_wav", vlm);  // click sound (for waking up some browsers' sound play if neccesary)
  $(function () {  // autozoom @ start
    CheckSizeZoom()  // calculate size and position for autozoom
    $('#divWrap').css('visibility', 'visible');
  });
  $(window).resize(CheckSizeZoom);  // autozoom to calculated size
  $("#game").focus(); // get focus on the game
  highScore[1] = 0;  // highest score game A
  highScore[2] = 0;  // highest score game B
  PicPreload();  // this function preloads all images to make them ready for use
  MainPicturesShow();  // show default figures
  demoID = window.setTimeout("MainTimeStart()", 60000);  // start demo after a minute  
  console.log("\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39 --- %c "+today+" %c --- %c welcome to this Game & Watch simmulator, have fun! ", 
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:lime; color:orangered; font-weight:bold;",
        " ---");   // color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// jump, unlock locked wall above, attack a creature or deactivate active map
function Action () {
  var labyVal = laby[posy][posx];    // get labyrinth value @ current position
  var labyValJump = laby[posy+1][posx];  // get labyrinth value if jumping @ current position
  if (!(labyVal%8>3)&&labyValJump%8>3&&!pause&&!levelDone&&!miss) {  // if no ceiling above & wall to jump on underneath and level not done yet and not miss going on
    if (jumpID) {     // if jump & land was initiated
      window.clearTimeout(jumpID);  // stop jump & land
      jumpID = null;  // reset jump ID
    };
    HeroHide();  // hide hero @ previous position 
    if ((posy-1)%4) {    // if not leaving screen range
      jumping = true;  // jumpinh/falling in progress, no other jumps possible
      posy--;    // jump 1 position up
      HeroShow();  // show hero @ current position 
      PlaySound("move_wav", vlm);  // move/jump sound 
      if (!demo) jumpID = window.setTimeout("JumpLand();", 800)  // come down and land after jump in 800 milliseconds
    } else {
      if (posy>1) {    // if not end of labyrinth range
        jumping = true;  // jumpinh/falling in progress, no other jumps possible
        posy--;    // jump 1 position up
        screenLineSet = parseInt((posy-1)/4);    // calculate current screen line set (4 lines per screen segment)
        screenShifted = 0;    // no screen shift going on
        ArtGuardsHide();    // hide all present artifacts and creatures
        ScreenShift('up');
        PlaySound("move_wav", vlm);  // move/jump sound 
        if (!demo) jumpID = window.setTimeout("JumpLand();", 800)  // come down and land after jump in 800 milliseconds
     } else {
        HeroShow();  // show hero @ final position 
      };
    };
    LabyCheck();    // check what's present & going on @ this labyrinth position & progress
  } else {
    if (laby[posy][posx]%16>7&&keyHold) {    // if wall above has lock & key aquired
      PlaySound("unlock_wav", vlm);  // unlock/open sound 
      OpenWall("up", 3,posx,posy);    // open wall above
    };
  };
};

// hero attacks the snake with rocks
function AttackSnake () {
  if (snakeHitID) {     // if snake hit was initiated
    window.clearTimeout(snakeHitID);  // stop snake getting hit
    snakeHitID = null;  // reset snake hit ID
  };
  if (!heroAttacking&&!pause) {    // if hero is not yet attacking snake and game not paused
    if (heroAttackID) {     // if hero attacking was initiated
      window.clearTimeout(heroAttackID);  // stop hero attacking
      heroAttackID = null;  // reset hero attacking ID
    };
    heroAttacking = 1;    // hero is attacking snake
    PicShow("Armstop", nullPre.src);    // hide left external hero's arms up
    PicShow("Armsdown", ArmsdownPre.src);  // show left external hero's arms (hands) in "rock throwing"/"rest" position
    PicShow("FallingStone", FallingStonePre.src);    // show falling stone, thrown by hero to attack snake
    snakeHitID = window.setTimeout('PicShow("FallingStone", nullPre.src);',700);  // hide falling stone, thrown by hero to attack snake after 800 milliseconds
    if (snakePos==1) {    // if snake @ most left position
      starBlink = 0;    // start of blink seqeunce of snake getting hit
      snakeHit++;    // count snake hit by hero
      PlaySound("snakeHit_wav", vlm);  // snake hit sound 
      SnakeHit();    // snake hit animation
    };
    if (snakeHit>4) {    // if snake got hit more than 4 times
      pause = true;
      heroAttackID = window.setTimeout("starBlink = 1; SnakeDone();",1000);    // animate beaten snake i a second
    }; 
    heroAttackID = window.setTimeout("AttackSnakeBack();", 700);    // return hero's hands up after throwing the rock @ the snake after 700 milliseconds
  };
};

// Return hero's hands after throwing the rock @ the snake
function AttackSnakeBack () {
  if (heroAttackID) {     // if hero attacking was initiated
    window.clearTimeout(heroAttackID);  // stop hero attacking
    heroAttackID = null;  // reset hero attacking ID
  };
  heroAttacking = 0;    // hero is not attacking snake
  if (heroExtern) PicShow("Armstop", ArmstopPre.src);    // show left external hero's arms up if hero still out of laby
  PicShow("Armsdown", nullPre.src);    // hide left external hero's arms (hands) in "rock throwing"/"rest" position
}; 

// hero attacks the spider with rocks
function AttackSpider () {
  if (!heroAttacking&&!pause) {    // hero is attacking spider and game not paused
    if (heroAttackID) {     // if hero attacking was initiated
      window.clearTimeout(heroAttackID);  // stop hero attacking
      heroAttackID = null;  // reset hero attacking ID
    };
    heroAttacking = 1;    // hero is attacking spider
    PicShow("StoneTop", StoneTopPre.src);  // show the stone the hero throws @ top to attack the big spider
    if (spiderPos==0||spiderPos==5) {    // if spider not attacking
      starBlink = 0;    // start of blink seqeunce of spider getting hit
      spiderHit++;   // count spider hit by hero
      PlaySound("spiderHit_wav", vlm);  // spider hit sound 
      SpiderHit();    // spider hit animation
    };
    if (spiderHit>4) {    // if spider got hit more than 4 times
      pause = true;
      heroAttackID = window.setTimeout("starBlink = 1; HeroHide(); SpiderDone();",1000);    // animate hero exit after beaten the spider in a second
    };
    heroAttackID = window.setTimeout("PicShow('StoneTop', nullPre.src);",200);  // hide the thrown stone on top in 200 milliseconds
  };
};

// go down @ game or change alarm hour or minutes if alarm is being set
function Down () {
  var labyVal = posx<44?laby[posy+1][posx]:0;    // get labyrinth value beneath current position if in laby dimention
  if ((game==1||game==2)&&!miss) {  // if game playing and not miss going on
    // go position downwards
    if ((labyVal%16>7)&&keyHold) {  // if wall underneath has lock & key aquired
      PlaySound("unlock_wav", vlm);  // unlock/open sound 
      OpenWall("down", 3,posx,posy);    // open wall below
    };
  } else {
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmMin--;  // substract a minute from alarm time
      if (prefAlarmMin==-1) prefAlarmMin=59;  // substracting a minute from 0 gets 60
      AlarmShowNum();  // show alarm time
    };
  };
};

// down button or -key pressed
function DownPressed () {
  if (mapActive) {    // if reading map
    if (screenLineSet<screenLineSetLast) {   // if not lowest screen segment
      screenLineSet++;    // go to lower screen segment
      screenShifted = 0;    // no screen shift going on 
      ArtGuardsHide();    // hide all present artifacts and creatures
      ScreenShift('down');
    };    
  };  
  if (!keyPressed&&(!demoID||game==5||game==8)) { // if game still running or alarm being set
    Down();  // go down @ game or change alarm hour or minutes if alarm is being set
    keyPressed = true;
  };
};

// actually go down
function GoDown () {
  if (jumpID) {     // if jump & land was initiated
    window.clearTimeout(jumpID);  // stop jump & land
    jumpID = null;  // reset jump ID
  };
  HeroHide();  // hide hero @ previous position 
  if (posy%4) {    // if not leaving screen range
    posy++;    // hero goes position below
    HeroShow();  // show hero @ current position 
    PlaySound("move_wav", vlm);  // move/jump sound 
    if (laby[posy+1][posx]%8>3) JumpLand()    // land immediately if floor underneath
    else jumpID = window.setTimeout("JumpLand();", 400)  // check if no wall underneeth & come down and land if so in 400 milliseconds    
  } else {
    if ((posy+1)<(lastLine-1)) {    // if not end of labyrinth range or hero got stung by scorpion
      posy++;    // hero goes position below
      screenLineSet = parseInt((posy-1)/4);    // calculate current screen line set (4 lines per screen segment)
      screenShifted = 0;    // no screen shift going on
      ArtGuardsHide();    // hide all present artifacts and creatures
      ScreenShift('down');
      PlaySound("move_wav", vlm);  // move/jump sound 
      if (laby[posy][posx]%64>31) {    // if scorpion @ landing place
        jumping = false;    // jumping/falling done
        Miss();
      };
    } else {
      jumping = false;    // jumping/falling done
      Miss();
    };
  };
  if (jumpMoved>0) jumpMoved--;  // one step closer to be able to move
  LabyCheck();    // check what's present & going on @ this labyrinth position & progress
};

// actually go to the left
function GoLeft () {
  var miss = false;
  for (s=1; s<(scorpions+1); s++) {    // check all scorpions
    if (!invincible&&(posxScorpion[s] ==posy&&(posyScorpion[s]+1)==posx)) {    // if scorpion meets vincible hero
      miss = true;
    };
  };    
  if (!miss&&!levelDone) {    // if no miss @ going on level
    if (!jumpMoved) {    // if jump progressed enough to move
      if (jumpID) {     // if jump & land was initiated
        window.clearTimeout(jumpID);  // stop jump & land
        jumpID = null;  // reset jump ID
      };
      HeroHide();  // hide hero @ previous position 
      if ((posx-1)%5) {    // if not leaving screen range
        posx--;    // hero goes position to the left
        HeroShow();  // show hero @ final position 
        PlaySound("move_wav", vlm);  // move/jump sound 
        jumpID = window.setTimeout("JumpLand();", 400);  // check if no wall underneeth & come down and land if so in 400 milliseconds    
      } else {
        if (posx>1) {    // if not end of labyrinth range
          pause = true;  
          posx--;    // go position to the left
          screenRowSet = parseInt((posx-1)/5);    // calculate row set (of 5 rows per segment) of the labyrinth shown on screen
          screenShifted = 0;    // no screen shift going on yet
          ArtGuardsHide();    // hide all present artifacts and creatures
          ScreenShift('left');
          PlaySound("move_wav", vlm);  // move/jump sound 
        } else {
          HeroShow();  // show hero @ final position 
        };
      };
      if (laby[posy+1][posx]%8>3) {   // if  floor underneeth
          jumping = false;    // jumping/falling done
      } else { 
        if (jumping) jumpMoved = 3  // three steps limit before able to move
        else jumpMoved = 1;   // one step left before able to move
      };
      LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    };
  } else {
    Miss();
  };
};

// actually go to the right
function GoRight () {
  var miss = false;    // no miss yet
  for (s=1; s<(scorpions+1); s++) {    // check all scorpions
    if (!invincible&&(posxScorpion[s] ==posy&&(posyScorpion[s])==posx)) {    // if scorpion meets vincible hero
      miss = true;
    };
  };    
  if (!miss&&!levelDone) {    // if no miss @ going on level
    if (!jumpMoved) {    // if jump progressed enough to move
      if (jumpID) {     // if jump & land was initiated
        window.clearTimeout(jumpID);  // stop jump & land
        jumpID = null;  // reset jump ID
      };
      HeroHide();  // hide hero @ previous position 
      if (posx%5) {    // if not leaving screen range
        posx++;    // go position to the right
        HeroShow();  // show hero @ current position 
        PlaySound("move_wav", vlm);  // move/jump sound 
        jumpID = window.setTimeout("JumpLand();", 400)  // check if no wall underneeth & come down and land if so in 250 milliseconds    
      } else {
        if (posx<lastRow) {    // if not en of labyrinth range
          pause = true; 
          posx++;    // go position to the right
          screenRowSet = parseInt((posx-1)/5);    // calculate row set (of 5 rows per segment) of the labyrinth shown on screen
          screenShifted = 0;    // no screen shift going on yet
          ArtGuardsHide();    // hide all present artifacts and creatures
          ScreenShift('right');
          PlaySound("move_wav", vlm);  // move/jump sound 
        } else {
          HeroShow();  // show hero @ final position 
        };
      };
      if (laby[posy+1][posx]%8>3) {   // if  floor underneeth
          jumping = false;    // jumping/falling done
      } else { 
        if (jumping) jumpMoved = 3  // three steps limit before able to move
        else jumpMoved = 1;   // one step before able to move
      };
      LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    };
  } else {
    Miss();
  };
};

// hero re-enters the laby after attacking a monster
function HeroBack (attacker) {
  HeroHide();    // hide hero @ current position
  heroExtern = 0;    // hero is not out of the labyrinth anymore
  heroAttacking = 0;    // hero is not attacking snake or spider
  HeroShow();    // show hero @ next position
};

// hero goes outside the laby to attack a monster
function HeroLeave (attacker) {
  HeroHide();    // hide hero @ current position
  if (attacker=="snake") {    // if monster is snake
    heroExtern = 1;    // indicate hero's place to the right
  };
  if (attacker=="spider") {    // if monster is spider
    heroExtern = 2;    // indicate hero's place to the left
  };
  HeroShow();    // show hero @ next position
};

//
function JumpExtern () {
  if (jumpID) {     // if jump & land was initiated
    window.clearTimeout(jumpID);  // stop jump & land
    jumpID = null;  // reset jump ID
  };
  HeroHide();    // hide hero @ current position
  heroExtern++;    // go to left external jump position 
  HeroShow();    // show hero @ next position
  // if hero @ laby section where map available
  if (mapHero&&screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap&&!mapReceived) {
    mapReceived = true;    // hero got the map
    MapShow();    // show the map on the top left corner if not received, else show the side map indicating map received
  };
  jumpID = window.setTimeout("JumpExternBack();",700);    // return from jumping in 700 milliseconds
};

//
function JumpExternBack () {
  HeroHide();    // hide hero @ current position
  heroExtern--;    // hero landed @ the left outside the labyrinth
  HeroShow();    // show hero @ next position
  heroAttacking = 0;    // hero is not attacking spider
};

//  fall down to land after jump
function JumpLand () {
  var labyVal = posy<44?laby[posy+1][posx]:0;  // if not end of labyrinth get labyrinth value @ position beneath
  if (jumpMoved>0) jumpMoved--;  // one less jump/land position to wait before move is possible
  if (!(labyVal%8>3)) {    // if no floor underneeth
    GoDown();    // actually go down
  } else {
    jumping = false;    // jumping/falling done
    jumpMoved = 0;  // able to move after jumpLand 
    if (!invincible&&(laby[posy][posx]%64>31)&&(scorpionDir[(ScorpionNumber(posy,posx))]<1)) {    // miss if scorpion present and not moving away from vincible hero
      Miss();
    } else {
      LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    };
  };
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
  var labyVal = laby[posy][posx];    // get labyrinth value @ current position
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss) {  // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);  // stop key up delay
      keyPressedID = null;  // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    if (!levelChooser) {    // if not choosing level @ game B
      if (labyVal%2) {  // if @ next position wall present
        if ((labyVal%4>1)&&keyHold) {  // if next wall has lock and key aquired
          PlaySound("unlock_wav", vlm);  // unlock/open sound 
          OpenWall("left",3,posx,posy);    // open wall to the left
        };
      } else {
        // if labyrinth segment has big spider or map && hero is @ entering position
        if (((posy%4)==2)&&((exitBlockedSpider||(mapHero&&!mapReceived))&&((posx-screenRowSet*5) + 5*(posy-screenLineSet*4 -1)==6)&&((screenLineSet==screenLineSetSpiderBig&&screenRowSet==screenRowSetSpiderBig)||(screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap))))  {    
          if (!heroExtern) {    // if hero inside the laby
            HeroLeave("spider");    // go outside the laby @ the exit blocking spider
            if (spiderPos==4) {    // if attacking spider @ open wall (entrance)            
              if (spiderAttackID) {     // if key up delay was initiated
                window.clearTimeout(spiderAttackID);  // stop key up delay
                spiderAttackID = null;  // reset key press ID
              };              
              Miss();    // if spider already @ the entrance, miss
              spiderAttackID = window.setTimeout("SpiderAttack();",600);    // next spider attack in 600 milliseconds
            };
          };
        } else {
          if (heroExtern==1) {    // if hero outside the laby @ diamond snake
            HeroBack("snake");    // enter the laby again @ diamond snake
          } else {  
            if (posx>1) {    // if not @ most left position of laby
              GoLeft();  // go position to the left
            };
          };
        };
      };
    } else {
      if (level>1) level--    // if not first level, level down
      else level = levels;    // else goto last level
      LevelShow();    // show current level choice
    };
  } else {
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmHour--;  // substract an hour from alarm setting
      if (prefAlarmHour==-1) prefAlarmHour = 23;  // substracting an hour from 0 gets 24 -1 = 23
      AlarmShowNum();  // show alarm time
    };
  };
};

// left button or -key pressed
function LeftPressed () {
  if (mapActive) {    // if reading map
    if (screenRowSet>0) {    // if row set (of 5 rows per segment) not the first of the labyrinth shown on screen
      screenRowSet--;    // go to previous segment
      screenShifted = 0;    // no screen shift going on yet
      ArtGuardsHide();    // hide all present artifacts and creatures
      ScreenShift('left');
    };        
  } else {
    if (!keyPressed&&(!demoID||game==5||game==8)) { // if game still running or alarm being set
      Left();  // go left @ game or change alarm hour or minutes if alarm is being set
    }; 
  };
};

// show current level choice
function LevelShow () {
  PicShow("Num1", LevPre.src);    // show "L" for level
  PicShow("Num2", nullPre.src);    // second digit not used
  // next two digits show current choise of level to play
  if (level>9) PicShow("Num3", numPre[Math.floor(level/10)+1].src);    // third digit
  else PicShow("Num3", nullPre.src);    // empty below 10
  PicShow("Num4", numPre[(level%10)+1].src);  // fourth digit
};

// make an array
function MakeArray (size) {
  this.length = size;
  for(var i=1; i<=size; i++) this[i] = 0;
};

// lopen the locked wall @ given direction
function OpenWall (wallDir,wallSequence,posxWall,posyWall) {
  var posxLockedWall = posxWall-screenRowSet*5;    // calculate row on screen of locked wall
  var posyLockedWall = posyWall-screenLineSet*4;    // calculate line on screen of locked wall
  var keyPosX = 0;    // horizontal animation position for key use
  var keyPosY = 0;    // vertical animation position for key use
  if (demoID) {     // if demo was initiated
    window.clearTimeout(demoID);  // stop demo timer
    demoID = null;  // reset demo ID
  };
  pause = true;
  if (keyHold==1) PicShow("KeyLeft", nullPre.src);  // if last key holding, hide left Key Left when used
  switch (wallDir) {    // wall direction position adjustments
    case "right" : 
      posxLockedWall = posxWall-screenRowSet*5+1;    // calculate adjusted row on screen for right locked wall
      keyPosX = -1;    // readjustment for the key use
      break;
    case "down" :
      posyLockedWall = posyWall-screenLineSet*4+1;    // calculate adjusted line on screen for bottom locked wall
      keyPosY = -1;    // readjustment for the key use
      break;
    default :
  };
  switch (wallSequence) {    // wall opening animation sequence
    case 3 :
      // show key next to hero to open the wall
      PicShow("Key"+eval((posyLockedWall+keyPosY)*10+(posxLockedWall+keyPosX))+"", KeyPre.src);   // show the key @ hero opening this wall
      break;
    case 2 :
      // hide key next to hero to open the wall
      PicShow("Key"+eval((posyLockedWall+keyPosY)*10+(posxLockedWall+keyPosX))+"", nullPre.src);
      // hide the lock of the specified wall
      if (wallDir=="down"||wallDir=="up") PicShow("LockHor"+eval(posyLockedWall*10+posxLockedWall)+"", nullPre.src)
      else PicShow("LockVert"+eval(posyLockedWall*10+posxLockedWall)+"", nullPre.src);
      break;
    case 1: 
      // hide the specified wall
      if (wallDir=="down"||wallDir=="up") PicShow("WallHor"+eval(posyLockedWall*10+posxLockedWall)+"", nullPre.src)
      else PicShow("WallVert"+eval(posyLockedWall*10+posxLockedWall)+"", nullPre.src);
      break;
    default: 
  };
  wallSequence--;    // next unlock animation
  if (wallSequence) {    // if animation still running
    demoID = window.setTimeout("OpenWall ('"+wallDir+"',"+wallSequence+","+posxWall+","+posyWall+");", 200);  // next animation step
  } else {
     if (wallDir=="down"||wallDir=="up") {    // if wall to open is above or beneath
       laby[(posyWall+(wallDir=="up"?0:1))][posxWall] = eval(laby[(posyWall+(wallDir=="up"?0:1))][posxWall]) - 12;    // remove horizontal lock (8) and wall (4)    (8+4=12)
       if (wallDir=="down") GoDown();    // fall if wall below opened
     } else {
       laby[posyWall][(posxWall+(wallDir=="left"?0:1))] = eval(laby[posyWall][(posxWall+(wallDir=="left"?0:1))]) - 3;    // remove vertical lock (2) and wall (1)    (2+1=3)
     };
     keyHold--;    // one key used
     pause = false;
  };
};

// show/hide figure on screen
function PicShow (id, name) {
  if (name) document.images[id].src = name;  // if picture given assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
  var labyVal = posx<80?laby[posy][posx+1]:0;    // get labyrinth value on the right of current position if within laby dimention
  var vaseNum;    // to remember the vase number in this laby segment
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss) {  // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);  // stop key up delay
      keyPressedID = null;  // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    if (!levelChooser) {    // if not choosing level @ game B
      if (labyVal%2&&!heroExtern) {  // if next wall present and hero intern the labyrinth
        if ((labyVal%4>1)&&keyHold) {  // if next wall has lock & key aquired
          PlaySound("unlock_wav", vlm);  // unlock/open sound 
          OpenWall("right", 3,posx,posy);    // open wall to the right
        } else {
          if (laby[posy][posx]%1024>511) {    // if switch present
            if (laby[posy][posx]%255>127) {    // if lever is up
              laby[posy][posx] = eval(laby[posy][posx]) + 128;    // pull lever down          
            } else {
              laby[posy][posx] = eval(laby[posy][posx]) - 128;    // push lever up    
            }
            EventsCheck();    // check moving platforms animation and controls
            ShowCurrentLevelPart();  // show current visible part of the game level  
          };
        };
      } else {
        vaseNum = VaseNumSearch();    // get and remember the vase number in this laby segment
        // if labyrinth segment has vase && hero is @ vase position    
        if (vase[vaseNum]&&((posx-screenRowSet*5) + 5*(posy-screenLineSet*4 -1)==20)&&(screenLineSet==screenLineSetVase[vaseNum]&&screenRowSet==screenRowSetVase[vaseNum]))  {    
          if (vase[vaseNum]<5) VaseHit(vaseNum)    // if vase not yet desrtoyed, hit vase
          else GoRight();  // go position to the right
        } else {
          // if labyrinth segment has diamond snake && hero is @ diamond snake position
          if (((posy%4)==2)&&(snakeDiamond&&((posx-screenRowSet*5) + 5*(posy-screenLineSet*4 -1)==10)&&(screenLineSet==screenLineSetSnakeDiamond&&screenRowSet==screenRowSetSnakeDiamond)))  {    
            if (!snakeAttack&&!snakeDiamondDone) {    // if snake not attacking hero and not defeated yet by hero
              SnakeAttack();    // let snake attack hero
              snakeAttack = true;
            };
            if (!heroExtern) HeroLeave("snake");    // let hero go right extern of the laby, if not there yet
          } else {
            if (heroExtern>1) {    // if hero left extern of the laby
               if (heroExtern==2) HeroBack("spider");    // if @ opening in the wall enter laby again
            } else {  
              GoRight();  // go position to the right
            };
          };
        };
      };
    } else {    // if level choosing @ game B going on
      if (level<levels) level++    // if not last level, next level is up
      else level = 1;    // else back to first level
      LevelShow();    // show current level choice
    };
  } else {    // if setting alarm
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmHour++;  // add an hour to alarm setting
      if (prefAlarmHour==24) prefAlarmHour = 0;  // addng an hour to 23 gets 0
      AlarmShowNum();  // show alarm time
    };
  };
};

// right button or -key pressed
function RightPressed () {
  if (mapActive) {    // if reading map
    if (screenRowSet<screenRowSetLast) {    // if row set (of 5 rows per segment) not last of the labyrinth shown on screen
      screenRowSet++;    // go to next segment
      screenShifted = 0;    // no screen shift going on yet
      ArtGuardsHide();    // hide all present artifacts and creatures
      ScreenShift('right');
    };     
  } else {
    if (!keyPressed&&(!demoID||game==5||game==8)) {  // if game still running or alarm being set
      Right();  // go right @ game or change alarm hour or minutes if alarm is being set
    };
  };
};

// snake attacking hero to protect the diamond
function SnakeAttack () {
  var randomChooser;    // for random snake start position
  var snakePosPrev = snakePos;    // remember previous snake position
  // if not paused & diamond snake segment reached
  if (snakeAttackID) {    // if snake attack active
    window.clearTimeout(snakeAttackID);  // stop snake attack timer
    snakeAttackID = null;    // reset snake attack ID
  };    
  if (!pause&&screenLineSet==screenLineSetSnakeDiamond&&screenRowSet==screenRowSetSnakeDiamond) {
    if (spiderAttackID) {    // if spider attack timer active
      window.clearTimeout(spiderAttackID);  // stop spider attack timer
      spiderAttackID = null;    // reset spider attack ID
    };
    PicShow("StarStone", nullPre.src);    // hide star by stone, thrown by hero after hit
    if (snakePos) {  // if snake attack in progress
      snakeDir = Math.floor(Math.random()*7)?snakeDir:(snakeDir*(-1));    // randomise snake attack direction
      if (snakePos==2) {    // if snake in center position
        if (heroExtern==1) Miss();    // if hero present above snake, he gets bitten
      };
      snakePos+=snakeDir;    // position of attacking snake one position further
      if (snakePos>3||snakePos<0) snakePos = 0;    // no position of attacking snake
    } else {
      randomChooser = Math.floor(Math.random()*4);    // randomise timing for next attack
      if (randomChooser) snakePos = (randomChooser==1||randomChooser==3)?randomChooser:0;    // randomise starting position for next attack
      snakeDir = Math.floor(Math.random() * 2)?1:-1;    // randomise snake attack direction
    };
    if (snakeHit<6) {    // if snake not hit six times yet
      SnakesHide();    // hide the diamond snakes
      if (snakePos||snakePosPrev) PlaySound("move_wav", vlm);  // move/jump sound 
      if (snakePos&&!shiftPause) {    // if snake attack going on and no screen shift going on
        spiderAttackID = window.setTimeout('PicShow("Snake'+eval(snakePos)+'", Snake'+eval(snakePos)+'Pre.src);',5);  // show snake @ snake position if in section
      };  
      snakeAttackID = window.setTimeout("SnakeAttack();",700);    // next snake attack animation step in 700 milliseconds
    };
  } else {
    snakeAttackID = window.setTimeout("SnakeAttack();",300);    // next snake attack attempt animation step in 300 milliseconds
  };
};

// snake is beaten animation
function SnakeDone () {
  if (snakeAttackID) {    // if snake attack active
    window.clearTimeout(snakeAttackID);  // stop snake attack
    snakeAttackID = null;  // reset snake attack ID
  };
  PlaySound("move_wav", vlm);  // move/jump sound 
  PicShow("Snake3", Snake3Pre.src);  // show snake @ most right position;
  PicShow("StarStone", nullPre.src);    // hide star by stone, thrown by hero
  switch(starBlink) {    // snake is beaten animation sequence
    case 1 :
      SnakesHide();
      PicShow("SackLeftStar", SackLeftStarPre.src);    // show left knock out star @ snake
      break;
    case 2 :
      PicShow("SackStarRight", SackStarRightPre.src);    // show right knock out star @ snake
      break;
    case 4 :
      PicShow("SackStarRight", nullPre.src);  // hide right knock out star @ snake
      break;
    case 5 :
      PicShow("SackLeftStar", nullPre.src);  // hide left knock out star @ snake
      PicShow("SackStarRight", SackStarRightPre.src);    // show right knock out star @ snake
      break;
    case 6 :
      PicShow("SackLeftStar", SackLeftStarPre.src);    // show left knock out star @ snake
      break;
    case 7 :
      PicShow("SackStarRight", nullPre.src);  // hide right knock out star @ snake
      break;
    case 8 :
      PicShow("SackLeftStar", nullPre.src);  // hide left knock out star @ snake
      break;
    default :
  };
  starBlink++;    // next step
  if (starBlink<9) {    // if star blink animation not done yet
    snakeAttackID = window.setTimeout("snakePos = 0;  SnakeDone();", 300)    // proceed with next step in 300 milliseconds
  } else {
    blinkNum = 1;    // prepare for getting points for beating snake
    snakeAttackID = window.setTimeout("HeroHide(); SnakeDonePoints();", 1200);    // hide hero @ current position and animate points for defeating snake in over a minute
  };
};

// extra points after snake killed animation
function SnakeDoneNext () {
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop previous blink timer
    blinkID = null;  // reset blink ID 
  };
  HeroDiamondShow('down',0);    // show hero, arms down, on the right collecting points for defeating creature
  pause = false;
  HeroDiamondHide();    // hide external hero and arms on the right, the diamond he might hold as well
  HeroShow();    // show the hero @ current position
  if (invincible)  blinkID = window.setTimeout("HeroBlink("+2+");", 250);    // blink hero when invincible 
};

// getting points for beaten snake animation
function SnakeDonePoints (labyVal) {
  pause = true;
  SnakeDiamondHide();    // hide the diamond and snakes
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop previous blink timer
    blinkID = null;  // reset blink ID 
  };
  if (levelDoneID) {    // if level done timer active
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID
  };
  if (blinkNum<2) {
    HeroDiamondShow("up",1);    // show hero, arms up, on the right collecting points for defeating creature
  };
  blinkID = window.setTimeout("HeroDiamondShow('down',1);",(demo?1000:blinkSpeed));    // show hero, arms down, on the right collecting points for defeating creature
  if (blinkNum) {    // if blinking not done yet
    ScoreAdd(20);
    levelDoneID = window.setTimeout("SnakeDonePoints("+labyVal+");",(demo?2000:(blinkSpeed*2)))    // next step
  } else {
    snakeDiamondDone = 1;  // snake diamond done
    blinkNum = 2;  // number of blink animations
    if (!gold) {    // if all the gold found
      levelDoneID = window.setTimeout("LevelDoneSnake ();",(demo?2000:(blinkSpeed*2.5)));    // animate level with snake done in two and a half seconds
    } else {
      levelDoneID = window.setTimeout("SnakeDoneNext();",(demo?2000:(blinkSpeed*2)));    // proceed with game after snake killed animation in two seconds
    };
  };
  blinkNum--;    // next step
};

// snake hit animation
function SnakeHit () {
  if (snakeAttackID) {    // if snake attack initiated
    window.clearTimeout(snakeAttackID);  // stop snake attack timer
    snakeAttackID = null;  // reset snake attack ID
  };
  if (starBlink%2) PicShow("StarStone", StarStonePre.src);  // show star by stone, thrown by hero every 2 steps
  else PicShow("StarStone", nullPre.src);  // hide star by stone, thrown by hero every other steps
  starBlink++;    // next step
  if (starBlink<5) {    // if snake hit animation not done yet
    snakeAttackID = window.setTimeout("snakePos = 0;  SnakeHit();", 300)    // animate next step in 300 milliseconds
  } else {
    SnakesHide();    // hide the diamond snakes
    snakeAttack = true;    // let snake attack hero again
    snakeDir = -1;    // snake attack direction counter clock wise
    snakePos = 4;    // first attack position in this direction
    SnakeAttack();    // animate next attack step
  }; 
}; 

// spider attacking to guard the exit
function SpiderAttack () {
  var randomChooser;    // for random spider start position
  var spiderPosPrev = spiderPos;    // remember previous spider position
  // if all the gold found & exit blocking spider reached
  if (!gold&&!pause&&screenLineSet==screenLineSetSpiderBig&&screenRowSet==screenRowSetSpiderBig) {
    if (spiderAttackID) {    // if spider attack initiated
      window.clearTimeout(spiderAttackID);  // stop spider attack timer
      spiderAttackID = null;  // reset spider attack ID
    };
    spiderAttack = 1;    // spider is attacking
    if (!((spiderPos==3)&&(heroExtern==3))) {    // if hero already @ hitting position
      if (spiderPos) {    // if spider attack still running
        spiderPos++;    // position of attacking spider one position further
        if (spiderPos>5) {    // if end of spider attack animation
          spiderPos = 0;    // no position of attacking spider
        };
      } else {
        randomChooser = Math.floor(Math.random() * 3);    // throw dice to see if next attack gets started
        if (randomChooser) spiderPos = (randomChooser==0)?0:1;    // set next attack if dice provided
      };
      if (spiderHit<6) {    // if spider not beaten yet
        SpidersHide();    // hide the small spiders
        if (spiderPos||spiderPosPrev) PlaySound("move_wav", vlm);  // move/jump sound 
        if (spiderPos&&!shiftPause) {    // if spider attack going on and no screen shift going on
          SpiderBigShow();  // show spider @ spider position if in section
        };
        // if spider hits hero
        if (((spiderPos==4) &&(heroExtern==3||heroExtern==2))||((spiderPos==3)&&(heroExtern==3))) {
          Miss();
          spiderPos = 0;    // end of this attack
        };
        spiderAttackID = window.setTimeout("SpiderAttack();",600);    // next attack in 600 milliseconds
      };  
    } else { 
      Miss();
      spiderPos = 0;    // end of this attack
      spiderAttackID = window.setTimeout("SpiderAttack();",600);    // next attack in 600 milliseconds
    };
  } else {
    spiderAttackID = window.setTimeout("SpiderAttack();",300);    // try again in 300 milliseconds
  };
};

// spider is beaten animation
function SpiderDone () {
  if (spiderAttackID) {    // if spider attack initiated
    window.clearTimeout(spiderAttackID);  // stop spider attack
    spiderAttackID = null;  // reset spider attack ID
  };
  mapActive = false;    // map is not active
  mapDeactivate = false;    // not deactivating active map so screenshift can proceed
  mapHero = false;    // the top map is not present on this level
  mapReceived = false;    // hero didn't get the map yet
  PlaySound("move_wav", vlm);  // move/jump sound 
  switch(starBlink) {    // animation steps
    case 1 :
      PicShow("Exit", ExitPre.src);  // show the exit
      PicShow("ExitDoor", nullPre.src);  // hide/open exit door
      PicShow("SpiderBig", nullPre.src);  // hide the big spider on top
      PicShow("SpiderLeft", nullPre.src);  // hide the smaller spider on the left
      PicShow("SpiderLeg", nullPre.src);  // hide the big spider's leg on top
      PicShow("SpiderTop", nullPre.src);  // hide the smaller spider on top
      PicShow("StoneTop", nullPre.src);  // hide the stone the hero throws @ top to attack the big spider
      break;
    case 2 :
      PicShow("HeroExit", HeroExitPre.src);    // show the hero @ the exit
      PicShow("HatExit", HatExitPre.src);    // show hero's hat @ the exit
      break;
    case 3 :
      PicShow("HeroExit", nullPre.src);  // hide hero @ the exit
      break;
    case 4 :
      PicShow("HatExit", nullPre.src);  // hide hero's hat @ the exit
      break;
    default :
  };
  starBlink++;    // next step
  if (starBlink<5) {    // if exit animation not done
    spiderAttackID = window.setTimeout("spiderPos = 0;  SpiderDone();", 800)    // animate next step in 800 milliseconds
  } else {
    blinkNum = 1;    // first animation sequence
    spiderAttackID = window.setTimeout("HeroHide(); SpiderDonePoints();", 1200);    // hide hero @ current position and animate hero collecting points for spider that is beaten
  };
};

// animate hero collecting points for spider that is beaten
function SpiderDonePoints () {
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop previous blink timer
    blinkID = null;  // reset blink ID 
  };
  if (levelDoneID) {    // if level done timer active
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID
  };
  if (spiderAttackID) {    // if spider attack initiated
    window.clearTimeout(spiderAttackID);  // stop spider attack
    spiderAttackID = null;  // reset spider attack ID
  };
  pause = true;
  ArtGuardsHide();    // hide all present artifacts and creatures
  if (blinkNum<2) {    // if not second animation sequence
    HeroDiamondShow("up",0);    // show hero, arms up, on the right collecting points for defeating creature
  };
  blinkID = window.setTimeout("HeroDiamondShow('down',0);",(demo?1000:blinkSpeed));    // show hero, arms down, on the right collecting points for defeating creature
  if (blinkNum) {   // if animation not done
    ScoreAdd(15);    
    levelDoneID = window.setTimeout("SpiderDonePoints();",(demo?2000:(blinkSpeed*2)))    // next step
  } else {
    blinkNum = 2;  // second number of blink animations
    PlaySound("levelEnd_wav", vlm);    // end of level sound 
    spiderAttackID = window.setTimeout("HeroHide(); LevelDone();", 1000);    // hide hero @ current position and initiate level done in a second
  };
  blinkNum--;   // one less step of hero animation, collecting points
};

// spider hit animation
function SpiderHit () {
  if (spiderHitID) {    // if spider hit initiated
    window.clearTimeout(spiderHitID);  // stop spider hit timer
    spiderHitID = null;  // reset spider hit ID
  };
  if (starBlink==2) {    // @ second animation step
    PicShow("SpiderBig", nullPre.src);  // hide exit blocking spider 
    PicShow("SpiderLeg", nullPre.src);  // hide attacking leg of exit blocking spider 
  } else {
    PicShow("SpiderBig", SpiderBigPre.src);  // show exit blocking spider
  };
  starBlink++;    // next animation part
  if (starBlink<4) {    // if spider hit animation not done yet
    spiderHitID = window.setTimeout("spiderPos = 0;  SpiderHit();", 300)    // animate next step in 300 milliseconds
  } else {
    SpidersHide();    // hide all the spiders
    spiderAttack = 1;    // spider is attacking
    SpiderAttack();    // spider attacking animation
  }; 
}; 

// unlock wall to open above @ game or change alarm hour or minutes if alarm is being set
function Up () {
  var labyVal = posy>1?laby[posy][posx]:0;    // get labyrinth value @ current position if in laby dimention
  // if ((game==1||game==2)&&(labyVal%8>3)&&!pause&&!jumping&&!miss) {  // if game playing & wall above and not miss going on
  if ((game==1||game==2)&&!miss) {  // if game playing and not miss going on
    if (laby[posy][posx]%16>7&&keyHold) {    // if wall above has lock & key aquired
      PlaySound("unlock_wav", vlm);  // unlock/open sound 
      OpenWall("up", 3,posx,posy);    // open wall above
    };
  } else {
    if (game==5 || game==8) {  // change the alarm time
      prefAlarmMin++;  // add a minute to alarm time
      if (prefAlarmMin==60) prefAlarmMin=0;  // adding a minute to 59 gets 0
      AlarmShowNum();  // show alarm time
    };
  };
};

// up button or -key pressed
function UpPressed () {
  var labyVal = posy<44?laby[posy+1][posx]:0;  // if not end of labyrinth get labyrinth value @ position beneath
  if (mapActive) {    // if reading map
    if (screenLineSet>0) {    // if not highest screen segment
      screenLineSet--;    // go screen segment up
      screenShifted = 0;    // no screen shift going on yet
      ArtGuardsHide();    // hide all present artifacts and creatures
      ScreenShift('up');
    };    
  } else {
    if (!keyPressed&&(!demoID||game==5||game==8)) { // if game still running or alarm being set
      if (!(laby[posy][posx]%16>7) && game!=5 && game!=8) {    // if no lock present above or alarm time been set
        // if labyrinth segment has non active map && hero is @ this segment and wall above present & hero not on a moving platform
        if (((labyVal%8>3)&&((mapReceived&&!mapActive)))&&!platformActive[PlatformNumber((posy+1),posx)]) {
          mapActive = true;    // activate map
          screenLineSetHero = screenLineSet;    // remember the line set @ heroes position
          screenRowSetHero = screenRowSet;    // remember the row set @ heroes position
          MapBlink();
        }
      } else {
        Up();  // go up @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
      };
    };
  };
};

// use button or -key pressed
function UsePressed () {
  var horizonted = 0;    // to indicate if horizontal shift is needed to get back to hero's screen section
  var verticalled = 0;    // to indicate if vertical shift is needed to get back to hero's screen section
  if (mapActive) {    // if reading map
    horizonted = screenRowSet<screenRowSetHero?1:screenRowSet>screenRowSetHero?-1:0;
    verticalled = screenLineSet<screenLineSetHero?1:screenLineSet>screenLineSetHero?-1:0;
	 mapDeactivate = true;    // deactivating active map so screenshift will stop to default
    screenLineSet = screenLineSetHero;    // screen shift to hero's screen line
    screenRowSet = screenRowSetHero;    // screen shift to hero's screen row
    screenShifted = 0;    // no screen shift going on yet
    ArtGuardsHide();    // hide all present artifacts and creatures
    if (verticalled) ScreenShift(verticalled==-1?'up':'down');     // perform vertical shift if needed to get back to hero's screen section
    if (horizonted) ScreenShift(horizonted==-1?'left':'right');    // perform horizontal shift if needed to get back to hero's screen section
    mapActive = false;    // map not active anymore
    MapShow();    // show the map on the top left corner if not received, else show the side map indicating map received
  } else {
    if (!keyPressed&&(!demoID||game==5||game==8)&&!jumping) { // if game still running or alarm being set
      if (levelChooser) {    // if choosing level on game B
        if (gameID) {    // if game timer active
          window.clearTimeout(gameID);  // stop the game timer to avoid possible double call
          gameID = null;    // reset game ID
        };
        GameSet(); // default game settings and figures
        levelChooser = false;    // level chosen, game can begin
        gameID = window.setTimeout("MainGameBGoOn()", gameSpeed);  // start chosen game in gameSpeed milliseconds
      };
      switch (heroExtern) {    // if hero left or right out of the laby
        case 1 :    // left outside
          if (!heroAttacking&&!pause&&!snakeDiamondDone) AttackSnake();    // If hero not attacking, no pause and snake not beaten, attack snake now
          break;
        case 2 :    // right outside not jumping
          if (!pause) JumpExtern();    // if not paused, jump @ the left outside the labyrinth
          break;
        case 3 :    // right outside jumping
          // if hero not hitting spider, no pause and no map to retreive @ this place
          if (!spiderHitID&&!heroAttacking&&!pause&&!(mapHero&&screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap)) {
            if (gold) PlaySound("unlock_wav", vlm)  // if not all the gold found, play unlock sound 
            else AttackSpider();    // spider attacking animation
          };
          break;
        default :
          Action();  // do a default use action @ game or change alarm hour or minutes if alarm is being set
      };
      keyPressed = true;
    };
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
  alarmStateIndPre = new Image();
  AmuletPre = new Image();
  AmuletPre.src = "img/screen/Amulet.png";    // to show amulet hidden in the vase
  AnkhPre = new Image();
  AnkhPre.src = "img/screen/Ankh.png";    // to show ankh key hidden in the vase
  ArmsdownPre = new Image();
  ArmsdownPre.src = "img/screen/Armsdown.png";    // to show left external hero's arms (hands) in "rock throwing"/"rest" position
  ArmstopPre = new Image();
  ArmstopPre.src = "img/screen/Armstop.png";    // to show left external hero's arms up
  AlarmStateIndPre = new Image();
  AlarmStateIndPre.src = "img/screen/AlarmStateInd.png";    // to show bell in fron of rime/score if alarm is set
  BellDownPre = new Image();
  BellDownPre.src = "img/screen/BellDown.png";    // to show bell & hand of bell ringer down
  BellHandDownPre = new Image();
  BellHandDownPre.src = "img/screen/BellHandDown.png";    // to show second hand of bell ringer down
  BellUpPre = new Image();
  BellUpPre.src = "img/screen/BellUp.png";    // to show bell & hand of bell ringer up
  DiamondPre = new Image();
  DiamondPre.src = "img/screen/Diamond.png";    // to show the loose top diamond
  DiamondHandPre = new Image();
  DiamondHandPre.src = "img/screen/DiamondHand.png";    // to show diamond in hero's hand
  ExitPre = new Image();
  ExitPre.src = "img/screen/Exit.png";    // to show exit
  ExitDoorPre = new Image();
  ExitDoorPre.src = "img/screen/ExitDoor.png";    // to show exit door
  FallingStonePre = new Image();
  FallingStonePre.src = "img/screen/FallingStone.png";    // to show falling stone, thrown by hero to attack snake
  GoldPre = new Image();
  GoldPre.src = "img/screen/gold.png";    // to show gold rocks
  HandsPre = new Image();
  HandsPre.src = "img/screen/Hands.png";    // to show open hands possibly throwing diamond
  HandsUnderDiamondPre = new Image();
  HandsUnderDiamondPre.src = "img/screen/HandsUnderDiamond.png";    // to show hands under diamond
  HatExitPre = new Image();
  HatExitPre.src = "img/screen/HatExit.png";    // to show hero's hat @ the exit
  HeroPre = new Array();
  for (i=1 ; i<21 ; i++) {   // to show the 20 hero locations
    HeroPre[i] = new Image();
    HeroPre[i].src = (i%2?"img/screen/HeroRight.png":"img/screen/HeroLeft.png");
  };
  HeroDiamondPre = new Image();
  HeroDiamondPre.src = "img/screen/HeroDiamond.png";    // to show hero @ holding diamond place
  HeroExitPre = new Image();
  HeroExitPre.src = "img/screen/HeroExit.png";    // to show hero @ the exit
  HeroLeftPre = new Image();
  HeroLeftPre.src = "img/screen/HeroLeft_.png";    // to show left external hero
  HeroPlatformPre = new Image();
  HeroPlatformPre.src = "img/screen/HeroPlatform.png";    // to show right external hero on the platform
  HeroSideTopPre = new Image();
  HeroSideTopPre.src = "img/screen/HeroSideTop.png";    // to show left top external hero jumping for the map or attacking the spider
  KeyPre = new Image();
  KeyPre.src = "img/screen/Key.png";     // to show the laby keys and key holding indication @ left
  LevPre = new Image();
  LevPre.src = "img/screen/lev.png";    // to show level indication "L"
  LockHorPre = new Image();
  LockHorPre.src = "img/screen/LockHor.png";    // to show the locks of horizontal walls
  LockVertPre = new Image();
  LockVertPre.src = "img/screen/LockVert.png";    // to show the locks of vertical walls
  MapPre = new Image();
  MapPre.src = "img/screen/map.png";    // to show the side map indicating map received
  MapHeroPre = new Image();
  MapHeroPre.src = "img/screen/MapHero.png";    // to show the top map indicating map is available to be received
  MoonPre = new Image();
  MoonPre.src = "img/screen/moon.png";    // to show the moon above the pyramides
  nullPre = new Image();
  nullPre.src = "img/null.gif";    // empty picture to hide any figure
  numPre = new Array();
  for (i=1 ; i<11 ; i++) {     // to show the 10 digital numbers
    numPre[i] = new Image();
    numPre[i].src = "img/screen/num"+eval(i-1)+".png";
  };
  numColonPre = new Image();
  numColonPre.src = "img/screen/num_colon.png";    // to show time splitter colon
  PlatformPre = new Image();
  PlatformPre.src = "img/screen/platform.png";    // to show platform where the hero attacks the snake from
  PyramidSmallLinePre = new Array();
  for (i=1 ; i<8 ; i++) {     // to show the 7 lines under the pyramids
    PyramidSmallLinePre[i] = new Image();
    PyramidSmallLinePre[i].src = "img/screen/PyramidSmallLine"+eval(i)+".png";    // to show the 7 small lines under the pyramide as progress indication
  };
  PyramidsPre = new Image();
  PyramidsPre.src = "img/screen/pyramids.png";    // to show the pyramids on top
  SackLeftStarPre = new Image();
  SackLeftStarPre.src = "img/screen/sackleftstar.png";    // to show left knock out star @ snake
  SackStarRightPre = new Image();
  SackStarRightPre.src = "img/screen/sackstarright.png";    // to show right knock out star @ snake
  StarStonePre = new Image();
  StarStonePre.src = "img/screen/starstone.png";    // to show star @ stone, thrown by hero
  ScorpionLeftPre = new Image();
  ScorpionLeftPre.src = "img/screen/ScorpionLeft.png";    // to show the wandering scorpions facing the left
  ScorpionRightPre = new Image();
  ScorpionRightPre.src = "img/screen/ScorpionRight.png";    // to show the wandering scorpions facing the right
  SmallHeroPre = new Array();
  for (i=1 ; i<4 ; i++) {     // to show the 3 small heroes indicating lives left
    SmallHeroPre[i] = new Image();
    SmallHeroPre[i].src = ("img/screen/SmallHero.png");
  };
  Snake1Pre = new Image();
  Snake1Pre.src = "img/screen/snake1.png";    // to show left attacking snake
  Snake2Pre = new Image();
  Snake2Pre.src = "img/screen/snake2.png";    // to show middel attacking snake
  Snake3Pre = new Image();
  Snake3Pre.src = "img/screen/snake3.png";    // to show right attacking snake
  SnakeDiamondPre = new Image();
  SnakeDiamondPre.src = "img/screen/snakediamond.png";    // to show snake diamond
  SpiderBigPre = new Image();
  SpiderBigPre.src = "img/screen/SpiderBig.png";  // to show the big spider on top
  SpiderLeftPre = new Image();
  SpiderLeftPre.src = "img/screen/SpiderLeft.png";  // to show the spider on the left
  SpiderLegPre = new Image();
  SpiderLegPre.src = "img/screen/SpiderLeg.png";  // to show the big spider's leg on top
  SpiderTopPre = new Image();
  SpiderTopPre.src = "img/screen/SpiderTop.png";  // to show the spider on top
  StoneTopPre = new Image();
  StoneTopPre.src = "img/screen/StoneTop.png";  // to show the stone on top
  SunPre = new Image();
  SunPre.src = "img/screen/Sun.png";    // show the sun above the pyramides
  SwitchBasePre = new Image();
  SwitchBasePre.src = "img/screen/SwitchBase.png";  // to show the switch bases
  SwitchDownPre = new Image();
  SwitchDownPre.src = "img/screen/SwitchDown.png";  // to show the switches down
  SwitchUpPre = new Image();
  SwitchUpPre.src = "img/screen/SwitchUp.png";  // to show the switches up
  soundOnPre = new Image();
  soundOnPre.src = "img/case/buttons/butOn.png";  // to show sound button in on-state
  soundOffPre = new Image();
  soundOffPre.src = "img/case/buttons/butOff.png";  // to show sound button in off-state
  VasePre = new Image();
  VasePre.src = "img/screen/Vase.png";  // to show the vase
  VaseCrackLeftPre = new Image();
  VaseCrackLeftPre.src = "img/screen/VaseCrackLeft.png";  // to show left crack in the vase
  VaseCrackRightPre = new Image();
  VaseCrackRightPre.src = "img/screen/VaseCrackRight.png";  // to show the right crack in the the vase
  WallHorPre = new Image();
  WallHorPre.src = "img/screen/WallHor.png";  // to show horizontal walls
  WallVertPre = new Image();
  WallVertPre.src = "img/screen/WallVert.png";  // to show vertical walls
};

// erase all figures from screen
function AllPicturesClear () {
  AllPicturesScreenClear();    // erase all labyrinth figures
  AlarmShow();    // show if alarm is set on or not
  PicShow("Amulet", nullPre.src);    // hide amulet hidden in the vase
  PicShow("Ankh", nullPre.src);    // hide ankh key hidden in the vase
  PicShow("Armsdown", nullPre.src);    // hide left external hero's arms (hands) in "rock throwing"/"rest" position
  PicShow("Armstop", nullPre.src);  // hide left external hero's arms up 
  if (!alarmOn) PicShow("AlarmStateInd", nullPre.src); // hide alarm indicator on screen
  PicShow("BellDown", nullPre.src);    // hide bell & hand of bell ringer down
  PicShow("BellHandDown", nullPre.src);    // hide second hand of bell ringer down
  PicShow("BellUp", nullPre.src);    // hide bell & hand of bell ringer up
  PicShow("Diamond", nullPre.src);    // hide the loose top diamond
  PicShow("DiamondHand", nullPre.src);    // hide diamond in hero's hands
  PicShow("Exit", nullPre.src);  // hide exit
  PicShow("ExitDoor", nullPre.src);  // hide exit door
  PicShow("FallingStone", nullPre.src);    // hide falling stone, thrown by hero to attack snake
  if (!gameOver) {
    PicShow("Hands", nullPre.src);    // hide open hands possibly throwing diamond
    PicShow("HandsUnderDiamond", nullPre.src);    // hide hands under diamond
    PicShow("HeroDiamond", nullPre.src);    // hide hero @ holding diamond place
  };
  PicShow("HatExit", nullPre.src);    // hide hero's hat @ the exit
  PicShow("HeroExit", nullPre.src);    // hide hero @ the exit
  PicShow("HeroLeft", nullPre.src);    // hide left external hero
  PicShow("HeroPlatform", nullPre.src);    // hide right external hero on the platform
  PicShow("HeroSideTop", nullPre.src);    // hide left top external hero jumping for the map or attacking the spider
  PicShow("KeyLeft", nullPre.src);     // hide key holding indication @ left
  PicShow("Map", nullPre.src);    // hide the side map indicating map received
  PicShow("MapHero", nullPre.src);  // hide the top map indicating map is NOT available to be received
  PicShow("Moon", nullPre.src);  // hide the moon above the pyramides
  for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src); // hide all score/time/alarm numbers
  PicShow("NumColon", nullPre.src);  // hide the time/alarm colon
  PicShow("Platform", nullPre.src);  // hide platform where the hero attacks the snake from
  for (i=1 ; i<8 ; i++) PicShow("PyramidSmallLine"+eval(i)+"", nullPre.src);   // hide the 7 small lines under the pyramide
  PicShow("Pyramids", nullPre.src);  // hide the pyramids on top
  PicShow("SackLeftStar", nullPre.src);  // hide left knock out star @ snake
  PicShow("SackStarRight", nullPre.src);  // hide right knock out star @ snake
  PicShow("StarStone", nullPre.src);    // hide star by stone, thrown by hero
  for (i=1 ; i<4 ; i++) PicShow("SmallHero"+eval(i)+"", nullPre.src); // hide the 3 small heroes indicating lives left
  PicShow("Snake1", nullPre.src);    // hide left attacking snake
  PicShow("Snake2", nullPre.src);    // hide middel attacking snake
  PicShow("Snake3", nullPre.src);    // hide right attacking snake
  PicShow("SnakeDiamond", nullPre.src); // hide ringing Snake diamond
  PicShow("SpiderBig", nullPre.src); // hide the big spider on top
  PicShow("SpiderLeft", nullPre.src); // hide the spider on the left
  PicShow("SpiderLeg", nullPre.src); // hide the big spider's leg on top
  PicShow("SpiderTop", nullPre.src); // hide the spider on top
  PicShow("StoneTop", nullPre.src);  // hide the stone the hero throws @ top to attack the big spider
  PicShow("Sun", nullPre.src); // hide the sun on top
  PicShow("Vase", nullPre.src);  // hide the vase
  PicShow("VaseCrackLeft", nullPre.src);  // hide left crack in the vase
  PicShow("VaseCrackRight", nullPre.src);  // hide the right crack in the the vase
};

// erase all labyrinth figures from screen
function AllPicturesLabyrinthClear () {
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Gold"+eval(i*10+j)+"", nullPre.src);   // hide the 20 gold rocks
  PicShow("Hands", nullPre.src);    // hide open hands possibly throwing diamond
  PicShow("HandsUnderDiamond", nullPre.src);  // hide hands under diamond
  PicShow("HeroDiamond", nullPre.src);    // hide hero @ holding diamond place
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Key"+eval(i*10+j)+"", nullPre.src);   // hide the 20 Keys
  for (i=1 ; i<6 ; i++) for (j=1 ; j<6 ; j++) PicShow("LockHor"+eval(i*10+j)+"", nullPre.src);   // hide the 25 horizontal wall locks
  for (i=1 ; i<5 ; i++) for (j=1 ; j<7 ; j++) PicShow("LockVert"+eval(i*10+j)+"", nullPre.src);   // hide the 24 vertical wall locks
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Scorpion"+eval(i*10+j)+"", nullPre.src);   // hide the 20 Scorpions
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchBase"+eval(i*10+j)+"", nullPre.src);   // hide the 20 hero locations
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchDown"+eval(i*10+j)+"", nullPre.src);   // hide the 20 hero locations
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchUp"+eval(i*10+j)+"", nullPre.src);   // hide the 20 hero locations
  for (i=1 ; i<6 ; i++) for (j=1 ; j<6 ; j++) PicShow("WallHor"+eval(i*10+j)+"", nullPre.src);   // hide the 25 horizontal walls
  for (i=1 ; i<5 ; i++) for (j=1 ; j<7 ; j++) PicShow("WallVert"+eval(i*10+j)+"", nullPre.src);   // hide the 24 vertical walls
};

// erase all labyrinth figures & hero
function AllPicturesScreenClear () {
  AllPicturesLabyrinthClear();
  for (i=1 ; i<21 ; i++) PicShow("Hero"+eval(i)+"", nullPre.src);   // hide the 20 hero locations
};

// show all figures
function AllPicturesShow () {
  MainFiguresShow();   // show all alarm, hero & game related figures
  for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);  // "8"
  PicShow("NumColon", numColonPre.src);  // ":"
};

// erase all 7 small lines under pyramids
function AllPyramidSmallLinesClear () {
  for (i=1 ; i<8 ; i++) pyramidSmallLine[i] = 0;    // clear the 7 small lines under the pyramids
};

// erase all scorpions from screen
function AllScorpionsClear () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<6 ; j++) {     // the rows
      PicShow("Scorpion"+eval(i*10+j)+"", nullPre.src);   // hide the 20 scorpions
    };
  };
};

// show all scorpions in this Game
function AllScorpionsGameShow () {
  var labyVal;
  AllScorpionsClear();
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<6 ; j++) {     // the rows
      labyVal = laby[(i+screenLineSet*4+ lineShift)][(j+screenRowSet*5+rowShift)]    // get the segment value
      if ((labyVal%64>31)&&i<5&&j<6) PicShow("Scorpion"+eval(i*10+j)+"", ((i+j)%2)?ScorpionRightPre.src:ScorpionLeftPre.src);   // show the present of 20 Scorpions    //gcScorpion = 32,  
    };
  };
};

// hide all present artifacts and creatures
function ArtGuardsHide () {
  if (mapHero&&!mapReceived) MapHide();    // if map present, but not yet received, hide it
  if (vase) VaseHide();    // if vase(s)) present, hide them
  if (snakeDiamond) SnakeDiamondHide();    // hide snake if present
  if (exitBlockedSpider) SpiderBigHide();    // hide spiders if present
};

// show exit
function ExitShow () {
  PicShow("Exit", ExitPre.src);    // show exit
  PicShow("ExitDoor", ExitDoorPre.src);    // show exit door
};

// show current screen status from bottom to top
function FiguresScreenShowCurrent () {
  if (levelNew) {     // new level started, all figures need to be reset
    AllPicturesClear();  // erase all figures
    levelNew = false;  // no new level started, not all figures need to be reset
  };
  ShowCurrentLevelPart();  // show current visible part of the game level  
  PicShow("Pyramids", PyramidsPre.src);    // show the pyramids on top
  HeroShow();    // show the hero @ current position
  if (demo) TimeShow()  // show current time
  else {
    LivesShow();    // show current lives left
    ScoreShow(score);
  };
  TimeIndicatorShow();    // show moon or sun according to current time
};

// hide all heroes
function HeroesHide () {
  for (i=20 ; i>0 ; i--) {  // all descending heros position
    if (hero[i]) {    // if hero present @ this position
        PicShow("Hero"+eval(i)+"", nullPre.src);   // hide the hero @ this position
    };
  };
};

// show all heroes
function HeroesShow () {
  for (i=20 ; i>0 ; i--) {  // all descending heros position
    if (hero[i]) {    // if hero present @ this position
        PicShow("Hero"+eval(i)+"", HeroPre[i].src);   // show the hero @ this position
    };
  };
};

// hide external hero and arms on the right, the diamond he might hold as well
function HeroDiamondHide () {
  PicShow("HeroDiamond", nullPre.src);  // hide hero @ diamond holding place
  PicShow("Diamond", nullPre.src);    // hide the loose top diamond
  PicShow("DiamondHand", nullPre.src);  // hide the diamond when in heroes hands
  PicShow("Hands", nullPre.src);  // hide open (throwing-) hands of hero
  PicShow("HandsUnderDiamond", nullPre.src);  // hide hands of hero holding diamond    
};

    // show hero, arms up or down, on the right collecting points for defeating creature
function HeroDiamondShow (state, diamond) {
  if (blinkNum>1) PlaySound("move_wav", vlm);  // move/jump sound 
  PicShow("HeroDiamond", HeroDiamondPre.src);    // show hero @ holding diamond place
  if (state=="up") {
    if (diamond) {
      PicShow("Diamond", DiamondPre.src);    // show the loose top diamond
      PicShow("DiamondHand", nullPre.src);    // hide diamond in hero's hands
    };
    PicShow("Hands", HandsPre.src);    // show open hands possibly throwing diamond
    PicShow("HandsUnderDiamond", nullPre.src);    // show hands under diamond
  } else {
    if (diamond) {
      PicShow("Diamond", nullPre.src);    // hide the loose top diamond
      PicShow("DiamondHand", DiamondHandPre.src);    // show diamond in hero's hand
    };  
    PicShow("Hands", nullPre.src);  // show open hands possibly throwing diamond
    PicShow("HandsUnderDiamond", HandsUnderDiamondPre.src);    // show hands under diamond
  };
};

// hide hero @ current position
function HeroHide () {
  var calcPos = (posx-screenRowSet*5) + 5*(posy-screenLineSet*4 -1);    // calculate hero's position on screen
  PicShow("HeroPlatform", nullPre.src);  // hide hero on platform where hero attacks the snake
  PicShow("Armstop", nullPre.src);  // hide top, arms (hands) in rock ready to throw throw position
  PicShow("Armsdown", nullPre.src);    // hide left external hero's arms (hands) in "rock throwing"/"rest" position
  PicShow("HeroLeft", nullPre.src);  // hide extern hero @ the left (snake) position
  PicShow("HeroSideTop", nullPre.src);    // hide left top external hero jumping for the map or attacking the spider
  PicShow("Hero"+eval(calcPos)+"", nullPre.src);   // hide the hero @ his current position
};

// show hero @ current position
function HeroShow () {
  var calcPos = (posx-screenRowSet*5) + 5*(posy-screenLineSet*4 -1);    // calculate hero's position on screen
  if (!(mapActive&&shiftPause)) {    // if not screen shifting while reading map
    HeroHide();    // hide hero @ current position
    switch (heroExtern) {
      case 1 : 
        PicShow("HeroPlatform", HeroPlatformPre.src);    // show right external hero on the platform
        if (heroAttacking||snakeDiamondDone) {    // if hero attacking snake or snake beaten
          PicShow("Armstop", nullPre.src);  // hide left external hero's arms up 
          PicShow("Armsdown", ArmsdownPre.src);    // show left external hero's arms (hands) in "rock throwing"/"rest" position
        } else {
          PicShow("Armstop", ArmstopPre.src);    // show left external hero's arms up
          PicShow("Armsdown", nullPre.src);    // hide left external hero's arms (hands) in "rock throwing"/"rest" position
        };
        break;
      case 2 :
        PicShow("HeroLeft", HeroLeftPre.src);    // show left external hero
        break;
      case 3 :
        PicShow("HeroSideTop", HeroSideTopPre.src);    // show left top external hero jumping for the map or attacking the spider
        break;
      default :
        PicShow("Hero"+eval(calcPos)+"", HeroPre[calcPos].src);   // show the hero @ his current position
    };
  };
};

// show shifting hero @ current position
function HeroShowScreenShift (dir, posxShift, posyShift) {
  var calcPosShifted = (posxShift-screenRowSet*5) + 5*(posyShift-screenLineSet*4 -1);    // calculate hero's shifted position on screen
  PicShow("Hero"+eval(calcPosShifted)+"", HeroPre[calcPosShifted].src);   // show the hero @ his current position
};

// set all labyrinth elements to zero
function LabyClear () {
  for (i=0 ; i<44 ; i++) {     // the lines
    for (j=1 ; j<80 ; j++) {     // the rows
      laby[i][j] = 0;
    };
  };
};

// hide all lives in the box
function LivesHide () {
  for (var i=1 ; i<4 ; i++) PicShow("SmallHero"+eval(i)+"", nullPre.src);   // hide the 3 small heroes indicating lives left
};

// show current lives left
function LivesShow () {
  LivesHide();    // hide all lives in the box
  for (i=1 ; i<((life<4?life:3)+1) ; i++) PicShow("SmallHero"+eval(i)+"", SmallHeroPre[i].src);   // show the according small heroes showing lives left
};

// show all alarm, hero & related figures
function MainFiguresShow () {
  PicShow("Amulet", AmuletPre.src);    // show amulet hidden in the vase
  PicShow("Ankh", AnkhPre.src);    // show ankh key hidden in the vase
  PicShow("Armsdown", ArmsdownPre.src);  // show left external hero's arms (hands) in "rock throwing"/"rest" position
  PicShow("Armstop", ArmstopPre.src);    // show left external hero's arms up
  PicShow("AlarmStateInd", AlarmStateIndPre.src);  // show alarm indication
  PicShow("BellDown", BellDownPre.src);    // to show bell & hand of bell ringer down
  PicShow("BellHandDown", BellHandDownPre.src);    // show second hand of bell ringer down
  PicShow("BellUp", BellUpPre.src);    // show bell & hand of bell ringer up
  PicShow("Diamond", DiamondPre.src);    // show the loose top diamond
  PicShow("DiamondHand", DiamondHandPre.src);    // show diamond in hero's hands
  PicShow("Exit", ExitPre.src);    // show exit
  PicShow("ExitDoor", ExitDoorPre.src);    // show exit door
  PicShow("FallingStone", FallingStonePre.src);    // show falling stone, thrown by hero to attack snake
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Gold"+eval(i*10+j)+"", GoldPre.src);   // show the 20 gold rocks
  PicShow("Hands", HandsPre.src);    // to show open hands possibly throwing diamond
  PicShow("HandsUnderDiamond", HandsUnderDiamondPre.src);    // to show hands under diamond
  PicShow("HatExit", HatExitPre.src);    // show hero's hat @ the exit
  for (i=1 ; i<21 ; i++) PicShow("Hero"+eval(i)+"", HeroPre[i].src);   // show the 20 heros in the laby
  PicShow("HeroDiamond", HeroDiamondPre.src);    // show hero @ holding diamond place
  PicShow("HeroExit", HeroExitPre.src);    // show hero @ the exit
  PicShow("HeroLeft", HeroLeftPre.src);    // show left external hero
  PicShow("HeroPlatform", HeroPlatformPre.src);    // show right external hero on the platform
  PicShow("HeroSideTop", HeroSideTopPre.src);    // show left top external hero jumping for the map or attacking the spider
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Key"+eval(i*10+j)+"", KeyPre.src);   // show the 20 Keys
  PicShow("KeyLeft", KeyPre.src);    // show key holding indicator left
  for (i=1 ; i<6 ; i++) for (j=1 ; j<6 ; j++) PicShow("LockHor"+eval(i*10+j)+"", LockHorPre.src);   // show the 25 horizontal wall locks
  for (i=1 ; i<5 ; i++) for (j=1 ; j<7 ; j++) PicShow("LockVert"+eval(i*10+j)+"", LockVertPre.src);   // show the 24 vertical wall locks
  PicShow("Map", MapPre.src);    // show the side map indicating map received
  PicShow("MapHero", MapHeroPre.src);    // show the top map indicating map is available to be received
  PicShow("Moon", MoonPre.src);    // show the moon above the pyramides
  PicShow("Platform", PlatformPre.src);    // show platform where the hero attacks the snake from
  for (i=1 ; i<8 ; i++) PicShow("PyramidSmallLine"+eval(i)+"", PyramidSmallLinePre[i].src);   // show the 7 lines under the pyramid as progress indication
  PicShow("Pyramids", PyramidsPre.src);    // show the pyramids on top
  PicShow("SackLeftStar", SackLeftStarPre.src);    // show left knock out star @ snake
  PicShow("SackStarRight", SackStarRightPre.src);    // show right knock out star @ snake
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("Scorpion"+eval(i*10+j)+"", ((i+j)%2)?ScorpionRightPre.src:ScorpionLeftPre.src);   // show the 20 Scorpions
  for (i=1 ; i<4 ; i++) PicShow("SmallHero"+eval(i)+"", SmallHeroPre[i].src);   // show the 3 small heroes indicating lives left
  PicShow("Snake1", Snake1Pre.src);    // show left attacking snake
  PicShow("Snake2", Snake2Pre.src);    // show middel attacking snake
  PicShow("Snake3", Snake3Pre.src);    // show right attacking snake
  PicShow("SnakeDiamond", SnakeDiamondPre.src);    // show snake diamond
  PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
  PicShow("SpiderLeft", SpiderLeftPre.src);  // show the smaller spider on the left
  PicShow("SpiderLeg", SpiderLegPre.src);  // show the big spider's leg on top
  PicShow("SpiderTop", SpiderTopPre.src);  // show the smaller spider on top
  PicShow("StarStone", StarStonePre.src);    // show star @ stone, thrown by hero
  PicShow("StoneTop", StoneTopPre.src);    // show the stone the hero throws @ top to attack the big spider
  PicShow("Sun", SunPre.src);  // show the sun on top
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchBase"+eval(i*10+j)+"", SwitchBasePre.src);   // show the 20 switch bases
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchDown"+eval(i*10+j)+"", SwitchDownPre.src);   // show the 20 down switches
  for (i=1 ; i<5 ; i++) for (j=1 ; j<6 ; j++) PicShow("SwitchUp"+eval(i*10+j)+"", SwitchUpPre.src);   // show the 20 up switches
  PicShow("Vase", VasePre.src);  // to show the vase
  PicShow("VaseCrackLeft", VaseCrackLeftPre.src);  // to show left crack in the vase
  PicShow("VaseCrackRight", VaseCrackRightPre.src);  // to show the right crack in the the vase
  for (i=1 ; i<6 ; i++) for (j=1 ; j<6 ; j++) PicShow("WallHor"+eval(i*10+j)+"", WallHorPre.src);   // show the 25 horizontal walls
  for (i=1 ; i<5 ; i++) for (j=1 ; j<7 ; j++) PicShow("WallVert"+eval(i*10+j)+"", WallVertPre.src);   // show the 24 vertical walls
};

// show all figures & "12:00"
function MainPicturesShow () {
  MainFiguresShow();   // show all alarm, hero & game related figures
  PicShow("Num1", numPre[2].src);   // 1
  PicShow("Num2", numPre[3].src);   // 2
  PicShow("Num3", numPre[1].src);   // 0
  PicShow("Num4", numPre[1].src);   // 0
  PicShow("NumColon", numColonPre.src);  // ":"
};

// let the side map indicating map received blink
function MapBlink (mTimes) {
  if (mapBlinkID) {    // map blink timer active
    window.clearTimeout(mapBlinkID);  // stop the map blink timer
    mapBlinkID = null;    // reset map blink ID
  };
  if (mapActive) {    // if reading map
    if (mTimes%2) MapHide()    // hide the map of the current level @ present position every two steps
    else MapShow();    // show the map of the current level @ present position every other two steps
    mTimes--;    // next step
    if (mTimes) mapBlinkID = window.setTimeout("MapBlink(1);", 400)    // next odd step in 400 milliseconds
    else mapBlinkID = window.setTimeout("MapBlink(2);", 400);    // next even step in 400 milliseconds
  };
};

// hide the side map indicating map NOT received and top map NOT available to be received either
function MapHide () {
  PicShow("Map", nullPre.src);// hide the side map indicating map received
  PicShow("MapHero", nullPre.src);    // hide the top map indicating map is NOT available to be received
};

// show the map on the top left corner if not received, else show the side map indicating map received
function MapShow () {
  if (mapHero) {    // if the top map is present to be grabbed by the hero
    if (mapReceived) {    // if hero got the map
      PicShow("Map", MapPre.src);    // show the side map indicating map received
      PicShow("MapHero", nullPre.src);    // hide the top map indicating map is NOT available to be received
    } else {
      PicShow("MapHero", MapHeroPre.src);    // show the top map indicating map is available to be received
    };
  };
};

// shift screen in the approperiate direction
function ScreenShift (dir) {
  var posxShift;    // horizontal direction screen shift value
  var posyShift;    // vertical direction screen shift value
  var posxShifted;    // horizontal direction hero shift value
  var posyShifted;    // vertical direction hero shift value
  var dirRange;    // number of lines/rows to shift
  var shifted;    // screen shift progress, 0 if screen shift completed
  shiftPause = true;    // to pause the neccesary processes during screen shift
  if (screenShiftID) {    // ID for timeout shifting screen active
    window.clearTimeout(screenShiftID);  // stop screen shift timer
    screenShiftID = null;  // reset screen shift ID
  };
  switch (dir) {    // according to direction of screenshift
    case "down" :
      posxShift = 0;    // no horizontal movement
      posyShift = -1;   // vertical movement
      dirRange = 4;    // 4 positions per vertical screen shift
      break;
    case "left" :
      posxShift = 1;   // horizontal movement
      posyShift = 0;   // no vertical movement
      dirRange = 5;    // 5 positions per horizontal screen shift
      break;
    case "right" :
      posxShift = -1;   // horizontal movement
      posyShift = 0;   // no vertical movement
      dirRange = 5;    // 5 positions per horizontal screen shift
      break;
    case "up" :
      posxShift = 0;   // no horizontal movement
      posyShift = 1;   // vertical movement
      dirRange = 4;    // 4 positions per vertical screen shift
      break;
    default: 
  }  
  AllPicturesScreenClear();    // erase all labyrinth figures
  screenShifted++;    // next position the labyrinth shifts in the according direction on the screen
  if (screenShifted==1) {    // @ first shift
    posxLevStart = posx;    // new start position of hero after miss
    posyLevStart = posy;    // new start position of hero after miss
    EventsCheck();    // check if entering next screen view triggered any of the platforms
  };
  shifted = dirRange-screenShifted;    // next screen shift progress, 0 if screen shift completed
  posxShifted = posx + (5  - screenShifted)*(-posxShift);    // @ oposite side of full shifted screen, next step back
  posyShifted = posy + (4  - screenShifted)*(-posyShift);    // @ oposite side of full shifted screen, next step back
  ShowCurrentLevelPart((shifted*posyShift),(shifted*posxShift));    // show one position shifted screen
  // if screenposition of the map is reached and map is just deactivated and no screen shift going on
  if ((!mapActive&&!mapDeactivate)||(screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap&&!shiftPause)) {    
    HeroShowScreenShift(dir, posxShifted, posyShifted);    // show one position shifted hero
  };  
  if (shifted) {    // screenshift not done yet
    screenShiftID = window.setTimeout("ScreenShift ('"+dir+"')", 100);  // next shift screen in the indicated direction
  } else {
    mapDeactivate = false;    // not deactivating active map so screenshift can proceed
    pause = false;    // was paused by GoLeft() or GoRight()
    shiftPause = false;    // to unpause the neccesary processes after screen shift
    // if screenposition of the map is reached or map is not active
    if (!mapActive||(screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap)) {    
      HeroShow();    // show hero @ actual position
    };
    LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    if (!(laby[posy+1][posx]%8>3)) {    // if no floor underneeth
      if (!jumpID) jumpID = window.setTimeout("GoDown();",400);    // fall further after screen has shifted down
    } else {
      jumping = false;  // jumping/falling done
    };
  };
};

// hide the diamond & snakes
function SnakeDiamondHide () {
  SnakesHide();    // hide the diamond snakes
  // hide Platform if not on diamond snake segment or all the gold was found and no spider blocking the exit, so level is done
  if ((!gold&&!exitBlockedSpider)||snakeDiamond&&screenLineSet!=screenLineSetSnakeDiamond||screenRowSet!=screenRowSetSnakeDiamond) PicShow("Platform", nullPre.src);  
  PicShow("SnakeDiamond", nullPre.src);  // hide snake diamond
};

// show the diamond
function SnakeDiamondShow () {
  PicShow("Platform", PlatformPre.src);    // show platform where the hero attacks the snake from
  if (!snakeDiamondDone) {
    PicShow("SnakeDiamond", SnakeDiamondPre.src);    // show snake diamond
  };
};

// hide the diamond snakes
function SnakesHide () {
  PicShow("Snake1", nullPre.src);    // hide left attacking snake
  PicShow("Snake2", nullPre.src);    // hide middel attacking snake
  PicShow("Snake3", nullPre.src);    // hide right attacking snake
};

// hide the big exit blocking spider and attack addings
function SpiderBigHide () {
  SpidersHide();    // hide the spider attack addings
  PicShow("SpiderBig", nullPre.src);  // hide the big exit blocking spider
};

// show the big exit blocking spider and attack addings according to attack progress
function SpiderBigShow () {
  switch(spiderPos) {    // according to attack progress
    case 0 : case 5 :
      PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
      PicShow("SpiderLeft", nullPre.src);  // show the spider on the left
      PicShow("SpiderLeg", nullPre.src);  // show the big spider's leg on top
      PicShow("SpiderTop", nullPre.src);  // show the spider on top
      break;
    case 1 :
      PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
      PicShow("SpiderLeft", nullPre.src);  // show the spider on the left
      PicShow("SpiderLeg", SpiderLegPre.src);  // show the big spider's leg on top
      PicShow("SpiderTop", nullPre.src);  // show the spider on top
      break;
    case 2 :
      PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
      PicShow("SpiderLeft", nullPre.src);  // show the spider on the left
      PicShow("SpiderLeg", SpiderLegPre.src);  // show the big spider's leg on top
      PicShow("SpiderTop", SpiderTopPre.src);  // show the spider on top
      break;
    case 3 :
      PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
      PicShow("SpiderLeft", nullPre.src);  // show the spider on the left
      PicShow("SpiderLeg", nullPre.src);  // show the big spider's leg on top
      PicShow("SpiderTop", SpiderTopPre.src);  // show the spider on top
      break;
    case 4 :
      PicShow("SpiderBig", SpiderBigPre.src);  // show the big spider on top
      PicShow("SpiderLeft", SpiderLeftPre.src);  // show the spider on the left
      PicShow("SpiderLeg", nullPre.src);  // show the big spider's leg on top
      PicShow("SpiderTop", nullPre.src);  // show the spider on top
      break;
    default :
  };
};

// hide the spider attack addings
function SpidersHide () {
  PicShow("SpiderLeft", nullPre.src);  // hide the spider on the left
  PicShow("SpiderLeg", nullPre.src);  // hide the big spider's leg on top
  PicShow("SpiderTop", nullPre.src);  // show the spider on top
};

// hide the vase, cracks and artifacts
function VaseHide () {
  PicShow("Amulet", nullPre.src);    // hide amulet hidden in the vase
  PicShow("Ankh", nullPre.src);    // hide ankh key hidden in the vase
  PicShow("Vase", nullPre.src);  // to hide the vase
  PicShow("VaseCrackLeft", nullPre.src);  // to hide left crack in the vase
  PicShow("VaseCrackRight", nullPre.src);  // to hide the right crack in the the vase
};

// show the vase, cracks and artifacts according to state progress
function VaseShow (vaseNum) {
  switch(vase[vaseNum]) {    // according to state progress
    case 1 :    // if vase untouched
      PicShow("Vase", VasePre.src);  // to show the vase
      break;
    case 2 :    // if vase hit once
      PicShow("Vase", VasePre.src);  // to show the vase
      PicShow("VaseCrackLeft", VaseCrackLeftPre.src);  // to show left crack in the vase
      break;
    case 3 :    // if vase hit twice
      PicShow("Vase", VasePre.src);  // to show the vase
      PicShow("VaseCrackLeft", VaseCrackLeftPre.src);  // to show left crack in the vase
      PicShow("VaseCrackRight", VaseCrackRightPre.src);  // to show the right crack in the the vase
      break;
    case 4 :    // if vase hit three times and got broken
      if (vaseArtifact[vaseNum]==0) vase[vaseNum]++;  // hero can pass now, no artifact present
      if (vaseArtifact[vaseNum]==1) PicShow("Amulet", AmuletPre.src);    // show amulet hidden in the vase
      if (vaseArtifact[vaseNum]==2) PicShow("Ankh", AnkhPre.src);    // show ankh key hidden in the vase
      PicShow("Vase", nullPre.src);  // hide the broken vase
      PicShow("VaseCrackLeft", nullPre.src);  // hide left crack in the vase
      PicShow("VaseCrackRight", nullPre.src);  // hide the right crack in the the vase
      break;
    case 5 :
      if (vaseArtifact[vaseNum]==1) {    // if atrifact was invicibility amulet
        PicShow("Amulet", nullPre.src);    // hide amulet hidden in the vase
        invincible = true;
        HeroBlink(2);    // blink hero twice
      };
      if (vaseArtifact[vaseNum]==2) {    // if artifact was life adding ankh key
        PicShow("Ankh", nullPre.src)    // hide ankh key hidden in the vase
        vaseArtifact[vaseNum] = 0;    // empty vase to prevent multiple life gains
        life++;    // extra life gained
        LivesShow();    // show current lives left
      };
      if (((posx+1)==lastRow)&&!(laby[posy][lastRow]%2)) {    // if vase @ end of laby
        laby[posy][lastRow]+=1;    // put wall where vase was to prevent hero from falling out of the laby
        LabyCheck();    // check what's present & going on @ this labyrinth position & progress
        vase[vaseNum]++;    // add an extra progress step to indicate end of the vase
      };
      break;
    default :
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all game ID's
function AllStop () {
  GameReset();  // clear game related ID's
  pause = true;
  TimerReset(); // stop the counter to show the current time
};

// ignore and clear all other keys that are/were pressed
function ClearPressedKeys () {
  AKeyPressed = false;
  BKeyPressed = false;
  keyPressed = false;
  TKeyPressed = false;
};  
// clear game related game ID's
function GameReset () {
  if (blinkID) { // if  blinking triggered
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (demoID) {     // if demo was planned or running
    window.clearTimeout(demoID);  // stop demo sequence from starting (again)
    demoID = null;  // reset demo ID
  };
  if (eventsID) {    // if events timer active
    window.clearTimeout(eventsID);  // reset events timer
    eventsID = null;    // reset events ID
  };
  if (gameID) {     // if game was planned or running
    window.clearTimeout(gameID);  // stop the game
    gameID = null;  // reset game ID
  };
  if (heroAttackID) {     // if hero attacking was initiated
    window.clearTimeout(heroAttackID);  // stop hero attacking
    heroAttackID = null;  // reset hero attacking ID
  };
  if (jumpID) {     // if jump was initiated
    window.clearTimeout(jumpID);  // stop the jump animation
    jumpID = null;  // reset jump ID
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  if (mapBlinkID) {    // map blink timer active
    window.clearTimeout(mapBlinkID);  // stop the map blink timer
    mapBlinkID = null;    // reset map blink ID
  };
  if (scorpionsID) {    // if scorpions move delay active
    window.clearTimeout(scorpionsID);  // stop scorpions move delay
    scorpionsID = null;    // reset scorpions ID
  };
  if (screenShiftID&&(game!=1&&game!=2)||acl) {    // if ID for timeout shifting screen active outside game or acl pressed
    window.clearTimeout(screenShiftID);  // stop screen Shift timer 
    screenShiftID = null;  // reset screen Shift ID
  };
  if (snakeAttackID) {    // if snake attack active
    window.clearTimeout(snakeAttackID);  // stop snake attack timer
    snakeAttackID = null;  // reset snake attack ID
  };
  if (snakeHitID) {     // if snake hit was initiated
    window.clearTimeout(snakeHitID);  // stop snake getting hit
    snakeHitID = null;  // reset snake hit ID
  };
  if (spiderAttackID) {     // if spider attack active
    window.clearTimeout(spiderAttackID);  // stop spider attack timer
    spiderAttackID = null;  // reset spider attack ID
  };
  if (spiderHitID) {     // if spider hit active
    window.clearTimeout(spiderHitID);  // stop spider hit timer
    spiderHitID = null;  // reset spider hit ID
  };
  blinkNum = 2;
};

// clear all pictures & variables
function ResetAll () {
  AllStop();    // stop game if playing and reset all game ID's
  alarmSetting = false;     // stop setting alarm
  game = 9;   // 9-idle;
  gameOver = 0;  // no game is over
  life = 0;  // no lives left
  mapActive = false;    // map is not active
  mapDeactivate = false;     // not deactivating active map
  mapHero = false;    // the map is not available in this level
  mapReceived = false;    // hero didn't receive the map
  AllPicturesClear();  // erase all figures
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
  if (aclID) {     // if acl timer for fast double click trigger is active
    window.clearTimeout(aclID); // stop the acl timer
    aclID = null;  // reset acl ID
  };
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  acl = true; // indicates "acl" already clicked
  pause = true;
  PlaySound("click_wav", vlm);  // click sound for pushing the reset button
  AlarmReset();  // reset all alarm settings
  ResetAll(); // clear all pictures & variables
  demo = false;
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (acl) AllPicturesShow()  // show all figures & "88:88" if "acl" clicked twice fast
  else MainPicturesShow(); // else show all figures & "12:00"
  aclID = window.setTimeout("acl = false;", 130);   // show all pictures if "acl" clicked twice in 130 milliseconds
  demoID = window.setTimeout("MainTimeStart()", 60000);  // start demo after a minute  
};

// put the vase in the labyrinth sector with given line & row with 1=amulet or 2=ankh key
function VasesReset () {
  for (tel=1; tel<11; tel++) {    // all 10 possible vases
    vaseArtifact[tel] = 0;    // this vase has no artifact
    screenLineSetVase[tel] = 0;    // reset line of laby segment for this vase
    screenRowSetVase[tel] = 0;    // reset row of laby segment for this vase
    vase[tel] = 0;    // not this vase present on this level
  };
  vases = 0;  // no vases present yet
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show demo
function Demo () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  demo = true;
  level = 1;
  GameSet();   // default game settings and figures
  AllPicturesClear();  // erase all figures
  demoID = window.setTimeout("DemoSet()", 10);  // next step after a second  
};

// next demo step
function DemoRun () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (demo) {    // if demo still running
    if (!pause) {    // no pause initiated
      switch(demoSequence) {    // according to demo progress
        case 2 :
        case 3 :
        case 5 :
        case 6 :
          GoRight();
          break;
        case 4 :
          Action();    // jump
          break;
        default : 
      };
    };
    if (demoSequence<9) {    // if not last step of demo
      demoSequence++    // next step
      demoID = window.setTimeout("DemoRun()", 1000);  // perform next step after a second  
    } else {
      demoID = window.setTimeout("DemoSet()", 800);  // perform next step after 800 milliseconds
    };
  };
};

// set demo 
function DemoSet () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (gameID) {  // if game still planned to start stop that plan to avoid double run
    window.clearTimeout(gameID);    // stop game timer
    gameID = null;    // reset game ID
  };
  demoSequence = 1;
  GameSet();   // default game settings and figures
  pause = false;
  posx = posxLevStart;    // remember first horizontal position of hero for level (re-)start
  posy = posyLevStart;    // remember first vertical position of hero for level (re-)start
  gameID = window.setTimeout("FiguresScreenShowCurrent()", 500);    // show current screen half a second delayed
  demoID = window.setTimeout("DemoRun()", 800);  // next step after 800 milliseconds
};

// create scorpions animation
function EventsCreate () {
  ScorpionsSearch();    // search for scorpions & get their locations
  for (x=1; x<(scorpions+1); x++) scorpionDirPrev[x] = 0;     // start scorpion x with no previous move direction
  for (x=1; x<(scorpions+1); x++) scorpionDir[x] = 1;     // start scorpion x to move to the right
  screenLineSet = parseInt((posyLevStart-1)/4);    // calculate current screen line set (4 lines per screen segment)
  screenRowSet = parseInt((posxLevStart-1)/5);    // calculate current screen row set (5 rows per screen segment)
};

// next move of game
function GameGo () {
  if (gameID) {    // if a game timer already/still active
    window.clearTimeout(gameID);  // stop the game's possible double call
    gameID = null;    // reset game ID
  };
  if (scorpionsID) {    // if scorpions move delay active
    window.clearTimeout(scorpionsID);  // stop scorpions move delay to prevent double call
    scorpionsID = null;    // reset scorpions ID
  };
  if (!pause) {
    ShowCurrentLevelPart();  // show current visible part of the game level  
    if (scorpions)  scorpionsID = window.setTimeout("ScorpionsMove();",(gameSpeed/2));    // animate next movement of scorpion(s) if present
    if (platforms) PlatformsMove();    // if moving platforms active, animate next movement
  }; 
  gameID = window.setTimeout("GameGo()", gameSpeed);  // next step in gamespeed milliseconds
};

// resume game after pause for any game pausing event
function GameGoNext () {
  var calcPosScorpion;    // calculated scorpion @ hero's position on screen
  var scorpionNumber;
  if (game==1||game==2) {   // if game a or b running
    if (blinkID) { // if  blinking triggered
      window.clearTimeout(blinkID);  // stop blink timer
      blinkID = null;  // reset blink ID 
    };
    if (gameID) {    // if a game timer already/still active
      window.clearTimeout(gameID);  // stop the game's possible double call
      gameID = null;    // reset game ID
    };
    if (jumpID) {     // if jump was initiated
      window.clearTimeout(jumpID);  // stop the jump animation
      jumpID = null;  // reset jump ID
    };
    posx = posxLevStart;    // remember first horizontal position of hero for level (re-)start
    posy = posyLevStart;    // remember first vertical position of hero for level (re-)start
    calcPosScorpion = 10*(posy-screenLineSet*4 )+ (posx-screenRowSet*5);    // calculate scorpion @ hero's position on screen
    scorpionNumber = ScorpionNumber(posy,posx);    // search which scorpion number is situated @ this line and row         
    console.log("@ GameGoNext() : posyScorpion["+scorpionNumber+"]==posxLevStart = "+posyScorpion[scorpionNumber]+"=="+posxLevStart+" = "+(posyScorpion[scorpionNumber]==posxLevStart)+"     -     calcPosScorpion = "+calcPosScorpion);
    console.log("@ GameGoNext() : posxScorpion["+scorpionNumber+"]==posyLevStart = "+posxScorpion[scorpionNumber]+"=="+posyLevStart+" = "+(posxScorpion[scorpionNumber]==posyLevStart));
    if ((posyScorpion[scorpionNumber]==posxLevStart || ((posyScorpion[scorpionNumber]+scorpionDir[scorpionNumber])==posxLevStart))&&posxScorpion[scorpionNumber]==posyLevStart) {    // delete scorpion if too close to hero's re-entry point 
      // hide scorpion on screen if no screen shift going on
      PicShow("Scorpion"+eval(calcPosScorpion)+"", nullPre.src);    
      laby[posxScorpion[scorpionNumber]][posyScorpion[scorpionNumber]]=eval(laby[posxScorpion[scorpionNumber]][posyScorpion[scorpionNumber]])-32;    // remove scorpion from this labyrinth place
      posyScorpion[scorpionNumber] = 0;    // reset its row location
      posxScorpion[scorpionNumber] = 0;    // reset its line location
    };
    heroAttacking = 0;  // hero not attacking
    jumping = false;  // jumping/falling done
    FiguresScreenShowCurrent();    // show current screen     
    HeroShow();    // show hero @ actual position
    LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    if (invincible)  blinkID = window.setTimeout("HeroBlink("+2+");", 250);    // blink hero when invincible 
    pause = false;
    if (!(laby[posy+1][posx]%8>3)) {    // if no floor underneeth
      jumpID = window.setTimeout("GoDown();", (miss?gameSpeed:1));  // next step of falling in gamespeed milliseconds
      miss = false;
    } 
    miss = false;
    gameID = window.setTimeout("GameGo();", gameSpeed);  // next step of game in gamespeed milliseconds
  };
};

// default game settings and figures
function GameSet () {
  AllStop();    // stop game if playing and reset all game ID's
  blinkNum = 2;  // number of blink animations
  eventsCount = 0;   // no events added yet
  exitBlockedSpider = 0;    // no spider blocking exit yet
  gold = 0;  // no gold rocks counted yet
  heroExtern = 0;    // hero not on the outside of the labyrinth
  invincible = false;
  jumpMoved = 0;  // able to move after this jumpLand 
  keyHold = 0;  // holding no keys yet
  if (levelDone) levelNew = true;  // new level started, all figures need to be reset
  LabyClear();    // empty labyrinth
  VasesReset();    // reset previous vases found
  lastLine = 1;  // last line of labyrinth starts from position 1
  lastRow = 0;  // last row of labyrinth
  levelDone = 0;    // level not done yet
  line = 0;  // current line of labyrinth
  lineShift = 0;    // screen not shifted vertically yet
  mapActive = false;    // map is not active
  mapDeactivate = false;     // not deactivating active map
  mapHero = false;    // the map is not available in this level
  mapReceived = false;    // hero didn't receive the map
  miss = false;
  platforms = 0;    // no moving platforms counted yet
  pMoveCount = 1;    // odd (1) - even (2) sequence @ platforms turn for moving
  row = 1;  // current row of labyrinth
  rowShift = 0;    // screen not shifted horizontally yet
  screenLineSet = 0;    // indicates which line set (of 4 lines per segment) of the labyrinth is shown on screen
  screenRowSet = 0;    // indicates which row set (of 5 rows per segment) of the labyrinth is shown on screen  
  shiftPause = false;    // no pause for the neccesary processes because no screen shift going on
  snakeAttack = 0;    // no snake attack yet
  snakeDiamond = 0;   // no diamond snake present yet
  snakeDir = Math.floor(Math.random() * 2)?1:-1;    // random direction of attacking snake
  snakeHit = 0;    // snake not yet hit
  snakePos = 0;    // no position of attacking snake yet
  spiderAttack = 0;    // no spider attack yet
  spiderHit = 0;    // spider not yet hit
  spiderPos = 0;    // no animation position of attacking spider yet
  gameID = window.setTimeout("Level"+eval(level)+"Create();",1);    // load chosen/next level
  eventsID = window.setTimeout("EventsCreate();",2);    // create scorpions animation events
  eventsID = window.setTimeout("EventsCheck();",4);    // check moving platforms animation and controls
};

// let hero blink @ miss position
function HeroBlink (times) {  
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  // console.log("@ HeroBlink("+times+" : levelDone = "+levelDone+"  -  heroExtern = "+heroExtern+"  -  miss = "+miss+"  - shiftPause = "+shiftPause+"  - mapActive = "+mapActive);
  // if level not done and hero not out of the laby, without miss and no screen shifting and map not active
  if (!levelDone&&!(heroExtern&&!miss)&&!shiftPause&&!mapActive) {
    if (times%2) HeroHide()     // hide hero @ current position every two steps
    else HeroShow();    // show hero @ actual position every other two steps
    if (times) times--;    // one next step less to go
    if (!invincible||miss) {    // if hero is not invincible or miss occurs
      if (times==11) PlaySound("miss_wav", vlm);  // miss sound 
      if (times) {    // if blinking not over
        blinkID = window.setTimeout("HeroBlink("+times+");", 250)    // blink hero a number of times 
      } else {
        HeroShow();    // show hero @ actual position
        if (life) {    // if not all lives lost
          heroExtern = 0;    // hero back inside laby
          blinkID = window.setTimeout("GameGoNext();", 500);    // resume game after any game pausing event in half a second
        } else {
          MainGameOver();    // stop game if running + start demo after a minute 
        };
      };
    } else {
      if (times) blinkID = window.setTimeout("HeroBlink(1);", 250)    // blink hero once
      else blinkID = window.setTimeout("HeroBlink(2);", 250)    // blink hero twice
    };
  } else {
    if (!levelDone) blinkID = window.setTimeout("HeroBlink("+times+");", 250);    // blink hero a number of times
  };
};

// check what's present & going on @ this labyrinth position & progress
function LabyCheck () {
  var labyVal = laby[posy][posx];    // current labyrinth position
  if (laby[posy+1][posx]%8>3) {    //  if floor underneath hero, land hero
    jumping = false;  // jumping/falling done
    jumpMoved = 0;  // able to move after this jumpLand 
  };
  if (labyVal%128>63) {    // gold rock collected
     gold--;  // one less gold rock to collect
     PicShow("Gold"+eval((posy-screenLineSet*4)*10+(posx-screenRowSet*5))+"", nullPre.src);   // hide gold rock on screen
     if (!gold&&(snakeDiamond?snakeDiamondDone:1)&&!exitBlockedSpider) {
      if (levelDoneID) {    // if level done animation timer
        window.clearTimeout(levelDoneID);  // stop previous level done timer
        levelDoneID = null;  // reset level done ID 1
      };
      pause = true;
      PlaySound("levelEnd_wav", vlm);    // end of level sound 
      levelDoneID = window.setTimeout("HeroHide(); LevelDone("+labyVal+");", (demo?200:100));    // hide hero @ current position and if all present gold rock collected, level is done
    } else {
      laby[posy][posx]-=64;  // remove gold rock from labyrinth
      if (!levelDone&&!demo) {    // if not level done @ gameplay
        PlaySound("keyGet_wav", vlm);    // sound of getting key or gold
        ScoreAdd(3);
      };
    };
  };
  if (labyVal>1023) {    // if key present @ position
    keyHold++;  // one more key collected
    laby[posy][posx] = eval(laby[posy][posx]-1024);    // 
    ShowCurrentLevelPart();  // show current visible part of the game level  
    PicShow("KeyLeft", KeyPre.src);    // show key holding indicator left
    PlaySound("keyGet_wav", vlm);    // sound of getting key or gold
  };  
  if (!shiftPause) {    // if no screen shift going on
    vaseNum = VaseNumSearch();    // get the vase number of this segment
    if (vaseNum) {    // if segment has a vase
      if (vase[vaseNum]<6) {      // only 5 vases per laby possible
        VaseShow(vaseNum);    // show this vase
      };
    } else {
      VaseHide();    // hide the vase
    };
    // if screenposition of the snake diamond is reached and no screen shift going on
    if (snakeDiamond&&screenLineSet==screenLineSetSnakeDiamond&&screenRowSet==screenRowSetSnakeDiamond&&!shiftPause) {    
      if (snakeHit<6) {    // if snake hit less than six times
        snakeDiamond = snakePos+1;    // next snake position
        SnakeDiamondShow();    // show the snake diamond
        // if snake present & hero located @ snake diamond section & wall @ snake's platform gone, let snake attack
        if ((!snakeAttackID&&!snakeDiamondDone)&&(screenLineSet==screenLineSetSnakeDiamond&&screenRowSet==screenRowSetSnakeDiamond)&&!(laby[(screenLineSet*4 + 2)][((screenRowSet+1)*5+1 )]%2) ) SnakeAttack();    
      };
    } else {
      SnakeDiamondHide();
    };
    // if screen position of the exit blocking spider is reached and no screen shift going on
    if (exitBlockedSpider&&screenLineSet==screenLineSetSpiderBig&&screenRowSet==screenRowSetSpiderBig&&!shiftPause) {    
      if (spiderHit<6) {    // if spider got hit less than 6 times
        PicShow("Exit", ExitPre.src);  // show exit
        PicShow("ExitDoor", ExitDoorPre.src);    // show exit door
        SpiderBigShow();    // show exit blocking spider
        if (!spiderAttack) SpiderAttack();    // if spider not attacking yet, let it attack
      };
    } else {
      PicShow("Exit", nullPre.src);  // hide exit
      PicShow("ExitDoor", nullPre.src);    // hide exit door
      SpiderBigHide();    // hide exit blocking spider
    };
    // if screenposition of the map is reached and map is active or map is received and no screen shift going on
    if ((mapHero&&screenLineSet==screenLineSetMap&&screenRowSet==screenRowSetMap&&!shiftPause)||mapReceived) {    
      MapShow();    // show the map on the top left corner if not received, else show the side map indicating map received
    } else {
      MapHide();    // hide the map of the current level
    };
  };
};

// end of level animation
function LevelDone (labyVal) {
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop previous blink timer
    blinkID = null;  // reset blink ID 
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  levelDone = 1;
  mapActive = false;    // map is not active
  mapDeactivate = false;    // not deactivating active map so screenshift can proceed
  mapHero = false;    // the top map is not present on this level
  mapReceived = false;    // hero didn't get the map yet
  pause = true;
  if (blinkNum<2) {
    HeroDiamondShow("up",0);    // show hero, arms up, on the right collecting points for defeating creature
  };
  if (blinkNum==1&&!demo) {
    if (exitBlockedSpider) {
      ScoreAdd(15);
    } else {
      ScoreAdd(((labyVal?labyVal:0)%128>63)?"18":"15");
    };
  };
  blinkID = window.setTimeout("HeroDiamondShow('down',0);",(demo?1000:blinkSpeed));    // show hero, arms down, on the right collecting points for defeating creature
  if (blinkNum) {
    levelDoneID = window.setTimeout("LevelDone("+labyVal+");",(demo?2000:(blinkSpeed*2)));    // next step
  } else {
    if (!demo) {
      if (level<levels) {    // if not last level
        console.log("----------------------------------------------------------------------------------------------------  %c L E V E L   "+level+"   D O N E %c  ---------------------------------------------------------------------------------------------------------","background-color:darkgreen; color:yellow; font-weight:bold;","background-color:tr; color:black; font-weight:bold;");
        level++;    // next level
        GameSet(); // default game settings and figures
        levelDoneID = window.setTimeout("GameGoNext();", gameSpeed);  // start running next level in gameSpeed milliseconds
      } else {
        levelDoneID = window.setTimeout("MainGameOver();", gameSpeed*2);    // stop game if running + start demo after a minute  in twice the gameSpeed milliseconds
      };
    };
  };
  blinkNum--;    // one less time to blink
};

// end of snake level animation
function LevelDoneSnake () {
  PicShow('DiamondHand', nullPre.src);    // hide diamond in hero's hands
  PlaySound('levelEnd_wav', vlm);     // end of level sound 
  LevelDone();    // end of level animation
};

// button pressed to play game A
function MainGameA () {
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {   // if not already game A or B playing
    AllStop();  // stop game if playing and reset all game ID's
    demo = false;    // once this key is hit, the demo is turned off
    level = 1    // game A starts @ level 1
    levelChooser = false;    // can't choose a level @ game A
    life = 3;    // number of lives left
    GameSet();   // default game A settings and figures
    score = 0;
    AllPicturesClear();
    HighScoreShow(1);    // show highest score since this browser tab was opened
  };
};

// "game A" button released so actually play game A
function MainGameAGo () {
  if (game!=1&&game!=2) {     // if not already game A or B playing
    if (gameID) {    // if a game timer already/still active
      window.clearTimeout(gameID);  // stop the game's possible double call
      gameID = null;    // reset game ID
    };
    game = 1;   // game A
    pause = false;    // unpause game
    posx = posxLevStart;    // remember first horizontal position of hero for level (re-)start
    posy = posyLevStart;    // remember first vertical position of hero for level (re-)start
    FiguresScreenShowCurrent()    // show current screen
    LabyCheck();    // check what's present & going on @ this labyrinth position & progress
    GameGo();  // start running game
  };
};

// button pressed to play game B
function MainGameB () {
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {     // if not already game A or B playing
    AllStop();    // stop game if playing and reset all game ID's
    demo = false;    // once this key is hit, the demo is turned off
    life = 3;    // number of lives left
    level = 1    // start @ level 1 to choose from
    levelChooser = true;    // to play game B, you have to choose which level to start from
    AllPicturesClear();
    HighScoreShow(2);    // show highest score since this browser tab was opened
  };
};

// game B" button released so actually play game B
function MainGameBGo () {
  if (game!=1&&game!=2) {     // if not already game A or B playing
    game = 2;   // game B
    pause = false;    // unpause game
    jumping = false;    // not jumping/falling
    LevelShow();    // show current level choice
  };
};

// play game B after having made a choice of starting level
function MainGameBGoOn () {
  score = 0;
  if (gameID) {    // if a game timer already/still active
    window.clearTimeout(gameID);  // stop the game's possible double call
    gameID = null;    // reset game ID
  };
  pause = false;    // unpause game
  posx = posxLevStart;    // remember first horizontal position of hero for level (re-)start
  posy = posyLevStart;    // remember first vertical position of hero for level (re-)start
  FiguresScreenShowCurrent()    // show current screen
  LabyCheck();    // check what's present & going on @ this labyrinth position & progress
  gameID = window.setTimeout("GameGo()", gameSpeed);  // start running game in gameSpeed milliseconds
};

// stop game if running + start demo after a minute  
function MainGameOver () {
  console.log("----------------------------------------------------------------------------------------------------  %c G A M E    O V E R %c  ---------------------------------------------------------------------------------------------------------","background-color:red; color:yellow; font-weight:bold;","background-color:tr; color:black; font-weight:bold;");
  gameOver = 1;  
  if (demoID) {    // if demo timer active
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (gameID) {    // if a game timer already/still active
    window.clearTimeout(gameID);  // stop the game's possible double call
    gameID = null;    // reset game ID
  };
  AllStop();    // stop game if playing and reset all game ID's
  PlaySound("gameOver_wav", vlm);    // game over sound 
  demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
  game = 9;    // 9 = game is idle;
  if (level==levels) gameID = window.setTimeout("LevelOutLoad();", gameSpeed)    // start running game end animation in gameSpeed milliseconds
  else console.log("----------------------------------------------------------------------------------------------------  %c    @  level  "+level+"    %c  ---------------------------------------------------------------------------------------------------------","background-color:red; color:yellow; font-weight:bold;","background-color:tr; color:black; font-weight:bold;");
};
 
// miss
function Miss () {
  console.log("---------------------------------------------------------------------------------------------------------  %c M I S S %c  --------------------------------------------------------------------------------------------------------------","background-color:orange; color:yellow; font-weight:bold;","background-color:tr; color:black; font-weight:bold;");
  if (!miss) {
    if (snakeAttackID) {    // if snake attack active
      window.clearTimeout(snakeAttackID);  // stop snake attack timer
      snakeAttackID = null;  // reset snake attack ID
    };
    if (spiderAttackID) {     // if spider attack active
      window.clearTimeout(spiderAttackID);  // stop spider attack timer
      spiderAttackID = null;  // reset spider attack ID
    };
    miss = true;
    AllStop();    // stop game if playing and reset all game ID's
    pause = true;
    jumpMoved = 0;  // able to move after jumpland
    HeroBlink(12);    // blink hero twelve times 
    if (exitBlockedSpider) {    // if exit blocking big spider prtesent on this level
      snakeAttackID = window.setTimeout('PicShow("StoneTop", nullPre.src);',500);  // hide the stone the hero throws @ top to attack the big spider
      spiderPos = 0;    // put spider away
    };
    if (snakeDiamond) {        // if diamond snake present on this level
      spiderAttackID = window.setTimeout('PicShow("FallingStone", nullPre.src);',500);    // hide falling stone, thrown by hero to attack snake after half a minute
      snakePos = 5;    // put snake away
      snakeDir = 1;    // ascending direction
    };
    life--;    // one life lost
    LivesShow();    // show current lives left
  };
};

// show leading zeroes
function n(n){
  return n>9?""+n:"0"+n;
};

// hit vase to get the invincible amulet or extra life ankh key
function VaseHit (vaseNum) {
  if (keyPressedID) {     // if key press release delay was initiated
    window.clearTimeout(keyPressedID);  // stop key press release delay
    keyPressedID = null;  // reset key press ID
  };
  keypressed = true;    // to avoid continous vase movement
  vase[vaseNum]++;
  VaseShow(vaseNum);
};

// search vase number present @ this labyrinth position
function VaseNumSearch () {
  var vaseNumFound = 0;
  for (vaseNumCheck=1; vaseNumCheck<(vases+1); vaseNumCheck++) {    // for all current vases
    // if vase segment found, get this vase's number
    if (screenLineSet==screenLineSetVase[vaseNumCheck]&&screenRowSet==screenRowSetVase[vaseNumCheck]) vaseNumFound = vaseNumCheck;
  };
  return vaseNumFound;    // return the number of the vase in this segment
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

//platform functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// check if platform is able to move
function PlatformBoxed (boxLineP,boxRowP) {
  var endOfLaby = ((boxLineP+1)>(lastLine-1));    // check if platform not @ bottom of laby
  var platformNumber = PlatformNumber(boxLineP,boxRowP);    // search which platform number is situated @ this line and row
  var platformBoxed = false;    // platform not boxed yet untill fully stuck between platforms or wall
  var platformAbove = boxLineP>0?laby[boxLineP-1][boxRowP]%8>3:1;   // check if platform/wall above or end of Labyrinth
  var platformLeft = laby[boxLineP][(boxRowP-1)]%8>3;   // check if pllatform/wall @ left present
  var platformRight =  laby[boxLineP][boxRowP+1]%8>3;   //    // check if pllatform/wall @ right present
  var platformUnder = endOfLaby?1:laby[boxLineP+1][boxRowP]%8>3;   // check if platform/+wall underneath present
  if ((Math.abs(platformDir[platformNumber])==1&& platformLeft && platformRight) ||(Math.abs(platformDir[platformNumber])==2&&platformAbove && (platformUnder||endOfLaby))) {    // if stuck between other platforms or wall
    platformBoxed = true;
  } 
  return platformBoxed
};

// move platforms in labyrinth
function PlatformsMove () {
  var screenShifting = new Array;    // moving platform going out of screen range
  var posxScorpionPlatform = new Array;    // line position scorpions on moving platform
  var posyScorpionPlatform = new Array;    // row position scorpions on moving platform
  var scorpionPlatformNumber = new Array;    // number of the scorpion on moving platform
  for (s=1; s<(platforms+1); s++) {    // for all platforms
    if (platformActive[s]&&!PlatformBoxed (posxPlatform[s],posyPlatform[s])) {    // if this platform is active and not boxed in
      if (Math.abs(platformDir[s])==1&&pMoveCount==platformSeq[s]) {    // if left - right movement and this platform's sequence met
        if ((laby[(posxPlatform[s])][(posyPlatform[s] + platformDir[s])] % 8>3)||(laby[(posxPlatform[s]-1)][(posyPlatform[s] + (platformDir[s]<0?0:1))] % 2)) {    // if  horizontal or vertical wall @ next spot
          platformDir[s] = -platformDir[s];    // change direction to avoid running into next wall or moving platform
        };
        if (((posy+1)==posxPlatform[s])&&(posx==posyPlatform[s])) {    // if hero is on platform, 
          if (!shiftPause) HeroHide();  // hide hero @ previous position if not screen shifting
          if ((posx+(platformDir[s]<0?-1:0))%5) {    // if not leaving screen range
            posx+=platformDir[s];  // take him with, in platform's direction
            if (!mapActive) PlaySound("move_wav", vlm);    // move/jump sound 
            } else {    // leaving screen range
             if (posx>1) {    // if not end of labyrinth range
              pause = true; 
              posx+=platformDir[s];    // take him with, in platform's direction
              screenRowSet = parseInt((posx-1)/5);    // calculate row set (of 5 rows per segment) of the labyrinth shown on screen
              screenShifted = 0;    // no screen shift going on yet
              screenShifting[s] = 1;    // moving platform going out of screen range
              if (!mapActive) PlaySound("move_wav", vlm);  // move/jump sound 
            };
          };
        };
        if (laby[posxPlatform[s]-1][posyPlatform[s]]%64>31) {    // if scorpion is on platform, 
          posxScorpionPlatform[s] = posxPlatform[s]-1;    // line position scorpion on moving platform
          posyScorpionPlatform[s] = posyPlatform[s];    // row position scorpion on moving platform
          scorpionPlatformNumber[s] = ScorpionNumber(posxScorpionPlatform[s],posyScorpionPlatform[s]);    // search which scorpion number is situated @ this line and row         
          laby[posxPlatform[s]-1][posyPlatform[s]]=eval(laby[posxPlatform[s]-1][posyPlatform[s]])-32;    // remove scorpion from previous position
          laby[posxPlatform[s]-1][posyPlatform[s]+platformDir[s]]=eval(laby[(posxPlatform[s]-1)][posyPlatform[s]+platformDir[s]])+32;    // put scorpion @ new position
          posyScorpion[scorpionPlatformNumber[s]]+=platformDir[s];    // meet line position scorpion with position moving platform
        };              
        laby[posxPlatform[s]][posyPlatform[s]]=eval(laby[posxPlatform[s]][posyPlatform[s]])-4;    // remove platform from previous position
        laby[posxPlatform[s]][(posyPlatform[s]+platformDir[s])]=eval(laby[posxPlatform[s]][(posyPlatform[s]+platformDir[s])])+4;    // put platform @ new position
        posyPlatform[s]+=platformDir[s];    // meet line position with new position moving platform
      } else {    // not left - right movement and this platform's sequence met
        if (Math.abs(platformDir[s])==2&&pMoveCount==platformSeq[s]) {    // if up - down movement and this platform's sequence met
          // if  horizontal wall @ next spot or end of labyrinth
          if ((laby[(posxPlatform[s] + (platformDir[s]/2))][(posyPlatform[s])] % 8>3)||!((posxPlatform[s] + (platformDir[s]/2))<(lastLine))||((posxPlatform[s] + (platformDir[s]/2))<2)) {    
            platformDir[s] = -platformDir[s];    // change direction to avoid running into next wall or moving platform
          };
          // if hero is underneath decending platform 
          if (((posy==posxPlatform[s])&&(posx==posyPlatform[s])&&(platformDir[s]==2))&&!((laby[(posxPlatform[s] + (platformDir[s]/2))][(posyPlatform[s])] % 8>3)||!(posxPlatform[s]<(lastLine-1)))) {    
            Miss();
          } else {
            if (((posy+1)==posxPlatform[s])&&(posx==posyPlatform[s])) {  // if hero is on platform, 
              if ((posy+(platformDir[s]<0?-1:0))%4) {    // if not leaving screen range
                posy+=(platformDir[s]/2);  // take him with, in platform's direction
                if (!mapActive) PlaySound("move_wav", vlm);  // move/jump sound 
              } else {    // leaving screen range
                if (posy>1) {    // if not end of labyrinth range
                  pause = true;    // pause game
                  posy+=(platformDir[s]/2);  // take him with
                  screenLineSet = parseInt((posy+(platformDir[s]/2))/4);    // calculate current screen line set (4 lines per screen segment)
                  screenShifted = 0;    // no screen shifting yet
                  screenShifting[s] = 1;    // moving platform going out of screen range
                  if (!mapActive) PlaySound("move_wav", vlm);  // move/jump sound 
                };
              };
            };
            if (laby[posxPlatform[s]-1][posyPlatform[s]]%64>31) {  // if scorpion is on platform, 
              posxScorpionPlatform[s] = posxPlatform[s]-1;    // line position scorpion on moving platform
              posyScorpionPlatform[s] = posyPlatform[s];    // row position scorpion on moving platform
              scorpionPlatformNumber[s] = ScorpionNumber(posxScorpionPlatform[s],posyScorpionPlatform[s]);    // search which scorpion number is situated @ this line and row
              laby[posxPlatform[s]-1][posyPlatform[s]]=eval(laby[posxPlatform[s]-1][posyPlatform[s]])-32;    // remove scorpion from previous position
              laby[(posxPlatform[s]-1+(platformDir[s]/2))][posyPlatform[s]]=eval(laby[posxPlatform[s]-1+(platformDir[s]/2)][posyPlatform[s]])+32;    // put scorpion @ new position
              posxScorpion[scorpionPlatformNumber[s]]+=(platformDir[s]/2);    // meet line position scorpion with position moving platform
            };
            laby[posxPlatform[s]][posyPlatform[s]]=eval(laby[posxPlatform[s]][posyPlatform[s]])-4;    // remove platform from previous position
            laby[posxPlatform[s]+(platformDir[s]/2)][posyPlatform[s]]=eval(laby[posxPlatform[s]+(platformDir[s]/2)][posyPlatform[s]])+4;    // put platform @ new position
            posxPlatform[s]+=(platformDir[s]/2);    // meet line position with new position moving platform
          };        
        };  
      };
    if(!mapActive) {    // if not reading map
        if (screenShifting[s]) {    // if moving platform going out of screen range
          ArtGuardsHide();    // hide all present artifacts and creatures
          ScreenShift(platformDir[s]==-1?"left":platformDir[s]==1?"right":platformDir[s]==-2?"up":"down");    // shift screen in accordingly direction
        } else {    // moving platform not going out of screen range
          if (!pause) {
            if (!shiftPause) ShowCurrentLevelPart();  // show current visible part of the game level if not screen shifting
            LabyCheck();    // check what's present & going on @ this labyrinth position & progress
          };  
        };
      };
    };
  };
  pMoveCount = pMoveCount==1?2:1;    // switch odd (1) - even (2) sequence @ platforms turn for next moving sequence
};

// search which platform number is situated @ this line and row
function PlatformNumber (searchLine,searchRow) {
  var platformSearchNumber = 0;    // no platform number found yet
  for (o=1 ; o<(platforms+1) ; o++) {     // all platform numbers
    if (searchLine==posxPlatform[o]&&searchRow==posyPlatform[o]) platformSearchNumber = o;    // remember found number
  };
  return platformSearchNumber;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end platform functions

//scorpion functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// check if scorpion can move in the oopposite direction
function BackBlocked (bbPlace) {
  return ( scorpionDir[bbPlace]==1 ? (ScorpionLeft (bbPlace)||NoFloorLeft(bbPlace)||WallLeft (bbPlace)) : (ScorpionRight (bbPlace)||WallRight (bbPlace)||NoFloorRight (bbPlace)) );
};

// check if scorpion can move in the given direction
function FrontBlocked (fbPlace) {
  return ( scorpionDir[fbPlace]==1 ? (ScorpionRight (fbPlace)||WallRight (fbPlace)||NoFloorRight (fbPlace)) : (ScorpionLeft (fbPlace)||NoFloorLeft(fbPlace)||WallLeft (fbPlace)) );
};

// check if scorpion can move to the left (A) because floor is present there
function NoFloorLeft (nflPlace) {
  return !(laby[(posxScorpion[nflPlace]+1)][(posyScorpion[nflPlace]-1)]% 8>3)
};

// check if scorpion can move to the right (D) because floor is present there
function NoFloorRight (nfrPlace) {
  return !(laby[(posxScorpion[nfrPlace]+1)][(posyScorpion[nfrPlace]+1)]% 8>3)
};

// check if scorpion can move horizonlally
function ScorpionBoxed (boxLine,boxRow) {
  var scorpionBoxed = false;
  var scorpionNumber = ScorpionNumber(boxLine,boxRow);    // get number of scorpion @ this position
  if (BackBlocked (scorpionNumber)&&FrontBlocked (scorpionNumber)) {    // if scorpion can't move in the given or opposite direction
    scorpionBoxed = true;    // indicate this scorpion is boxed in
    if (scorpionDir[scorpionNumber]) {    // if scorpion has direction, so not boxed before
      scorpionDirPrev[(ScorpionNumber(boxLine,boxRow))] = scorpionDir[(ScorpionNumber(boxLine,boxRow))];    // remember the direction of this scorpions'
      scorpionDir[(ScorpionNumber(boxLine,boxRow))] = 0;    // this scorpion has no direction while boxed
    };
  } else {
    if (!scorpionDir[(ScorpionNumber(boxLine,boxRow))]) scorpionDir[(ScorpionNumber(boxLine,boxRow))] = scorpionDirPrev[(ScorpionNumber(boxLine,boxRow))];    // give back current or old direction after being boxed
  };
  return scorpionBoxed;
};

// check if scorpion can move to the left (1) because no other scorpion present there
function ScorpionLeft (slPlace) {
  return (laby[posxScorpion[slPlace]][(posyScorpion[slPlace]-1)]%64>31);
};

// check if scorpion can move to the right (2) because no other scorpion present there
function ScorpionRight (srPlace) {
  return (laby[posxScorpion[srPlace]][(posyScorpion[srPlace]+1)]%64>31);
};

// check if scorpion can move to the left (B) because no vertical wall present there
function WallLeft (wlPlace) {
  return (laby[posxScorpion[wlPlace]][(posyScorpion[wlPlace]+0)]% 2)
};

// check if scorpion can move to the right (C) because no vertical wall present there
function WallRight (wrPlace) {
  return (laby[posxScorpion[wrPlace]][(posyScorpion[wrPlace]+1)]% 2)
};

// move scorpions around labyrinth
function ScorpionsMove () {
  var calcPosScorpion;
  var dirSwitched = false;
  var posxScorpionMov = new Array();
  var posyScorpionMov = new Array();
  for (s=1; s<(scorpions+1); s++) {    // check all scorpions
    if (!ScorpionBoxed(posxScorpion[s],posyScorpion[s])) {    // if scorpion not boxed
      posyScorpionMov[s] = posyScorpion[s]%5==0?5:posyScorpion[s]%5;    // calculate screen line position
      posxScorpionMov[s] = posxScorpion[s]%4==0?4:posxScorpion[s]%4;    // calculate screen row position
      // if scorpion not boxed and not able to move in it's give direction
      if ( !ScorpionBoxed(posxScorpion[s],posyScorpion[s]) && ( scorpionDir[s] ==1 ? ((laby[posxScorpion[s]][(posyScorpion[s]+1)]%64>31)||(laby[posxScorpion[s]][(posyScorpion[s]+1)]% 2)||!(laby[(posxScorpion[s]+1)][(posyScorpion[s]+1)]% 8>3)) : ((laby[posxScorpion[s]][(posyScorpion[s]-1)]%64>31)||!(laby[(posxScorpion[s]+1)][(posyScorpion[s]-1)]% 8>3)||(laby[posxScorpion[s]][(posyScorpion[s]+0)]% 2)) ) ) {              
        scorpionDir[s] = -scorpionDir[s];    // switch direction
        dirSwitched = true;    // indicate direction was switched
      } else {
        dirSwitched = false;    // indicate direction was not switched
      };
      if (!invincible&&((posyScorpion[s]==(posx+(scorpionDir[s]<0?0:-1)) || ((posyScorpion[s]==posx)&&(scorpionDir[s]==1)&&dirSwitched))&&(posxScorpion[s]==posy))) {    // if scorpion meets vincible hero
        Miss();
      } else {
        if (!(laby[posxScorpion[s]][(posyScorpion[s]+scorpionDir[s])]%64>31)) {    // if not other scorpion got in the way
          // if not active platform @ next place
          if (!((PlatformNumber((posxScorpion[s]+1),(posyScorpion[s]+scorpionDir[s])))&&platformActive[PlatformNumber((posxScorpion[s]+1),(posyScorpion[s]+scorpionDir[s]))])) {    
            laby[posxScorpion[s]][posyScorpion[s]]=eval(laby[posxScorpion[s]][posyScorpion[s]])-32;    // remove scorpion from this labyrinth place
            laby[posxScorpion[s]][(posyScorpion[s]+scorpionDir[s])]=eval(laby[posxScorpion[s]][(posyScorpion[s]+scorpionDir[s])])+32;    // put scorpion @ next labyrinth place
            if (Math.floor((posyScorpion[s]-1)/5)==screenRowSet&&!shiftPause) {    // if this scorpion in this segment and no screen shift going on
              PicShow("Scorpion"+(10*posxScorpionMov[s]+posyScorpionMov[s])+"", nullPre.src);
            }
            if (Math.floor((posyScorpion[s]+scorpionDir[s]-1)/5)==screenRowSet&&!shiftPause) {    // if this scorpion's next position in same segment and no screen shift going on
              AllScorpionsGameShow ()    // show present scormoins
            };
            posyScorpion[s]+=scorpionDir[s];    // scorpion moves in its set direction
          } else {    // other scorpion got in the way
            scorpionDir[s] = -scorpionDir[s];    // change scorpion's previous moving direction left (-1), boxed and no direction (0) or right (1)
            dirSwitched = true;    // indicate direction was switched
          };  
        };
      };
    };
  };
};

// search which scorpion is situated @ this line and row
function ScorpionNumber (searchLine,searchRow) {
  var scorpionSearchNumber = 0;    // number of scorpion not found yet
  for (n=1 ; n<(scorpions+1) ; n++) {     // go thru all the scorpion numbers
    if (searchLine==posxScorpion[n]&&searchRow==posyScorpion[n]) scorpionSearchNumber = n;    // remember scorpion's number found
  };
  return scorpionSearchNumber;
};

// search for scorpions & get their locations
function ScorpionsSearch () {
  var scorpionsFound = 0;    // no scorpions counted yet
  var posxScorpionFound = new Array();      // for all scorpions line positions
  var posyScorpionFound = new Array();      // for all scorpions row positions
  for (i=0 ; i<44 ; i++) {     // the lines
    for (j=1 ; j<80 ; j++) {     // the rows
      if (laby[i][j]%64>31) {    // if scorpion present @ this postiton
        scorpionsFound++;    // one more scorpion found
        posxScorpionFound[scorpionsFound] = i;    // remember scorpion's line
        posyScorpionFound[scorpionsFound] = j;    // remember scorpion's row
      };
    };
  };
  posxScorpion = posxScorpionFound;      // store set of all scorpion positions
  posyScorpion = posyScorpionFound;     // store set of all scorpion positions
  scorpions =  scorpionsFound;    // remember scorpion count
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end scorpion functions
