/*------------------------------------------------------------------time------------------------------------------------------------------*/

var timeID;   // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();

//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
  if (gameID) {
    clearTimeout(gameID);  // stop the game if running
    gameID = null;
  };
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (alarmOn) PicShow("AlarmStateInd", AlarmStateIndPre.src); // show alarm indicator on screen
  if (!demo) {    // if MainTimes demo not yet running 
    ResetAll();  // clear all pictures & variables
    StopAllSound();
    PlaySound("click_wav", vlm);  // click sound for push button
  };
};
  
// show current time & demo
function MainTimeStart () {
  demo = true;   // to show demo
  game = 4;  // clock running
  TimeShow();  // show current time
  Demo();   // run demo
};

// get current time
function Time () {
  today = new Date();
  hour = today.getHours();
  min = today.getMinutes();
  sec = today.getSeconds();
};

// show moon or sun according to current time
function TimeIndicatorShow () {
  if (hour<5||hour>21) {    // show moon from 22:00 till 02:00
    PicShow("Moon", MoonPre.src);  // show Moon
    PicShow("Sun", nullPre.src);  // show the sun on top
  } else {
    if (hour>9&&hour<15) {    // show sun from 10:00 till 14:00
      PicShow("Sun", SunPre.src);  // show the sun on top
      PicShow("Moon", nullPre.src);  // show Moon
    } else {    // else show none
      PicShow("Sun", nullPre.src);  // show the sun on top
      PicShow("Moon", nullPre.src);  // show Moon
    };
  };
};

// stop showing current time
function TimerReset () {
  if (timeID) {  // if time running
    clearTimeout(timeID);  // stop time timer
    timeID = null;  // reset time ID
  };
};

// show current time
function TimeShow () {
  TimerReset();    // stop showing current time
  Time();  // get current time
  if (!$('#ButTime:active').length&&!TKeyPressed) {  // if time button no longer pressed (else show alarm time)
    TimeShowOnScreen(min, hour);  // show the current time
  }; 
  timeID = window.setTimeout("TimeShow()", 1000);   // next second...
};

// show required time and indicators on screen from parameters
function TimeShowOnScreen(min, hour) {
  // set integer to time digits
  if (hour<10) PicShow("Num1", nullPre.src)
  else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
  PicShow("Num2", numPre[(hour%10)+1].src);
  PicShow("Num3", numPre[Math.floor(min/10)+1].src);
  PicShow("Num4", numPre[(min%10)+1].src);
  PicShow("NumColon", numColonPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions

