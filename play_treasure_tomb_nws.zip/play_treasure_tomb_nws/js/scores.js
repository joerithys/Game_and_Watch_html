/*------------------------------------------------------------------scores------------------------------------------------------------------*/

var highScore = new Array();  // to remember the highest score played for both games since opened in the browser
var score = 0;  // score (all beneath 100) at init
var scoreID  // ID for counting score

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow (i) {
	ScoreShow(highScore[i]);
};

// add certain points to score
function ScoreAdd (points) {
  if (game==1||game==2) {
    if (points) {
      score++;
      points--;
      scoreID = window.setTimeout("ScoreAdd ("+points+");", 75);
    } else {
      if (score>highScore[game]) highScore[game] = score;	   // if passed highscore @ of this game, set new highscore
    };
    ScoreShow(score);
  };
};

// hide score from screen
function ScoreHide () {
	$("#Num1").addClass("hidden");
	$("#Num2").addClass("hidden");
	$("#Num3").addClass("hidden");
	$("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
	$("#Num1").removeClass("hidden");
	$("#Num2").removeClass("hidden");
	$("#Num3").removeClass("hidden");
	$("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
	if (scoreTS>999) 	// first digit
		if (Math.floor((scoreTS/1000)%10)==0) PicShow("Num1", nullPre.src)
		else PicShow("Num1", numPre[Math.floor((scoreTS/1000)%10)+1].src);
	else PicShow("Num1", nullPre.src);
	if (scoreTS>99) 	// secons digit
		if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0) PicShow("Num2", nullPre.src)
		else PicShow("Num2", numPre[Math.floor(scoreTS%1000/100)+1].src);
	else PicShow("Num2", nullPre.src);
	if (scoreTS>9)  	// third digit
		if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0  && Math.floor(scoreTS%100/10)==0) PicShow("Num3", nullPre.src)
		else PicShow("Num3", numPre[Math.floor(scoreTS%100/10)+1].src);
	else PicShow("Num3", nullPre.src);
	PicShow("Num4", numPre[(scoreTS%10)+1].src);	// fourth digit
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
