//Product:	Covid19 HTML - Silver Screen (Nintendo) Simulator
//Version:	1.1
//Started:	13.04.2020
//Last update:	07.08.2020
//Author:	Flyzy (Joeri Thys)
//Original G&W:	Nintendo Co. Ltd
//Credits:
//Design, layout and artwork by Lee Robson (hydef)


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var blinkSpeed = 500;  // blinking speed for bonus
var blinkID;    // ID for timeout blinking score

var autoPlay = false;   // let the current game play automatically for test purposes
var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling

var color = false;           // indicator to show/hide colored background

var game = 0;   // 0-no game-all pictures; 1-gameA; 2-gameB; 3-game over; 4-clock; 
var gamePause = false;	
var gameID;	// ID for timeout game sequence
var gameResetID;
var gameSpeedMinimum;	// minimum speed for game sequence
var gameSpeedMaximum = 250;	// maximum speed for game sequence
var gameSpeed;	// speed for game sequence

// reset pressed keys to none pressed
var keyLeft = false;
var keyRight = false;
var keyPressed = false;	// indicates if a previuos key was already pressed to avoid double entries

var kongHoldingPaper;   // kong is holding toilet paper ready to throw
var kongThrowingPaper;  // kong is about to throw the toilet paper he holds
var kongThrowingPaperDone;  // kong thrown the toilet paper he held
var kongThrown = 0; // to avoid accidental 2 x KongHoldingPaper after kongThrownDone
var kongPause = false;

var mario;	// position Mario
var marioPause = false;
var marioKillID;        // ID for timeout mario getting killed

var pointsBonus = false;        // 300/500 points reached with 4 marios remaining
var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off
var miss;	// number of lives left
var missBlink = 1;  // for blinking missed attempts
var missBlinkID;        // ID for blinking Mario angels when cleared as bonus

var highScore = new Array();	// for highest scores for games a & b
var score = 0;	// score (all beneath 10000) at init
var scorePause = false;
var scoreBlinkID;    // ID for timeout score count
var sequence = 1;	// m=1234/b=24/k=1234/s=1
var zoomed = 1;		// default screen auto adapted to window size

var timeID;     // ID for timeout time indication
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var toiletPapers = new MakeArray(12);        // array of falling toiletPapers figures
var toiletPapersShelf = new MakeArray(6);        // array of toiletPapers figures on the shelf
var toiletPapersPause = false;
var toiletPapersRandom;      // random number for toiletPapers throw timing
var toiletPapersOnShelfBlink;  // for blinking times recuperated toiletPapers for bonus
var toiletPapersOnShelfBlinkID;  // ID for blinking recuperated toiletPapers for bonus
var toiletPapersOnShelfSetFullID;  // ID for recuperating toiletPapers for bonus
var toiletPapersRollID;  // ID for rolling missed toiletPapers
var tPos;       // place where Mario missed the falling toilet paper

var viruses = new MakeArray(27);	// array of virus figures
var virusesPause = false;
var gameRandom;  // random number for game sequence

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables



//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading names & game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "e": case "E": case "ArrowLeft":	// left key
            document.images['Move Left'].src = 'img/case/curl_in.png';
            if (!keyLeft) { // move left
                keyLeft = true;
                if (!marioPause) ButtonLeft();	// press left button
            };
            break;
        case "o": case "O": case "ArrowRight":	// right key
            document.images['Move Right'].src = 'img/case/curr_in.png';
            if (!keyRight) { // move right
                keyRight = true;
                if (!marioPause) ButtonRight();	// press right button
            };
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            document.images['Game A'].src = 'img/case/butset_in.png';
            if (!keyPressed) MainGameA(); // play Game A
            keyPressed = true;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" pressed
            document.images['Game B'].src = 'img/case/butset_in.png';
            if (!keyPressed) MainGameB(); // play Game B
            keyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
            document.images['aclButton'].src = 'img/case/buttons/acl_push.png';
            TotalReset(); // show full sprites
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/butset_in.png';
            MainTime(); // show time & demo
            break;
        //test case buttons
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;
                if (vlm==0.01)  SetSound(true);	// show sound turned on
            };
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case String.fromCharCode(233): case "Control" :	// "Ctrl"-key
            color = !color;     // indicator to show/hide colored background
            InlayShow();	// switch background black/color
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "e": case "E": case "ArrowLeft":	// arrow left key released
            document.images['Move Left'].src = 'img/case/curl.png';
            keyLeft = false; // left released;
            break;
        case "o": case "O": case "ArrowRight":	// arrow right key released
            document.images['Move Right'].src = 'img/case/curr.png';
            keyRight = false; // right released;
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/butset.png'; 
            MainGameAGo(); // play Game A
            keyPressed = false;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" released
            MainGameBGo(); // play Game B
            document.images['Game B'].src = 'img/case/butset.png';
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['aclButton'].src = 'img/case/buttons/acl.png';     // show acl button default
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/butset.png';
            break;
        default:
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly



//when page loaded focus on game 
$(document).ready(function () {
    $(function () {
        CheckSizeZoom();
        $('#divWrap').css('visibility', 'visible');
    });
    $(window).resize(CheckSizeZoom);
    $("#game").focus(); // get focus on the game
    PicPreload();	// this function preloads all images according to the blur setting
    TotalReset();	// set game to standard settings and show all figures
});



//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// left button or -key pressed
function ButtonLeft () {
    if (game==1 || game==2) LetMarioLeft();
};

// right button or -key pressed
function ButtonRight () {
    if (game==1 || game==2) LetMarioRight();
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};

// let score blink while score over 300 and no miss lost
function MissBlink () {    
    if (game==1 || game==2) {	// game a or b
        if (missBlink<4) {	// number of blinking the missed Marios
            MissHide();
            PlaySound("beep_", vlm);
            missBlinkID = window.setTimeout("MissShow()", blinkSpeed/2);
            missBlinkID = window.setTimeout("MissBlink()", blinkSpeed);
        } else {
            MissHide();
            PlaySound("beep_", vlm);
        };
    missBlink++;
    };
};

// let score blink while score over 300 and no miss lost
function ScoreBlink () {
    if (game==1 || game==2) {	// game a or b
        if (pointsBonus) {      // bonus for reaching 300/500 without any misses
            ScoreHide();
            scoreBlinkID = window.setTimeout("ScoreShow(score)", blinkSpeed);
            scoreBlinkID = window.setTimeout("ScoreBlink()", 2*blinkSpeed);
        } else ScoreShow(score);
    };
};

// let score blink while score over 300 and no miss lost
function ToiletPapersOnShelfBlink () {
    if (game==1 || game==2) { // game a or b 
        if (toiletPapersOnShelfBlink<4) {       // bonus for reaching 300/500 with miss(es)
            ToiletPapersOnShelfShowAll();       // get all thrown toiles papers on the shelf back
            PlaySound("beep_", vlm);
            toiletPapersOnShelfBlinkID = window.setTimeout("ToiletPapersOnShelfShow()", blinkSpeed/2);
            toiletPapersOnShelfBlinkID = window.setTimeout("ToiletPapersOnShelfBlink()", blinkSpeed);
        } else {
            ToiletPapersOnShelfShowAll();       // for final unblink
            PlaySound("beep_", vlm);
        };
    toiletPapersOnShelfBlink++;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions



//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    donkeyUpPre = new Image();  // Donkey jumping up
    donkeyUpPre.src = "img/screen/donkey_up.png";
    donkeyDownPre = new Image();        // Donkey standing down
    donkeyDownPre.src = "img/screen/donkey_down.png";
    gamePre = new Array();
    for (i=1 ; i<3 ; i++) {
        gamePre[i] = new Image();	// to show which game is playing, a or b
        gamePre[i].src = "img/screen/game"+eval(i)+".png";
    };
    inlayPre = new Image();
    inlayPre.src = "img/screen/inlay.png";	// to show building
    inlayColPre = new Image();
    inlayColPre.src = "img/screen/inlay_c.png";	// to show building surrounding in color
    kongPre = new Image();      // Kongs body
    kongPre.src = "img/screen/kong_dance_body.png";
    kongLeftArmDownPre = new Image();   
    kongLeftArmDownPre.src = "img/screen/kong_dance_arm_left_down.png";
    kongLeftArmUpPre = new Image();
    kongLeftArmUpPre.src = "img/screen/kong_dance_arm_left_up.png";
    kongRightArmDownPre = new Image();
    kongRightArmDownPre.src = "img/screen/kong_dance_arm_right_down.png";
    kongRightArmUpPre = new Image();
    kongRightArmUpPre.src = "img/screen/kong_dance_arm_right_up.png";
    kongThrowPaperLeftPre = new Image();
    kongThrowPaperLeftPre.src = "img/screen/kong_throw_paper_l.png";
    kongThrowPaperRightPre = new Image();
    kongThrowPaperRightPre.src = "img/screen/kong_throw_paper_r.png";
    koopaPre = new Image();     // Koopas body
    koopaPre.src = "img/screen/koopa_body.png";
    koopaHeadDownPre = new Image();
    koopaHeadDownPre.src = "img/screen/koopa_head_down.png";
    koopaHeadUpPre = new Image();
    koopaHeadUpPre.src = "img/screen/koopa_head_up.png";
    marioPre = new Array();
    for (i=1 ; i<5 ; i++) {	// to show the Marios
        marioPre[i] = new Image();
        marioPre[i].src = "img/screen/mario_"+eval(i)+".png";
    };
    marioMovePre = new Image(); // Mario running off indication the screen when hit by a virus
    marioMovePre.src = "img/screen/mario_move.png";
    maskPre = new Image(); // Mask falling off Mario running off the screen when hit by a virus
    maskPre.src = "img/screen/mask.png";
    missPre = new Image();	// angel to show the times Mario got hit by a virus
    missPre.src = "img/screen/mario_angel.png"; 
    misstextPre = new Image();  // text "MISS" above the times Mario got hit by a virus
    misstextPre.src = "img/screen/miss.png";
    nullPre = new Image();	// empty picture to hide any figure
    nullPre.src = "img/null.gif";
    numPre = new Array(); 	// to show the 10 numbers
    for (i=1 ; i<11 ; i++) {
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();	// to show time splitter colon
    numColonPre.src = "img/screen/num_colon.png";
    soundOnPre = new Image();	// to show sound button in on-state
    soundOnPre.src = "img/case/butOn"+".png";
    soundOffPre = new Image();	// to show sound button in off-state
    soundOffPre.src = "img/case/butOff"+".png";
    toiletPaperPre = new Array();       // to show the falling toilet papers
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            toiletPaperPre[place] = new Image();
            toiletPaperPre[place].src = "img/screen/toilet_paper_"+eval(place)+".png";
        };
    };
    toiletPaperRollPre = new Array();   // to show the rolling toilet papers
    for (i=1 ; i<5 ; i++) {
        toiletPaperRollPre[i] = new Image();
        toiletPaperRollPre[i].src = "img/screen/toilet_paper_roll_"+eval(i)+".png";
    };
    toiletPaperShelfPreAr = new Array();        // to show the toilet papers on the shelf
    for (i=1 ; i<7 ; i++) {
        toiletPaperShelfPreAr[i] = new Image();
        toiletPaperShelfPreAr[i].src = "img/screen/toilet_paper_pack.png";
    };
    toiletPaperShelfPre = new Image();        // to show the toilet papers shelf
    toiletPaperShelfPre.src = "img/screen/toilet_paper_shelf.png";
    virusPre = new Array();     // to show the falling viruses
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            virusPre[place] = new Image();
            virusPre[place].src = "img/screen/virus_"+eval(place)+".png";
        };
    };
};

// hide all figures
function MainPicturesClear () {
    PicShow("NumColon", nullPre.src);
    PicShow("DonkeyUp", nullPre.src);
    PicShow("DonkeyDown", nullPre.src);
    PicShow("Game1", nullPre.src);
    PicShow("Game2", nullPre.src);
    PicShow("Kong", nullPre.src);
    PicShow("KongLeftArmUp", nullPre.src);
    PicShow("KongLeftArmDown", nullPre.src);
    PicShow("KongRightArmUp", nullPre.src);
    PicShow("KongRightArmDown", nullPre.src);
    PicShow("KongThrowPaperLeft", nullPre.src);
    PicShow("KongThrowPaperRight", nullPre.src);
    PicShow("Koopa", nullPre.src);
    PicShow("KoopaHeadUp", nullPre.src);
    PicShow("KoopaHeadDown" , nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Mario"+eval(i)+"", nullPre.src);
    PicShow("MarioMove", nullPre.src);
    PicShow("Mask", nullPre.src);
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
    PicShow("MissText", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            PicShow("ToiletPaper"+eval(place)+"", nullPre.src);
        };
    };
    for (i=1 ; i<5 ; i++) PicShow("ToiletPaperRoll"+eval(i)+"", nullPre.src);
    for (i=1 ; i<7 ; i++) PicShow("ToiletPaperShelf"+eval(i)+"", nullPre.src);
    PicShow("ToiletPaperShelf", nullPre.src);
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            PicShow("Virus"+eval(place)+"", nullPre.src);
        };
    };
};

// show all figures
function MainPicturesShow () {
    PrefSoundSettings();
    PicShow("NumColon", numColonPre.src);
    PicShow("DonkeyUp", donkeyUpPre.src);
    PicShow("DonkeyDown", donkeyDownPre.src);
    PicShow("Game1", gamePre[1].src);
    PicShow("Game2", gamePre[2].src);
    PicShow("Kong", kongPre.src);
    PicShow("KongLeftArmUp", kongLeftArmUpPre.src);
    PicShow("KongLeftArmDown", kongLeftArmDownPre.src);
    PicShow("KongRightArmUp", kongRightArmUpPre.src);
    PicShow("KongRightArmDown", kongRightArmDownPre.src);
    PicShow("KongThrowPaperLeft", kongThrowPaperLeftPre.src);
    PicShow("KongThrowPaperRight", kongThrowPaperRightPre.src);
    PicShow("Koopa", koopaPre.src);
    PicShow("KoopaHeadUp", koopaHeadUpPre.src);
    PicShow("KoopaHeadDown" , koopaHeadDownPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Mario"+eval(i)+"", marioPre[i].src);
    PicShow("MarioMove", marioMovePre.src);
    PicShow("Mask", maskPre.src);
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    PicShow("MissText", misstextPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            PicShow("ToiletPaper"+eval(place)+"", toiletPaperPre[place].src);
        };
    };
    for (i=1 ; i<5 ; i++) PicShow("ToiletPaperRoll"+eval(i)+"", toiletPaperRollPre[i].src);
    for (i=1 ; i<7 ; i++) PicShow("ToiletPaperShelf"+eval(i)+"", toiletPaperShelfPreAr[i].src);
    PicShow("ToiletPaperShelf", toiletPaperShelfPre.src);
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            PicShow("Virus"+eval(place)+"", virusPre[place].src);
        };
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them



//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich sound on/off; dont preload here
function PrefSound () {
    prefSound = !prefSound;
    PrefSoundEval();
};

// Show sound settings according to current (or cookie) settings
function PrefSoundEval () {
    if (!prefSound) { // if sound is set to "off" 
        preVlm = vlm;   // remember last sound volume
        vlm = 0;        // set volume to 0
    } else {
        if (preVlm==0) preVlm = 0.01; // if no previous volume, set to minimum
        vlm = preVlm;   // set volume to "on"
    };
    PrefSoundSettings();	// show sound on/off indication
    PrefSoundShow();	// show volume indicator on screen for testing purposes
    PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
    var vlmTxt = "";    // empty sound volume indicator picture
    $("#SoundStateInd").html("");	// empty/hide volume indicator
    if (prefSoundShow) {      // if volume indicator is set to show
        $("#SoundStateIndBkgnd").removeClass("hidden");		
        if (vlm>0.00999) {
            for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
            $("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
        } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    } else {
        $("#SoundStateIndBkgnd").addClass("hidden");
        $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
    if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
    else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// swich sound on/off; dont preload here
function SetSound (setting) {
    prefSound = setting;
    PrefSoundSettings();	// show sound on/off indication
    PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
    StopSound("beep_", vlm);
    StopSound("mario_kill_", vlm);
    StopSound("toilet_paper_catch_", vlm);
    StopSound("toilet_paper_fall_", vlm);
    StopSound("virus_fall_", vlm);
    StopSound("virus_hit_", vlm);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions



//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all figures
function AllFiguresReset () {
    DancersReset();
    ToiletPapersReset();
    ToiletPapersShelfReset();
    VirusesReset();
};

// set dancers @ initial positions
function DancersReset () {
    DonkeyShow(0);      //show Donkey standing down
    KongShow(1,1);      //show Kong left arm up right arm down
    KoopaShow(0);           //show Koopa head down
};

// reset game for next wave or end
function GameReset () {
    window.clearTimeout(gameID);	// stop game
    VirusesReset();
    MarioReset();
    SpeedReset();
    UnPauseAll();
};

// set Mario in the middle
function MarioReset () {
    mario = 2;
    MarioShow();
};

// remove all misses & "MISS" text
function MissClear () {
    miss = 0;
    UnPauseAll();
    MissTextHide ();
};

// Let the misses blink & reset them
function MissReset () {
    if (game==1 || game==2) {
        MissBlink();
        missClearID = window.setTimeout("MissClear()", 2000);    
    } else MissClear();
};

// pause all
function PauseAll () {
    dancePause = true;
    gamePause = true;
    marioPause = true;
    toiletPapersPause = true;
    virusesPause = true;
};

// reset all to basics
function ResetAll () {	// reset all screen settings
    AllFiguresReset();
    ToiletPapersReset();
    AllStop();	//
    MainPicturesShow();	// show all main figures
    UnPauseAll();
};

// reset speed according to the current score
function SpeedReset () {
    gameSpeed = gameSpeedMinimum - Math.round(score%1000/5) - Math.floor(score/50) - Math.floor(score/1000);
    if (gameSpeed<gameSpeedMaximum) gameSpeed = gameSpeedMaximum;
};

// remove all falling toilet papers
function ToiletPapersReset () {
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            toiletPapers[place] = 0;    // reset the falling toilet paper @ that position
        };
    };
    ToiletPapersShow(); // show on screen
    ToiletPapersRollHide(); // hide all rolling toilet papers
    KongHoldingPaperHide();     // hide toilet paper Kong was holding
    kongHoldingPaper = 0;       // kong not holding a toilet paper
    kongThrowingPaper = 0;       // kong not throwing a toilet paper
    kongThrowingPaperDone = 0;       // kong not just thrown a toilet paper
    kongThrown = 0; // no falling but not yet registered toilet paper
    tPos = 0;   // no position of thrown toilet paper
};

// set all toilet papers on the shelf 
function ToiletPapersShelfReset () {
    if (pointsBonus) {
        ToiletPapersOnShelfBlink();
        toiletPapersOnShelfSetFullID = window.setTimeout("ToiletPapersShelfSetFull()", 2000);    
    } else ToiletPapersShelfSetFull();  // final unblink
};

// show all toilet papers on the shelf 
function ToiletPapersShelfSetFull () {
    for (var i=1 ; i<7 ; i++) toiletPapersShelf[i] = 1;    
    UnPauseAll();
};

// "ACL" is pressed to clear any game and reset all on going to default and show all figures
function TotalReset () {
    ResetAll();
    game = 0; // 
    if(demoID){
        clearTimeout(demoID);
        demoID = null;
    }
    demoID = window.setTimeout("MainTimeStart()", 120000);	// start demo after 2 minutes    
};

// unpause all
function UnPauseAll () {
    dancePause = false;
    gamePause = false;
    marioPause = false;
    toiletPapersPause = false;
    virusesPause = false;
};

// remove all falling virusses
function VirusesReset () {
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            viruses[place] = 0;
        };
    };
    VirusesShow();      //show on screen
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions



//show/hide different pieces of the game
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// set dancers @ sequence positions
function DancersShow () {
    DonkeyShow(sequence>2?1:0);      //show Donkey
    if (kongHoldingPaper) {     // show Kong holding toilet paper according to sequence settings
        if (sequence==2) KongHoldingPaper(1)
        else KongHoldingPaper(0);
        kongHoldingPaper = 0;
        kongThrowingPaper = 1;
    } else {
        if (kongThrowingPaper) {     // show Kong throwing toilet paper according to sequence settings
            if (sequence==3) KongThrowingPaper(1)
            else KongThrowingPaper(0);
            kongThrowingPaper = 0;
            kongThrowingPaperDone = 1;
        } else {
            KongShow(sequence==1?1:0,sequence==2?0:1);      //show Kong dancing, left arm & right arm according to sequence settings
        };
    };
    KoopaShow(sequence<3?1:0);  //show Koopa head up/down according to sequence settings
};

//show Donkey up/down
function DonkeyShow (jump) {
    if (jump) {
        PicShow("DonkeyUp", donkeyUpPre.src);
        PicShow("DonkeyDown", nullPre.src);
    } else {
        PicShow("DonkeyUp", nullPre.src);
	PicShow("DonkeyDown", donkeyDownPre.src);
    };   
};   
   
//Show if playing game a or b on screen
function GameShow () {
    if (!demo) {
        if (game==1) PicShow("Game1", gamePre[1].src)
        else if (game==2) PicShow("Game2", gamePre[2].src);
    };
};

// check & show highest score on screen
function HighScoreShow (game) {
    pause = true;
    highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
    ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

// hide toilet paper Kong was holding
function KongHoldingPaperHide () {
    PicShow("KongThrowPaperLeft", nullPre.src);
    PicShow("KongThrowPaperRight", nullPre.src);
};

// show konfs arm holding toilet paper to throw according to sequence settings
function KongHoldingPaperShow (rightArm) {
    if (rightArm) PicShow("KongThrowPaperRight", kongThrowPaperRightPre.src)
    else PicShow("KongThrowPaperLeft", kongThrowPaperLeftPre.src);
};

//show Kong left/right arm up/down according to sequence settings
function KongShow (leftArm,rightArm) {
    PicShow("Kong", kongPre.src);
    if (leftArm) {
	PicShow("KongLeftArmUp", kongLeftArmUpPre.src);
	PicShow("KongLeftArmDown", nullPre.src);
    } else {
	PicShow("KongLeftArmUp", nullPre.src);
	PicShow("KongLeftArmDown", kongLeftArmDownPre.src);
    };
    if (rightArm) {
	PicShow("KongRightArmUp", kongRightArmUpPre.src);
	PicShow("KongRightArmDown", nullPre.src);
    } else {
	PicShow("KongRightArmUp", nullPre.src);
	PicShow("KongRightArmDown", kongRightArmDownPre.src);
    };    
};    
  
//show Koopa head up/down according to sequence settings
function KoopaShow (head) {
    PicShow("Koopa", koopaPre.src);
    if (head) {
	PicShow("KoopaHeadUp", koopaHeadUpPre.src);
	PicShow("KoopaHeadDown" , nullPre.src);
    } else {
	PicShow("KoopaHeadUp", nullPre.src);
	PicShow("KoopaHeadDown" , koopaHeadDownPre.src);
    };
};           

//Show game start situation on screen
function MainPicturesGame () {
    mario = 2;	// Mario in center
    sequence++; // next sequence
    DancersShow();
    GameShow();
    MarioShow();
    MissShow();
    ToiletPaperShelfShow();
};

// show Mario @ current position
function MarioShow () {
    for (var i=1 ; i<4 ; i++) {
        if (mario==eval(i)) PicShow("Mario"+eval(i)+"", marioPre[i].src)
        else PicShow("Mario"+eval(i)+"", nullPre.src);
    };
};

// hide "MISS" text
function MissTextHide () {
    PicShow("MissText", nullPre.src);
};

// show "MISS" text
function MissTextShow () {
    PicShow("MissText", misstextPre.src);
};

// hide misses
function MissHide () {
    for (var i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
};

// show misses
function MissShow () {
    for (var i=1 ; i<4 ; i++) {
        if (i<=miss) PicShow("Miss"+eval(i)+"", missPre.src)
        else  PicShow("Miss"+eval(i)+"", nullPre.src);
    };
};

// translate score to the digits on screen
function ScoreShow (score) {
    if (score>999) 
        if (Math.floor((score/1000)%10)==0) PicShow("Num1", nullPre.src)
        else PicShow("Num1", numPre[Math.floor((score/1000)%10)+1].src);
    else PicShow("Num1", nullPre.src);
    if (score>99) 
        if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0) PicShow("Num2", nullPre.src)
        else PicShow("Num2", numPre[Math.floor(score%1000/100)+1].src);
    else PicShow("Num2", nullPre.src);
    if (score>9)  
        if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0  && Math.floor(score%100/10)==0) PicShow("Num3", nullPre.src)
        else PicShow("Num3", numPre[Math.floor(score%100/10)+1].src);
    else PicShow("Num3", nullPre.src);
    PicShow("Num4", numPre[(score%10)+1].src);
};

// hide score
function ScoreHide () {
    for (var i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

/*
function ScoreHide () {
    $("#Num1").addClass("hidden");
    $("#Num2").addClass("hidden");
    $("#Num3").addClass("hidden");
    $("#Num4").addClass("hidden");
};

function ScoreUnHide () {
    $("#Num1").removeClass("hidden");
    $("#Num2").removeClass("hidden");
    $("#Num3").removeClass("hidden");
    $("#Num4").removeClass("hidden");
};
*/

// hide toilet paper on shelf
function ToiletPapersOnShelfhide () {
    for (i=1 ; i<7 ; i++) PicShow("ToiletPaperShelf"+eval(i)+"", nullPre.src);
};

// show current toilet paper on shelf
function ToiletPapersOnShelfShow () {
    for (i=1 ; i<7 ; i++) {
        if (toiletPapersShelf[i]) PicShow("ToiletPaperShelf"+eval(i)+"", toiletPaperShelfPreAr[i].src)     // shown toilet papers
        else PicShow("ToiletPaperShelf"+eval(i)+"", nullPre.src);     // hidden toilet papers
    };
};

// show all toilet paper on shelf
function ToiletPapersOnShelfShowAll () {
    for (i=1 ; i<7 ; i++) PicShow("ToiletPaperShelf"+eval(i)+"", toiletPaperShelfPreAr[i].src);
};

// show rolling toilet paper @ current position
function ToiletPapersRollHide (pos) {
    for (h=1 ; h<5 ; h++) PicShow("ToiletPaperRoll"+eval(h)+"", nullPre.src);     // hide all rolling toilet papers
};

// show rolling toilet paper @ current position
function ToiletPapersRollShow (pos) {
    if (pos>1) PicShow("ToiletPaperRoll"+eval((pos-1))+"", nullPre.src);     // hide previous rolling toilet papers
    if (pos<5) PicShow("ToiletPaperRoll"+eval(pos)+"", toiletPaperRollPre[pos].src);     // show present rolling toilet papers
};

// show toilet paper shelf
function ToiletPaperShelfShow () {
    PicShow("ToiletPaperShelf", toiletPaperShelfPre.src);     // shown/hidden toilet papers
    ToiletPapersOnShelfShow();		// show current toilet papers on the shelf
};

// show the moving toilet papers @ their current positions
function ToiletPapersShow () {
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            place = kol*10 + row;
            if (toiletPapers[place]==0) PicShow("ToiletPaper"+eval(place)+"", nullPre.src)     // hidden toilet papers
            else PicShow("ToiletPaper"+eval(place)+"", toiletPaperPre[place].src);     // shown toilet papers
        };
    };
};

// show all falling virusses @ sequence row
function VirusesRowShow () {
    var placeVS;
    for (var i=1 ; i<5 ; i++) {
        placeVS = sequence*10 + i;      // calculate position of element
        if (viruses[placeVS]) PicShow("Virus"+eval(placeVS)+"", virusPre[placeVS].src)	// shown viruses
        else PicShow("Virus"+eval(placeVS)+"", nullPre.src)	// hidden viruses
    };
};

// show all present viruses
function VirusesShow () {
    var placeVS;
    for (kol=1 ; kol<4 ; kol++) {
        for (row=1 ; row<5 ; row++) {
            placeVS = kol*10 + row;
            if (viruses[placeVS]) PicShow("Virus"+eval(placeVS)+"", virusPre[placeVS].src)	// shown viruses
            else PicShow("Virus"+eval(placeVS)+"", nullPre.src)	// hidden viruses
        }; 
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end show different pieces of the game



//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
    // if not already clock running or to prevent MainTime to run before failed flag_05-sound ended
    if (game!=4) {      
        StopAllSound();
        TotalReset();	// reset all
        PlaySound("click_", vlm);	// click sound for push button
        MainTimeStart(); // show current time
    };
};
	
// actual part to stop all and show time
function MainTimeStart () {
    if (game>2 || game==0) {
        demo = true;    // to show demo
        TimeShow();	// show current time
        GameA();        // use game a as demo
        gameID = window.setTimeout("GameGo()", gameSpeed);
    };
};

// show current time
function TimeShow () {
    Time();	// get current time
    TimeShowOnScreen();
    timeID = window.setTimeout("TimeShow()", 1000);
};

// show required time and indicators on screen
function TimeShowOnScreen () {
    // set integer to time digits
    if (hour<10) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
    PicShow("Num2", numPre[(hour%10)+1].src);
    PicShow("Num3", numPre[Math.floor(min/10)+1].src);
    PicShow("Num4", numPre[(min%10)+1].src);
    PicShow("NumColon", numColonPre.src);
};

// get current time
function Time () {
    today = new Date();
    hour = today.getHours();
    min = today.getMinutes();
    sec = today.getSeconds();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions


	
//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing
function AllStop () {
    window.clearTimeout(blinkID);	// stop score blinking
    blinkID = null;
    window.clearTimeout(demoID);	// stop demo from starting after 2 minutes no action
    demoID = null;
    window.clearTimeout(gameID);	// stop game
    gameID = null;
    window.clearTimeout(gameResetID);   // stop delay game reset for next run
    gameResetID = null;
    window.clearTimeout(marioKillID);   // stop Mario from running after hit
    marioKillID = null;
    window.clearTimeout(missBlinkID);   // stop misses blinking
    missBlinkID = null;
    window.clearTimeout(scoreBlinkID);  // stop score blinking
    scoreBlinkID = null;
    window.clearTimeout(timeID);	// stop time indication
    timeID = null;
    window.clearTimeout(toiletPapersOnShelfBlinkID);    // stop toilet papers blinking on shelf
    toiletPapersOnShelfBlinkID = null;
    window.clearTimeout(toiletPapersOnShelfSetFullID);  // stop reset toilet papers on the shelf
    toiletPapersOnShelfSetFullID = null;
    autoPlay = false;
    pointsBonus = false;
};

// play game A
function GameA () {
    if (game!=1 && game!=2) {
        //PlaySound("click_", vlm);	// click sound for push button
        ResetAll();	// reset all screen settings
        // variables reset
        ToiletPapersReset();    // reset the falling toilet papers
        MainPicturesClear();	// hide all figures
        if (demo) {
            game = 4;
            toiletPapersRandom = 5;
            gameRandom = 5;
            gameSpeedMinimum = 500;	// minimum speed for game sequence
            score = 0;
            TimeShow();
        } else { 
            //game = 1; // gameA
            toiletPapersRandom = 145;
            gameRandom = 6;
            gameSpeedMinimum = 550;	// minimum speed for game sequence
            score = 0;
            //ScoreShow();
            HighScoreShow(1);      // show highest score for game a
        };
        gameSpeed = gameSpeedMinimum;	// speed for game sequence
        miss = 0;
        missBlink = 1;
        sequence = 1;   // start sequence
        MainPicturesGame();	// set game to start situation 
        //gameID = window.setTimeout("GameGo()", gameSpeed);
    };
};

// play game B
function GameB () {
    if (game!=1 && game!=2) {
        //PlaySound("click_", vlm);	// click sound for push button
        ResetAll();	// reset all screen settings
        ToiletPapersReset();    // reset the falling toilet papers
        MainPicturesClear();	// hide all figures
        // variables reset
        //game = 2; // gameB
        gameRandom = 5;
        gameSpeedMinimum = 550;	// minimum speed for game sequence
        gameSpeed = gameSpeedMinimum;	// speed for game sequence
        miss = 0;
        missBlink = 1;
        score = 0;
        sequence = 1;
        toiletPapersRandom = 140;
        //ScoreShow();
        MainPicturesGame();	// set game to start situation 
        //gameID = window.setTimeout("GameGo()", gameSpeed);
        HighScoreShow(2);      // show highest score for game b
    };
};

// initiate game
function GameGo () {
    if (!gamePause) GameMove();	// engage game if not paused
    if (game!=3) gameID = window.setTimeout("GameGo()", gameSpeed);     // if not game over keep game going
};

// synchronise all moves
function GameMove () {
    if (demo) MarioAutoMove()
    else if (autoPlay) MarioAutoMove(); // for testing flyzy purposes
    DancersShow ();	// let Kong move & throw viruses
    VirusesGo();	// viruses go, move show and repeat 
    ToiletPapersGo(); // ToiletPapers go, move show and repeat
    if (sequence<3) sequence++
    else sequence = 1;
};

// game end
function GameOver () {
    game = 3; // game over indication
    if (!demo) {
        if(demoID){
            clearTimeout(demoID);
            demoID = null;
        }
        demoID = window.setTimeout("MainTimeStart()", 120000);	// start demo after 2 minutes
    } else GameA();
};

// show/hide colored background
function InlayShow () {
    color?PicShow("Inlay", inlayColPre.src):PicShow("Inlay", inlayPre.src);	
};

// let kong stand by to throw
function KongHoldingPaper (rightArm) {
    if (!rightArm) KongShow(1,sequence==2?0:1)      //show Kong left arm up right according to sequence
    else KongShow(sequence==1?1:0,1);      //show Kong left arm up right arm down
    KongTakeFromShelf();
    KongHoldingPaperShow(rightArm);
};

// Kong takes a toilet paper from the shelf
function KongTakeFromShelf () {
    var taken = 0;
    for (i=1 ; i<7 ; i++) {
        if (toiletPapersShelf[i] && !taken) {
            toiletPapersShelf[i] = 0;
            taken++;
        };
    };
    ToiletPapersOnShelfShow();  // show remaining toilet papers on shelf
};

// let kong stand by to throw
function KongThrowingPaper (rightArm) {
    if (!rightArm) KongShow(0,sequence==2?0:1)      //show Kong left arm up right according to sequence
    else KongShow(sequence==1?1:0,0);      //show Kong left arm up right arm down
    KongHoldingPaperHide();     // hide toilet paper Kong was holding
};

// initiate Kong getting ready to throw toilet paper
function KongThrowInit () {
    var randyT;
    if (score<4 && !demo) randyT = 0
    else randyT = Math.floor(toiletPapersRandom*Math.random())==0;
    if (randyT && ToiletPapersOnShelfPresent()) {
        kongHoldingPaper = 1;
        kongThrowingPaper = 0;
        kongThrowingPaperDone = 0;
        kongThrown = 1; // to avoid accidental 2 x KongHoldingPaper
    };
};

// actual left function to let Mario go left
function LetMarioLeft () {
    if (mario>1) mario--;
    MarioShow();
    if (ToiletPapersCollision()) ToiletPaperBonus();
};

// actual right function to let Mario go right
function LetMarioRight () {
    if (mario<3) mario++;
    MarioShow();
    if (ToiletPapersCollision()) ToiletPaperBonus();
};

// button pressed to play game A
function MainGameA () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
        MainGameOver();	// stop demo if running + clear all
    };
    GameA();
};

// "game A" button released so actually play game A
function MainGameAGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 1; // game A
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// button pressed to play game B
function MainGameB () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
        MainGameOver();	// stop demo if running + clear all
    };
    GameB();
};

// "game B" button released so actually play game B
function MainGameBGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 2; // game B
        ScoreShow(score);
        pause = false;
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// stop demo if running + clear all
function MainGameOver () {
    ResetAll();	// reset all
    if(demoID){
        clearTimeout(demoID);
        demoID = null;
    }
    demoID = window.setTimeout("MainTimeStart()", 120000);
};

// Mario becomes an angel
function MarioDead () {
    //hide running Mario & falling mask
    PicShow("Mario4", nullPre.src);
    PicShow("MarioMove", nullPre.src);
    PicShow("Mask", nullPre.src);
    MissShow(); // show misses
    if (!demo) MissTextShow();  // show "MISS" text 
    VirusesReset();
    ToiletPapersReset();
    if (!demo)  PlaySound("mario_kill_", vlm);    
    if (miss<3) {
        gameResetID = window.setTimeout("GameReset()", 1000);   // reset for next attempt
        gameID = window.setTimeout("GameGo()", 1000);   // go to next attempt
    } else GameOver();
};

// Mario gets killed and runs off screen
function MarioKill () {
    PlaySound("mario_kill_", vlm);	// sound for Mario colliding with virus
    PauseAll();
    if (!demo) {
        miss++;
        PlaySound("mario_kill_", vlm);
        pointsBonus = false;
    };
    marioKillID = window.setTimeout("MarioMove()", 800);	// Mario runs off screen
};

// Mario gets hit and runs off screen
function MarioMove () {
    for (i=1 ; i<4 ; i++) PicShow("Mario"+eval(i)+"", nullPre.src);   // hide Mario @ current position
    PicShow("Mario4", marioPre[4].src); // show Mario moving
    PicShow("MarioMove", marioMovePre.src);     // show Marios motion
    PicShow("Mask", maskPre.src);       // Mario losses his mask
    if (!demo)  PlaySound("mario_kill_", vlm);    
    marioKillID = window.setTimeout("MarioDead()", 800);	//  Mario becomes an angel
};

// add certain points to score
function ScoreAdd (points) {
    if (pointsBonus) points*=2;
    for (var a=0 ; a<points ; a++) {
        score++;
        if ((score%1000)==0) gameRandom = 5;
        if ((score%100)==0) SpeedReset();       // reset speed every 100 points
        if ((score%1000)==300 || (score%1000)==500) {   // bonus @ 300/500 points
            gameRandom--;
            ScoreShow(score);
            PauseAll();
            missBlink = 1;
            toiletPapersOnShelfBlink = 1;
            if (!miss) {
                pointsBonus = true;
                toiletPapersRandom-=30;
                ToiletPapersShelfReset();       // if no misses get all toilet papers on shelf
            } else MissReset(); // else reset all misses
            ScoreBlink();
        };
    };
    highScore[game] = (((highScore[game]>score))?highScore[game]:score);        // if current score higheer than recorded, record
    ScoreShow(score);
};

// speeds up the game with given value
function SpeedUp (speed) {
    if ((gameSpeed>gameSpeedMaximum) && !demo) gameSpeed -= speed; 
};

// get extra points for catching a toilet paper, and reset the sequence
function ToiletPaperBonus() {
    if (!demo) {
        ScoreAdd(5); // Mario gets 5 extra points
        ScoreShow(score);
        ToiletPapersReset();    //reset falling toilet papers sequence
        PlaySound("toilet_paper_catch_", vlm);    
    };
};

// toilet papers check collision with mario
function ToiletPapersCollision () {
    if (toiletPapers[(mario*10+4)]==1)  {
        toiletPapers[(mario*10+4)] = 0;        
        toiletPapersRollID = window.setTimeout("ToiletPapersShow()", blinkSpeed/2);	// hide the moving ToiletPaper after collision
        return true;
    } else return false;
};

// toilet papers move & show or initiate
function ToiletPapersGo () {
    if (!toiletPapersPause) {
        if (!(ToiletPapersPresent() || kongThrowingPaperDone || kongThrown)) KongThrowInit()  // determine if next toiletpaper gets thrown
        else {
            kongThrown = 0; // no falling but not yet registered toilet paper
            ToiletPapersMove();	// ToiletPapers move
            ToiletPapersShow();	// show the moving ToiletPapers
            if (toiletPapers[(sequence*10+4)] && ToiletPapersCollision()) ToiletPaperBonus();     // get bonud if caught
        }
    };
};

// move toilet papers
function ToiletPapersMove () {
    var placeT;
    for (var y=4 ; y>1 ; y--) {
        placeT = sequence*10 + y;      // calculate position of element
        if (y==4 && toiletPapers[placeT] && !ToiletPapersCollision()) tPos = sequence;
        toiletPapers[placeT] = toiletPapers[placeT-1];  // move toilet paper down a place
    };
    if (kongThrowingPaperDone) {     // if Kong has done throwing a new toilet paper from the shelf
        toiletPapers[sequence*10 + 1] = 1; // let the thrown toilet paper starting to fall @ hihgest position
        kongThrowingPaperDone = 0;      
    } else toiletPapers[placeT-1] = 0;  // else no new falling toilet paper
    if (ToiletPapersRowPresent()) PlaySound("toilet_paper_fall_", vlm)	//if toilet paper on row of sequence present, sound for viruses falling  
    else if (tPos) ToiletPapersRoll (tPos);   // if Mario missed the fallen toilet paper let it start rolling
};

// sheck how many toilet papers left on shelf
function ToiletPapersOnShelfPresent () {
    var presentTOS = 0;
    for (i=1 ; i<7 ; i++) if (toiletPapersShelf[i]) presentTOS++;
    if (demo && !presentTOS) ToiletPapersShelfReset();    // if demo and shelf empty, fill it again
    return presentTOS;  // return counted toilet papers on the shelf
};

// sheck how many falling toilet papers
function ToiletPapersPresent () {
    var presentT = 0;
    if (tPos) presentT++
    else {
	for (kol=1 ; kol<4 ; kol++) {
            for (row=1 ; row<5 ; row++) {
                place = kol*10 + row;
                if (toiletPapers[place]) presentT++;
            };
	};
    };
    return presentT;    // return counted falling toilet papers
};
    
// let the missed toilet paper roll off the screen
function ToiletPapersRoll (pos) {
    tPos = pos; // position where toilet paper fell
    if (tPos<6) {
        ToiletPapersRollShow (tPos);    // show fallen toilet paper on screen
        tPos++; // next position for show @ next sequence
    } else ToiletPapersReset();    // fallen toilet paper rolled off screen, next may fall
};

// check if toilet paper on row of sequence present
function ToiletPapersRowPresent () {
    var presentTR = 0;
    var placeTR;
    for (var q=1 ; q<5 ; q++) {
        placeTR = sequence*10 + q;      // calculate position of element
        if (toiletPapers[placeTR]) presentTR++;
    };
    return presentTR;    // return counted falling toilet papers on that row
};

// Viruses check collision with mario
function VirusCollision () {
    if (viruses[(sequence*10+4)]==1 && mario==sequence)  return true
    else return false;
};

// let viruses go; 
function VirusesGo () {
    if (!virusesPause) {
        VirusesMove();	// viruses move
        VirusesRowShow();	// show viruses @ present row
        if (sequence==2) {
            if (gameSpeed>350) SpeedUp(2)	// let viruses fall faster
            else SpeedUp(1);	// let viruses fall faster
        };
    };
};

//-----------------------+++++++++++++++++++++++++++++++++--------------------------

// check if number falling viruses exeeded a specific maximum
function VirusesMaxedOut () {
    var virusesMaxedOut = 0;
    if (sequence==3 && viruses[11] && viruses[21])  virusesMaxedOut++; // no 3 on row
    if (game==2) {   // if game b playing
        if (((score%1000)<999) && sequence==3 && viruses[11] && viruses[21])  virusesMaxedOut++; // no 3 on row below 999 points
        if (VirusesRowPresent()>2) virusesMaxedOut++; // maximum 3 viruses per row
        if ((score%1000)<50) if (VirusesPresent()>4) virusesMaxedOut++; // maximum 5 viruses below 50 points
        else if (VirusesPresent()>8) virusesMaxedOut++; // else maximum 8 viruses after 50 points
        if ((score%1000)<100 && viruses[(sequence*10+1)]) virusesMaxedOut++;    // no 2 virusses after eachother below 100 points
    } else {    // game a or demo
        if (sequence==3 && viruses[11] && viruses[21])  virusesMaxedOut++; // never 3 on row
        if (VirusesRowPresent()>1) virusesMaxedOut++; // maximum 3 viruses per row
        if ((score%1000)<10) if (VirusesPresent()>1) virusesMaxedOut++; // maximum 2 viruses below 10 points
        if ((score%1000)<50) if (VirusesPresent()>2) virusesMaxedOut++; // maximum 3 viruses below 50 points
        if ((score%1000)<100) if (VirusesPresent()>3) virusesMaxedOut++; // maximum 4 viruses below 100 points
        else if (VirusesPresent()>6) virusesMaxedOut++; // else maximum 6 viruses
        if ((score%1000)<200 && viruses[(sequence*10+1)]) virusesMaxedOut++;    // no 2 virusses after eachother below 200 points
        if ((score%1000)<999 && (kongThrowingPaper || kongThrowingPaperDone)) virusesMaxedOut++;    // no virusses together with toiletPaper below 999 points
    };
    return virusesMaxedOut;     // return the counted number of falling viruses that exeeded the maximum
};

// check if number falling viruses stays below a specific minimum
function VirusesMinnedOut (pos) {
    virusesMinnedOut = 0
    if  ((!VirusesPresent() && sequence==mario) ||         //  no random falling virusses the first 3 times
        ((score%1000)>3 && (score%1000)<6 && VirusesPresent()<1) ||    //  no less than 2 falling virusses between 3 & 6 points
        ((score%1000)>=6 && (score%1000)<200 && VirusesPresent()<2) ||    //  no less than 2 falling virusses between 6 & 200 points
        ((score%1000)>=200 && (score%1000)<600 && VirusesPresent()<3) ||    //  no less then 3 falling virusses between 200 & 600 points
        ((score%1000)>=600 && VirusesPresent()<4)) virusesMinnedOut++;  //  no less then 4 falling virusses after 600 points
    return virusesMinnedOut;
};

// viruses falling
function VirusesMove () {
    var randyM;
    var placeM;
    if  ((score%1000)<3 && !demo) randyM = 0    //  no random falling virusses the first 3 times
    else randyM = Math.floor(gameRandom*Math.random())==0;
    for (var y=4 ; y>1 ; y--) {
        placeM = sequence*10 + y;      // calculate position of element
        if (y==4 && viruses[placeM]) {
            if (VirusCollision()) MarioKill()     // if virus moves from last position check if it hits Mario
            else {
                if (!demo) {
                    ScoreAdd(1);        // add the virus hitting the floor to the score
                    PlaySound("virus_hit_", vlm);	// sound for viruses hitting the floor
                };
            };
        };
        viruses[placeM] = viruses[placeM-1];    // virus falls to next position
    };
    if (((randyM || VirusesMinnedOut()) && !VirusesMaxedOut()) || (VirusesMinnedOut() && score<200)) viruses[placeM-1] = 1 // determin new virus falling
    else viruses[placeM-1] = 0; // else no new virus falling
    if (VirusesRowPresent()) PlaySound("virus_fall_", vlm);	// sound for viruses falling    
};

// check how many viruses are falling
function VirusesPresent () {
    var presentV = 0;
	for (kol=1 ; kol<4 ; kol++) {
            for (row=1 ; row<5 ; row++) {
                place = kol*10 + row;
                if (viruses[place]) presentV++;
            };
	};
    return presentV;     // return the counted number of falling viruses
};
    
// check how many viruses are falling on the sequence row
function VirusesRowPresent () {
    var presentVR = 0;
    var placeVR;
    for (var z=1 ; z<5 ; z++) {
        placeVR = sequence*10 + z;      // calculate position of element
        if (viruses[placeVR]) presentVR++;
    };
    return presentVR;     // return the counted number of falling viruses on that row
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions



//------------------------------------------------------------------------------------------------------------------------------------------------------
// move mario automatically for the demo without points
function MarioAutoPlay () {
    autoPlay = ! autoPlay;
};

// move mario automatically for the demo without points
function MarioAutoMove () {
    switch (mario) {
        case 1:     //if Mario is @ left side
            if (viruses[14] || !viruses[24] || toiletPapers[24]) LetMarioRight();
            break;
        case 2:     //if Mario is @ center
            if ((viruses[24] && !viruses[34]) || toiletPapers[34]) LetMarioRight();
            if ((viruses[24] && viruses[34]) || toiletPapers[14]) LetMarioLeft();
            break;
        case 3:     //if Mario is @ right side
            if ((viruses[34] && sequence==1) || !viruses[24] || toiletPapers[24]) LetMarioLeft();
            break;
        default:        
    };
};
//------------------------------------------------------------------------------------------------------------------------------------------------------
