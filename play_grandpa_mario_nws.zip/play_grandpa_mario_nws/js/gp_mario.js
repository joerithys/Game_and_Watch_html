//Product:	        Grandfather Mario HTML - Wide Screen (Nintendo) Simulator
//Version:	        1.1
//Started:	        09.01.2021
//Last update:	        11.03.2021
//Author/creator:       LCDGamer
//Programmer	        Flyzy (Joeri Thys)
//3D GFM                WhoIsQwert
//Original G&W:	        Nintendo Co. Ltd

//	To do : 
//      -       possible speedup @ lower row occupation ?
//      -       possible after 1000 possible 2 Goombas after another without space in between ?
//      -       possible reset goombasAtOnceGame to 2 or 3 every 100 points ?

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var blinkSpeed = 500;  // blinking speed for bonus indication
var blinkID;    // ID for timeout blinking score

var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling & keeping cycling
var hitting = 0;	// hitting status demo 0:not_hitting - 1:hitting - 2:back

var fallPos = 2;    // position of last fallen Goomba to be hidden
var fallResetID;        // ID for hiding fallen Goombas delay
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 8-alarm-off
var gameID;	// ID for timeout game sequence
var gameResetID;        // ID for return hitting pipe after 0,3 sec stationary
var gameSpeedMinimum = 350;	// minimum speed for game sequence timer
var gameSpeedMaximum = 200;	// maximum speed for game sequence timer
var gameSpeed = 500;	// speed for game sequence timer
var hitID;      // for small hitting delay, enough to first show arm up when hitting after move
var hitPos;   // to indicate last hitting attempt
var life = 3;   // number of lives left
var liftPos;   // position of last hitting hand to be lifted again
var missedID;   //      ID for missed Goomba delay & proceed with game
var missed = false;     // indicating missed Goomba, game paused, no hitting popssible
var missedBlink = 0;     // number of blinks left, indicating missed Goomba, game paused, no hitting popssible
var missedPos;  // position missed Goomba to jump up to victory
var goombaPresent = new Array();  // array of all Goombas
var goombaHit = false;    // indicates if a surfaced Goomba is hit
var goombaHitID;  //	ID to reset the row when Goomba is hit
var goombaHittablePos;    // Goomba to be hit @ pipe position
var goombasAtOnce;        // calculated sequence of max number of Goombas allowed to surface @ once
var goombasAtOnceGame;        // actual game sequence of max number of Goombas allowed to surface @ once
var goombaOutRow;       // position where Goomba got out
var goombasRowMove;     // row of cxurrently moving Goombas
var goombasPresent;   // indicates how many Goombas currently moving
var goombasPresentLine;   // indicates how many Goombas currently moving @ that line
var goombasPresentRow;   // indicates how many Goombas currently moving @ that row
var goombaSurfaced;       // indicates if a Goomba has surfaced and which row
var highScore = 0;
var pause = false;	
var pauseID;	// ID to pause the game temporarily (pause stopper)
var pos;        // position hand of grandfather Mario
var runTime = 5;	// times to run GoombaBlink() function
var rythm = 0;  //&Auto() : rythm of the blinking visual auto indicator
var sequence = 1;	// sequence to let Goombas move seperately per row
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var keyLeft = false;
var keyRight = false;
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var hitKeyPressed = false;	// indicates if a previuos hit key was already pressed to avoid double entries
var RKeyPressed = false;	// indicates if a previuos hit "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;	// indicates if a previuos hit "TIME" key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var pointsBonus = false;
var score = 0;	// score (all beneath 100) at init
var scoreBonus = 0;	// score bonus not added
var scoreBonusID;    // ID for timeout bonus indication blinking score
var scorePrev;	// previous set score for gaps between sets of upcoming Goombas

var alarm = false;	// alarm not running
var alarmID;    // ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = true;     // for indicationif alarm is set on or off
var alarmSetting = false;       // if alarm is at set mode to make changes
var alarmSet = "h";     // setting alarm hoors (h) or minutes (m)

var prefAlarmMin = 0;	// last saved alarm setting minutes
var prefAlarmHour = 0;	// last saved alarm setting hours

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "q": case "Q": case "ArrowLeft":	// left keys
            // show left button pressed
            document.images['Move Left'].src = 'img/case/buttons/left_flat.png';     
            LeftPressed();      // function to move left
            break;
        case "s": case "S": case "ArrowRight":	// right keys
            // show right button pressed
            document.images['Move Right'].src = 'img/case/buttons/right_flat.png';     
            RightPressed();     // function to move right
            break;
        case "Space": case " ":	// space key
            // show hit button pressed
            document.images['Hit gb'].src = 'img/case/buttons/hit_flat.png';     
            HitAtPressed();     // function to hit @ current position
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game button pressed
            document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';     
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) {
                keyPressed = true;
                MainGameA(); // show high score @ play Game A after button release
            };
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) {
                TKeyPressed = true;
                MainTime(); // show time & demo
            };
            TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
            document.images['Acl'].src = 'img/case/buttons/acl_push.png';
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) {
                RKeyPressed = true;
                TotalReset(); // show full sprites
            };
            break;
        case"w": case"W":     // if "w" or "W" pressed
            // show alarm button pressed
            document.images['Alarm'].src = 'img/case/buttons/grey_2_flat.png';
            MainAlarm(); // set alarm
            break;
        //test case buttons 
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;   // current voluem becomes previus set @ next change of volume
            };
            if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;   // current voluem becomes previus set @ next change of volume
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;     // show/hide indicator
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'										pause = "+pause+" --- hitKeyPressed = "+hitKeyPressed);
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "q": case "Q": case "ArrowLeft":	// left key released
            // show left button default
            document.images['Move Left'].src = 'img/case/buttons/left.png';     
            keyPressed = false;
            break;
        case "s": case "S": case "ArrowRight":	// right key released
            // show right button default
            document.images['Move Right'].src = 'img/case/buttons/right.png';     
            keyPressed = false;
            break;
        case "Space": case " ":	// space key released
            // show hit button default
            document.images['Hit gb'].src = 'img/case/buttons/hit.png';     
            //hitKeyPressed = false;   
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/buttons/grey_1.png';  
            MainGameAGo(); // start running Game A
            keyPressed = false;
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/grey_3.png';
            TKeyPressed = false;
            TimeShowOnScreen(min, hour);
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['Acl'].src = 'img/case/buttons/acl.png';
            RKeyPressed = false;
            break;
        case"w": case"W":     // if "w" or "W" pressed
            document.images['Alarm'].src = 'img/case/buttons/grey_2.png';
            break;
        default: 
    };
    //console.log("@keyup : demoID = "+demoID);
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
    $(function () {
        CheckSizeZoom();
        $('#divWrap').css('visibility', 'visible');
    });
    $(window).resize(CheckSizeZoom);
    $("#game").focus(); // get focus on the game
    PicPreload();	// this function preloads all images to make them ready for use
    AllPicturesShow();	// show default figures
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually go to the left
function GoLeft () {
    if (pos>1) {	// if not totally left
        pos--;	// go position to the left with hand
        HandsShow(pos);
        hitKeyPressed = false;	// case go left before lifting hand after hitattempt
    };
};

// actually go to the right
function GoRight () {
    if (pos<4) {	// if not totally right
        pos++;	// go position to the right with hand
        HandsShow(pos);
        hitKeyPressed = false;	// case go right before lifting hand after hitattempt
    };
};

// hit button or -key pressed
function HitAtPressed () {
    if (alarmSet=="m") alarmSet = "h"
    else if (alarmSet=="h") alarmSet = "m";
    if (!hitKeyPressed&&!demoID&&life>0&&!pause) {        // to avoid continious hit @ running game
        HitAt(pos);    // hit if hand returned from previous hit
        hitKeyPressed = true;
    };
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
    if (goombaHit) Lift(pos);   // if hit previously, lift hitting hand before moving to the left
    if (game==1) {	// if game playing
        GoLeft();	// go position to the left with hand
    } else {
        if (game==5 || game==8) {	// change the alarm time
            if (alarmSet=="m") {	// change minutes of alarm time
                prefAlarmMin--;	// subtract a minute from alarm time
                if (prefAlarmMin==-1) prefAlarmMin = 59;
                AlarmShowNum();	// show alarm time
            } else if (alarmSet=="h") {	// add an hour to alarm time
                prefAlarmHour--;	// subtract an from hour alarm setting
                if (prefAlarmHour==-1) prefAlarmHour = 23;
                AlarmShowNum();	// show alarm time
            };
        };
    };
};

// left button or -key pressed
function LeftPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) { // if game still running or alarm being set
        Left();    // go left @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;	// if picture given assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
    if (goombaHit) Lift(pos);   // if hit previously, lift hitting hand before moving to the left
    if (game==1) {	// if game playing
        GoRight ();	// go position to the right with hand
    } else {
        if (game==5 || game==8) {	// change the alarm time
            if (alarmSet=="m") {	// change minutes of alarm time
                prefAlarmMin++;	// add a minute to alarm time
                if (prefAlarmMin==60) prefAlarmMin=0;
                AlarmShowNum();	// show alarm time
            } else if (alarmSet=="h") {	// change minutes of alarm time
                prefAlarmHour++;	// add an hour to alarm setting
                if (prefAlarmHour==24) prefAlarmHour = 0;
                AlarmShowNum();	// show alarm time
            };
        };
    };
};

// right button or -key pressed
function RightPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&(life>0||game!=1)) {  // if game still running or alarm being set
        Right();    // go right @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    alarmStateIndPre = new Image();
    alarmStateIndPre.src = "img/screen/alarmStateInd.png";	// to show if alarm is set on or off
    bellDownPre = new Image();
    bellDownPre.src = "img/screen/bellDown.png";	// to show ringing bell in down-state @ alarm
    bellRingerPre = new Image();
    bellRingerPre.src = "img/screen/bellRinger.png";	// to show bell ringer @ alarm
    bellUpPre = new Image();
    bellUpPre.src = "img/screen/bellUp.png";	// to show ringing bell in up-state @ alarm
    gfmPre = new Image();
    gfmPre.src = "img/screen/GFM.png";	// to show 3D GFM above Hit key to indicate auto run
    goombaPre = new Array();
    hitIndPre = new Array();
    goombaHillPre = new Array();
    for (i=1 ; i<5 ; i++) { 	// to show the 5 surfaced goombas
        goombaPre[i] = new Image();
        goombaPre[i].src = "img/screen/goomba"+eval(i)+".png";  // emerged Goombas
        hitIndPre[i] = new Image();
        hitIndPre[i].src = "img/screen/hitInd"+eval(i)+".png";  // hit indications @ emerged & hit Goombas
        for (j=1 ; j<4 ; j++) { 	// to show their according goomba hills
            goombaHillPre[(i*10+j)] = new Image();
            goombaHillPre[(i*10+j)].src = "img/screen/goomba"+eval(i)+"Hill"+eval(j)+".png";    // tube indicators of rising Goombas
        };
    };
    goombaFallPre = new Array();
    for (i=1 ; i<5 ; i++) goombaFallPre[i] = new Image();
    for (i=1 ; i<5 ; i++) goombaFallPre[i].src = "img/screen/goombaFall"+eval(i)+".png";	// to show fallen Goomba @ position "i"
    goombaJumpPre = new Array();
    for (i=1 ; i<5 ; i++) goombaJumpPre[i] = new Image();
    for (i=1 ; i<5 ; i++) goombaJumpPre[i].src = "img/screen/goombaJump"+eval(i)+".png";	// to show escaped up jumping Goomba @ position "i"
    handDownPre = new Array();  // hitting hands
    for (i=1 ; i<5 ; i++) handDownPre[i] = new Image();
    for (i=1 ; i<5 ; i++) handDownPre[i].src = "img/screen/handDown"+eval(i)+".png";	// to show the hand down @ position "i"
    handUpPre = new Array();    // upper hands
    for (i=1 ; i<5 ; i++) handUpPre[i] = new Image();
    for (i=1 ; i<5 ; i++) handUpPre[i].src = "img/screen/handUp"+eval(i)+".png";	// to show the hand up @ position "i"
    handEmptyPre = new Array(); // opposit hands
    for (i=1 ; i<3 ; i++) handEmptyPre[i] = new Image();
    for (i=1 ; i<3 ; i++) handEmptyPre[i].src = "img/screen/handEmpty"+eval(i)+".png";	// to show the free hand opposit to the one @ position "i"
    missPre = new Image();
    missPre.src = "img/screen/miss.png";	// to show missed goombas
    missTxtPre = new Image();
    missTxtPre.src = "img/screen/misstxt.png";	// to show missed text
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
    soundOnPre = new Image();
    soundOnPre.src = "img/case/buttons/butOn.png";	// to show sound button in on-state
    soundOffPre = new Image();
    soundOffPre.src = "img/case/buttons/butOff.png";	// to show sound button in off-state
};

// hide all goombas falling
function AllGoombasFallHide () {
    for (i=1 ; i<5 ; i++) PicShow("GoombaFall"+eval(i)+"", nullPre.src);
};

// hide all Goombas jumping out after miss
function AllGoombasJumpHide () {
    for (i=1 ; i<5 ; i++) PicShow("GoombaJump"+eval(i)+"", nullPre.src);
};

// hide all tube indicators of rising Goombas
function AllGoombaHillsHide () {
    for (i=1 ; i<5 ; i++) { 	        // the rows
        for (j=1 ; j<4 ; j++) { 	// the lines
            PicShow("Goomba"+eval(i)+"Hill"+eval(j)+"", nullPre.src);
        };
    };
};

// show all tube indicators of rising Goombas
function AllGoombaHillsShow () {
    for (i=1 ; i<5 ; i++) {		// the rows
        for (j=1 ; j<4 ; j++) { 	// the lines
            PicShow("Goomba"+eval(i)+"Hill"+eval(j)+"", goombaHillPre[(i*10+j)].src);
        };
    };
};

// hide all hands
function AllHandsUpHide () {
    for (i=1 ; i<5 ; i++) PicShow("HandUp"+eval(i)+"", nullPre.src);
};


// hide all hit indications @ emerged Goombas
function AllHitIndsHide () {
    for (i=1 ; i<5 ; i++) PicShow("HitInd"+eval(i)+"", nullPre.src);
};

// hide all figures
function AllPicturesClear () {
    AllGoombaHillsHide();
    HandsHide();
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
    PicShow("Misstxt", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Goomba"+eval(i)+"", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("HitInd"+eval(i)+"", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("GoombaFall"+eval(i)+"", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("GoombaJump"+eval(i)+"", nullPre.src);
    PicShow("BellUp", nullPre.src);
    PicShow("BellDown", nullPre.src);
    PicShow("BellRinger", nullPre.src);
    PicShow("AlarmStateInd", nullPre.src);
    PicShow("NumColon", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// show all figures
function AllPicturesShow () {
    AllGoombaHillsShow();
    for (i=1 ; i<5 ; i++) PicShow("HandDown"+eval(i)+"", handDownPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("HandUp"+eval(i)+"", handUpPre[i].src);
    for (i=1 ; i<3 ; i++) PicShow("HandEmpty"+eval(i)+"", handEmptyPre[i].src);
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    PicShow("Misstxt", missTxtPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Goomba"+eval(i)+"", goombaPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("HitInd"+eval(i)+"", hitIndPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("GoombaFall"+eval(i)+"", goombaFallPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("GoombaJump"+eval(i)+"", goombaJumpPre[i].src);
    PicShow("NumColon", numColonPre.src);	// ":"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
    PicShow("BellUp", bellUpPre.src);
    PicShow("BellDown", bellDownPre.src);
    PicShow("BellRinger", bellRingerPre.src);
    PicShow("AlarmStateInd", alarmStateIndPre.src);
};

// hide falling Goomba
function GoombaFallEnd (fallPos) {
    PicShow("GoombaFall"+eval(fallPos)+"", nullPre.src);
};

// hide all men & arms
function HandsHide () {
    for (i=1 ; i<5 ; i++) PicShow("HandUp"+eval(i)+"", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("HandDown"+eval(i)+"", nullPre.src);
    for (i=1 ; i<3 ; i++) PicShow("HandEmpty"+eval(i)+"", nullPre.src);
};

// show man @ current position
function HandsShow (pos) {
    var emptyPos = pos<3?2:1;   // determin free hand oposit to pipe holding hand @ current position
    HandsHide();
    PicShow("HandUp"+eval(pos)+"", handUpPre[pos].src);	// show hand up @ current position
    PicShow("HandEmpty"+eval(emptyPos)+"", handEmptyPre[emptyPos].src);	// show free hand @ opposit position
};

// hide missed goomba in the box
function MissHide () {
    for (var i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
};

// show all missed Goomba in the box & miss text
function MissedShow () {
    for (i=1 ; i<(4-life) ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    if (3-life) PicShow("Misstxt", missTxtPre.src);
    missed = false;	// reset missed indication to resume or end game
};

// hide "MISS" text
function MissTextHide () {
    PicShow("Misstxt", nullPre.src);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//make beep-sound
function Beep () {
    PlaySound("beep_", vlm);
};

// swich sound on/off; dont preload here
function PrefSound () {
    prefSound = !prefSound;
    PrefSoundEval();    // Show sound volume settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
    if (!prefSound) { // if sound is set to "off" 
        preVlm = vlm;   // remember last sound volume
        vlm = 0;        // set volume to 0
    } else {
        if (preVlm==0) preVlm = 0.01; // if no previous sound volume, set to minimum
        vlm = preVlm;   // set sound volume to previous setting
    };
    PrefSoundSettings();	// show sound on/off indication
    PrefSoundShow();	// show volume indicator on screen for testing purposes
    PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
    var vlmTxt = "";    // empty sound volume indicator picture
    $("#SoundStateInd").html("");	// empty/hide volume indicator on screen
    if (prefSoundShow) {      // if volume indicator is set to show
        if (vlm>0.00999) {
            // count number of sound indicator bars & translate to html
            for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
            $("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
        } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    } else {
        $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
    if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
    else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// show/hide icons for sound & alarm as set
function ShowSndIcns () {
    if (!alarmOn && game!=9) {
        PicShow("AlarmStateInd", nullPre.src);
    } else {
        PicShow("AlarmStateInd", alarmStateIndPre.src);
    };
};

// swich sound on/off; dont preload here
function SetSound (setting) {
    prefSound = setting;
    PrefSoundSettings();	// show sound on/off indication
    PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
	StopSound("alarm_", vlm);
	StopSound("end_", vlm);
	StopSound("goombaMove_", vlm);
	StopSound("goombaOut_", vlm);
	StopSound("hit_", vlm);
	StopSound("noHit_", vlm);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all alarm settings
function AlarmReset () {
    window.clearTimeout(alarmID);	// stop running alarm sound from repeating
    alarmID = null;
    window.clearTimeout(alarmOffID);	// stop running timer to turn off alarm @ running
    alarmOffID = null;
    alarm = false;	// alarm not running
    alarmOn = false;     // for indicationif alarm is set on or off			
    alarmRinging = false;	// to prevent alarm going off again after turning off
    alarmSetting = false;       // if alarm is at set mode to make changes
    alarmSet = "h";     // setting alarm hoors (h) or minutes (m)
    prefAlarmMin = 0;	// last saved alarm setting minutes
    prefAlarmHour = 0;	// last saved alarm setting hours
};

// stop game if playing and reset all ID's
function AllStop () {
    GameReset();    // clear gameID, gameResetID & pauseID
    window.clearTimeout(demoID);	// stop demo from starting (again)
    demoID = null;
    window.clearTimeout(scoreBonusID);	//  stop beeping @ bonus indication
    scoreBonusID = null;
    pointsBonus = false;
    TimerReset(); // stop the counter to show the current time
};

// clear gameID, gameResetID & pauseID
function GameReset () {
    if (!demo) {
        AllGoombasFallHide();
        if (fallResetID) {
            window.clearTimeout(fallResetID);	// stop timer to let Goomba fall after being hit
            fallResetID = null;
        };
        if (hitID) {
            window.clearTimeout(hitID);	// reset ID for hiting hand delay
            hitID = null;
        };
        if (missedID) {
            window.clearTimeout(missedID);	// stop any escaped goombas after miss
            missedID = null;
        };
        if (goombaHitID) {
            window.clearTimeout(goombaHitID);	//  stop showing changes or goomba hit check after last goomba hitting
            goombaHitID = null;
        };		
    };
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop return hit hand after 0,3 sec stationary
        gameResetID = null;
    };
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause stopper
        pauseID = null;
    };
};

// remove all goombas & tube indicators of rising Goombas
function GoombasReset () {
    for (t=1 ; t<5 ; t++) {
        GoombasRowReset(t);     // remove goomba & tube indicators of rising Goombas from row t
    };
    GoombasShow();      // show all Goombas and hills @ present state
};

// remove Goomba & tube indicators of rising Goombas from row
function GoombasRowReset (row) {
    for (u=0 ; u<5 ; u++) {	// from all positions in row
        goombaPresent[(row*10+u)] = 0;	// remove goomba/tube-indicators from position
    };
    goombaHit = false;
};

// remove goomba & tube indicators of rising Goombas from row
function GoombaOutReset () {
    goombaPresent[(fallPos*10+4)] = 0;	// remove outcomming goomba from position
    GoombasShow();      // show all Goombas and hills @ present state
};

// Let the misses blink & reset them
function MissReset () {
    if (missedID) {
        window.clearTimeout(missedID);	// stop any escaped goombas after miss
        missedID = null;
    };
    if (game==1) {
        MissBlink();
        missClearID = window.setTimeout("MissClear()", 2000);    // remove "MISS" text & reset lives & misses after 2 seconds
    } else MissClear(); // remove "MISS" text & reset lives & misses
};

// clear all pictures & variables
function ResetAll () {
    AllStop();  // stop game if playing and reset all ID's
    MissClear(); // remove "MISS" text & reset lives & misses
    AllPicturesClear ();        // hide all figures
    alarmSet = "h";     // to start alarm set with the hours
    alarmSetting = false;       // stop running alarm
    GoombasReset();	// remove Goomba & tube indicators of rising Goombas from row
    hitting = 0;        // reset demo hitting indicator
    goombaSurfaced = false;       // reset possible surfaced Goomba
    game = 0;   // no-game-all-pictures
    pause = false;
};

// reset speed according to the current score
function SpeedReset () {
    gameSpeed = gameSpeedMinimum - Math.round(score%1000/25) - Math.floor(score/50) - Math.floor(score/1000);
    gameSpeed = gameSpeed>gameSpeedMaximum?gameSpeed:gameSpeedMaximum;
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    PlaySound("click_", vlm);	// click sound for push button
    if (alarm) TimeAlarmOff();	// stop alarm if running
    AlarmReset();
    ResetAll(); // clear all pictures & variables
    AllPicturesShow(); // show all figures & "88:88" @ timer
    window.clearTimeout(alarmID);	// stop running alarm sound from repeating
    alarmID = null;
    window.clearTimeout(alarmOffID);	// stop running timer to turn off alarm @ running
    alarmOffID = null;
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show alarm time & on/off indication
function AlarmShow (ind) {
    AlarmShowNum();	// show alarm time
    if (ind=="on") {
        alarmOn = true;
        PicShow("AlarmStateInd", alarmStateIndPre.src); // show alarm indicator on screen
    } else {
        alarmOn = false;
        PicShow("AlarmStateInd", nullPre.src); // hide alarm indicator on screen
    };
};

// show alarm time setting
function AlarmShowNum () {
    TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
};

// 0-no game-all pictures; 1-gameA; 2-gameB; 3-game over; 4-clock; 5-set alarm (on); 6-high score; 7-keys; 8-set alarm (off);
// set the alarm
function MainAlarm () {
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (demoID) {
        clearTimeout(demoID);     // if demo was planned or running, stop sequence
        demoID = null;
    };
    if (!alarmSetting) {
        ResetAll();	// clear all pictures & variables
        alarm = false;  // alarm is not currently running
        keys = 7;	// no remapping keys
        demo = false;		// once the alarm key is hit, the demo is turned off
        PlaySound("click_", vlm);	// click sound for push button
        alarmSetting = true;
    };
    if (game!=5) {
        game = 5; // set alarm (on)
        AlarmShow("on");	// show alarm time & on indication
        TimeAlarmBackground();
    } else {
        game = 8; // set alarm (off)
        AlarmShow("off");	// show alarm time & off indication
    };	
    demoID = setTimeout("MainTimeStart()", 300000);	// start demo after 5 minutes
};

// "time" is pressed, stop all and show time
function MainTime () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game's possible missed() call
        gameID = null;
    };
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (game!=4||!demo) {      // if MainTime not yet running 
        StopAllSound();
        PlaySound("click_", vlm);	// click sound for push button
        MainTimeStart(); // show current time & demo
    };
};
	
// show current time & demo
function MainTimeStart () {
    ResetAll();	// clear all pictures & variables
    MainPicturesReDefault();	// show default start pictures of GP_Mario
    ShowSndIcns();      // show if alarm is set on or not
    TimeShow();	// show current time
    demo = true;     // to show demo
    game = 4;	// clock running
    Demo();     // run demo
};

// get current time
function Time () {
    today = new Date();
    hour = today.getHours();
    min = today.getMinutes();
    sec = today.getSeconds();
};

// check if its time for alarm
function TimeAlarm () {
    Time();	// get current time
    var alarmTime;
    if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) { 
        alarm = true;
        // set start alarm at start next minute
        alarmTime = 60000-(sec*1000);
        // alarm rings at start next minute
        alarmID = setTimeout("TimeAlarmGo()", alarmTime);
        // stop alarm 30 seconds after start
        alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000)); // turn alarm off after half a minute
    };
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
    if (alarmOn) {		
        TimeAlarm();	// check if its time for alarm if alarmOn
        setTimeout("TimeAlarmBackground()", 30000)	;       // check every half minute
    }; 
};

// alarm rings
function TimeAlarmGo () {
    Time();	// get current time
    PicShow("BellRinger", bellRingerPre.src);   // show bell ringer
    if ((sec%2)==1) {	// let Jr. jump up and down @ alarm
        PicShow("BellUp", nullPre.src);
        PicShow("BellDown", bellDownPre.src);
        if (game!=1) PlaySoundEvenIfDemo("alarm_", vlm);	// sound for alarm if no key pressed
    } else {
        PicShow("BellUp", bellUpPre.src);
        PicShow("BellDown", nullPre.src);
    }
    alarmID = setTimeout("TimeAlarmGo()", 1000);        // repeat after a second
};

// turn running alarm off
function TimeAlarmOff () {
    if (alarmID) {
        clearTimeout(alarmID);     // if alarm was planned or running, stop sequence
        alarmID = null;
    };
    alarm = false;
    if (game==0) {	// if acl show all bells
        PicShow("BellUp", bellUpPre.src);
        PicShow("BellDown", bellDownPre.src);
    } else {
        PicShow("BellUp", nullPre.src);
        PicShow("BellDown", nullPre.src);
        PicShow("BellRinger", nullPre.src);
    };
};

// show current time
function TimeShow () {
    TimerReset();
    Time();	// get current time
    if (!$('#ButTime:active').length&&!TKeyPressed) {    // if time button no longer pressed (else show alarm time)
        TimeShowOnScreen(min, hour);    // show the current time
    }; 
    timeID = window.setTimeout("TimeShow()", 1000);     // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen(min, hour) {
    // set integer to time digits
    if (hour<10) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
    PicShow("Num2", numPre[(hour%10)+1].src);
    PicShow("Num3", numPre[Math.floor(min/10)+1].src);
    PicShow("Num4", numPre[(min%10)+1].src);
    PicShow("NumColon", numColonPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// next sequence from 1 to 4 and back
function CalculateNextSeq (calculatePos) {
    if (calculatePos<4) calculatePos++
    else calculatePos = 1;
    return calculatePos;
};

// calculate next positioned Goombas to calculatePos (mostly sequence)
function CalculatePos (calculatePos) {
    switch (calculatePos) {
        case 1 :
            calculatePos =  1;
            break;
        case 2 :
            calculatePos =  3;
            break;
        case 3 :
            calculatePos =  4;
            break;
        case 4 :
            calculatePos =  2;
            break;
        default:
    };
    return calculatePos;
};

// show demo
function Demo () {
    if (demoID) {	// if demo still planned to start stop that plan to avoid double run
        clearTimeout(demoID);
        demoID = null;
    };
    if (GoombasPresent()) {
        if (hitting==1) {	// arm needs to lift after hit
            // if surfaced goomba is hit, start new one @ the other side
            if (goombaPresent[14]) goombaPresent[41] = 1;	
            else if (goombaPresent[44]) goombaPresent[11] = 1;
            GoombaHit();	// goomba has been hit, define row hit goomba & reset that row
            Lift(pos);          // lift hitting arm
            hitting = 0;	// no hitting
        } else {
            if (GoombaHittable(pos)) {	// if Goomba @ pipe position is hittable
                Hit(pos);	// hit with hammer
                hitting++;	// next step is lift hammer again
            } else GoombasMove();       // move all present Goombas
        };
    } else goombaPresent[11] = 1;	// start first goomba left in the beginning
    GoombasShow();
    // automated moves according to position man & surfacing goomba
    if ((goombaPresent[12]||goombaPresent[13]||goombaPresent[14]) && pos!=1) GoLeft();
    if ((goombaPresent[42]||goombaPresent[43]||goombaPresent[44]) && pos!=4) GoRight();
    demoID = window.setTimeout("Demo()", 1000);	// next step after a second  
};

// if goomba surfaced without getting hit
function Failed (goombaOutRow) {
    if (goombaOutRow!=goombaHit&&goombaOutRow) {	// if row not previous hit podition to avoid double fail
        AllStop();      // stop game if playing and reset all ID's
        pause = true;	// pause the game untill Failed() sequence has finished
        Lift(fallPos);  // if hit still going on, lift hand again
        missedPos = goombaOutRow;       // missed position is where Goomba came out (before next comes out)
        missed = true;
        life--;         // one life less
        goombaSurfaced = false;
        PlaySound("goombaOut_", vlm);   // play sound of Goomba comming out
        PicShow("GoombaJump"+eval(goombaOutRow)+"", goombaJumpPre[goombaOutRow].src);   // show Goomba comming out & jump up
        missedID = window.setTimeout("GoombaBlink(runTime--)", 200);    // blink jumping up Goomba a couple of times
        gameID = window.setTimeout("Missed(missedPos)", 1200);	// hide jumping  Goomba after some time @ add to missed box
    };
};

// next move of game
function GameGo () {
    var goombaPos;        // possible position of next upcomming goomba
    var newGoomba = false;        // defined if a new GoombaPos is added to the scene 
    var goombasPresentLine3 = GoombasPresentLine(3);    // count the number of goombas present @ line 3
    var goombasPresentLine1 = GoombasPresentLine(1);    // count the number of goombas present @ line 1
    var goombasPresentRow = GoombasPresentRow(goombasRowMove);     // count the number of Goombas present @ cuurently moving row
    var counter = 0;    // loop counter to avoid loop from getting stuck by running for ever if last add was delayed
    if (gameID) {
        clearTimeout(gameID);	// stop the game's possible double call
        gameID = null;
    };
    if (!pause) {
        goombasPresent = GoombasPresent();  // count current present Goombas
        if (goombasPresentRow) GoombasMove();   // if current addressed row has any Goombas in it, move them one position up
        if ((goombasAtOnceGame>=goombasPresent) || !goombasPresent || (goombasPresentLine3&&goombasPresent<2)) {      // if goomba must be added
             if (!missed && !NewGoombasDelay() && (goombasPresentLine1<4)) {     // if its possible to add a new Goomba to this row
                do {        // find empty place to set goomba
                    goombaPos = Math.floor(4*Math.random())+1;
                    counter++;  // count this loop
                    if (counter>8) {    // after ! runs, reset counter & check again if line 1 isn't full
                        counter = 0;
                        goombasPresentLine1 = GoombasPresentLine(1);
                    };
                } while(goombaPresent[(goombaPos*10+1)] && (goombasPresentLine1<4));    // as long as there's a Goomba in front and line is not full
                if (goombasPresentLine1<4) {
                    newGoomba = true;	// @ test log : decided to place new Goomba			
                    goombaPresent[(goombaPos*10+0)] = 1;    // add new Goomba @ calculated row @ hidden line
                } else newGoomba = "truely";
            };
        };
        GoombasShow();  // show all Goombas present
        gameID = window.setTimeout("GameGo()", gameSpeed);    // next step in gameSpeed milliseconds
        GameGoNextPos ();	//	determine next row to move upward
    }; 
};

// resume game after pause for indicating missed Goomba or bonus
function GameGoNext () {
    if (hitID) {
        clearTimeout(hitID);	// reset ID for small hitting delay if exists
        hitID = null;
    };
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    GameReset(); // clear gameID, gameResetID & pauseID
    pause = false;      // undo pause
    // delayed hit if possible & Goomba comming out
    gameID = window.setTimeout("GameGo()", gameSpeed);        // go on with game in gameSpeed milliseconds
};

// next positioned Goombas to move to avoid GF Mario has to move pipe 3 positions @ 1 GoombasMove()
function GameGoNextPos () {
    sequence = CalculateNextSeq(sequence);      // next sequence in & to 4 and back
    goombasRowMove = CalculatePos(sequence);    // calculate next positioned Goombas to calculatePos (mostly sequence) 
};

// common settings games
function GameSet () {
    ResetAll();	// reset all screen settings
    gameSpeed = gameSpeedMinimum;       // start @ lowest speed (in milliseconds)
    goombaHit = false;	// not goomba hit
    goombasAtOnce = 1;    // start with no more than 1 calculated Goomba @ once befor new Goomba is added
    goombasAtOnceGame = 1;    // start with no more than 1 Goomba @ once befor new Goomba is added
    life = 3;	// number of lives left
    missed = false;     // no goomba missed
    pos = 2;	// pipe starts @ 2nd position
    score = 0;  // reset score
    scorePrev = 6;  // previous set score trigger for new calculated number of Goombas present @ sequence
    MainPicturesGame();	// show default pictures @ start of the game & show score
    goombasAtOnceGame = GoombasPresentAtOnce();      // define how many Goombas at once allowed the nest step
};

// goomba has been hit, define row hit goomba & reset that row
function GoombaBlink (runTime) {
    if (missedID) {
        window.clearTimeout(missedID);	// stop any escaped goombas after miss
        missedID = null;
    };
    if (runTime%2 != 0) PicShow("GoombaJump"+eval(missedPos)+"", nullPre.src)   // @ even runtimes hide out jumping Goomba
    else PicShow("GoombaJump"+eval(missedPos)+"", goombaJumpPre[missedPos].src);   // @ odd runtimes show out jumping Goomba
    missedID = window.setTimeout("GoombaBlink(runTime--)", 200);        // next runtime
};

// goomba has been hit, define row hit goomba & reset that row
function GoombaHit () {
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop return hit hand after 0,3 sec stationary
        gameResetID = null;
    };
    // define position row to hit goomba
    goombaHittablePos = GoombaHittable(pos);
    fallPos = pos;      // store fall position so @ next GFM move the right Goomba falls
    if (!goombaHit && !missed && goombaHittablePos) {
        PicShow("HitInd"+eval(pos)+"", hitIndPre[pos].src);     // show hit indication @ Goombas head
        goombaHit = pos;	// to check if no double fail
        if (!demo)  {
            ScoreAdd(1);	// add score and lift arm after 300 ms
        };
        PlaySound("hit_", vlm);	// hitting a Goomba
        goombaSurfaced = false;
    } else {
        PlaySound("noHit_", vlm);	// hitting nothing
    };
    if (!demo)  {
        gameResetID = window.setTimeout("Lift(fallPos)", 300);
    };
    goombaHittablePos = false;	// reset indicator
};

// get position of surfacing goomba left or right of the man's position
function GoombaHittable (pos) {
    var goombaHittable = 0;
    if (goombaHitID) {
        window.clearTimeout(goombaHitID);	//  stop showing changes or goomba hit check after last goomba hitting
        goombaHitID = null;
    };
    if (!goombaHit) {
        if (goombaPresent[(pos*10+4)] && !goombaPresent[(i*10+5)]) goombaHittable = pos;
    } else goombaHitID = window.setTimeout("GoombaHittable(pos)", 10);
    return goombaHittable;
};

// goombas moving up one position
function GoombasMove () {
    var goombaOut = false;      // indicates if Goomba surfaced
    var soundOut = false;       // to play move sound only once if multiple Goombas move @ same row
    goombaHittablePos = GoombaHittable(pos);    // indicates if Goomba surfaced @ pod hand GFM
    if (!pause) {
        if (!demo) {
            for (j=5 ; j>0 ; j--) {
                if (goombaPresent[(goombasRowMove*10+j-1)]&&!soundOut) {        // if a Goomba present @ moving row and no sound yet played
                    PlaySound("goombaMove_", vlm);	// Goomba moving
                    soundOut = true     // sound for this row already played
                };
                goombaPresent[(goombasRowMove*10+j)] = goombaPresent[(goombasRowMove*10+j-1)];	// copy from lower goomba state
                goombaPresent[(goombasRowMove*10+j-1)] = 0;	// reset lower goomba state
            }
            goombaOut = GoombaOut();	// indicates if a goomba surfaced & @ which position
            if (goombaOut&&goombaOut!=goombaHit) {	// if surfaced goomba is not hit in time
                AllStop();      // stop game if playing and reset all ID's
                pause = true;
                Failed(goombaOut);	// let goomba jump up to victory
            };
        } else {        // only move all Goombas
            for (i=4 ; i>0 ; i--) { 
                for (j=5 ; j>1 ; j--) {
                    goombaPresent[(i*10+j)] = goombaPresent[(i*10+j-1)];	// copy from lower goomba state
                    goombaPresent[(i*10+j-1)] = 0;	// copy from lower goomba state
                }
            };
        };
    };
};

// gives place where goomba surfaced or escaped
function GoombaOut () {
    var goombaOut = false;              // row escaped Goomba
    goombaSurfaced = false;
    if (goombaPresent[(goombasRowMove*10+5)]) goombaOut = goombasRowMove;         // position of escaped goomba
    else if (goombaPresent[(goombasRowMove*10+4)]) goombaSurfaced = goombasRowMove;    // position of surfaced goomba
    return goombaOut;
};

// count the number of goombas present
function GoombasPresent () {
    var goombasPresent = 0;
    for (i=1 ; i<5 ; i++) {     // the lines
        for (j=0 ; j<6 ; j++) { // the rows
            if (goombaPresent[(i*10+j)]) goombasPresent++;
        };
    };
    if (goombaSurfaced) goombasPresent--;
    return goombasPresent;
};

// count the number of goombas present @ line goombasPresentLine
function GoombasPresentLine (goombasPresentLine) {
    var goombasPresent = 0;
    for (i=1 ; i<5 ; i++) {
        if (goombaPresent[(i*10+goombasPresentLine)]) goombasPresent++;
    };
    return goombasPresent;
};

// count the number of goombas present @ row goombasPresentRow
function GoombasPresentRow (goombasPresentRow) {
    var goombasPresent = 0;
    for (j=0 ; j<6 ; j++) {
        if (goombaPresent[(goombasPresentRow*10+j)]) goombasPresent++;
    };
    if (goombaSurfaced==goombasPresentRow) goombasPresent--;
    return goombasPresent;
};

// define how many goombas at once allowed according to goombas-present sequence
function GoombasPresentAtOnce () {
    var oldScorePrev = scorePrev
    if (score>=scorePrev) {     // if score reached previous set score trigger
        // shift the goombas-present sequence
        if (goombasAtOnce<10) goombasAtOnce++
        else    if (score<11) goombasAtOnce = 1
                else goombasAtOnce = 2;
        scorePrev+=16-goombasAtOnce; // calculate next previous set score trigger
    };
    if ((score%1000)<100) goombasAtOnceGame = goombasAtOnce>3?3:goombasAtOnce
        else if ((score%1000)<250) goombasAtOnceGame = goombasAtOnce>4?4:goombasAtOnce
            else if ((score%1000)<400) goombasAtOnceGame = goombasAtOnce>5?5:goombasAtOnce
                else if ((score%1000)<550) goombasAtOnceGame = goombasAtOnce>6?6:goombasAtOnce
                    else if ((score%1000)<700) goombasAtOnceGame = goombasAtOnce>7?7:goombasAtOnce
                        else if ((score%1000)<850) goombasAtOnceGame = goombasAtOnce>8?8:goombasAtOnce
                            else goombasAtOnceGame = goombasAtOnce>9?9:goombasAtOnce;
    return goombasAtOnceGame;
};

// show all goombas and hills present
function GoombasShow () {
    for (i=1 ; i<5 ; i++) { 
        for (j=1 ; j<5 ; j++) { 
            if (j==4)   // goombas
                if (goombaPresent[(i*10+j)]) PicShow("Goomba"+eval(i)+"", goombaPre[i].src);
                else PicShow("Goomba"+eval(i)+"", nullPre.src);
            else {	// goomba hills
                if (goombaPresent[(i*10+j)]) PicShow("Goomba"+eval(i)+"Hill"+eval(j)+"", goombaHillPre[(i*10+j)].src)
                else PicShow("Goomba"+eval(i)+"Hill"+eval(j)+"", nullPre.src);
            };
        };
    };	
};

// hit button or key pressed
function HitAt (pos) {
    if (game==1) {	// if game playing
        Hit(pos);	// swing pipe @ current position
    };
};

// try to hit surfaced Goomba
function Hit (hitPos) {
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop previous return hit hammer after 0,3 sec stationary
        gameResetID = null;
    };
    PicShow("HandUp"+eval(hitPos)+"", nullPre.src);	// hide hand up to show hitting hand
    PicShow("HandDown"+eval(hitPos)+"", handDownPre[hitPos].src);	// show hitting hand
    if (!demo) {
        GoombaHit();	// Goomba has been hit, define row hit Goomba & reset that row
    } else {
        PicShow("HitInd"+eval(hitPos)+"", hitIndPre[hitPos].src);       // show hit indication @ Goombas head
    };
};

// lift hitting hand
function Lift (liftPos) {
    if (game==1||demo) {
        var timeOut;
        if (fallResetID) {
            clearTimeout(fallResetID);	// stop previous return hit hammer after 0,3 sec stationary
            fallResetID = null;
        };
        timeOut = demo?1000:500;    // delay to hide fallen Goombas after tmeOut time demo/game
        if (goombaHit||demo) {     
            PicShow("GoombaFall"+eval(liftPos)+"", goombaFallPre[liftPos].src); // show falling Goomba
            AllHitIndsHide();   // hide all hit indicators
            GoombaOutReset()	// remove goomba out jumping Goombas
            goombaHit = false;
        };
        PicShow("HandDown"+eval(liftPos)+"", nullPre.src);	// hide hitting hand
        if (liftPos==pos) PicShow("HandUp"+eval(liftPos)+"", handUpPre[liftPos].src);	// show hand up after hit
        fallResetID = window.setTimeout('AllGoombasFallHide()', timeOut);   // hide fallen Goombas
        hitKeyPressed = false;
    };
};

// button pressed to play the game
function MainGameA () {
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (game!=1) {   // if not already game A or B playing
        GameSet(); // variables reset
        if (demo) {
            demo = false;		// once this key is hit, the demo is turned off
            if (demoID) {
                clearTimeout(demoID);   // prevent demo from restarting if planned
                demoID = null;
            };
        };
        ShowSndIcns();      // show alarm indicator if alarm is set to on
        HighScoreShow();        // show highest score since this browser tab was opened
    };
};

// button pressed to play game A
function MainGameAGo () {
    if (game!=1) {   // if not already game playing
        if (gameID) {
            clearTimeout(gameID);	// stop the game's possible double call
            gameID = null;
        };
        PlaySound("click_", vlm);	// click sound for push button
        sequence = Math.floor(4*Math.random())+1;      // randomly choose first sequence to start
        GameGoNextPos();        // next positioned Goombas to move to avoiding GF Mario has to move pipe 3 positions @ 1 GoombasMove()
        goombaPresent[goombasRowMove*10+0] = 1;   //      first rising Goomba @ calculated position
        game = 1; // gameA
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", gameSpeed);    // start running game in  half a second
    };
};

// stop game if running + clear all
function MainGameOver () {
    if (demoID) {
        clearTimeout(demoID);	// stop the game
        demoID = null;
    };
    AllStop();  // stop game if playing and reset all ID's
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

// set & show pipe @ 2nd position
function MainPicturesDefault () {
    pos = 2;    //pipe starts @ 2nd position
    HandsShow(pos);     // show pipe @ 2nd position
};

// show default pictures @ start of the game & show score
function MainPicturesGame () {
    MainPicturesReDefault();	// set & show pipe @ 2nd position after emptying screen
    ScoreShow(score);
};

// set & show pipe @ 2nd position after emptying screen
function MainPicturesReDefault () {
    AllPicturesClear();     // hide all figures on screen
    MainPicturesDefault();      // set & show pipe @ 2nd position
};

// let score blink while score over 300 or 500 and no misses
function MissBlink () {    
    if (missedID) {
        window.clearTimeout(missedID);	// stop any escaped goombas after miss
        missedID = null;
    };
    if (game==1) {	// game running
        if (missedBlink<4) {	// number of blinking the missed Marios
            MissHide(); // hide missed goomba in the box
            Beep();
            missedID = window.setTimeout("MissedShow()", blinkSpeed/2); // show delayed all missed Goomba in the box & miss text
            missedID = window.setTimeout("MissBlink()", blinkSpeed);    // repeat
        } else {
            MissHide(); // hide missed goomba in the box
            Beep();
        };
    missedBlink++;      // count blinking
    };
};

// remove "MISS" text & reset lives & misses
function MissClear () {
    MissTextHide ();    // remove "MISS" text
    life = 3;
    missed = false;
};

// show misses & surfaced out jumping goomba
function Missed (goombaOutRow) {
    if (game==1) {	// if game playing
        if (demoID) {
            clearTimeout(demoID);	// stop the game
            demoID = null;
        };
        if (missedID) {
            clearTimeout(missedID);	// stop any remaining out jumping goombas 
            missedID = null;
        };
        PicShow("GoombaJump"+eval(goombaOutRow)+"", nullPre.src);   // show missed surfaced out jumping goomba
        GoombasShow();  
        MissedShow();	// show missed goomba in the box
        if (life>0) {
            missedID = window.setTimeout("GameGoNext()", 1500)	// next step after a 2 seconds
        } else {
            demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute if no lives left
            HandsHide();
            for (i=1 ; i<3 ; i++) PicShow("HandEmpty"+eval(i)+"", handEmptyPre[i].src); // show all empty hands
            missedID = window.setTimeout('PlaySound("end_", vlm)',1000);	// game over sound
            game = 3;
        };
    };
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// check if 1 goomba present & max 2 goombas allowed, keep 1 position in between, delay if not
function NewGoombasDelay () {
    var goombaDelay = true;
    if (goombasAtOnceGame==1 && goombasPresent) {   // if two goombas allowed, and already one present
        if (goombaPresent[(goombasRowMove*10+3)] && !(goombaSurfaced==goombasRowMove))  goombaDelay = false;
    } else goombaDelay = false;
    return goombaDelay;    
};

// speeds up the game with given value
function SpeedUp (speed) {
    var prevSpeed = gameSpeed;  // for logging...
    if (gameSpeed>gameSpeedMaximum) gameSpeed -= speed; // if not @ max speed, speed up
};

// stop showing current time
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow () {
    ScoreShow(highScore);
};

// add certain points to score
function ScoreAdd (points) {
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause stopper
        pauseID = null;
    };
    for (var a=0 ; a<points ; a++) {
        score++;
        if ((score%100)==0) SpeedReset();       // reset speed every 100 points
        if ((score%1000)==300 || (score%1000)==500) {   // bonus @ 300/500 points
            ScoreShow(score);
            AllStop();      // stop game if playing and reset all ID's
            pause = true;
            missedBlink = 1;    // for blinking score @ bonus or misses to be reset
            if (life==3) {      // if no life lost 
                pointsBonus = true;     // bonus earned
                scoreBonus = 1;	// score bonus IS already added
            } else MissReset(); // else reset all misses
            ScoreBlink();
            pauseID = window.setTimeout("GameGoNext()", 1500);  // resume game after 2 seconds
        };
        if (score%10==0/* || (pointsBonus&&(score-1)%10==0)*/) {     // every 10 points let goombas go faster
            SpeedUp(5);
        };
    };
    if (score>highScore) highScore = score;       // if passed highscore @ normal game set new highscore
    if (pointsBonus&&!scoreBonus) {
        scoreBonus = 1;	// score bonus IS already added
        ScoreAdd(points);
    } else scoreBonus = 0;	// score bonus not added
    ScoreShow(score);
    goombasAtOnceGame = GoombasPresentAtOnce();      // define how many Goombas at once allowed the nest step
};

// let score blink while score over 300 and no miss lost
function ScoreBlink () {
    if (scoreBonusID) {
        clearTimeout(scoreBonusID);  // stop pause trigger
        scoreBonusID = null;
    };
    if (game==1) {	// game running
        if (pointsBonus) {      // bonus for reaching 300/500 without any misses
            ScoreHide();
            scoreBonusID = window.setTimeout("ScoreUnHide()", blinkSpeed);      // unhide score delayed
            scoreBonusID = window.setTimeout("ScoreBlink()", 2*blinkSpeed);     // repeat
        } else ScoreUnHide();
        if (missedBlink<3) {	// number of beeps to indicate bonus
            Beep();
            missedID = window.setTimeout("Beep()", 500);        // play second beep delayed half a second
            missedBlink++;      // count beep
        };
    };
};

// hide score from screen
function ScoreHide () {
    $("#Num1").addClass("hidden");
    $("#Num2").addClass("hidden");
    $("#Num3").addClass("hidden");
    $("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
    $("#Num1").removeClass("hidden");
    $("#Num2").removeClass("hidden");
    $("#Num3").removeClass("hidden");
    $("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
    if (scoreTS>999) 
        if (Math.floor((scoreTS/1000)%10)==0) PicShow("Num1", nullPre.src)
        else PicShow("Num1", numPre[Math.floor((scoreTS/1000)%10)+1].src);
    else PicShow("Num1", nullPre.src);
    if (scoreTS>99) 
        if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0) PicShow("Num2", nullPre.src)
        else PicShow("Num2", numPre[Math.floor(scoreTS%1000/100)+1].src);
    else PicShow("Num2", nullPre.src);
    if (scoreTS>9)  
        if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0  && Math.floor(scoreTS%100/10)==0) PicShow("Num3", nullPre.src)
        else PicShow("Num3", numPre[Math.floor(scoreTS%100/10)+1].src);
    else PicShow("Num3", nullPre.src);
    PicShow("Num4", numPre[(scoreTS%10)+1].src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
