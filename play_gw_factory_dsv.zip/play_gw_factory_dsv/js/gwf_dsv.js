//Product:	        	G&W title HTML - double screen vertical Screen (Nintendo) Simulator
//Version:	        	1.1
//Started:              19.04.2021
//Last update:	        15.12.2021
//Author/creator:       Nintendo, Florent Gorges, Isao Yamazaki & Flyzy (Joeri Thys)
//Programmer	        Flyzy (Joeri Thys)
//Original G&W:	        Nintendo Co. Ltd

//Credits:
//Design, layout and artwork by Lee Robson (hydef), Nintendo & Flyzy (Joeri Thys)
//Based on scans by Sean Riddle

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var placesChecked = false;      // not allowed occupied places to start new gwCase not ok

var blinkSpeed = 500;  // blinking speed for bonus indication
var failedBlinkSpeed = 200;  // blinking speed for angry boss animation
var blinkID;    // ID for timeout blinking score while bonus valid

var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling & keeping cycling
var sequence = 1;	// sequence to let figures move seperately per row

var testRun = 0;	// for test logging titles

var acl = false;	// for showing acl pictures, all if pressed twice fast
var aclID;	// ID to view all pictures @ fast double click
var actionID;      // for small action delay, enough to first reset action before next move
var actPos;   // to indicate last action position when arms are moving back to default position
var actionPos;   // to indicate last action position
var animateID;	// ID to animate angry boss
var armsMoveID;	// ID to animate arms moving back after throwing a gwCase on the truck, even @ miss

var diff = 0;	// to indicate difficulty factor on PlacesChecked() for testing purposes

var failedID;   // ID to let failed Mario or uncaughed game fall
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameID;	// ID for timeout game sequence
var gameLoaded = false;	// to indicate a gwCase has been loaded on the truck
var gameSpeedMax = 230;	// maximum speed for game sequence timer
var gameSpeedMin = 350;	// minimum speed for game sequence timer
var gameSpeed = 500;	// speed for game sequence timer
var gameTossed = true;	// to indicate a gwCase has been tossed towards the truck
var gwCase = new Array();	// g&w game cases
var gwCaseGap;	// gap or no gap between the gwCases on the conveyor belt
var gwCaseHold = 0;	// indicates Mario holding gwCase @ bottom and needs to load truck before going up or rest
var gwCaseHoldPause = 0;	// maximum time when Mario catches a gwCase @ the bottom before the next gwCase appeares on top
var gwCaseMoveDelay = new Array();	// for preventing moving caught gwCase to soon
var gwCaseID = new Array();	// to animate the loading of the truck
var highScore = new Array();
var life = 0;   // number of lives left
var loaded = false;	// to indicate the truck is fully loaded, ready to take off
var marioRest = 0;	// to animate Mario resting
var marioResting = 0	// to indicate Mario is resting
var marioResetID;	// to end Mario resting
var marioRestID;	// ID to animate Mario resting
var maxGwCaseAllowed = 1;	// to indicate the maximum allowed number of gwCases on the conveyor belt @ once
var missClearID	// ID for removing "MISS" text & reset lives & misses
var missedID;   //      ID for missed item animation delay & proceed with game
var missed = false;     // indicating missed item, game paused, no action popssible
var missedBlink = 0;     // number of blinks left, indicating missed item, game paused, no action popssible
var missedPos;  // position player @ missed
var missedWhileLoading = false;	// to indicate Mario fell during loading
var nextGwCaseAllowed;	// to indicate if a new gwCase may start
var newGwCase;       // get new gwCase randomly
var pause = 0;	
var pos = 0;        // start/current position player
var prevPos = 0;        // previuos position player
var runTime = 0;	// Mario has not yet entered the building...  1 = entered!
var truckSmokeID = new Array();	// ID for all truck animation
var truckSmokeSeq;	// sequence of truck smoke @ stationary
var truckSmokeSpeed;	// truck smoke animation speed
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var actionKeyPressed = false;	// to enter the building, to catch or toss a gwCase onto the truck.
var keyDown = false;
var keyLeft = false;
var keyRight = false;
var keyUp = false;
var keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
var RKeyPressed = false;	// indicates if a previuos hit "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;	// indicates if a previuos hit "TIME" key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var driveBonus = 0;	// score bonus not added
var driveBonusID;    // ID for timeout full truck bonus score
var pauseID;	// to pause for indicating the score changes
var pointsBonus = false;        // no bonus earned yet
var score = 0;	// score (all beneath 100) at init
var scoreBonus = 0;	// score bonus not added yet
var scoreBonusPause = 0;	// pause to blink bonus indication 
var scoreBonusID;    // ID for timeout bonus indication blinking score
var scorePrev;	// previous set score for gaps between sets

var alarm = false;	// alarm not running
var alarmID;    // ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = false;     // for indicationif alarm is set on or off
var alarmSetting = false;       // if alarm is at set mode to make changes
var cursor = true;	// cursor + present

var prefAlarmMin = 0;	// last saved alarm setting minutes
var prefAlarmHour = 0;	// last saved alarm setting hours

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game button pressed
            document.images['Game A'].src = 'img/case/buttons/black_1_flat.png';     
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainGameA(); // show high score @ play Game A after button release
            keyPressed = true;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" pressed
            // show game button pressed
            document.images['Game B'].src = 'img/case/buttons/black_2_flat.png';     
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainGameB(); // show high score @ play Game B after button release
            keyPressed = true;
            break;
        case "x": case "X": case "ArrowDown":	// down key released
            // show down button pressed
            document.images['Move Down'].src = 'img/case/buttons/down_flat.png';     
            DownPressed();      // function to move down
            keyPressed = true;
            break;
        case "s": case "S": case "ArrowLeft":	// left keys
            // show left button pressed
            document.images['Move Left'].src = 'img/case/buttons/left_flat.png';     
            LeftPressed();      // function to move left
            keyPressed = true;
            break;
        case "d": case "D": case "ArrowRight":	// right keys
            // show right button pressed
            document.images['Move Right'].src = 'img/case/buttons/right_flat.png';     
            RightPressed();     // function to move right
            keyPressed = true;
            break;
        case "e": case "E": case "ArrowUp":	// up key released
            // show up button pressed
            document.images['Move Up'].src = 'img/case/buttons/up_flat.png';     
            UpPressed();      // function to move up
            break;
        case "Space": case " ": case "Enter":	// space or enter key
            // show action button pressed
            document.images['Action gb'].src = 'img/case/buttons/action_flat.png';     
            ActionPressed();     // function to hit @ current position
            keyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
            document.images['Acl'].src = 'img/case/buttons/acl_push.png';
            TotalReset(); // show full sprites
            RKeyPressed = true;
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/black_3_flat.png';
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainTime(); // show time & demo
            TKeyPressed = true;
            TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
            break;
        case"w": case"W":     // if "w" or "W" pressed
            // show alarm button pressed
            document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
            if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainAlarm(); // set alarm
            break;
        //test case buttons 
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;   // current voluem becomes previus set @ next change of volume
            };
            if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;   // current volume becomes previus set @ next change of volume
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;     // show/hide indicator
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
            $(function () {
                CheckSizeZoom();
                $('#divWrap').css('visibility', 'visible');
            });
            $(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : \x1B[31m" + e.keyCode + "\x1B[30m <==> '\x1B[35m" + e.key + "\x1B[30m'										pause = "+pause+" --- actionKeyPressed = "+actionKeyPressed+"  --  gwCaseHold = "+gwCaseHold);
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "x": case "X": case "ArrowDown":	// down key released
            // show down button default
            document.images['Move Down'].src = 'img/case/buttons/down.png';     
            keyPressed = false;
            break;
        case "s": case "S": case "ArrowLeft":	// left key released
            // show left button default
            document.images['Move Left'].src = 'img/case/buttons/left.png';     
            keyPressed = false;
            break;
        case "d": case "D": case "ArrowRight":	// right key released
            // show right button default
            document.images['Move Right'].src = 'img/case/buttons/right.png';     
            keyPressed = false;
            break;
        case "e": case "E": case "ArrowUp":	// up key released
            // show up button default
            document.images['Move Up'].src = 'img/case/buttons/up.png';     
            keyPressed = false;
            break;
        case "Space": case " ": case "Enter":	// space or enter key released
            // show action button default
            document.images['Action gb'].src = 'img/case/buttons/action.png';     
            actionKeyPressed = false;   
            keyPressed = false;
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/buttons/black_1.png';  
            MainGameAGo(); // start running Game A
            keyPressed = false;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" released
            document.images['Game B'].src = 'img/case/buttons/black_2.png';  
            MainGameBGo(); // start running Game B
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['Acl'].src = 'img/case/buttons/acl.png';
            RKeyPressed = false;
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/black_3.png';
            TKeyPressed = false;
            TimeShowOnScreen(min, hour);
            break;
        case"w": case"W":     // if "w" or "W" pressed
            document.images['Alarm'].src = 'img/case/buttons/acl.png';
            break;
        default: 
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
    $(function () {
        CheckSizeZoom();
        $('#divWrap').css('visibility', 'visible');
    });
    $(window).resize(CheckSizeZoom);
    $("#game").focus(); // get focus on the game
    highScore[1] = 0;	// high score game A
    highScore[2] = 0;	// high score game B
    PicPreload();	// this function preloads all images to make them ready for use
    MainPicturesShow();	// show default figures
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
    console.log('\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39'); 	// color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually perform the action
function Action () {
    var armsTime = gameSpeed*2/3;	// speed of returning arms
    if ((game==1 || game==2) && !missed) {	// if game playing & no fail
        switch (pos) {
            case 0:	// Mario still outside and enters the building
                if (runTime==0) {
                    PlaySound("move_mario_", vlm);
                    prevPos = pos;	// remember previous position
                    pos = 2;	// Mario inside @ the door
                    MarioShow();
                    runTime = 1;	// indicates that Mario entered the building
                };
                break;
            case 1 :	// Mario @ top left position grabbing gwCase4
                if (!missed && !gwCase[5]) {	// to avoid any action when Mario has a miss
                    PlaySound("action_", vlm);
                    actionPos = 1;	// remember previous position
                    PicShow("ArmsDown1", nullPre.src);
                    PicShow("ArmsUp1", armsUpPre[1].src);  
                    if (gwCase[4]) {	// if gwCase4 present
                        gwCaseHold = 4;	// catching gwCase4 for putting it down
                    };
                    actionID = window.setTimeout('ArmsMove(1)', armsTime);	// putting it down if present
                };
                break;
            case 5 : 	// Mario @ middle right position grabbing gwCase11
                if (!missed && !gwCase[12]) {	// to avoid any action when Mario has a miss
                    PlaySound("action_", vlm);
                    actionPos = 5;	// remember previous position
                    PicShow("ArmsDown5", nullPre.src);
                    PicShow("ArmsUp5", armsUpPre[5].src);            
                    if (gwCase[11]) {	// if gwCase11 present
                        gwCaseHold = 11;	// catching gwCase11 for putting it down
                    };
                    actionID = window.setTimeout('ArmsMove(5)', armsTime);	// putting it down if present
                };
                break; 
            case 7 :	// Mario @ bottom middle position grabbing gwCase18
                if (!missed) {	// to avoid any action when Mario has a miss
                    PlaySound("action_", vlm);
                    actionPos = 7;	// remember previous position
                    PicShow("ArmsDown7", nullPre.src);
                    PicShow("ArmsUp7", armsUpPre[7].src);            
                    if (gwCase[18]) {	// if gwCase18 present
                        if (gwCaseHold) Failed(18)	// if still holding previous gwCase
                        else gwCaseHold = 18;	// catching gwCase18 & running around with it untill thrown on the truck
                    };
                    actionID = window.setTimeout('ArmsMove(7)', armsTime);	// putting it down if present
                };
                break;
            case 8 : 	// Mario @ bottom left position throwing gwCase20 if carrying
                if (!missed) {	// to avoid any action when Mario has a miss
                    actionPos = 8;	// remember previous position
                    if (gwCase[20]) {	// if gwCase20 present
                        gwCaseHold = 0;	// Masio was carrying gwCase20 & has thrown it on the truck
                        gwCase[20] = 0;     // holding gwCase gone & dropped on the truck
                        LoadTruck();	// throwing it on the truck if present
                        PlaySound("point_", vlm);
                        ScoreAdd(1);
                    } else {
                        PlaySound("action_", vlm);
                    };
                    PicShow("GwCase20", nullPre.src);
                    PicShow("ArmsUp8", nullPre.src);            
                    PicShow("ArmsDown8", armsDownPre[8].src);
                    armsMoveID = window.setTimeout('ArmsMove(8)', armsTime);	// arms back after throwing it on the truck
                };
                break;
            default:
        };
    };
};

// action button or -key pressed
function ActionPressed () {
    if (!actionKeyPressed&&!demoID&&life>0&&!pause&&(!(gwCaseHold&&pos<8))) {        // to avoid continious action @ running game
        Action(pos);    // try to perform action @ current position
        actionKeyPressed = true;
    };
};

// Move arms of mario @ action back from receiving or loading the gwCase
function ArmsMove (actPos) {
    if (actionID) {
        window.clearTimeout(actionID);	// stop previous action attempts
        actionID = null;
    } 
    if (actPos<8) {	// if Mario not @ position 8
        PicShow("ArmsUp"+actPos+"", nullPre.src);	// hide receiving arms
        if (actPos==pos) PicShow("ArmsDown"+actPos+"", armsDownPre[actPos].src); // if Mario not yet gone from that position show retreaved arms
    } else {
        PicShow("ArmsDown"+actPos+"", nullPre.src);	// hide receiving arms
        if (actPos==pos) PicShow("ArmsUp"+actPos+"", armsUpPre[actPos].src); // if Mario not yet gone from that position show retreaved arms
    };
    if ((gwCase[20] || loaded) && actPos==8) {	// if gwCase tossed on truck or truck fully loaded
        if (loaded) DriveTruckAway();	// if truck fully loaded, the truck drives off
    } else {
        if (!gwCaseHold && actPos==pos) {	// if not yet holding a gwCase (grabbed a little early) and didn't move
            ArmsMoveScoreChecked(actPos);	// Check move arms of mario or mario @ action back from receiving or loading the gwCase in time
        };
        if (gwCaseHold) {	// if Mario holding a gwCase
            ArmsMoveScored(actPos);	// process point & drop caught gwCase
        };
    };
    actionPos = 0;	// end of action
};

// Check move arms of mario or mario @ action back from receiving or loading the gwCase in time
function ArmsMoveScoreChecked (actPos) {
    if (actPos==1&&gwCase[4]) {	// top catching position & gwCase ready to be cought @ top conveyor belt
        gwCaseHold = 4	// @ top left position, if gwCase4 present, catching gwCase4 for putting it down
    } else {
        if (actPos==5&&gwCase[11]) {	// center catching position & gwCase ready to be cought @ center conveyor belt
            gwCaseHold = 11	// @ center right position, if gwCase11 present, catching gwCase11 for putting it down
        } else if (actPos==7&&gwCase[18]) {	// bottom catching position & gwCase ready to be cought @ bottom conveyor belt
            gwCaseHold = 18;	// @ bottom middle position, if gwCase18 present, catching gwCase18 & running around with it untill thrown on the truck
        };
    };
};


// process point & drop caught gwCase
function ArmsMoveScored (actPos) {
    PlaySound("point_", vlm)
    ScoreAdd(1);
    if (actPos!=7 || pos!=8) {	// if Mario not @ bottom catching position
        PicShow("GwCase"+eval(gwCaseHold)+"", nullPre.src);     // hide previous gwCase
        gwCase[gwCaseHold] = 0;     // delete previous gwCase
    } else {
        PicShow("GwCase18", nullPre.src);     // hide previous gwCase
        gwCase[18] = 0;     // delete previous gwCase                
    };
    if (gwCaseHold<18) {
        PicShow("GwCase"+eval(gwCaseHold+1)+"", gwCasePre[(gwCaseHold+1)].src);	// show current gwCase
        gwCase[gwCaseHold+1] = 1;	// set current gwCase
        gwCaseHold = 0	// if Mario not @ end, put gwCase down
    } else {
        if (pos==7) gwCaseHold = 19;	// else carry gwCase for toss on truck
        else if (pos==8) gwCaseHold = 20;	// else toss gwCase on truck
        PicShow("GwCase"+eval(gwCaseHold)+"", gwCasePre[gwCaseHold].src);	// show current gwCase
        gwCase[gwCaseHold] = 1;	// set current gwCase
    };
};

// go down if possible @ game or decrease alarm hour if alarm is being set
function Down () {
    if ((game==1 || game==2) && !missed) {	// if game playing & no fail
        GoDown();	// go position down if possible
    } else {
        if (game==5 || game==8) {	// change the alarm time
            prefAlarmHour--;	// subtract an from hour alarm setting
            if (prefAlarmHour==-1) prefAlarmHour = 23;
            AlarmShowNum();	// show alarm time
        };
    };
};

// down button or -key pressed
function DownPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&!scoreBonusPause) { // if game still running, no pause or alarm being set
        Down();    // go down if possible @ game or change alarm hour if alarm is being set
        keyPressed = true;
    };
};

// actually go to down if possible
function GoDown () {
    if (!loaded) {	// if truck not leaving
        prevPos = pos;	// remember previous position
        if (pos==2 || pos==3 || pos==6)	// check if Mario @ right place to go down
            pos++;
        if (prevPos!=pos) {
            PlaySound("move_mario_", vlm);        // play move sound if Mario actually moved
            MarioShow();
        };
    };
};

// actually go to the left if not on ladder
function GoLeft () {
    if (!loaded) {	// if truck not leaving
        prevPos = pos;	// remember previous position
        if (pos==7) {	// @ bottom middle position
            pos++;
            if (gwCaseHold || (actionID&&gwCase[18])) {
                if (actionID) {
                    window.clearTimeout(actionID);	// stop previous action attempts
                    actionID = null;
                };
                if (gwCase[18]) {
                    gwCase[18] = 0;	// in case of bad timing
                    PlaySound("point_", vlm)
                    ScoreAdd(1);
                } else {
                    gwCase[19] = 0;	// in case of good timing
                };
                gwCase[20] = 1;
                gwCaseHold = 20;	// gwCase holding position @ truck	
                PicShow("GwCase18", nullPre.src);	// both in case of bad timing
                PicShow("GwCase19", nullPre.src);	// both in case of bad timing
                PicShow("GwCase20", gwCasePre[20].src);
            };
        } else {
            if (pos==2  || pos==5 ) { 	// @ top middle or center left position
                if (pos==5 && actionPos) {
                    ArmsMoveScoreChecked (actionPos);	// check if Mario grabbed a gwCase in time
                    if (gwCaseHold) ArmsMoveScored(actionPos);	// if so process point & drop caught gwCase
                };
                pos--;
            } else {
                if (pos==4) // @ center middle position
                    pos = 6	// center left position
                else {
                    if (pos==0 && runTime!=0) 	// outside the factory behind the door @ top right position
                        pos = 2	// top middle position (@ the door)
                    else {
                        if (pos==9) {	// @ bottom right position (Mario resting)
                            if (marioRestID) {
                                window.clearTimeout(marioRestID);	// Stop Mario resting animation
                                marioRestID = null;
                            };
                            marioRest = 0;
                            marioResting = 0;
                            pos = 7;	// Mario @ bottom middle position
                        } else {
                            if (game==2 &&(pos==1 || pos==6 || pos==8))	// for game B @ top left, center left or bottom left position
                                Failed(pos);	// fall from floor
                        };
                    };
                };
            };
        };
        if (prevPos!=pos) {
            PlaySound("move_mario_", vlm);        // play move sound if Mario actually moved
            MarioShow();
        };
   };
};

// actually go to the right if not on the ladder
function GoRight () {
    if (!loaded) {	// if truck not leaving
        prevPos = pos;	// remember previous position
        if (pos==8) {	// @ bottom left position
            pos--
            if (actionPos) ArmsMove(prevPos);   // move Marios arms so he doesn't automatically catches @ pos 7
            if (gwCaseHold) {
                gwCase[20] = 0;
                gwCase[19] = 1;
                PicShow("GwCase20", nullPre.src);
                PicShow("GwCase19", gwCasePre[19].src);
                gwCaseHold = 19;	// gwCase holding @ bottom ladder
            };
        } else {
            if (pos==1  || pos==4 ) {	// @ top left or center middle position
                if (pos==1 && actionPos) {
                    ArmsMoveScoreChecked (actionPos);	// check if Mario grabbed a gwCase in time
                    if (gwCaseHold) ArmsMoveScored(actionPos);	// if so process point & drop caught gwCase
                };
                pos++;
            } else {
                if (pos==6) pos-=2	// @ center left position
                else {
                    if (game==2 && pos==2)	// for game B @ top middle position
                        pos = 0 	// outside the factory behind the door @ top right position 
                    else {
                        if (game==2 && pos==7) {	// for game B @ bottom middle position
                            marioResting = 1;
                            pos = 9;	// bottom right position (Mario resting)
                            if (gwCaseHold>17) {	// if Mario holding gwCase while going to rest
                                gwCase[gwCaseHold] = 0;
                                PicShow("GwCase"+eval(gwCaseHold)+"", nullPre.src);
                                Failed(gwCaseHold);
                            };
                            marioRest = 1;
                            MarioRestAnimate();
                        } else {
                            if (game==2 && pos==5)	// for game B @ center right position
                                Failed(pos);
                        };
                    };
                };
            };
        };
        if (prevPos!=pos) {
            PlaySound("move_mario_", vlm);        // play move sound if Mario actually moved
            MarioShow();
        };
    } ;
};

// actually go up if possible
function GoUp () {
    if (!loaded) {	// if truck not leaving
        prevPos = pos;	// remember previous position
        if (pos==3 || pos==4 || pos==7)	// on the ladder, @ center middle or bottom middle position
            pos--;
        if (prevPos!=pos) {
            PlaySound("move_mario_", vlm);        // play move sound if Mario actually moved
            MarioShow();
            if (gwCaseHold>17) {	// if Mario holding gwCase while climbing the ladder
                gwCase[gwCaseHold] = 0;	// drops gwCase
                PicShow("GwCase"+eval(gwCaseHold)+"", nullPre.src);
                Failed(gwCaseHold);
            };
        };
    };
};

// move gwCase moving on machine's conveyor belts
function GwCaseMove () {
    switch (sequence) {	// whitch of the 3 conveyor belts moves next
        case 1 :	// top conveyor belt
            if (gwCase[4]) {	// if last gwCase still present
                if (actionPos!=1) Failed(4);	// if last gwCase not caught by Mario
            } else { 
                if (gwCase[3]) gwCaseMoveDelay[1] = 1;	// not ok to move gwcase 5 next time
                gwCase[4] = gwCase[3];	// move gwCase 3
            };
            for (i=3 ; i>0 ; i--) {	// move other gwCases of this conveyor belt
                gwCase[i] = gwCase[(i-1)];
            };
            gwCase[0] = 0;	// reset first gwCase of this conveyor belt 
            break;
        case 2 :	// center conveyor belt
            if (gwCase[11]) {	// if last gwCase still present
                if (actionPos!=5) Failed(11);	// if last gwCase still present, not caught by Mario
            } else {
                if (gwCase[10]) gwCaseMoveDelay[5] = 5;	// not ok to move gwcase 12 next time
                gwCase[11] = gwCase[10];	// move gwCase 10
            };
            for (i=10 ; i>6 ; i--) {	// move other gwCases of this conveyor belt but first one
                gwCase[i] = gwCase[(i-1)];
            };
            if (!gwCaseMoveDelay[1] && !gwCase[7]) {	// if not caught too soon
                gwCase[6] = gwCase[5];	// move gwCase 5
                gwCase[5] = 0;	// reset first gwCase of this conveyor belt 
            } else {
                gwCaseMoveDelay[1] = 0;	// ok to move gwcase 5 next time
                gwCase[6] = 0;	// reset second gwCase of this conveyor belt for next run
            };
            break;
        case 3 :	// bottom conveyor belt
            if (gwCase[17]) {	// if pre-last gwCase present
                gwCaseHoldPause = 4;	// initiate timer to allow new gwCase to start
            } else if (gwCaseHold>1) gwCaseHoldPause--;	// if still holding the gwCase count down timer
            if (gwCase[18]) {	// if last gwCase still present
                if (actionPos!=7 || gwCaseHold) Failed(18);	// if last gwCase still present, not caught by Mario
            } else gwCase[18] = gwCase[17];	// move gwCase 17
            for (i=17 ; i>13 ; i--) {	// move other gwCases of this conveyor belt but first one
                gwCase[i] = gwCase[(i-1)];
            };
            if (!gwCaseMoveDelay[5] && !gwCase[14]) {	// if not caught too soon
                gwCase[13] = gwCase[12];	// move gwCase 12
                gwCase[12] = 0;	// reset first gwCase of this conveyor belt 
            } else {
                gwCaseMoveDelay[5] = 0;	// ok to move gwcase 12 next time
                gwCase[13] = 0;	// reset second gwCase of this conveyor belt for next run
            };
            break;
        default :
    };
    for (i=1 ; i<21 ; i++) {	// show all gwCases present
        if (gwCase[i]) 
            PicShow("GwCase"+eval(i)+"", gwCasePre[i].src)
        else
            PicShow("GwCase"+eval(i)+"", nullPre.src);
    };
};

// go left @ game or decrease alarm minutes if alarm is being set
function Left () {
    if ((game==1 || game==2) && !missed) {	// if game playing & no fail
        GoLeft();	// go position to the left
    } else {
        if (game==5 || game==8) {	// change the alarm time
            prefAlarmMin--;	// subtract a minute from alarm time
            if (prefAlarmMin==-1) prefAlarmMin = 59;
            AlarmShowNum();	// show alarm time
        };
    };
};

// left button or -key pressed
function LeftPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&!scoreBonusPause) {  // if game still running, no pause or alarm being set
        Left();    // go left @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;	// if picture given assign it to the figure
};

// go right @ game or increase alarm minutes if alarm is being set
function Right () {
    if ((game==1 || game==2) && !missed && !marioRest) {	// if game playing and no miss at the moment & Mario not resting
        GoRight ();	// go position to the right
    } else {
        if (game==5 || game==8) {	// change the alarm time
            prefAlarmMin++;	// add a minute to alarm time
            if (prefAlarmMin==60) prefAlarmMin = 0;
            AlarmShowNum();	// show alarm time
        };
    };
};

// right button or -key pressed
function RightPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&!scoreBonusPause) {  // if game still running, no pause or alarm being set
        Right();    // go right @ game or change alarm hour or minutes if alarm is being set
        keyPressed = true;
    };
};

// go up @ game or increase alarm hour if alarm is being set
function Up () {
    if (game==1 || game==2) {	// if game playing
        GoUp ();	// go position up
    } else {
        if (game==5 || game==8) {	// change the alarm time
            prefAlarmHour++;	// add an hour to alarm setting
            if (prefAlarmHour==24) prefAlarmHour = 0;
            AlarmShowNum();	// show alarm time
        };
    };
};

// up button or -key pressed
function UpPressed () {
    if (!keyPressed&&(!demoID||game==5||game==8)&&!actionID&&!scoreBonusPause) {  // if game still running, no pause or action going on or alarm being set
        Up();    // go up @ game or change alarm hour if alarm is being set
        keyPressed = true;
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    alarmStateIndPre = new Image();
    alarmStateIndPre.src = "img/screen/alarmStateInd.png";	// to show if alarm is set on or off
    armsDownPre = new Array();
    armsUpPre = new Array();
    armsDownPre[1] = new Image();
    armsDownPre[1].src = "img/screen/armsDown1.png";	// to show arms in down-state of Mario @ place 1
    armsUpPre[1] = new Image();
    armsUpPre[1].src = "img/screen/armsUp1.png";	// to show arms in up-state of Mario @ place 1
    armsDownPre[5] = new Image();
    armsDownPre[5].src = "img/screen/armsDown5.png";	// to show arms in down-state of Mario @ place 5
    armsUpPre[5] = new Image();
    armsUpPre[5].src = "img/screen/armsUp5.png";	// to show arms in up-state of Mario @ place 5
    armsDownPre[7] = new Image();
    armsDownPre[7].src = "img/screen/armsDown7.png";	// to show arms in down-state of Mario @ place 7
    armsUpPre[7] = new Image();
    armsUpPre[7].src = "img/screen/armsUp7.png";	// to show arms in up-state of Mario @ place 7
    armsDownPre[8] = new Image();
    armsDownPre[8].src = "img/screen/armsDown8.png";	// to show arms in down-state of Mario @ place 8
    armsUpPre[8] = new Image();
    armsUpPre[8].src = "img/screen/armsUp8.png";	// to show arms in up-state of Mario @ place 8
    armsDownBossPre = new Image();
    armsDownBossPre.src = "img/screen/armsDownBoss.png";	// to show arms in down-state of the Boss
    armsUpBossPre = new Image();
    armsUpBossPre.src = "img/screen/armsUpBoss.png";	// to show arms in up-state of the Boss
    bossPre = new Image();
    bossPre.src = "img/screen/boss.png";	// to show the boss
    bellPre = new Image();
    bellPre.src = "img/null.gif";	// to show ringing bell in down-state @ alarm
    bellDownPre = new Image();
    bellDownPre.src = "img/screen/bellDown.png";	// to show ringing bell in down-state @ alarm
    bellUpPre = new Image();
    bellUpPre.src = "img/screen/bellUp.png";	// to show ringing bell in up-state @ alarm
    gamePre = new Array();
    for (i=1 ; i<3 ; i++) { 	// to show the GAME A & GAME B indication
        gamePre[i] = new Image();
        gamePre[i].src = "img/screen/game"+eval(i)+".png";
    };
    crashPre = new Array();
    for (i=1 ; i<3 ; i++) { 	// to show the crashed g&w cases
        crashPre[i] = new Image();
        crashPre[i].src = "img/screen/crash"+eval(i)+".png";
    };
    gwCasePre = new Array();
    for (i=0 ; i<27 ; i++) { 	// to show the g&w cases
        gwCasePre[i] = new Image();
        gwCasePre[i].src = "img/screen/gwCase"+eval(i)+".png";
    };
	var gwCasePresent;
    marioPre = new Array();
    for (i=0 ; i<11 ; i++) { 	// to show the 11 Mario's
        marioPre[i] = new Image();
        marioPre[i].src = "img/screen/mario"+eval(i)+".png";
    };
    mario9IPre = new Image();
    mario9IPre.src = "img/screen/mario9_i.png";	// to show Mario @ place 9 not breathing out
    mario10DPre = new Image();
    mario10DPre.src = "img/screen/mario10_d.png";	// to show Mario @ place 10 head down
    mario10UPre = new Image();
    mario10UPre.src = "img/screen/mario10_u.png";	// to show Mario @ place 10 head up
    marioFallPre = new Array();
    for (i=1 ; i<5 ; i++) { 	// to show the falling Marios
        marioFallPre[i] = new Image();
        marioFallPre[i].src = "img/screen/marioFall"+eval(i)+".png";
    };
    missPre = new Image();
    missPre.src = "img/screen/miss.png";	// to show misses
    missTxtPre = new Image();
    missTxtPre.src = "img/screen/misstxt.png";	// to show missed text
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
    soundOnPre = new Image();
    soundOnPre.src = "img/case/buttons/butOn.png";	// to show sound button in on-state
    soundOffPre = new Image();
    soundOffPre.src = "img/case/buttons/butOff.png";	// to show sound button in off-state
    truckPre = new Image();
    truckPre.src = "img/screen/truck.png";	// to show the truck
    truckDriverPre = new Image();
    truckDriverPre.src = "img/screen/truckDriver.png";	// to show the truck driver
    truckSmoke1Pre = new Image();
    truckSmoke1Pre.src = "img/screen/truckSmoke1.png";	// to show truck's exhaust smoke 1
    truckSmoke2Pre = new Image();
    truckSmoke2Pre.src = "img/screen/truckSmoke2.png";	// to show truck's exhaust smoke 2
    truckMove1Pre = new Image();
    truckMove1Pre.src = "img/screen/truckMove1.png";	// to show moving truck's exhaust smoke 1
    truckMove2Pre = new Image();
    truckMove2Pre.src = "img/screen/truckMove2.png";	// to show moving truck's exhaust smoke 2
};

// hide all figures
function AllPicturesClear () {
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
    PicShow("Misstxt", nullPre.src);
    MarioArmsHide();
    PicShow("ArmsUpBoss", nullPre.src);
    PicShow("ArmsDownBoss", nullPre.src);
    PicShow("Boss", nullPre.src);
    PicShow("BellUp", nullPre.src);
    PicShow("BellDown", nullPre.src);
    PicShow("AlarmStateInd", nullPre.src);
    for (i=1 ; i<3 ; i++) PicShow("Crash"+eval(i)+"", nullPre.src);
    PicShow("NumColon", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
    for (i=1 ; i<3 ; i++) PicShow("Game"+eval(i)+"", nullPre.src);
    for (i=1 ; i<27 ; i++) PicShow("GwCase"+eval(i)+"", nullPre.src);
    for (i=1 ; i<11 ; i++) PicShow("Mario"+eval(i)+"", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("MarioFall"+eval(i)+"", nullPre.src);
    PicShow("Truck", nullPre.src);
    PicShow("TruckDriver", nullPre.src);
    PicShow("TruckSmoke1", nullPre.src);
    PicShow("TruckSmoke2", nullPre.src);
    PicShow("TruckMove1", nullPre.src);
    PicShow("TruckMove2", nullPre.src);
};

// show all figures
function AllPicturesShow () {
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    PicShow("Misstxt", missTxtPre.src);
    PicShow("NumColon", numColonPre.src);	// ":"
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// "8"
    PicShow("ArmsUp1", armsUpPre[1].src);
    PicShow("ArmsDown1", armsDownPre[1].src);
    PicShow("ArmsUp5", armsUpPre[5].src);
    PicShow("ArmsDown5", armsDownPre[5].src);
    PicShow("ArmsUp7", armsUpPre[7].src);
    PicShow("ArmsDown7", armsDownPre[7].src);
    PicShow("ArmsUp8", armsUpPre[8].src);
    PicShow("ArmsDown8", armsDownPre[8].src);
    PicShow("ArmsUpBoss", armsUpBossPre.src);
    PicShow("ArmsDownBoss", armsDownBossPre.src);
    PicShow("Boss", bossPre.src);
    PicShow("BellUp", bellUpPre.src);
    PicShow("BellDown", bellDownPre.src);
    PicShow("AlarmStateInd", alarmStateIndPre.src);
    for (i=1 ; i<3 ; i++) PicShow("Crash"+eval(i)+"", crashPre[i].src);
    for (i=1 ; i<3 ; i++) PicShow("Game"+eval(i)+"", gamePre[i].src);
    for (i=1 ; i<27 ; i++) PicShow("GwCase"+eval(i)+"", gwCasePre[i].src);
    for (i=1 ; i<11 ; i++) PicShow("Mario"+eval(i)+"", marioPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("MarioFall"+eval(i)+"", marioFallPre[i].src);
    PicShow("Truck", truckPre.src);
    PicShow("TruckDriver", truckDriverPre.src);
    PicShow("TruckSmoke1", truckSmoke1Pre.src);
    PicShow("TruckSmoke2", truckSmoke2Pre.src);
    PicShow("TruckMove1", truckMove1Pre.src);
    PicShow("TruckMove2", truckMove2Pre.src);
};

// show default pictures for demo
function MainPicturesDefault () {
    PicShow("Mario0", marioPre[0].src);
    PicShow("Truck", truckPre.src);
};

// show default pictures as @ start of the game
function MainPicturesGame () {
    MainPicturesDefault();
};

// show all figures & "12:00"
function MainPicturesShow () {
    MainPicturesDefault();	// show default pictures for demo
    MissShow();
    PicShow("ArmsUp1", armsUpPre[1].src);
    PicShow("ArmsDown1", armsDownPre[1].src);
    PicShow("ArmsUp5", armsUpPre[5].src);
    PicShow("ArmsDown5", armsDownPre[5].src);
    PicShow("ArmsUp7", armsUpPre[7].src);
    PicShow("ArmsDown7", armsDownPre[7].src);
    PicShow("ArmsUp8", armsUpPre[8].src);
    PicShow("ArmsDown8", armsDownPre[8].src);
    PicShow("ArmsUpBoss", armsUpBossPre.src);
    PicShow("ArmsDownBoss", armsDownBossPre.src);
    PicShow("Boss", bossPre.src);
    PicShow("BellUp", bellUpPre.src);
    PicShow("BellDown", bellDownPre.src);
    PicShow("AlarmStateInd", alarmStateIndPre.src);
    for (i=1 ; i<3 ; i++) PicShow("Crash"+eval(i)+"", crashPre[i].src);
    PicShow("NumColon", numColonPre.src);       // ":"
    PicShow("Num1", numPre[2].src);     // 1
    PicShow("Num2", numPre[3].src);     // 2
    PicShow("Num3", numPre[1].src);     // 0
    PicShow("Num4", numPre[1].src);     // 0
    for (i=1 ; i<3 ; i++) PicShow("Game"+eval(i)+"", gamePre[i].src);
    for (i=1 ; i<27 ; i++) PicShow("GwCase"+eval(i)+"", gwCasePre[i].src);
    for (i=0 ; i<11 ; i++) PicShow("Mario"+eval(i)+"", marioPre[i].src);
    for (i=1 ; i<5 ; i++) PicShow("MarioFall"+eval(i)+"", marioFallPre[i].src);
    PicShow("Truck", truckPre.src);
    PicShow("TruckDriver", truckDriverPre.src);
    PicShow("TruckSmoke1", truckSmoke1Pre.src);
    PicShow("TruckSmoke2", truckSmoke2Pre.src);
    PicShow("TruckMove1", truckMove1Pre.src);
    PicShow("TruckMove2", truckMove2Pre.src);
};

// show Mario @ current position
function MarioShow () {
    PicShow("Mario"+eval(prevPos)+"", nullPre.src);	// hide Mario @ previous position
    MarioArmsHide();	// to avoid previos arms to be left on screen 
    if (!missed) {
        PicShow("Mario"+eval(pos)+"", marioPre[pos].src);	// show Mario if no miss
        switch (pos) {	// show corresponding arms in default position
            case 1 : 
                if (!missed) PicShow("ArmsDown1", armsDownPre[1].src);            
                break;
            case 5 : 
                if (!missed) PicShow("ArmsDown5", armsDownPre[5].src);            
                break;
            case 1 : case 5 : case 7 :
                if (!missed) PicShow("ArmsDown7", armsDownPre[7].src);            
                break;
            case 8 : 
                if (!missed) PicShow("ArmsUp8", armsUpPre[8].src);
                break;
            default:
        };
        if (gwCaseHold>18) {
            PicShow("GwCase"+eval(gwCaseHold)+"", gwCasePre[gwCaseHold].src);
        };
    };
};

// hide Mario from screen on all positions
function MarioHide () {
    MarioArmsHide();	// hide Marios arms on all positions
    for (var i=1 ; i<11 ; i++) {
        PicShow("Mario"+eval(i)+"", nullPre.src);
    };
    for (i=1 ; i<5 ; i++) PicShow("MarioFall"+eval(i)+"", nullPre.src);	// in case Mario fell simultaniously with gwCase crash
};

// hide Marios arms on all positions
function MarioArmsHide () {
    PicShow("ArmsUp1", nullPre.src);
    PicShow("ArmsDown1", nullPre.src);
    PicShow("ArmsUp5", nullPre.src);
    PicShow("ArmsDown5", nullPre.src);
    PicShow("ArmsUp7", nullPre.src);
    PicShow("ArmsDown7", nullPre.src);
    PicShow("ArmsUp8", nullPre.src);
    PicShow("ArmsDown8", nullPre.src);
};

// hide misses in the box
function MissHide () {
    for (var i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);
};

// show all misses in the box & miss text
function MissShow () {
    for (i=1 ; i<(4-life) ; i++) PicShow("Miss"+eval(i)+"", missPre.src);
    if (3-life) PicShow("Misstxt", missTxtPre.src);
    missed = false;	// reset missed indication to resume or end game
};

// hide "MISS" text
function MissTextHide () {
    PicShow("Misstxt", nullPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
    GameReset();    // clear game related IDs
    pause = 100;	// time enough for the current events to run
    scoreBonusPause = 0;
    TimerReset(); // stop the counter to show the current time
};

// clear game related IDs
function GameReset () {
    if (actionID) {
        window.clearTimeout(actionID);	// reset ID for arms delay and ........
        actionID = null;
    };
    if (animateID) {
        clearTimeout(animateID);  // stop angry boss animation
        animateID = null;
    };
    if (blinkID) {
        window.clearTimeout(blinkID);	// stop score from blinking @ bonus
        blinkID = null;
    };
    if (demoID) {
        window.clearTimeout(demoID);	// stop demo from starting/running
        demoID = null;
    };
    if (driveBonusID) {
        window.clearTimeout(driveBonusID);	// stop full truck bonus score
        driveBonusID = null;
    };
    if (failedID) {
        window.clearTimeout(failedID);	// stop all failed animations and functions
        failedID = null;
    };
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (marioRestID) {
        window.clearTimeout(marioRestID);	// stop Mario resting animation
        marioRestID = null;
    };
    if (marioResetID) {
        window.clearTimeout(marioResetID);	// don't start animation after Mario was resting after full truck
        marioResetID = null;
    };
    if (missClearID) {
        window.clearTimeout(missClearID);	// don't remove "MISS" text & reset lives & misses
        missClearID = null;
    };
    if (missedID) {
        window.clearTimeout(missedID);	// don't start missed item animation
        missedID = null;
    };
    if (scoreBonusID) {
        window.clearTimeout(scoreBonusID);	//  stop beeping @ bonus indication
        scoreBonusID = null;
    };
};

// clear truck animation related IDs
function GameResetTruck () {
    for (i=5 ; i<21 ; i++) {
        if (truckSmokeID[i]) {
            window.clearTimeout(truckSmokeID[i]);	// don't start/proceed with truck smoke animation
            truckSmokeID[i] = null;
        };
    };
};

// reset & clear first three of the upcomming gwCases per conveyor belt after fail or finished truck
function GwCaseReset () {
    for (i=2 ; i<5 ; i++) {	// top conveyor belt 
        PicShow("GwCase"+eval(i)+"", nullPre.src);
        gwCase[i] = 0;
    };
    for (i=9 ; i<12 ; i++) {	// center conveyor belt
        PicShow("GwCase"+eval(i)+"", nullPre.src);
        gwCase[i] = 0;
    };
    for (i=16 ; i<19 ; i++) {	// bottom conveyor belt
        PicShow("GwCase"+eval(i)+"", nullPre.src);
        gwCase[i] = 0;
    };
};

// reset & clear all gwCases on machine
function GwCaseResetFull () {
    for (i=0 ; i<27 ; i++) gwCase[i] = 0;
};

// reset Mario variables after full load
function MarioReset () {
    for (i=5 ; i<21 ; i++) {
        if (truckSmokeID[i]) {
            window.clearTimeout(truckSmokeID[i]);	// reset possible previous ID for smoke & driving animation
            truckSmokeID[i] = null;
        };
    };
    EmptyTruck();
    marioRest = 0;
    marioResting = 0;
    prevPos = 9;	// to hide resting Mario @ next run
    if (demo) pos = 0	// Mario outside @ the door because sync shift due to sequence
    else pos = 2;	// Mario inside @ the door
    runTime = 1;	// indicates that Mario entered the building
    MarioShow();
};

// Let the misses blink & reset them
function MissReset () {
    if (missedID) {
        window.clearTimeout(missedID);	// temporarily stop miss indication after miss
        missedID = null;
    };
    if (game==1 || game==2) {
        MissBlink();	// let misses blink @ score of 300 or 500 if present
        missClearID = window.setTimeout("MissClear()", 2000);    // remove "MISS" text & reset lives & misses after 2 seconds if playing
    } else MissClear(); // remove "MISS" text & reset lives & misses if not playing
};

// clear all pictures & variables
function ResetAll () {
    demo = false;
    AllStop();  // stop game if playing and reset all ID's
    GameResetTruck();
    for (i=1 ; i<3 ; i++) {
        if (gwCaseID[i]) {	// stop animating the loading of the truck
            window.clearTimeout(gwCaseID[i]);
            gwCaseID[i] = null;
        };
    };
    BossMadReset();	// if previous game just finished BosMadAnimate might still be active
    DriverStopSmoking();        // stop all truck smoking animation
    GwCaseResetFull();        // empty the whole the conveyor belt
    gwCaseMoveDelay[1] = 0;
    gwCaseMoveDelay[5] = 0;
    MarioReset();	// reset Mario variables after full load
    MissClear(); // remove "MISS" text & reset lives & misses
    AllPicturesClear ();        // hide all figures
    alarmSetting = false;       // stop running alarm
    EmptyTruck();	// remove all gwCases from truck
    game = 0;   // no-game-all-pictures
    life = 0;	// lives reset
    pos = 0;	// Mario outside @ the door
    pause = 0;	// no pause
    runTime = 0;	// indicates that Mario not yet entered the building
    score = 0   // no score
    scoreBonusPause = 0;	// no pause to animate bonus
    sequence = 0;       // game sequence reset
};

// reset speed according to the current score
function SpeedReset () {
    gameSpeed = gameSpeedMin - Math.round(score%1000/25) - Math.floor(score/50) - Math.floor(score/1000);
    gameSpeed = gameSpeed>gameSpeedMax?gameSpeed:gameSpeedMax;
};

// stop showing current time
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    PlaySound("click_", vlm);	// click sound for push button
    if (alarm) TimeAlarmOff();	// stop alarm if running
    AlarmReset();	// reset alarm to default settings
    ResetAll(); // clear all pictures & variables
    if (acl) AllPicturesShow()    // show all figures & "88:88" if "acl" clicked twice fast
    else MainPicturesShow(); // show all figures & "12:00"
    acl = true; // indicates "acl" already clicked shortly before
    if (alarmID) {
        alarmID = null;
        clearTimeout(alarmID);	// stop running alarm sound from repeating
    };
    if (alarmOffID) {
        alarmOffID = null;
        clearTimeout(alarmOffID);	// stop running timer to turn off alarm @ running
    };
    aclID = window.setTimeout("acl = false;", 130);     // ID to show all pictures if "acl" clicked twice in 130 milliseconds
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// boss is mad because Mario didn't catch a gwCase, which crashed into pieces
function BossMad () {
    marioRest = 0;
    marioResting = false; 
    if (gwCaseHold) GwCaseHoldReset();	// if still holding any other gwCase, reset it
    MarioHide();	// Mario is called to the boss
    failedBlink = 2;	// times left to animate
    BossMadAnimate();
};

// animation for mad boss & guilty Mario 
function BossMadAnimate () {
    var animateSpeed;
    if (game==3) animateSpeed = 2000	// after game over
    else animateSpeed = 1000;	// during game
    if (failedID) {
        clearTimeout(failedID);  // stop failed functions trigger
        failedID = null;
    };
    if (animateID) {
        clearTimeout(animateID);  // stop animation trigger
        animateID = null;
    };
    if (failedBlink) {      // to animate mad boss & Mario shaking head
        if (life>0) {	// no more lives left
            failedBlink--;	// times left to animate
            PlaySound("failed_box_", vlm);	// first sound per animation sequence
            failedID = window.setTimeout('PlaySound("failed_box_", vlm)',(animateSpeed/2));	// second sound per animation sequence
            if (failedBlink==0) failedID = window.setTimeout('PlaySound("failed_box_", vlm)',(3*animateSpeed/4));	// final sound @ end animation
        } else {
            if (game!=3) {	// if game not over yet
                PlaySound("failed_mario_", vlm);	// sound fallen Mario
            };
        };
        BossMadAnimateDown();	// boss arms down, Mario head down
        failedID = window.setTimeout('BossMadAnimateUp()',(animateSpeed/2));	// boss arms up again, Mario head up again
    } else if (missed) {      // if still missed indicating
        PlaySound("failed_mario_", vlm);	// sound fallen Mario
        failedID = window.setTimeout('BossMadReset()',(animateSpeed/2));	// reset boss animate & missed variables 
    };
    if (missed) animateID = window.setTimeout('BossMadAnimate()',animateSpeed);     // if still missed indicating, keep animating
};

// boss arms down, Mario head down
function BossMadAnimateDown () {
    PicShow("Boss", bossPre.src);
    PicShow("Mario10", mario10DPre.src);
    PicShow("ArmsDownBoss", armsDownBossPre.src);
    PicShow("ArmsUpBoss", nullPre.src);	
};

// boss arms up again, Mario head up again
function BossMadAnimateUp () {
    PicShow("Mario10", mario10UPre.src);
    PicShow("ArmsDownBoss", nullPre.src);
    PicShow("ArmsUpBoss", armsUpBossPre.src);
};

// reset boss animate & missed variables & hide figures
function BossMadReset () {	
    if (animateID) {
        clearTimeout(animateID);  // stop pause trigger
        animateID = null;
    };
    if (failedID) {
        clearTimeout(failedID);  // stop pause trigger
        failedID = null;
    };
    PicShow("Boss", nullPre.src);
    PicShow("Mario10", nullPre.src);
    PicShow("ArmsDownBoss", nullPre.src);
    PicShow("ArmsUpBoss", nullPre.src);	
    failedBlink = 0;
    missed = false; // to avoid double reset before next BossMadAnimate()
    if (runTime!=0) pos = 2	// if Mario already entered the building, put him inside @ the door
    else pos = 0;	// else put Mario outside the door
    MarioShow();
};

// remove crashed gwCases & fallen Mario
function CrashClear () {
    PicShow("MarioFall4", nullPre.src);	// hide fallen Mario
    for (i=1 ; i<3 ; i++) PicShow("Crash"+eval(i)+"", nullPre.src);	// hide all crashed gwCases
};

// show demo and show the current time
function Demo () {
    var i;	// previous place game
    if (demoID) {
        clearTimeout(demoID);	// if demo still planned to start stop that plan to avoid double run
        demoID = null;
    };
    if (pause) pause--	// decrease pause time if running
    else {	// if no pause set, let the conveyor belts roll
        if (sequence<20) {	// if the demo sequence not ended it's run go to next animation
            i = sequence==0?20:sequence;	// remember previous sequence
            sequence++       // next game sequence of the demo
        } else {	// @ the end of the demo sequence, load the truck 
            sequence = 0;  // back to first position if demo sequence finished
            LoadTruck();	// throwing gwCase on the truck
            if (loaded) DriveTruckAway();	// drive truck away when fully loaded
            i = 20;	// remember last sequence position
        }
        PicShow("GwCase"+eval(i)+"", nullPre.src);	// hide gwCase @ previous position
        PicShow("GwCase"+eval(sequence)+"", gwCasePre[sequence].src);	// show gwCase @ new position
    };
    if (!marioRest) {	// move Mario if not resting according to the demo sequence
        if (sequence<6 && gameTossed) GoToTop()
        else if (sequence<13 && gameTossed) GoToCenter()
             else {
                GoToBottom();
            };
	};
    if (sequence==20) {	//  if the demo sequence ended, letMario go to the truck & initiate the gwCase to be tossed on it
        gameLoaded = false;
        gameTossed = false;
        prevPos = pos;	// remember previous position of Mario
        pos = 8;	// Mario goes to the truck
        MarioShow();
    };
    if (sequence==0 && !gameTossed) {	// toss the gwCase on the truck if not yet done @ start of new demo sequence
        PicShow("ArmsUp8", nullPre.src);
        PicShow("ArmsDown8", armsDownPre[8].src);
        gameTossed = true;
    };
    demoID = window.setTimeout("Demo()", 1000);	// next step after a second  
};

// add driveBonus times a bonus point to the score
function DriveBonus (driveBonus) {
    if (driveBonusID) {
        window.clearTimeout(driveBonusID);	// reset previous ID to avoid double call
        driveBonusID = null;
    };
    if (driveBonus>0) { // if not all points added
        driveBonus--;   // one time less left to add bonus score
        ScoreAdd(1);    // bonus score
        PlaySound("bonus_", vlm);
        driveBonusID = window.setTimeout("DriveBonus("+driveBonus+")", 200);    // add next point
    };
};

// initiation for started & running truck animation
function DriverStartUp () {
    // determine the speed for the smoke animation
    if (demo) truckSmokeSpeed = 1000;
    else truckSmokeSpeed = 100;
    truckSmokeSeq = 1;  // first sequence for the smoke animation
    DriverStartUpSmoking();     // started & running truck animation
};

// started & running truck animation
function DriverStartUpSmoking () {
    if (gwCase[25]) {     // if fifth gwCase loaded
        if (truckSmokeID[truckSmokeSeq]) {
            window.clearTimeout(truckSmokeID[truckSmokeSeq]);	// reset ID to avoid double activation
            truckSmokeID[truckSmokeSeq] = null;
        };
        switch (truckSmokeSeq) {        // show/hide smoke for the animation according to the smoke sequence
            case 1 :
                PicShow("TruckSmoke1", truckSmoke1Pre.src);
                break;
            case 2 :
                PicShow("TruckSmoke2", truckSmoke2Pre.src);
                break;
            case 3 :
                PicShow("TruckSmoke1", nullPre.src);
                PicShow("TruckSmoke2", nullPre.src);
                break;
            case 4 :
                truckSmokeSeq = 0;      // reset @ end sequence for next run
                break;
            default :
        };
        truckSmokeSeq++;        // next sequence
        truckSmokeID[truckSmokeSeq] = window.setTimeout('DriverStartUpSmoking()', truckSmokeSpeed);     // next running truck animation
    };
};

// stop all truck smoke animation
function DriverStopSmoking () {
    for (i=1 ; i<21 ; i++) {
        if (truckSmokeID[i]) {
            window.clearTimeout(truckSmokeID[i]);	// reset ID for smoke animation
            truckSmokeID[i] = null;
        };
    };     
};

// driving truck away animation
function Driving () {
    var truckSpeed;
    var truckStartSpeed;
    missedWhileLoading = false;
    for (i=1 ; i<6 ; i++) {
        if (truckSmokeID[i]) {
            window.clearTimeout(truckSmokeID[i]);	// reset ID for previous smoke animation of running truck
            truckSmokeID[i] = null;
        };
    };
    // determine animation speed
    if (demo) {
        truckStartSpeed = 1000;
        truckSpeed = 1000;
    } else {
        truckStartSpeed = 700;
        truckSpeed = 500;
    };
    // hide previoes smoke animation
    PicShow("TruckSmoke2", nullPre.src);
    PicShow("TruckSmoke1", nullPre.src);
    // truck smoke & move animation & empty truck 
    truckSmokeID[7] = window.setTimeout('PicShow("TruckSmoke1", truckSmoke1Pre.src)', truckStartSpeed);
    truckSmokeID[8] = window.setTimeout('PicShow("TruckSmoke1", nullPre.src); PicShow("TruckSmoke2", truckSmoke2Pre.src);', (truckSpeed*3));
    truckSmokeID[9] = window.setTimeout('PicShow("TruckSmoke2", nullPre.src)', (truckSpeed*4));	
    truckSmokeID[10] = window.setTimeout('EmptyTruckPic(); PicShow("TruckMove1", truckMove1Pre.src); PicShow("TruckMove2", truckMove2Pre.src)', (truckSpeed*5));
    truckSmokeID[11] = window.setTimeout('PicShow("TruckSmoke1", truckSmoke1Pre.src); PicShow("TruckSmoke2", truckSmoke2Pre.src);', (truckSpeed*5));
    truckSmokeID[12] = window.setTimeout('PicShow("TruckMove1", nullPre.src); PicShow("TruckMove2", nullPre.src);', (truckSpeed*6));
    truckSmokeID[13] = window.setTimeout('PicShow("TruckSmoke1", nullPre.src)', (truckSpeed*7));	
    truckSmokeID[14] = window.setTimeout('PicShow("TruckMove1", truckMove1Pre.src); PicShow("TruckMove2", truckMove2Pre.src);', (truckSpeed*8));
    truckSmokeID[15] = window.setTimeout('PicShow("TruckMove1", nullPre.src); PicShow("TruckMove2", nullPre.src);', (truckSpeed*9));
    truckSmokeID[16] = window.setTimeout('PicShow("TruckSmoke1", truckSmoke1Pre.src); PicShow("TruckSmoke2", nullPre.src);', (truckSpeed*9));
    truckSmokeID[17] = window.setTimeout('PicShow("TruckSmoke1", nullPre.src);', (truckSpeed*10));
    if (life>0 || demo) {       // if game still running or demo running
        if (!missed) 
            truckSmokeID[18] = window.setTimeout('MarioRest();', (truckSpeed*10))
        else  { 
            truckSmokeID[18] = window.setTimeout('EmptyTruck();', (truckSpeed*5));
            missedWhileLoading = true;
        };
        truckSmokeID[19] = window.setTimeout('PicShow("Truck", truckPre.src); if(missedWhileLoading) pause=0; if(missedWhileLoading) missedWhileLoading=false;', (truckSpeed*14) );	// show truck, end of pause, game goes on
    };
};

// drive loaded truck away
function DriveTruckAway () {
    console.log("------------------------------------------------------------------------------------------------------------------------------------");
    if (truckSmokeID[20]) {
        clearTimeout(truckSmokeID[20]);	// if demo still planned to start stop that plan to avoid double run
        truckSmokeID[20] = null;
    };
    if (demoID) {
        clearTimeout(demoID);	// if demo still planned to start stop that plan to avoid double run
        demoID = null;
    };
    if (demo) pause = 16
    else {
        pause = 100;	// wait for end of previous action and/or animation
        if (life>0) DriveBonus(10); // add 10 bonus points to score if game still running
    };
    if (!missed) marioRest = 1;      // Mario deserves a moment of rest after fully loading a truck
    PicShow("TruckDriver", nullPre.src);        // hide truck driver again
    truckSmokeID[20] = window.setTimeout("Driving()", 1000);     // animating let the truck drive off
}; 

// remove all games from the truck
function EmptyTruck () {
    for (i=21 ; i<27 ; i++) {
        gwCase[i] = 0;
    };
    loaded = false;     // truck no longer fully loaded
};

// remove the truck & all gwCasees on the truck 
function EmptyTruckPic () {
    PicShow("Truck", nullPre.src);
    for (i=21 ; i<27 ; i++) {
        PicShow("GwCase"+eval(i)+"", nullPre.src);
    };
};

// if missed gwCese or Mario @ index place
function Failed (index) {
    var failTimer;
    if (index&&!missed) {	// position Mario falling and not already a miss 
        AllStop();      // stop game if playing and reset all ID's
        missedPos = index;       // missed position 
        missed = true;
        pointsBonus = false;
        life--;         // one life less
        if (index<10 && index!=4) {
            // hide Mario & hid arms on previous position
            PicShow("Mario"+eval(index)+"", nullPre.src);
            MarioArmsHide();
            PlaySound("fall_", vlm);    // sound of falling Mario @ indes position
            // animate landing mario wirh landing sound after half a second
            failedID = window.setTimeout('PlaySound("failed_mario_", vlm); PicShow("MarioFall4", marioFallPre[4].src);PicShow("MarioFall"+eval(pos)+"", nullPre.src);', 500);
            failTimer = 1200;   // time needed for falling Mario animation
            runTime = 0;	// indicates that Mario left the building in an ambulance
            // show falling Mario @ right place according to the index
            if (index==1) { // Mario falling @ top left position
                pos = 1;
            };
            if (index==6) { // Mario falling @ center left position
                pos = 2;	// Mario's falling position to hide @ Mario's landing
            };
            if (index==5) { // Mario falling @ center right position
                pos = 3;	// Mario's falling position to hide @ Mario's landing
            };
            if (index==8) { // Mario falling @ bottom left position
                pos = 4;	// Mario's falling position to hide @ Mario's landing
                if (gwCase[20]) {	// if gwCase20 present
                    gwCaseHold = 0;	// Masio was carrying gwCase20 & has thrown it on the truck
                    gwCase[20] = 0;     // holding gwCase gone & dropped on the truck
                    // hide the gwCase Mario was holding while falling to animate it been thrown on the truck
                    PicShow("GwCase20", nullPre.src);     
                    LoadTruck();	// still throwing it on the truck while falling
                    if (loaded) DriveTruckAway();	// if truck fully loaded, the truck drives off
                };
                PicShow("MarioFall4", marioFallPre[4].src); // being so close to the ground Mario lands immediately
            } else PicShow("MarioFall"+eval(pos)+"", marioFallPre[pos].src);       // show Mario falling @ falling position
        } else {
            failedBlink = 3;    // times of blinking to indicate which gwCase failed just before crash
            PlaySound("failed_box_", vlm);      // sound of failure
            FailedBlink(index);    // start the blinking to indicate which gwCase failed just before crash
            failTimer = 4000;   // time needed for falling gwCase animation
        };
        gameID = window.setTimeout("Missed(missedPos)", failTimer);	// after some time add miss to missed box, clear crash/fall pics & go on
    };
};

// let score blink while score over 300 and no miss lost
function FailedBlink (index) {
    missed = true;
    if (failedID) {
        clearTimeout(failedID);  // reset previous ID to prevent double activation
        failedID = null;
    };
    if (failedBlink) {      // blinking missed gwCase not ended yet
        failedBlink--;  // one time less to blink gwCase
        PicShow("GwCase"+eval(index)+"", nullPre.src);	// hide missed gwCase again
        failedID = window.setTimeout("FailedBlinkBack("+index+")", failedBlinkSpeed);     // show missed gwCase again and repeat
        PlaySound("failed_box_", vlm);
    } else {
        PlaySound("failed_mario_", vlm);
        PicShow("GwCase"+eval(index)+"", nullPre.src);	// hide missed gwCase again
        // show crashed gwCase according to fail position
        if (index==4 || index==18) {
            PicShow("Crash2", crashPre[2].src);
        };
        if (index==11) {
            PicShow("Crash1", crashPre[1].src);
        };
        failedID = window.setTimeout("BossMad()", failedBlinkSpeed);    // animate  mad boss & guilty Mario 
    };
};

// show missed gwCase again and repeat
function FailedBlinkBack (index) {
    PicShow("GwCase"+eval(index)+"", gwCasePre[index].src);	// show missed gwCase again
    failedID = window.setTimeout("FailedBlink("+index+")", failedBlinkSpeed);     // repeat
};

// next move of game
function GameGo () {
    var counter = 0;    // loop counter to avoid loop from getting stuck by running for ever if last add was delayed
    if (gameID) {
        clearTimeout(gameID);	// stop previoius ID to avoid possible double call
        gameID = null;
    };
    if (!pause && !scoreBonusPause) {   // if no game or score pause set
        if (sequence<3) sequence++      // next game sequence if sequence not finished
        else {
            sequence = 1;      //  else back to first if game sequence finished
            NextGwCase();
        };
        GwCaseMove();   // move the sequenced line of gwCases on the conveyor belt
        if (GwCasePresent(sequence)) PlaySound("move_box_", vlm);       // play moving sound if a gwCase present on that piece of the conveyor belt
    } else {
        if (pause) pause--; // decrease game pause time if present
        if (scoreBonusPause) scoreBonusPause--; // decrease score pause time if present
    };
    if (game!=3) gameID = window.setTimeout("GameGo()", gameSpeed);    // if not game over, next step in gameSpeed milliseconds
};

// resume game after pause for indicating miss or bonus
function GameGoNext () {
    if (actionID) {
        clearTimeout(actionID);	// reset ID for hitting delay if exists
        actionID = null;
    };
    if (game==1||game==2) {     // if game a or b still running
        if (gameID) {
            clearTimeout(gameID);	// reset ID for next step to prevent double call
            gameID = null;
        };
        if (life>0) {   // if at least one life left
            missed = false;     // reset previous miss indicator
            if (!loaded && !missedWhileLoading) {
                pause = 0;      // end game pause if truck not driving off
                gameID = window.setTimeout("GameGo()", gameSpeed);    // next step in gameSpeed milliseconds
            } else {
                gameID = window.setTimeout("GameGoNext()", gameSpeed);    // next try in gameSpeed milliseconds
            };
        } else demoID = window.setTimeout("MainTimeStart()", 60000);	// if game no longer running, start demo after a minute  
    };
};

// initiate common game settings @ start of games
function GameSet () {
    ResetAll();	// clear all pictures & variables
    life = 3;	// maximum number of lives left
    missed = false;     // no previous misses
    scorePrev = 6;  // previous set score trigger for new calculated number of figures present @ sequence
    MainPicturesGame();	// show default pictures @ start of the game & show score
    gwCase[0] = 1;      // set first gwCase
};

// autofunction to go to bottom locationfunction for demo
function GoToBottom () {
    switch (pos) {
        case 0 :        // Mario outside the building
            pos = 2;	// Mario inside the factory @ the door
            MarioShow();
            break;
        case 1 :        // Mario @ the top left position
            GoRight();
            break;
        case 2 : case 3 :	// Mario inside the factory @ the door or on the top ladder
            GoDown();
            break;
        case 4 : case 5 :       // Mario @ center middle or right position
            GoLeft();
            break;
        case 6 :        // Mario @ center left position
            GoDown();
            break;
        case 7 :        // Mario @ bottom middle position
            if (sequence==18) { // if catching gwCase
                PicShow("ArmsUp7", armsUpPre[7].src);
                PicShow("ArmsDown7", nullPre.src);
            };
            if (sequence==19) { i       // if gwase has been caught
                PicShow("ArmsUp7", nullPre.src);
                PicShow("ArmsDown7", armsDownPre[7].src);
            };
            break;
        case 8 :        // Mario @ bottom left position
            if (sequence==20) { // if holfding gwCase
                PicShow("ArmsUp8", armsUpPre[8].src);
                PicShow("ArmsDown8", nullPre.src);
            };
            if (sequence==21) { // throwing gwCase on truck
                PicShow("ArmsUp8", nullPre.src);
                PicShow("ArmsDown8", armsDownPre[8].src);
            } ;
            break;
        default :
    };	
};

// autofunction to go to center locationfunction 
function GoToCenter () {
    switch (pos) {
        case 0 :        // Mario outside the building
            pos = 2;	// Mario inside the factory @ the door
            MarioShow();
            break;
        case 1 : case 4 : case 6 : case 8 :     // Mario @ the top left position or center middle or left position or bottom left position
            GoRight();
            break;
        case 2 : case 3 :	// Mario inside the factory @ the door or on the top ladder
            GoDown();
            break;
        case 5 :       // Mario @ center right position
            if (sequence==11)  {        // if catching gwCase
                PicShow("ArmsUp5", armsUpPre[5].src);
                PicShow("ArmsDown5", nullPre.src);
            };
            if (sequence==12) { // if gwase has been caught
                PicShow("ArmsUp5", nullPre.src);
                PicShow("ArmsDown5", armsDownPre[5].src);
            };
            break;
        case 7 :        // Mario @ bottom middle position
            GoUp();
            break;
        default :
    };	
};

// autofunction to go to top locationfunction 
function GoToTop () {
    switch (pos) {
        case 0 :        // Mario outside the building
            pos = 2;	// Mario inside the factory @ the door
            MarioShow();
            break;
        case 1 :        // Mario @ the top left position
            if (sequence==4) {  // if catching gwCase
                PicShow("ArmsUp1", armsUpPre[1].src);
                PicShow("ArmsDown1", nullPre.src);
            };
            if (sequence==5) {  // if gwase has been caught
                PicShow("ArmsUp1", nullPre.src);
                PicShow("ArmsDown1", armsDownPre[1].src);
            };
            break;
        case 2 : case 5 :	// Mario inside the factory @ the door or the center right position
            GoLeft();
            break;
        case 3 : case 4 : case 7 :       // Mario @ top ladder or center middle or right position or bottom middle position
            GoUp();
            break;
        case 6 : case 8 :        // Mario @ center left position or bottom left position
            GoRight();
            break;
        default :
    };
};

// drop game @ position i & animate it falling onto the truck
function GwCaseDrop (i) {
    var row = i%2?0:1;  // odd/even row
    var truckLoadSpeed;
    // determine the speed for loading the truck
    if (demo) truckLoadSpeed = 1000;    
    else truckLoadSpeed = 300;
    GwCaseDropShow(25+row);     // top gwCase of odd/even row on truck
    if (i<25) gwCaseID[1] = window.setTimeout("GwCaseDropShow("+(23+row)+")", truckLoadSpeed);  // next
    if (i<23) gwCaseID[2] = window.setTimeout("GwCaseDropShow("+(21+row)+")", (truckLoadSpeed*2));      // next
};

// show the gw case dropping and hide the previous one
function GwCaseDropShow (place) {
    if (place<25) PicShow("GwCase"+eval(place+2)+"", nullPre.src);      // hide previous
    PicShow("GwCase"+eval(place)+"", gwCasePre[place].src);     // show next
};

// hide all catching & holding gwCases @ the bottom of the factory
function GwCaseHoldReset () {
    for (i=18 ; i<21 ; i++) {
        PicShow("GwCase"+eval(i)+"", nullPre.src);
        gwCase[i] = 0;
    };
    gwCaseHold = false;
};

// check & count if any gwCases already running on that conveyor belt
function GwCasePresent (row) {
    var gwCasePresent = 0;
    switch (row) {      // check & count if any gwCases already running on ...
        case 0 :        // all conveyor belts
            for (i=0 ; i<21 ; i++) if (gwCase[i]) gwCasePresent++;
            break;
        case 1 :        // top conveyor belt
            for (i=0 ; i<5 ; i++) if (gwCase[i]) gwCasePresent++;
            break;
        case 2 :        // center conveyor belt
            for (i=5 ; i<12 ; i++) if (gwCase[i]) gwCasePresent++;
            break;
        case 3 :        // bottom conveyor belt
            for (i=12 ; i<19 ; i++) if (gwCase[i]) gwCasePresent++;
            break;
        default :
    };
    return gwCasePresent;       // result
};
            
// load the completed game in the truck
function LoadTruck () {
    gameLoaded = false; // gwCase not yet loaded @ start
    for (i=21 ; i<27 ; i++) {   // drop gwCase @ next empty spot
        if (!gwCase[i] && !gameLoaded) {        // next empty spot found & gwCase not yet dropped
            GwCaseDrop(i);      // drop gwCase @ next empty spot
            gwCase[i] = 1;      // gwCase landed
            gameLoaded = true;  // next empty spot found & gwCase loaded
        };
        if (gwCase[26] && gwCase[25]) { // if both top positions occupied by gwCase
            loaded = true;      // truck fully loaded
        } else if (gwCase[25] && gwCase[24]) {  // if last gwCase not yet loaded
            PicShow("TruckDriver", truckDriverPre.src);     // show driver
            DriverStartUp();        // driver starts up the truck and let it run
        };
    };
    // determin the duration of the pause till game continues
    if (demo) 
        if (loaded) pause = 6
    else pause = 3;
};

// button pressed to see high score & play game A
function MainGameA () {
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // game variables reset
        gameSpeed = 350;       // in milliseconds
        gameSpeedMin = 350;       // in milliseconds
        gameSpeedMax = 250;	// maximum speed for game sequence timer
        if (demo) {
            demo = false;		// once this key is hit, the demo is turned off
            if (demoID) {
                clearTimeout(demoID);   // prevent demo from restarting if planned
                demoID = null;
            };
        };
        ShowSndIcns();      // show alarm indicator if alarm is set to on
        HighScoreShow(1);        // show highest score for game A since this browser tab was opened
    };
};

// "game A" button released so actually play game A
function MainGameAGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        if (gameID) {
            clearTimeout(gameID);	// stop the game's possible double call
            gameID = null;
        };
        PlaySound("click_", vlm);	// click sound for push button
        sequence = 1;      // first sequence to start
        game = 1; // indicating game A
        PicShow("Game1", gamePre[1].src);	// show "GAME A" onscreen
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", gameSpeed);    // start running game in gameSpeed milliseconds
        console.log("------------------------------------------------------------\x1B[31mNew GAME "+(game==1?"A":"B")+"\x1B[30m--------------------------------------------------------------");
    };
};

// button pressed to see high score & play game B
function MainGameB () {
    if (alarm) TimeAlarmOff();	// stop alarm if running
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // game variables reset
        gameSpeed = 300;       // in milliseconds
        gameSpeedMin = 300;       // in milliseconds
        gameSpeedMax = 230;	// maximum speed for game sequence timer
        if (demo) {
            demo = false;		// once this key is hit, the demo is turned off
            if (demoID) {
                clearTimeout(demoID);   // prevent demo from restarting if planned
                demoID = null;
            };
        };
        ShowSndIcns();      // show alarm indicator if alarm is set to on
        HighScoreShow(2);        // show highest score for game B since this browser tab was opened
    };
};

// "game B" button released so actually play game B
function MainGameBGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        if (gameID) {
            clearTimeout(gameID);	// stop the game's possible double call
            gameID = null;
        };
        PlaySound("click_", vlm);	// click sound for push button
        sequence = 1;      // indicates game start
        game = 2; // game B
        PicShow("Game2", gamePre[2].src);	// show "GAME B" onscreen
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", gameSpeed);    // start running game in gameSpeed milliseconds
        console.log("------------------------------------------------------------\x1B[31mNew GAME "+(game==1?"A":"B")+"\x1B[30m--------------------------------------------------------------");
    };
};

// stop game if running + clear all
function MainGameOver () {
    AllStop();  // stop game if playing and reset all ID's
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

// let Mario rest after truck fully loaded 
function MarioRest () {
    if (marioResetID) {
        window.clearTimeout(marioResetID);	// reset possible previous ID for resetting Mario
        marioResetID = null;
    };
    if (marioRestID) {
        window.clearTimeout(marioRestID);	// reset possible previous ID for Mario resting delay & animation
        marioRestID = null;
    };
    marioRest = 1;      // to animate Mario resting
    marioResting = 1;   // to indicate Mario is resting
    prevPos = pos;	// remember previous position
    pos = 9;    // resting place @ the bottom right position
    GwCaseReset();      // reset & clear first three of the upcomming gwCases per conveyor belt after fail or finished truck 
    marioRestID = window.setTimeout('MarioShow();MarioRestAnimate();', 1000);   // start animation in a second
    marioResetID = window.setTimeout('MarioRestEnd()', 5000);   // end animation in 5 seconds
};

// animate Mario resting after full load
function MarioRestAnimate () {
    if (marioRestID) {
        window.clearTimeout(marioRestID);	// reset possible previous ID for Mario resting animation to avoid double call
        marioRestID = null;
    };
    if (marioResting) { // if Mario is still resting
        if (marioRest==1) {
            marioRest = 2;      // indicate to inhale next time
            PicShow("Mario9", marioPre[9].src); // show resting Mario exhaling & puff
        } else {
            marioRest = 1;      // indicate to exhale & puff next time
            PicShow("Mario9", mario9IPre.src); // show Resting Mario inhaling
        };
        marioRestID = window.setTimeout('MarioRestAnimate()',1000);     // repeate animation in a second
    };
};

// boss gives Mario instructions after resting
function MarioRestEnd () {
    var restEndTime = 2000;     // two seconds time to show Mario receiving instructions from boss
    if (marioRestID) {
        clearTimeout(marioRestID);  // stop next animation of Mario resting if already initiated
        marioRestID = null;
    };
    marioRest = 0;      // no animation of Mario resting
    marioResting = 0;   // to indicate Mario is no longer resting
    PicShow("Mario9", nullPre.src);     // hide resting Mario
    PicShow("Mario10", mario10UPre.src);        // showing Mario receiving instructions from boss
    PicShow("Boss", bossPre.src);       // show boss
    PicShow("ArmsUpBoss", armsUpBossPre.src);   // show upper arm boss giving Mario instructions
    // hide boss & Mario receiving instructions after restEndTime milliseconds
    marioRestID = window.setTimeout('MarioRestEndReset()', restEndTime);	// next step after 7 seconds, then end of pause, game goes on
};


// hide boss giving Mario instructions & go on
function MarioRestEndReset () {
    PicShow("Mario10", nullPre.src); 
    PicShow("Boss", nullPre.src); 
    PicShow("ArmsUpBoss", nullPre.src); 
    MarioReset(); 
    pause = 0;	// end of pause, game goes on
};

// let misses blink & score of 300 or 500 if misses present
function MissBlink () {   
   if (missedID) {
        window.clearTimeout(missedID);	// reset previous call if still active
        missedID = null;
    };
    if (game==1 || game==2) {	// if game running
        if (missedBlink<4) {	// number of blinking the misses
            MissHide(); // hide misses in the box
            Beep();
            missedID = window.setTimeout("MissedShow()", blinkSpeed/2); // show delayed all misses in the box & miss text again
            failedID = window.setTimeout("MissBlink()", blinkSpeed);    // repeat
        } else {
            MissHide(); // hide misses in the box
            Beep();
        };
    missedBlink++;      // count blinking
    };
};

// remove "MISS" text & reset lives & misses
function MissClear () {
    for (i=1 ; i<4 ; i++) PicShow("Miss"+eval(i)+"", nullPre.src);      // hide the three miss pics
    MissTextHide ();    // remove "MISS" text
    life = 3;   // reinstate all lives
    missed = false;     // no more current misses
};

// show misses in missed box, clear crash/fall pics & go on
function Missed (index) {
    if (game==1 || game==2) {	// if game playing
        if (missedID) {
            clearTimeout(missedID);	// reset previous call if still active
            missedID = null;
        };
        MissedShow();	// show misses in the box
        CrashClear();   // hide crashed gwCase and fallen Mario
        if (life>0) {   // if lives left
            GwCaseReset();// reset & clear first three of the upcomming gwCases per conveyor belt
            GameGoNext();       // resume game after pause for indicating miss
        } else {
            demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute if no lives left
            game = 3;   // game over indication
            PlaySound("game_over_", vlm);
        };
        if (index<10 && index!=4) pos = 0;      // 
        gwCaseHold = 0; // no longer holding any gwCase
        if (!GwCasePresent(0)) gwCase[0] = 1;           // set first gwCase to go if non present
    };
};

// show misses @ "miss" text
function MissedShow () {
    for (i=1 ; i<(4-life) ; i++) PicShow("Miss"+eval(i)+"", missPre.src);      // show number of misses by miss pics
    if (3-life) PicShow("Misstxt", missTxtPre.src);     // show "MISS" text
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// determin if a next gwCase is allowed to be started
function NextGwCase () {
    var gameRandom = 5; // default random range to 5
    newGwCase = 0;      // no new gwCase randomized yet
    gwCasePresent = GwCasePresent(0);   // count all gwCases present
    nextGwCaseAllowed = NextGwCaseAllowed();    // determin if a next gwCase is allowed to be started
    // determin how much gwCases allowed & gap in between on screen @ the same time by game & score
    if ((game==1 && score<6) || (game==2 && score<3)) {
        maxGwCaseAllowed = 1;
        gwCaseGap = 0;
    } else {
        if ((game==1 && score<20) || (game==2 && score<10)) {
            maxGwCaseAllowed = 2;
            gwCaseGap = 1;
        } else {
            if ((game==1 && score<40) || (game==2 && score<20)) {
                maxGwCaseAllowed = 3;
                newGwCase = 1;
            } else {
                if ((game==1 && score<63) || (game==2 && score<39)) {
                    gameRandom = 4;
                } else {
                    if ((game==1 && score<80) || (game==2 && score<50)) {
                        gameRandom = 3;
                    } else {
                        if ((game==1 && score<150) || (game==2 && score<99)) {
							maxGwCaseAllowed = 4;
                            gameRandom = 4;
                        } else {
                            if ((game==1 && score<165) || (game==2 && score<111)) {
                                gameRandom = 3;
                            } else {
                                if ((game==1 && score<181) || (game==2 && score<122)) {
                                    gameRandom = 2;
                                } else {
                                    if ((game==1 && score<214) || (game==2 && score<155)) {
                                        maxGwCaseAllowed = 5;
                                        gameRandom = 5;
                                    } else {
                                        if ((game==1 && score<286) || (game==2 && score<188)) {
                                            gameRandom = 4;
                                        } else {
                                            if ((game==1 && score<320) || (game==2 && score<210)) {
                                                gameRandom = 3;
                                            } else {
                                                if ((game==1 && score<354) || (game==2 && score<232)) {
                                                    gameRandom = 2;
                                                } else if ((game==1 && score>500) || (game==2 && score>350)) {
                                                    maxGwCaseAllowed = 6;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
    // end determin how much gwCases allowed on screen @ the same time 
    if (game==2 && score && score<15) newGwCase = 1       // always get new third gwCase @ GAME B
    if (game==1 && score>6 && score<9) newGwCase = 1       // always get new fourth gwCase @ GAME A
    else if (!newGwCase) newGwCase = Math.floor(gameRandom*Math.random())+1;       // get new gwCase randomly
    if (!gwCasePresent || (gwCasePresent==1&&gwCaseHoldPause==1) || (newGwCase==1&&nextGwCaseAllowed)) {        // if conditions ok
        gwCase[0] = 1;  // set next gwCase
        gwCaseHoldPause = 0;    // reset the pause after Mario caught a gwCase @ the bottom before the next gwCase appeares on top
        if (testRun==0) console.log("  00 |  01 |  02 |  03 |  04 |  05 |  06 |  07 \u2588  08 \u2588  09 |  10 |  11 \u2588  12 \u2588  13 |  14 |  15 |  16 |  17 \u2588  18 \u2588  19 |  20 ");
        console.log("  "+gwCase[0]+"  |  \x1B[31m"+gwCase[1]+"\x1B[30m  |  "+gwCase[2]+"  |  "+gwCase[3]+"  |  "+gwCase[4]+"  |  \x1B[34m"+gwCase[5]+"\x1B[30m  |  \x1B[31m"+gwCase[6]+"\x1B[30m  |  \x1B[31m"+gwCase[7]+"\x1B[30m  \u2588  \x1B[35m"+gwCase[8]+"\x1B[30m  \u2588  "+gwCase[9]+"  |  "+gwCase[10]+"  |  "+gwCase[11]+"  \u2588  \x1B[35m"+gwCase[12]+"\x1B[30m  \u2588  \x1B[34m"+gwCase[13]+"\x1B[30m  |  \x1B[31m"+gwCase[14]+"\x1B[30m  |  \x1B[31m"+gwCase[15]+"\x1B[30m  |  \x1B[34m"+gwCase[16]+"\x1B[30m  |  \x1B[34m"+gwCase[17]+"\x1B[30m  \u2588  \x1B[35m"+gwCase[18]+"\x1B[30m  \u2588  "+gwCase[19]+"  |  "+gwCase[20]+"     -"+testRun+"-    gwCasePresent : "+gwCasePresent+"  -  maxGwCaseAllowed : "+maxGwCaseAllowed+"    score : "+score+"     "+(life==1?"\x1B[31m":life==3?"\x1B[32m":"\x1B[34m")+"life : "+life+"\x1B[30m    gameSpeed : "+gameSpeed+"    diff : "+diff+"    |");
        if (testRun==20) testRun = 0
        else testRun++;
    };
};

// determin if a next gwCase is allowed to be started
function NextGwCaseAllowed () {
    var nextGwCaseAllowed = false;      // no next gwCase allowed yet
    // allow next gwCase to be set if conditions are met
    if (gwCaseGap==0) { 
        if ((gwCase[1]==0) && (gwCase[2]==1) && (gwCasePresent<maxGwCaseAllowed) && PlacesChecked()) nextGwCaseAllowed = true;
    } else {
        if ((gwCase[1]==0) && (gwCasePresent<maxGwCaseAllowed) && PlacesChecked()) nextGwCaseAllowed = true;
    };
    return nextGwCaseAllowed;   // give result
};

// check if no place occupied that prevents gwCase to start without making it impossible to not fail the game
function PlacesChecked () {
    placesChecked = false;      // not allowed occupied places to start new gwCase not ok
    if (!PlacesFirstThreeChecked() || (game==2 && score<70) || (game==1 && score<140)) {	// no 3 gwCases on a row after scored 140 @ game A àr 70 @ gameB
        // determine difficulties according to game & score
        if ((game==2 && score>250) || (game==1 && score>500)) {
            diff = 8;
            if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[14] && !gwCase[15]) placesChecked = true;
        } else {
            if (game==2 && score>200 || (game==1 && score>400)) {
                diff = 7;
                if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[14] && !gwCase[15]) placesChecked = true;
            } else {
                if (game==2 && score>150 || (game==1 && score>300)) {
                    diff = 6;
                    if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[14] && !gwCase[15] && !gwCase[16]) placesChecked = true;
                } else {
                    if (game==2 && score>110 || (game==1 && score>220)) {
                        diff = 5;
                        if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[13] && !gwCase[14] && !gwCase[15] && !gwCase[16]) placesChecked = true;
                    } else {
                        if (game==2 && score>80 || (game==1 && score>150)) {
                            diff = 4;
                            if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[13] && !gwCase[14] && !gwCase[15] && !gwCase[16] && !gwCase[17]) placesChecked = true;
                        } else {
                            if (game==2 && score>40 || (game==1 && score>100)) {
                                diff = 3;
                                if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[13] && !gwCase[14] && !gwCase[15] && !gwCase[16] && !gwCase[17] && !gwCase[18]) placesChecked = true;
                            } else {
                                if (game==2 && score>12 || (game==1 && score>50)) {
                                    diff = 2;
                                    if (!gwCase[1] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[12] && !gwCase[13] && !gwCase[14] && !gwCase[15] && !gwCase[16] && !gwCase[17] && !gwCase[18]) placesChecked = true;
                                } else {
                                    diff = 1;
                                    if (!gwCase[1] && !gwCase[5] && !gwCase[6] && !gwCase[7] && !gwCase[8] && !gwCase[12] && !gwCase[13] && !gwCase[14] && !gwCase[15] && !gwCase[16] && !gwCase[17] && !gwCase[18]) placesChecked = true;
                                };
                            };
                        };
                    };
                };
            };
        };
        // end determine difficulties according to game & score
    };
    return placesChecked;   // give result
};

// check if no place occupied that prevents gwCase to start without making it impossible to not fail the game
function PlacesFirstThreeChecked () {
    var placesFirstTwoOnThreeChecked = false;
    if (gwCase[2] && (gwCase[4]||gwCase[5])) placesFirstTwoOnThreeChecked = true
    return placesFirstTwoOnThreeChecked;
};

// speeds up the game with given value
function SpeedUp (speed) {
    var prevSpeed = gameSpeed;  // save previous speed for logging...
    if (gameSpeed>gameSpeedMax) gameSpeed -= speed; // if not @ max speed, speed up
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions
