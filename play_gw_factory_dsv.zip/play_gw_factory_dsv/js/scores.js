/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow (game) {
    ScoreShow(highScore[game]);
};

// add certain points to score
function ScoreAdd (points) {
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause stopper
        pauseID = null;
    };
    for (var a=0 ; a<points ; a++) {
        score++;
        if ((score%100)==0) SpeedReset();       // reset speed every 100 points
        if ((score%500)==0) SpeedUp(20);       // reset speed every 100 points
        if ((score%1000)==300 || (score%1000)==500) {   // bonus @ 300/500 points
            ScoreShow(score);
            if (!pause) pause = 5;
            scoreBonusPause = 5;
            missedBlink = 1;    // for blinking score @ bonus or misses to be reset
            if (life==3) {      // if no life lost 
                pointsBonus = true;     // bonus earned
                scoreBonus = 1;	// score bonus IS already added
            } else MissReset(); // else reset all misses
            ScoreBlink();
            pauseID = window.setTimeout("GameGoNext()", 1500);  // resume game after 2 seconds
        };
        if (score%10==0/* || (pointsBonus&&(score-1)%10==0)*/) {     // every 10 points let goombas go faster
            SpeedUp(5);
        };
    };
    if (!(score%1000)) gameSpeedMax = gameSpeedMax - (5*(score/1000));
    if (score>highScore[game]) highScore[game] = score;       // if passed highscore @ normal game set new highscore
    if (pointsBonus&&!scoreBonus) {
        scoreBonus = 1;	// score bonus IS already added
        ScoreAdd(points);
    } else scoreBonus = 0;	// score bonus not added
    ScoreShow(score);
};

// let score blink while score over 300 and no miss lost
function ScoreBlink () {
    if (scoreBonusID) {
        clearTimeout(scoreBonusID);  // stop pause trigger
        scoreBonusID = null;
    };
    if (game==1 || game==2) {	// game running
        if (pointsBonus) {      // bonus for reaching 300/500 without any misses
            ScoreHide();
            blinkID = window.setTimeout("ScoreUnHide()", blinkSpeed);      // unhide score delayed
            blinkID = window.setTimeout("ScoreBlink()", 2*blinkSpeed);     // repeat
        } else ScoreUnHide();
        if (missedBlink<3) {	// number of beeps to indicate bonus
            Beep();
            scoreBonusID = window.setTimeout("Beep()", 500);        // play second beep delayed half a second
            missedBlink++;      // count beep
        };
    };
};

// hide score from screen
function ScoreHide () {
    $("#Num1").addClass("hidden");
    $("#Num2").addClass("hidden");
    $("#Num3").addClass("hidden");
    $("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
    $("#Num1").removeClass("hidden");
    $("#Num2").removeClass("hidden");
    $("#Num3").removeClass("hidden");
    $("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
    if (scoreTS>999) 
        if (Math.floor((scoreTS/1000)%10)==0) PicShow("Num1", nullPre.src)
        else PicShow("Num1", numPre[Math.floor((scoreTS/1000)%10)+1].src);
    else PicShow("Num1", nullPre.src);
    if (scoreTS>99) 
        if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0) PicShow("Num2", nullPre.src)
        else PicShow("Num2", numPre[Math.floor(scoreTS%1000/100)+1].src);
    else PicShow("Num2", nullPre.src);
    if (scoreTS>9)  
        if (scoreTS>9999 && Math.floor((scoreTS/1000)%10)==0 && Math.floor(scoreTS%1000/100)==0  && Math.floor(scoreTS%100/10)==0) PicShow("Num3", nullPre.src)
        else PicShow("Num3", numPre[Math.floor(scoreTS%100/10)+1].src);
    else PicShow("Num3", nullPre.src);
    PicShow("Num4", numPre[(scoreTS%10)+1].src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
