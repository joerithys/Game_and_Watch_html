//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
	if (gameID) {
		clearTimeout(gameID);	// stop the game if running
		gameID = null;
	};
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (game!=4||!demo) {	  // if MainTime not yet running 
		StopAllSound();
		PlaySound("click_", vlm);	// click sound for push button
		MainTimeStart(); // show current time & demo
	};
};
	
// show current time & demo
function MainTimeStart () {
	ResetAll();	// clear all pictures & variables
	MainPicturesDefault();	// show default start pictures
	ShowSndIcns();	  // show if alarm is set on or not
	TimeShow();	// show current time
	demo = true;	 // to show demo
	game = 4;	// clock running
	demoID = window.setTimeout("Demo()", 1000);	// next step after a second
};

// get current time
function Time () {
	today = new Date();
	hour = today.getHours();
	min = today.getMinutes();
	sec = today.getSeconds();
};

// show current time
function TimeShow () {
	TimerReset();
	Time();	// get current time
	if (!$('#ButTime:active').length&&!TKeyPressed) {	// if time button no longer pressed (else show alarm time)
		TimeShowOnScreen(min, hour);	// show the current time
	}; 
	timeID = window.setTimeout("TimeShow()", 1000);	 // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen(min, hour) {
	// set integer to time digits
	if (hour<10) PicShow("Num1", nullPre.src)
	else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
	PicShow("Num2", numPre[(hour%10)+1].src);
	PicShow("Num3", numPre[Math.floor(min/10)+1].src);
	PicShow("Num4", numPre[(min%10)+1].src);
	PicShow("NumColon", numColonPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions

