//Product:	Covid19 HTML - Silver Screen (Nintendo) Simulator
//Version:	1.1
//Started:	13.04.2020
//Last update:	31.03.2021
//Author:	Flyzy (Joeri Thys)
//Original G&W:	Nintendo Co. Ltd
//Credits:
//Design, layout and artwork by Lee Robson (hydef)
//Based on scans by Sean Riddle
//Colour background by DarthMarino


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;       // indicates if demo is running or not
var demoID;     // ID for timeout demo autostart after last handling
var lauID;	// ID for timeout left arm up reset
var rauID;	// ID for timeout right arm up reset
var lluID;	// ID for timeout left leg up reset
var rluID;	// ID for timeout right leg up reset

var acl = false;	// for showing acl full if pressed twice fast
var aclID;	// ID to reset acl variable
var color = false;           // indicator to show/hide colored background
var failed = false;	
var game = 0;   // 0-no-game-all-pictures; 1-gameA; 2-gameB; 3-game-over; 4-clock; 
var gameID;	// ID for timeout game sequence
var gameShowID;	// ID for timeout game showing sequence
var gameRandom = 4;	// 4 tones
var gameResetID;        // ID for repeat indicator
var gameSpeedMinimum;	// minimum speed for game sequence timer
var gameSpeedMaximum = 40;	// maximum speed for game sequence timer
var gameSpeed;	// speed for game sequence timer
var mainTimePause = false;	// to prevent MainTime to run before failed flag_05-sound ended
var newTone;
var num;	// block number to present
var numBlockID;	// ID to reset numblocks
var pause = false;	
var pauseID;	// ID to pause the game temporarily (pause stopper)
var repeated = true;	// indicates if shown sequence/number block was repeated
var tones = [];	// array of tones figures
var tonesCount;	// number of tones in sequence @ game a
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var dir;	// direction arm/leg up or down
var keyLeftUp = false;
var keyLeftDown = false;
var keyRightUp = false;
var keyRightDown = false;
var keyPressed = false;	// indicates if a previuos key was already pressed to avoid double entries

var prefSound = 1;      // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var highScore = new Array();	// for highest scores for games a & b
var score = 0;	// score (all beneath 100) at init
var sequence = 1;	// for demo timer

var timeID;     // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var vlm = 1;            // sound volume 0.01-1
var preVlm = vlm;       // previous sound volume 0.01-1 to set when sound turned on again
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables


//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
    codeCurrent = e.keyCode;		// for reading names & game keys
    e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
    switch (e.key) {
        case "e": case "E":	// left up key
            // show left upper button pressed
            document.images['Left Up'].src = 'img/case/buttons/1_flat.png';     
            if (!keyPressed) FlagmanShow(1);    // if no key already pressed show left arm up
            keyPressed = true;
            break;
        case "d": case "D":	// left down key
            // show left lower button pressed
            document.images['Left Down'].src = 'img/case/buttons/3_flat.png';     
            if (!keyPressed) FlagmanShow(3);    // if no key already pressed show left leg up
            keyPressed = true;
            break;
        case "o": case "O":	// right up key
            // show right upper button pressed
            document.images['Right Up'].src = 'img/case/buttons/2_flat.png';     
            if (!keyPressed) FlagmanShow(2);    // if no key already pressed show right arm up
            keyPressed = true;
            break;
        case "k": case "K":	// right down key
            // show right lower button pressed
            document.images['Right Down'].src = 'img/case/buttons/4_flat.png';     
            if (!keyPressed) FlagmanShow(4);    // if no key already pressed show right leg up
            keyPressed = true;
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" pressed
            // show game a button pressed
            document.images['Game A'].src = 'img/case/buttons/grey_1_flat.png';     
            if (!keyPressed) MainGameA(); // play Game A
            keyPressed = true;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" pressed
            // show game b button pressed
            document.images['Game B'].src = 'img/case/buttons/grey_2_flat.png';     
            if (!keyPressed) MainGameB(); // play Game B
            keyPressed = true;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            // show acl button pressed
			document.images['aclButton'].src = 'img/case/buttons/acl_push.png';
            TotalReset(); // show full sprites
            break;
        case"t": case"T":     // if "t" or "T" pressed
            // show time button pressed
            document.images['Time'].src = 'img/case/buttons/grey_3_flat.png';
            MainTime(); // show time & demo
            break;
        //test case buttons
        case "+":	// "+"-numpadkey
            if (vlm<1) {
                vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
                preVlm = vlm;
            };
                if (vlm==0.01)  SetSound(true);	// show sound turned on
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "-":	// "-"-key
            if (vlm>0) {
                vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
                preVlm = vlm;
            };
            if (vlm==0) SetSound(false);	// show sound turned off
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case "/":	// "/"-key
            if (vlm==0.3) vlm = 0.03
            else vlm = 0.3;
            PrefSoundShow();	// show volume indicator on screen for testing purposes if set
            break;
        case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
            prefSoundShow = !prefSoundShow;
            PrefSoundShow();	// show volume indicator on screen for testing purposes
            break;
        case String.fromCharCode(233): case "Control" :	// "Ctrl"-key
            color = !color;     // indicator to show/hide colored background
            InlayShow();	// switch background black/color
            break;
        case ")": case String.fromCharCode(219):
            zoomed = zoomed?0:1;
			$(function () {
				CheckSizeZoom()
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);
            break;
        default:
    };
    console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function (e) {
    // game and arrow keys
    switch (e.key) {
        case "e": case "E":	// left up key released
            // show left upper button default
            document.images['Left Up'].src = 'img/case/buttons/1.png';     
            if (lauID) {
                window.clearTimeout(lauID);	// clear ID if still running from FlagmanShow
                // start flag reset after half a second
                lauID = setTimeout("if (!failed) LeftArm('down')", 100);	
            };
            keyPressed = false;
            break;
        case "d": case "D":	// left down key released
            // show left lower button default
            document.images['Left Down'].src = 'img/case/buttons/3.png';     
            if (lluID) {
                window.clearTimeout(lluID);		// clear ID if still running from previous FlagmanShow
                // start flag reset after half a second
                lluID = setTimeout("if (!failed) LeftLeg('down')", 100);	
            };
            keyPressed = false;
            break;
        case "o": case "O":	// right up key released
            // show right upper button default
            document.images['Right Up'].src = 'img/case/buttons/2.png';     
            if (rauID) {
                window.clearTimeout(rauID);		// clear ID if still running from previous FlagmanShow
                // start flag reset after half a second
                rauID = setTimeout("if (!failed) RightArm('down')", 100);	
            };
            keyPressed = false;
            break;
        case "k": case "K":	// right down key released
            // show right lower button default
            document.images['Right Down'].src = 'img/case/buttons/4.png';     
            if (rluID) {
                window.clearTimeout(rluID);		// clear ID if still running from previous FlagmanShow
                // start flag reset after half a second
                rluID = setTimeout("if (!failed) RightLeg('down')", 100);	
            };
            keyPressed = false;
            break;
        case "1": case"a": case"A":     // if "1", "a" or "A" released
            document.images['Game A'].src = 'img/case/buttons/grey_1.png';     // show game a button default
            MainGameAGo(); // play Game A
            keyPressed = false;
            break;
        case "2": case"b": case"B":     // if "2", "b" or "B" released
            document.images['Game B'].src = 'img/case/buttons/grey_2.png';     // show game b button default
            MainGameBGo(); // play Game A
            keyPressed = false;
            break;
        case"r": case"R":     // if "r" or "R" pressed
            document.images['aclButton'].src = 'img/case/buttons/acl.png';     // show acl button default
            break;
        case"t": case"T":     // if "t" or "T" released
            document.images['Time'].src = 'img/case/buttons/grey_3.png';
            break;
        default:
    };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game 
$(document).ready(function () {
	$(function () {
		CheckSizeZoom()
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);
    $("#Flagman").focus(); // get focus on the game
    PicPreload();	// this function preloads all images to make them ready for use
    TotalReset();	// clear all and reset all on going to default and show default figures
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// left up button or -key pressed
function LeftArm (dir) {
    if (dir=="up") {
        PicShow("LeftArmUp", leftArmUpPre.src);
        PicShow("LeftArmDown", nullPre.src);
    } else {
        PicShow("LeftArmUp", nullPre.src);
        PicShow("LeftArmDown", leftArmDownPre.src);
    };
};

// left down button or -key pressed
function LeftLeg (dir) {
    if (dir=="up") {
        PicShow("LeftLegUp", leftLegUpPre.src);
        PicShow("LeftLegDown", nullPre.src);
    } else {
        PicShow("LeftLegUp", nullPre.src);
        PicShow("LeftLegDown", leftLegDownPre.src);
    };
};

// right up button or -key pressed
function RightArm (dir) {
    if (dir=="up") {
        PicShow("RightArmUp", rightArmUpPre.src);
        PicShow("RightArmDown", nullPre.src);
    } else {
        PicShow("RightArmUp", nullPre.src);
        PicShow("RightArmDown", rightArmDownPre.src);
    };
};

// right down button or -key pressed
function RightLeg (dir) {
    if (dir=="up") {
        PicShow("RightLegUp", rightLegUpPre.src);
        PicShow("RightLegDown", nullPre.src);
    } else {
        PicShow("RightLegUp", nullPre.src);
        PicShow("RightLegDown", rightLegDownPre.src);
    };
};

// show/hide figure on screen
function PicShow (id, name) {
    if (name) document.images[id].src = name;
};

// make an array
function MakeArray (size) {
    this.length = size;
    for(var i=1; i<=size; i++) this[i] = 0;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions


//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images
function PicPreload () {
    blockPre = new Array();
    for (i=1 ; i<5 ; i++) { 	// to show the 5 timer blocks
        blockPre[i] = new Image();
        blockPre[i].src = "img/screen/block"+eval(i)+".png";
    };
    flagmanPre = new Image();
    flagmanPre.src = "img/screen/flagman.png";	// to show the flagman body
    inlayPre = new Image();
    inlayPre.src = "img/screen/inlay.png";	// to show building
    inlayColPre = new Image();
    inlayColPre.src = "img/screen/inlay_c.png";	// to show building surrounding in color
    leftArmDownPre = new Image();   
    leftArmDownPre.src = "img/screen/left_arm_down.png";
    leftArmUpPre = new Image();
    leftArmUpPre.src = "img/screen/left_arm_up.png";
    leftLegDownPre = new Image();   
    leftLegDownPre.src = "img/screen/left_leg_down.png";
    leftLegUpPre = new Image();
    leftLegUpPre.src = "img/screen/left_leg_up.png";
    nullPre = new Image();
    nullPre.src = "img/null.gif";	// empty picture to hide any figure
    numPre = new Array();
    for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers
        numPre[i] = new Image();
        numPre[i].src = "img/screen/num"+eval(i-1)+".png";
    };
    numColonPre = new Image();
    numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
    rightArmDownPre = new Image();
    rightArmDownPre.src = "img/screen/right_arm_down.png";
    rightArmUpPre = new Image();
    rightArmUpPre.src = "img/screen/right_arm_up.png";
    rightLegDownPre = new Image();
    rightLegDownPre.src = "img/screen/right_leg_down.png";
    rightLegUpPre = new Image();
    rightLegUpPre.src = "img/screen/right_leg_up.png";
    soundOnPre = new Image();
    soundOnPre.src = "img/case/buttons/butOn"+".png";	// to show sound button in on-state
    soundOffPre = new Image();
    soundOffPre.src = "img/case/buttons/butOff"+".png";	// to show sound button in off-state
    timerBlockPre = new Image();
    timerBlockPre.src = "img/screen/timer_block.png";	// to show the timer blocks
};

// hide all figures and show timer if game A
function AllPicturesClear (game) {
    NumBlockNone();
    PicShow("Flagman", nullPre.src);
    PicShow("NumColon", nullPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
    PicShow("LeftArmUp", nullPre.src);
    PicShow("LeftArmDown", nullPre.src);
    PicShow("RightArmUp", nullPre.src);
    PicShow("RightArmDown", nullPre.src);
    PicShow("LeftLegUp", nullPre.src);
    PicShow("LeftLegDown", nullPre.src);
    PicShow("RightLegUp", nullPre.src);
    PicShow("RightLegDown", nullPre.src);
    if (game==1) TimerShow(0);
};

// show all figures
function AllPicturesShow () {
    PrefSoundSettings();
    NumBlockAll();
    PicShow("Flagman", flagmanPre.src);
    PicShow("NumColon", numColonPre.src);
    for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);
    PicShow("LeftArmUp", leftArmUpPre.src);
    PicShow("LeftArmDown", leftArmDownPre.src);
    PicShow("RightArmUp", rightArmUpPre.src);
    PicShow("RightArmDown", rightArmDownPre.src);
    PicShow("LeftLegUp", leftLegUpPre.src);
    PicShow("LeftLegDown", leftLegDownPre.src);
    PicShow("RightLegUp", rightLegUpPre.src);
    PicShow("RightLegDown", rightLegDownPre.src);
    TimerShowFull();
};

// show/hide colored background
function InlayShow () {
    color?PicShow("Inlay", inlayColPre.src):PicShow("Inlay", inlayPre.src);	
};

// show all figures, flagman flags up, legs down and "12:00"
function MainPicturesShow () {
    PrefSoundSettings();
    NumBlockAll();      // show all number blocks
    PicShow("Flagman", flagmanPre.src); // flagman body
    PicShow("NumColon", numColonPre.src);       // ":"
    PicShow("Num1", numPre[2].src);     // 1
    PicShow("Num2", numPre[3].src);     // 2
    PicShow("Num3", numPre[1].src);     // 0
    PicShow("Num4", numPre[1].src);     // 0
    PicShow("LeftArmUp", leftArmUpPre.src);
    PicShow("RightArmUp", rightArmUpPre.src);
    PicShow("LeftLegDown", leftLegDownPre.src);
    PicShow("RightLegDown", rightLegDownPre.src);
    TimerShowFull();    // show all 5 timer blocks
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them


//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich sound on/off; dont preload here
function PrefSound () {
    prefSound = !prefSound;
    PrefSoundEval();    // Show sound settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
    if (!prefSound) { // if sound is set to "off" 
		StopAllSound();
        preVlm = vlm;   // remember last sound volume
        vlm = 0;        // set volume to 0
    } else {
        if (preVlm==0) preVlm = 0.01; // if no previous volume, set to minimum
        vlm = preVlm;   // set volume to "on"
    };
    PrefSoundSettings();	// show sound on/off indication
    PrefSoundShow();	// show volume indicator on screen for testing purposes
    PlaySound("click_", vlm);	// click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
    var vlmTxt = "";    // empty sound volume indicator picture
    $("#SoundStateInd").html("");	// empty/hide volume indicator
    if (prefSoundShow) {      // if volume indicator is set to show
        $("#SoundStateIndBkgnd").removeClass("hidden");		
        if (vlm>0.00999) {
            for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
            $("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
        } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    } else {
        $("#SoundStateIndBkgnd").addClass("hidden");
        $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
    };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
    if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
    else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// swich sound on/off; dont preload here
function SetSound (setting) {
    prefSound = setting;
    PrefSoundSettings();	// show sound on/off indication
    PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
	StopSound("flag01_", vlm);
	StopSound("flag02_", vlm);
	StopSound("flag03_", vlm);
	StopSound("flag04_", vlm);
	StopSound("flag05_", vlm);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions


//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
    window.clearTimeout(demoID);	// stop demo from starting (again)
    demoID = null;
    window.clearTimeout(gameID);	// stop the game
    gameID = null;
    window.clearTimeout(gameResetID);	// stop repeated indicatioin 
    gameResetID = null;
    window.clearTimeout(gameShowID);	// stop game from showing next sequence
    gameShowID = null;
    window.clearTimeout(lauID);	// ID for timeout left arm up reset
    lauID = null;
    window.clearTimeout(lluID);	// ID for timeout left leg up reset
    lluID = null;
    pause = false;
    window.clearTimeout(numBlockID); // ID to reset numblocks
    numBlockID = null;
    window.clearTimeout(rauID);	// ID for timeout right arm up reset
    rauID = null;
    repeated = true;
    window.clearTimeout(rluID);	// ID for timeout right leg up reset
    rluID = null;
    window.clearTimeout(timeID); // ID to show the time
    timeID = null;
};

// clear gameID, gameResetID & pauseID
function GameReset () {
    if (gameID) {
        clearTimeout(gameID);	// stop the game
        gameID = null;
    };
    if (gameResetID) {
        clearTimeout(gameResetID);	// stop repeated indicatioin 
        gameResetID = null;
    };
    if (pauseID) {
        clearTimeout(pauseID);  // stop pause stopper
        pauseID = null;
    };
};

// clear all pictures & variables
function ResetAll () {
    AllStop();  // stop game if playing and reset all ID's
    AllPicturesClear ();        // hide all figures and show timer if game A
    game = 0; // no-game-all-pictures
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
    ResetAll(); // clear all pictures & variables
    if (acl) AllPicturesShow()
	else MainPicturesShow(); // show all figures, flagman flags up, legs down and "12:00"
	acl = true;
	aclID = window.setTimeout("acl = false;", 130);
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions


//show/hide different pieces of the game
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// check & show highest score on screen
function HighScoreShow (game) {
    pause = true;
    highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
    ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

// hide score
function ScoreHide () {
    for (var i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
};

// translate score to the digits on screen
function ScoreShow (score) {
    PicShow("Num1", nullPre.src);
    if (game==1 || game==2) PicShow("Num2", numPre[Math.floor(life)+1].src)
    else PicShow("Num2", nullPre.src);
    if (!(game==1||game==2)&&score<10) PicShow("Num3", nullPre.src)
	else PicShow("Num3", numPre[Math.floor(score%100/10)+1].src);
    PicShow("Num4", numPre[(score%10)+1].src);
    if (game==1 || game==2) PicShow("NumColon", numColonPre.src)
    else PicShow("NumColon", nullPre.src);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end show different pieces of the game


//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
    // if not already clock running or to prevent MainTime to run before failed flag_05-sound ended
    if (game!=4&&!mainTimePause) {      
		StopAllSound();
		ResetAll();	// clear all pictures & variables
        MainTimeStart(); // show current time & demo
    };
};
	
// show current time & demo
function MainTimeStart () {
    PlaySound("click_", vlm);	// click sound for push button
    demo = true;     // to show demo
    sequence = 1;    // start sequence
    MainPicturesDefault();	// show default start pictures of flagman
    TimerShow(0);	// hide all remaining timer blocks
    game = 4;	// clock running
    TimeShow();	// show current time
};

// show current time
function TimeShow () {
    Time();	// get current time
    TimeShowOnScreen();
    ShowTime(sequence); // sequential flagman movement for demo time clock
    if (sequence<4) sequence++
    else sequence = 1;
    timeID = window.setTimeout("TimeShow()", 1000);     // next second...
};

// show required time and indicators on screen
function TimeShowOnScreen () {
    // set integer to time digits
    if (hour<10) PicShow("Num1", nullPre.src)
    else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
    PicShow("Num2", numPre[(hour%10)+1].src);
    PicShow("Num3", numPre[Math.floor(min/10)+1].src);
    PicShow("Num4", numPre[(min%10)+1].src);
    PicShow("NumColon", numColonPre.src);
};

// get current time
function Time () {
    today = new Date();
    hour = today.getHours();
    min = today.getMinutes();
    sec = today.getSeconds();
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions


	
//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// four movements for game
function Failed () {
    if (!failed) {      // if not failed already running
        AllStop();      // stop game if playing and reset all ID's
        failed = true;  // indicates the failed condition to avoid some parts timed to continue
        life--; // one attempt less
        pause = true;           // paused the game
        repeated = true;        // end of made attempt to repeat the sequence
        tonesCount = 0;         // back to first tone
        LeftArm('up');
        RightArm('up');
        LeftLeg('up');
        RightLeg('up');
        PlaySound("flag05_", vlm);      // "failed" sound
        ScoreShow(score);
        // allow mainTime to run only after the failed sound
        pauseID = window.setTimeout("mainTimePause = false", 1500);     // unpause after "failed" sound ended
        if (life) {     // if attempt(s) left
            if (game==2) timeID = window.setTimeout("TimerShowFull()", 1500);   // if game B show the timer
            gameID = window.setTimeout("GameGoNext()", 1500)	// go on with game and show sequence
        } else {
            MainGameOver();     // stop demo if running + clear all
        };
    };
};

// Movements for repeating sequence during game
function FlagmanShow (seq) {
    if (!failed) {
        if ((game==1 || game==2) && !pause && !repeated) {      // if game A or B and not pause or done repeating the sequence
            GameReset(); // clear gameID, gameResetID & pauseID
            if (tonesCount==(tones.length-1)) repeated = true;  // if last tone, done repeating the sequence
            if (seq==tones[tonesCount]) {       // if pushed tone is correct
                if (tonesCount==(tones.length-1))ScoreAdd(1);  // if last tone, done repeating the sequence, add point
                if (game==1) pause = true;      // pause so no next input till movement is done
                FlagmanShowTime(seq);   // show pressed move
                pauseID = window.setTimeout("pause = false", 300);      // wait to enable next move
                tonesCount++;   // next tone to press
                // go on with game
                if (game==1) {
                    gameID = window.setTimeout("GameGo()", 400);
                } else { 
                    gameID = window.setTimeout("GameGo()", 50);
                };
                TimerReset();   // stop timer blocks counting down
                if (game==1) {
                    if (repeated&&!failed) timeID = window.setTimeout("TimerShow(0)", 370);     // hide timer
                    if (!repeated) timeID = window.setTimeout("TimerShowFull()", 360);
                } else {
                    numBlockID = setTimeout("NumBlockNone()", 300);	// hide number blocks
                };
            } else Failed();    // initiate the failed function
        };
    };
};

// show current sequence part (game A)
function FlagmanShowSequence () {
    GameReset(); // clear gameID, gameResetID & pauseID
    MainPicturesGame();	// set game to start situation 
    FlagmanShowTime(tones[tonesCount]); // show current tone of sequence
    tonesCount++;       // next tone
    if (tonesCount<tones.length) {      // if not end of tones array
        gameID = window.setTimeout("FlagmanShowSequence()", 650);      // show next sequence part after a short time
    } else {
        tonesCount = 0; // back to first tone
        gameResetID = window.setTimeout("repeated = false", 350);       // allows to repeat the sequence after a short time
        gameID = window.setTimeout("GameGo()", 350);    // go on with the game after a short  time
    };
};


// four movements for game
function FlagmanShowTime (seq) {
    if (game==1) PlaySound("flag0"+seq+"_", vlm);
    if (game==2) PlaySound("flag0"+(seq==4?4:(seq+1))+"_", vlm);
    switch (seq) {
        case 1 : 
            clearTimeout(lauID);
            lauID = null;
            LeftArm('up');      // set flag 1
            lauID = setTimeout("if (!failed) LeftArm('down')", 350);	// start flag reset after less than half a second
            break;
        case 2 : 
            clearTimeout(rauID);
            rauID = null;
            RightArm('up');      // set flag 2
            rauID = setTimeout("if (!failed) RightArm('down')", 350);	// start flag reset after less than half a second
            break;
        case 3 : 
            clearTimeout(lluID);
            lluID = null;
            LeftLeg('up');      // set flag 3
            lluID = setTimeout("if (!failed) LeftLeg('down')", 350);	// start flag reset after less than half a second
            break;
        case 4 : 
            clearTimeout(rluID);
            rluID = null;
            RightLeg('up');      // set flag 4
            rluID = setTimeout("if (!failed) RightLeg('down')", 350);	// start flag reset after less than half a second
            break;
        default :
    };
};

// play game A
function GameA () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // variables reset
        TimerShow(0); // hide timer blocks
        HighScoreShow(1);       // show highest score for game a
    };
};

// play game B
function GameB () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        GameSet(); // variables reset
        HighScoreShow(2);       // show highest score for game a
    };
};

// next move of game
function GameGo () {
    if (!pause) {
        TimerReset();   // stop timer blocks counting down
        if (repeated) { // if shown sequence was repeated or failed
            if (!failed||game==2) {     // if not failed or game B (has new tone every time, even after failed entry) 
                newTone = Math.floor(gameRandom*Math.random())+1;       // get new tone randomly
                if (game==1) tones[tones.length] = newTone      // if game A, add to tone array
                else tones[0] = newTone;        // else, new tone is only tone
            };
            tonesCount = 0;     // back to first tone
            failed = false;     // reset failed indicator
            SeqShow();	// engage game if not paused
        } else {
            SeqRepeat();	// engage game if not paused		
        };
    };
};

// 
function GameGoNext () {
    GameReset(); // clear gameID, gameResetID & pauseID
    MainPicturesGame();	// set game to start situation 
    pause = false;      // undo pause
    tonesCount = 0;     // back to first tone
    gameID = window.setTimeout("GameGo()", 250);        // go on with game in a quarter of a second
};

// common settings games
function GameSet () {
    PlaySound("click_", vlm);	// click sound for push button
    ResetAll();	// reset all screen settings
    // variables reset
    gameSpeedMinimum = 400;	// minimum speed for game sequence
    gameSpeed = gameSpeedMinimum;	// speed for game sequence
    failed = false;      // reset failed indicator
    life = 3;	// number of lives left
    repeated = true;    // set repeated to start with a sequence show first
    score = 0;  // reset score
    tones = []; // empty tones array
    tonesCount = 0;     // reset sequence counter
    MainPicturesGame();	// set game to start situation 
};

// button pressed to play game A
function MainGameA () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
       if (demoID) {   // prevent demo from restarting if planned
            clearTimeout(demoID);
            demoID = null;
        };
    };
    GameA();    // play game A
};

// "game A" button released so actually play game A
function MainGameAGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 1; // game A
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};


// button pressed to play game B
function MainGameB () {
    if (demo) {
        demo = false;		// once this key is hit, the demo is turned off
        if (demoID) {   // prevent demo from restarting if planned
            clearTimeout(demoID);
            demoID = null;
        };
    };
    GameB();    // play game B
};

// "game B" button released so actually play game B
function MainGameBGo () {
    if (game!=1 && game!=2) {   // if not already game A or B playing
        game = 2; // game B
        pause = false;
        ScoreShow(score);
        gameID = window.setTimeout("GameGo()", 500);    // start next game step in half a second
    };
};

// stop game if running + clear all
function MainGameOver () {
    AllStop();  // stop game if playing and reset all ID's
    demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

// show default pictures as @ start of the game
function MainPicturesGame () {
    MainPicturesDefault();	// show default start pictures of flagman
	if (game==1) ScoreShow(score);
};

// show default start pictures of flagman
function MainPicturesDefault () {
    AllPicturesClear(game);     // hide all figures and show timer if game A
    PicShow("Flagman", flagmanPre.src);
    PicShow("LeftArmDown", leftArmDownPre.src);
    PicShow("RightArmDown", rightArmDownPre.src);
    PicShow("LeftLegDown", leftLegDownPre.src);
    PicShow("RightLegDown", rightLegDownPre.src);
};

// show leading zeroes
function n(n){
    return n>9?""+n:"0"+n;
};

// show all number blocks
function NumBlockAll () {
    for (i=1 ; i<5 ; i++) PicShow("Block"+eval(i), blockPre[i].src);
};

// hide all number blocks
function NumBlockNone () {
    for (i=1 ; i<5 ; i++) PicShow("Block"+eval(i), nullPre.src);
};

function NumBlockShow (num) {
    TimerShowFull();    // show all timer blocks
    PlaySound("flag0"+num+"_", vlm);    // play sound of shown number
    PicShow('Block'+eval(num), blockPre[num].src);      // show number (num)
    gameResetID = window.setTimeout("repeated = false", 300);       // allows to repeat the sequence after a short time
    gameID = window.setTimeout("GameGo()", 300);    // go on with the game after a short  time
};

// add certain points to score
function ScoreAdd (points) {
    for (var a=0 ; a<points ; a++) {
        score++;
        if ((score%100)==0) SpeedReset()       // reset speed every 100 points
        SpeedUp(15);    // speed up a little every made point
    };
    ScoreShow(score);
    highScore[game] = (((highScore[game]>score))?highScore[game]:score);        // if current score higheer than recorded, record
};

// try to repeat the moves
function SeqRepeat () {
    TimerReset();       // stop timer blocks counting down
    TimerShowFull();
    if (game==1) timeID = window.setTimeout('TimerStart(1)', 500)       // if game A start timer after half a second
    else TimerStart(1); // else start timer immediately
};

// show the flag sequence
function SeqShow () {
    if (game==1) gameShowID = window.setTimeout("FlagmanShowSequence()", 500);	// go on with game a
    if (game==2) gameShowID = window.setTimeout("NumBlockShow(newTone)", 500);	// go on with game b
};

// sequential flagman movement for demo time clock
function ShowTime (seq) {
    switch (seq) {
        case 1 : 
            LeftLeg('down');
            LeftArm('up');
            break;
        case 2 : 
            LeftArm('down');
            RightArm('up');
            break;
        case 3 : 
            RightArm('down');
            RightLeg('up');
            break;
        case 4 : 
            RightLeg('down');
            LeftLeg('up');
            break;
        default :
    };
};

// speeds up the game with given value
function SpeedUp (speed) {
    if (gameSpeed<350) speed -= 3;
    if (gameSpeed<300) speed -= 3;
    if (gameSpeed<250) speed -= 2;
    if (gameSpeed<200) speed -= 2;
    if (gameSpeed<150) speed -= 2;
    if (gameSpeed<100) speed -= 1;
    if (gameSpeed<50) speed -= 1;	
    if (gameSpeed>gameSpeedMaximum) gameSpeed -= speed; // if not @ max speed, speed up
};

// stop timer blocks counting down
function TimerReset () {
    if (timeID) {
        clearTimeout(timeID);
        timeID = null;
    };
};

// hide all but "count" number of timer blocks
function TimerShow (count) {
    for (i=1 ; i<(6-count) ; i++) PicShow("TimerBlock"+eval(i), nullPre.src);
};

// show all 5 timer blocks
function TimerShowFull () {
    for (i=1 ; i<6 ; i++) PicShow("TimerBlock"+eval(i), timerBlockPre.src);
};

// show timer counting down with timer blocks
function TimerStart (i) {
    if (!failed) {
        pause = false;      // undo pause
        PicShow("TimerBlock"+eval(i), nullPre.src);     // hide next timer block
        if (i<5) { // if timer blocks left
            timeID = window.setTimeout('TimerStart ('+eval(i+1)+')', gameSpeed) // hide next timer block
        } else {
            TimerReset();       // stop timer blocks counting down
            Failed();
        };
    };
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

