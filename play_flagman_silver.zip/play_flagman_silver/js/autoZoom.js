//prevent double clickzoom/focus
window.addEventListener('dblclick', function(e) {
	e.preventDefault();
});

//zoom according to window size
function CheckSizeZoom () {
	var figGameW;	// the target div plus some spacing
	var figH;	// max possible window hight
	var maxWidthLev;	// max zoom level for current window width
	var maxHightLev;	// max zoom level for current window height
	var mozTransformOrigin;	// to calculate body placing for mozilla browsers
	var mozTransformOriginRatio;	// to switch between centered or calculated body placing for mozilla browsers
	var zoomLev;
	if (zoomed) {
		figGameW = $("#game").width()+50;	// the target div plus some spacing
		figH = document.body.clientHeight;	// max possible window hight
		maxWidthLev = $(window).width() / figGameW;	// max zoom level for current window width
		maxHightLev = $(window).height() / figH * 0.9;	// max zoom level for current window height
		zoomLev = (maxWidthLev<maxHightLev?maxWidthLev:maxHightLev);	// calculated zoom level
		if (typeof (document.body.style.zoom) != "undefined") {
			$(document.body).css('zoom', zoomLev);
		} else {
			// Mozilla doesn't support zoom, use -moz-transform to scale and compensate for lost width
			// switch indication between centered or calculated body placing for mozilla browsers
			mozTransformOriginRatio = (($(window).width()/$('#game').width() < 1) &&  $(window).height()/$('#game').height() < 0.5) || zoomLev > ($(window).width()/$('#game').width())/2;	
			mozTransformOrigin = ($(window).width() - figGameW*zoomLev + 10) / 2	// to calculate body placing for mozilla browsers
			// switch between centered or calculated body placing according to current settings for mozilla browsers
			mozTransformOrigin = (($(window).width()<$('#game').width() || $(window).height()<$('#game').height())) && mozTransformOriginRatio?(mozTransformOrigin*(1.5 + zoomLev)+"px top"):"center top";
			$(document.body).css({
				"-moz-transform" : "scale(" + zoomLev + ")",
				"-moz-transform-origin" : " "+mozTransformOrigin+" 0px",
			});
			scroll(0, -$("#Info_bottom").height());	// goto top to avoid seing nothing after zoom
		}
		switchInfo("#Info_button","#Info_bottom");	// hide info button when clicked on and show info tag
	} else {
		if (typeof (document.body.style.zoom) != "undefined") {
			$(document.body).css('zoom', '');
		} else {
			// Mozilla doesn't support zoom, use -moz-transform to scale and compensate for lost width
			$(document.body).css({
				"-moz-transform" : "",
				"-moz-transform-origin" : "",
			});
		};
	};
};
