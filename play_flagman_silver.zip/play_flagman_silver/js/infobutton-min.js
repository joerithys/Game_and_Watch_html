//Product:	Mario's Bombs Away HTML/flash - Panorama Screen (Nintendo) Simulator
//Version:	1.0
//Started:	31.12.2018
//Last update:	14.02.2019
//Author:		Flyzy
//Website:	http://www.franckx-design.be/klanten/joeri/
//Original:	Nintendo Co. Ltd


//-------------------------------------------
// start on page load
$(document).ready(function() {
	$("#Info_bottom_txt").click(function() {
		switchInfo("#Info_button","#Info_bottom");	// hide info button when clicked on and show info tag
	});
	$("#Info_button").hover(	// darken info button when hovered over with mouse pointer
		function() {$("#info_button_img").attr("src","img/case/info_hover.png");},
		function() {$("#info_button_img").attr("src","img/case/info.png");
	});
});

// show a tag
function showInfo(el){
	$(el).removeClass("gone");
}

// hide an tag
function hideInfo(el){
	$(el).addClass("gone");
}

// switch between two tags
function switchInfo(el1,el2){
	var scrollFactor =  $(window).height() / 1.1;
	showInfo(el1);
	hideInfo(el2);
	if ($("#Info_button").hasClass("gone")) {
		$("#Manual").focus(); // get focus on the info text
		scroll(0, scrollFactor);	// get focus on the info text for Firefox
	} else {
		$("#game").focus(); // get focus on the game
		scroll(0, -scrollFactor); // get focus on the game for Firefox
	};
}

