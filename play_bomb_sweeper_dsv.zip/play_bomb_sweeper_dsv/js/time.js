/*------------------------------------------------------------------time------------------------------------------------------------------*/

var timeID;   // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
  
//time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "time" is pressed, stop all and show time
function MainTime () {
  if (gameID) {
    clearTimeout(gameID);  // stop the game if running
    gameID = null;
  };
  if (gameSound) {    // if game played with no sound by double key
    gameSound = 0;    // set game not played with no sound by double key
    prefSound = 1;    // sound back on
    PrefSoundEval();  // Show sound volume settings according to current settings
  };
  if (alarm) TimeAlarmOff();  // stop alarm if running
  if (alarmOn) {
    PicShow("Bell", 1); // show alarm indicator on screen
    PicShow("BellUp", 1); // show alarm indicator head up on screen
    PicShow("BellDown", 0); // hide alarm indicator head down on screen
  } else {
    PicShow("Bell", 0); // hide alarm indicator on screen
    PicShow("BellUp", 0); // hide alarm indicator head up on screen
    PicShow("BellDown", 0); // show alarm indicator head down on screen
  };
  if (!demo) {    // if MainTimes demo not yet running 
    PlaySound("click_wav", vlm);  // click sound for push button
  };
};
  
// show current time & demo
function MainTimeStart () {
  if (!demo) {    // if MainTimes demo not yet running 
    ResetAll();  // clear all pictures & variables
    demo = true;   // to indicate demo running
    game = 4;  // clock running
    TimeShow();  // show current time
    Demo();   // run demo
  };
};

// get current time
function Time () {
  today = new Date();
  hour = today.getHours();
  min = today.getMinutes();
  sec = today.getSeconds();
};

// stop showing current time
function TimerReset () {
  if (timeID) {  // if time running
    clearTimeout(timeID);  // stop time timer
    timeID = null;  // reset time ID
  };
};

// show current time
function TimeShow () {
  TimerReset();    // stop showing current time
  Time();  // get current time
  if (!$('#ButTime:active').length&&!TKeyPressed) {  // if time button no longer pressed (else show alarm time)
    TimeShowOnScreen(min, hour);  // show the current time
  }; 
  timeID = window.setTimeout("TimeShow()", 1000);   // next second...
};

// show required time and indicators on screen from parameters
function TimeShowOnScreen(min, hour) {
  // set integer to time digits
  if (hour<10) NumShow(1,"")
  else NumShow(1, (Math.floor(hour/10)+0));
  NumShow(2,((hour%10)+0));
  NumShow(3,(Math.floor(min/10)+0));
  NumShow(4,((min%10)+0));
  PicShow("NumColon", 1);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end time functions

