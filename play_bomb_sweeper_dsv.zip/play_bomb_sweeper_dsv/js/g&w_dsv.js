//Product:             Bomb Sweeper HTML - New Wide Screen (Nintendo) Simulator
//Version:             1.2
//Started:              03.07.2025
//Last update:       06.10.2025
//Author               Nintendo
//Programmer       Flyzy (Joeri Thys)

//Credits:
//Design, layout and artwork by Nintendo
//Case design based on scans by Sean Riddle

// || \\

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var acl = false;    // for showing acl pictures, all if "ACL" is pressed twice fast
var aclID;    // ID to view all pictures @ fast double click

var blinkID;    // ID for timeout blinking john solver
var blinkNum;    // number of blinks preset
var blinkSpeed = 500;    // speed of blink animation

var demo = false;    // indicates if demo is running or not
var demoID;    // ID for timeout demo autostart and run
var demoSequence;    // for demo animation

var game = 0;    // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameAPressed = false;    // button for game A pressed
var gameBPressed = false;    // button for game B pressed
var gameID;    // ID for timeout of game sequence
var gameOver = 0;    // game is not over

var gameSound = 0;    // game not played with no sound by double key
var gameSpeed = 500;    // speed for game sequence timer
var gameSetID;    // ID animation to resume game after miss
var life = 4;    // number of lives left (4 = acl)
var miss = false;  
var offDir;    // officer's moving direction
var offPlace;    // officer's current place
var pause = false;  
var timer;    // countdown time left to defuse bombs or run through sub stage level
var timerStart;    // starting time to defuse bombs
var wallMove = 0;    // indicating john taking wall with or not

// screen figures
var bombs = new Array();    // for all bomb positions
var wallHor = new Array();    // for all horizontal wall positions
var wallVert = new Array();    // for all vertical wall positions

// reset pressed keys to none pressed
var AKeyPressed = false;    // indicates if a previuos hit "of the game A" keyboard key was already pressed to avoid double entries
var BKeyPressed = false;    // indicates if a previuos hit of the "game B" keyboard key was already pressed to avoid double entries
var DkeyPressed = false;    // indicates if the down key pressed to furn off sound @ playing game
var keyPressed = false;    // indicates if a previuos direction key was already pressed to avoid double entries
var keyPressedID;    // ID for slower continues movements
var RKeyPressed = false;   // indicates if a previuos hit of the "ACL" key was already pressed to avoid double entries
var TKeyPressed = false;   // indicates if a previuos hit of the "TIME" key was already pressed to avoid double entries
var WKeyPressed = false;   // indicates if a previuos hit of the "ALARM" key was already pressed to avoid double entries

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

// Disable Double-Tap Zoom on Mobile Browser
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$('.no-zoom').bind('touchend', function(e) {
  e.preventDefault();
  // no code here. 
  $(this).click();
  // This line still calls the standard click event, in case the user needs to interact with the element that is being clicked on, but still avoids zooming in cases of double clicking.
});

document.addEventListener('dblclick', function(event) {
    event.preventDefault();
}, { passive: false });

(function($) {  // IOS
  $.fn.nodoubletapzoom = function() {
    $(this).bind('touchstart', function preventZoom(e) {
      var t2 = e.timeStamp
        , t1 = $(this).data('lastTouch') || t2
        , dt = t2 - t1
        , fingers = e.originalEvent.touches.length;
      $(this).data('lastTouch', t2);
      if (!dt || dt > 500 || fingers > 1) return; // not double-tap
      e.preventDefault(); // double tap - prevent the zoom
      // also synthesize click events we just swallowed up
      $(this).trigger('click').trigger('click');
    });
  };
})(jQuery);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// End Disable Double-Tap Zoom on Mobile Browser

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
  codeCurrent = e.keyCode;    // for reading game keys
  e.preventDefault();    // prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
  switch (e.key) {
    case "1": case "a": case "A":   // if "1", "a" or "A" pressed
      // show game A button pressed
      document.images['Game A'].src = 'img/case/buttons/black_1_flat.png';   
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!BKeyPressed) { // if no other key is pressed
        MainGameA(); // show high score & play Game A after button release
        AKeyPressed = true;
      };
      break;
    case "2": case "b": case "B":   // if "2", "b" or "B" pressed
      // show game B button pressed
      document.images['Game B'].src = 'img/case/buttons/black_2_flat.png';  // show pressed button on screen
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!AKeyPressed) { // if no other key is pressed
        MainGameB(); // show high score & play Game B after button release
        BKeyPressed = true;
      };
      break;
    case "d": case "D": case "ArrowRight":  // right keys
      // show left button pressed
      document.images['Move None'].src = 'img/case/buttons/x_pad_r_r.png';   
      RightPressed();    // function to move right
      break;
    case "e": case "E": case "ArrowUp":  // up keys
      // show left button pressed
      document.images['Move None'].src = 'img/case/buttons/x_pad_r_u.png';   
      UpPressed();    // function to move up
      keyPressed = true;
      break;
    case "s": case "S": case "ArrowLeft":  // left keys
      // show left button pressed
      document.images['Move None'].src = 'img/case/buttons/x_pad_r_l.png';   
      LeftPressed();    // function to move left
      break;
    case "x": case "X": case "ArrowDown":  // down keys
      // show left button pressed
      document.images['Move None'].src = 'img/case/buttons/x_pad_r_d.png';   
      DownPressed();    // function to move down
      DkeyPressed = true;    // to furn off sound @ playing game if simultaniously pressed game key
      break;
    case "r": case "R":   // if "r" or "R" pressed
      // show acl button pressed
      document.images['Acl'].src = 'img/case/buttons/acl_push.png';
      ClearPressedKeys();  // ignore and clear all other keys that are pressed
      TotalReset(); // show full sprites
      RKeyPressed = true;
      break;
    case "t": case "T":   // if "t" or "T" pressed
      // show time button pressed
      document.images['Time'].src = 'img/case/buttons/black_3_flat.png';
      TKeyPressed = true;
      MainTime();     // initiate demo 
      TimeShowOnScreen(prefAlarmMin, prefAlarmHour);    // show set alarm time 
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button pressed
      document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
      if (!keyPressed&&!RKeyPressed&&!TKeyPressed&&!WKeyPressed) MainAlarm(); // set alarm
      WKeyPressed = true;   // indicates if a previuos hit of the "ALARM" key was already pressed to avoid double entries
      break;
    //test case buttons 
    case "+":  // "+"-numpadkey
      if (vlm<1) {
        vlm = (parseFloat(vlm) + 0.01).toFixed(2);  // increase volume for test purposes
        preVlm = vlm;   // current volume becomes previus set @ next change of volume
      };
      if (vlm==0.01)  SetSound(true);  // show sound turned on
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "-":  // "-"-key
      if (vlm>0) {
        vlm = (parseFloat(vlm) - 0.01).toFixed(2);  // decrease volume for test purposes
        preVlm = vlm;   // current volume becomes previus set @ next change of volume
      };
      if (vlm==0) SetSound(false);  // show sound turned off
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    case "/":  // "/"-key
      if (vlm==0.3) vlm = 0.03
      else vlm = 0.3;
      prefSound = 1;    // sound on
      PrefSoundShow();  // show volume indicator on screen for testing purposes if set
      PrefSoundSettings();  // show sound on/off indication
      break;
    case "g": case "G":   // if "g" or "G" pressed
      // swich sound on/off for testing purposes
      PrefSound();
      break
    case "n": case "N":   // if "v" or "N" pressed
      // hide/show sound switch for testing purposes
      SoundSwitch();
      break
    case "@": case String.fromCharCode(233):  // mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
      prefSoundShow = !prefSoundShow;   // show/hide indicator
      PrefSoundShow();  // show volume indicator on screen for testing purposes
      break;
    default:
  };
}, false);

window.addEventListener("keyup", function (e) {
  // game and arrow keys
  switch (e.key) {
    case "1": case "a": case "A":   // if "1", "a" or "A" released
      // show game A button default
      document.images['Game A'].src = 'img/case/buttons/black_1.png';  
      if (AKeyPressed) MainGameAGo(); // start running Game A
      AKeyPressed = false;
      break;
    case "2": case "b": case "B":   // if "2", "b" or "B" released
      // show game B button default
      document.images['Game B'].src = 'img/case/buttons/black_2.png';   // show game B button default
      if (BKeyPressed) MainGameBGo(); // play Game A
      BKeyPressed = false;
      break;
    case "d": case "D": case "ArrowRight":  // left keys
      // show right button released
      document.images['Move None'].src = 'img/case/buttons/x_pad_r.png';   
      keyPressed = false;
      break;
    case "e": case "E": case "ArrowUp":  // up keys
      // show up button released
      document.images['Move None'].src = 'img/case/buttons/x_pad_r.png';   
      keyPressed = false;
      break;
    case "s": case "S": case "ArrowLeft":  // right keys
      // show left button released
      document.images['Move None'].src = 'img/case/buttons/x_pad_r.png';   
      keyPressed = false;
      break;
    case "x": case "X": case "ArrowDown":  // down keys
      // show down button released
      document.images['Move None'].src = 'img/case/buttons/x_pad_r.png';   
      DkeyPressed = false;    // down key no longer pressed
      break;
    case "r": case "R":   // if "r" or "R" released
      // show acl button default
      document.images['Acl'].src = 'img/case/buttons/acl.png';
      RKeyPressed = false;
      break;
    case "t": case "T":   // if "t" or "T" released
      // show time button default
      document.images['Time'].src = 'img/case/buttons/black_3.png';
      if (TKeyPressed) {
        MainTimeStart();     // start initiated demo 
        TimeShowOnScreen(min, hour);  // show required time and indicators on screen from current time
      };
      TKeyPressed = false;
      break;
    case "w": case "W":   // if "w" or "W" pressed
      // show alarm button default
      document.images['Alarm'].src = 'img/case/buttons/acl.png';
      WKeyPressed = false;   // indicates if a previuos hit of the "ALARM" key was already pressed to avoid double entries
      break;
   default: 
  };
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

// if reviewing this tab, refresh screen
$(window).focus(function(){
  //focus log code
  console.log("---      %c Window focused ! %c   ...   %c Refreching screen ... %c   --   %c Welcome back! %c          ---          "+(gameOver?"screen not refreshed because GAME OVER !!!%c%c":"%c SCREEN REFRESHED ! %c"),
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:turquoise; color:blue; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:green; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:purple; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "     ---");   // color test
});


//when page loaded focus on game 
$(document).ready(function () {
  Beep();    // play beep sound (for waking up some browsers' sound play if neccesary)
  $(function () {    // autozoom @ start
    CheckSizeZoom()    // calculate size and position for autozoom
  });
  $(window).resize(CheckSizeZoom);    // autozoom to calculated size
  $("#game").focus();   // get focus on the game
  highScore[1] = 0;    // highest score game A
  highScore[2] = 0;    // highest score game B
  load_levels();    // load all 45 levels of GAME A
  load_moves();    // load the moves of all 45 levels of GAME A
  MainPicturesShow();    // show most figures & "12:00"
  demoID = window.setTimeout("MainTimeStart()", 60000);  // start demo after a minute  
  console.log("\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39 --- %c "+today+" %c --- %c welcome to this Game & Watch simmulator, have fun! ", 
        "background-color:red; color:white; font-weight:bold;",
        "background-color:none; color:black; font-weight:bold;",
        "background-color:lime; color:orangered; font-weight:bold;",
        " ---");   // color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// down button or -key pressed
function DownPressed () {
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss&&posx<5) {    // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);    // stop key up delay
      keyPressedID = null;    // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    // go position downwards
    if (GoDownPossible()) {    // if nothing prevents john from going down
      if (wallHor[(posx+1)*10+posy]) {    // if wall needs to come with 
        // move it one position down
        wallHor[(posx+1)*10+posy] = 0;
        PicShow("WallHor"+eval((posx+1)*10+posy)+"", 0);
        wallHor[(posx+2)*10+posy] = 1;
        PicShow("WallHor"+eval((posx+2)*10+posy)+"", 1);
        wallMove = 1;    // indicating john taking wall with 
      };
      if (!(stageSubLevel&&posx==4)) {    // not possible to leave maze untill end of sub stage level
        if (posx==4) LevelDone()    // when leaving maze to get to the bomb, level is done
        else GoDown();    // actually go down
      };
    };
  } else {
    if (game==5 || game==8) {    // change the alarm time
      DemoRun();    // perform one step of demo
      prefAlarmMin--;    // substract a minute from alarm time
      if (prefAlarmMin==-1) prefAlarmMin=59;    // substracting a minute from 0 gets 60
      AlarmShowNum();    // show alarm time
    };
  };
};

// actually go down
function GoDown () {
  HeroHide();    // hide john solver @ current position on screen
  posx++;    // john solver goes position below
  HeroShow();    // show john solver @ current position on screen
  if (wallMove) {    // if john taking wall with
    PlaySound("wall_move_wav", vlm);  // move/jump sound 
    wallMove = 0;    // john not taking wall with
  } else {
    PlaySound("move_wav", vlm);  // move/jump sound 
  };
};

// check if john solver can go down
function GoDownPossible () {
  return (wallHor[(posx+1)*10+posy]?(posx==4||wallHor[(posx+2)*10+posy]?0:1):1);    // if no unmovable wall under john, or not @ bottom, and no wall beneath
};

// actually go to the left
function GoLeft () {
  HeroHide();    // hide john solver @ current position on screen
  posy--;    // john solver goes position to the left
  HeroShow();    // show john solver @ current position on screen
  if (wallMove) {    // if john taking wall with
    PlaySound("wall_move_wav", vlm);  // move/jump sound 
    wallMove = 0;    // john not taking wall with
  } else {
    PlaySound("move_wav", vlm);  // move/jump sound 
  };
};

// check if john solver can go left
function GoLeftPossible () {
  return (wallVert[posx*10+posy]?(posy==1||wallVert[posx*10+posy-1]?0:1):1);    // if no unmovable wall left of john, or not @ first position, and no wall @ position to the left
};

// actually go to the right
function GoRight () {
  HeroHide();    // hide john solver @ current position on screen
  posy++;    // go position to the right
  HeroShow();    // show john solver @ current position on screen
  if (wallMove) {    // john taking wall with
    PlaySound("wall_move_wav", vlm);  // move/jump sound 
    wallMove = 0;    // john not taking wall with
  } else {
    PlaySound("move_wav", vlm);  // move/jump sound 
  };
};

// check if john solver can go right
function GoRightPossible () {
  return (wallVert[posx*10+posy+1]?(posy==6||wallVert[posx*10+posy+2]?0:1):1);    // if no unmovable wall right of john, or not @ last position, and no wall @ position to the right
};

// actually go up
function GoUp () {
  HeroHide();    // hide john solver @ current position on screen
  posx--;    // john solver goes position above
  HeroShow();    // show john solver @ current position on screen
  if (wallMove) {    // john taking wall with
    PlaySound("wall_move_wav", vlm);  // move/jump sound 
    wallMove = 0;    // john not taking wall with
  } else {
    PlaySound("move_wav", vlm);  // move/jump sound 
  };
};

// check if john solver can go up
function GoUpPossible () {
  return (wallHor[(posx)*10+posy]?(posx==1||wallHor[(posx-1)*10+posy]?0:1):1);    // if no unmovable wall above john, or not @ top, and no wall @ position above
};

// go left @ game or change alarm hour or minutes if alarm is being set
function LeftPressed () {
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss) {  // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);  // stop key up delay
      keyPressedID = null;  // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    if (GoLeftPossible()) {    // if nothing prevents john from going left
      if (wallVert[posx*10+posy]) {    // if wall needs to come with 
        // move it one position to the left
        wallVert[posx*10+posy] = 0;
        PicShow("WallVert"+eval(posx*10+posy)+"", 0);
        wallVert[posx*10+posy-1] = 1;
        PicShow("WallVert"+eval(posx*10+posy-1)+"", 1);
        wallMove = 1;    // indicating john taking wall with 
      };
      if (!((stageSubLevel||stageSubLevelEnd)&&posy==1)) {    // not possible to leave maze during sub stage level
        if (posy==1) LevelDone()    // when leaving maze to get to the bomb, level is done
        else GoLeft();    // actually go left
      };
    };
  } else {
    if (game==5 || game==8) {  // change the alarm time
      DemoRun();    // perform one step of demo
      prefAlarmHour--;  // substract an hour from alarm setting
      if (prefAlarmHour==-1) prefAlarmHour = 23;  // substracting an hour from 0 gets 24 -1 = 23
      AlarmShowNum();  // show alarm time
    };
  };
};

// make an array
function MakeArray (size) {
  this.length = size;
  for(var i=1; i<=size; i++) this[i] = 0;
};

// show/hide figure on screen
function PicShow (id, present) {
  if (present) {    // if picture wanted to be present
    $("#"+id+"").removeClass("null");    // unhide
  } else {
    $("#"+id+"").addClass("null");    // hide
  };
};

// go right @ game or change alarm hour or minutes if alarm is being set
function RightPressed () {
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss) {    // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);    // stop key up delay
      keyPressedID = null;    // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    if (GoRightPossible()) {    // if nothing prevents john from going right
      if (wallVert[posx*10+posy+1]) {    // if wall needs to come with 
        // move it one position right
        wallVert[posx*10+posy+1] = 0;
        PicShow("WallVert"+eval(posx*10+posy+1)+"", 0);
        wallVert[posx*10+posy+2] = 1;
        PicShow("WallVert"+eval(posx*10+posy+2)+"", 1);
        wallMove = 1;    // indicating john taking wall with 
      };
      if (!((stageSubLevel||stageSubLevelEnd)&&posy==6)) {    // not possible to leave maze during sub stage level
        if (posy==6) LevelDone()    // when leaving maze to get to the bomb, level is done
        else GoRight();    // actually go right
      };
    };
  } else {     // if setting alarm
    if (game==5 || game==8) {    // change the alarm time
      DemoRun();    // perform one step of demo
      prefAlarmHour++;    // add an hour to alarm setting
      if (prefAlarmHour==24) prefAlarmHour = 0;    // addng an hour to 23 gets 0
      AlarmShowNum();    // show alarm time
    };
  };
};

// unlock wall to open above @ game or change alarm hour or minutes if alarm is being set
function UpPressed () {
  if ((game==1||game==2)&&!pause&&!keyPressed&&!miss) {    // if game playing and not miss going on
    if (keyPressedID) {     // if key up delay was initiated
      window.clearTimeout(keyPressedID);    // stop key up delay
      keyPressedID = null;    // reset key press ID
    };
    keyPressed = true;
    keyPressedID = window.setTimeout("keyPressed = false;",400);    // to immitate key up after 400 milliseconds, for continious movement
    if (GoUpPossible()) {    // if nothing prevents john from going up
      if (wallHor[(posx)*10+posy]) {    // if wall needs to come with 
        // move it one position down
        wallHor[(posx)*10+posy] = 0;
        PicShow("WallHor"+eval((posx)*10+posy)+"", 0);
        wallHor[(posx-1)*10+posy] = 1;
        PicShow("WallHor"+eval((posx-1)*10+posy)+"", 1);
        wallMove = 1;    // indicating john taking wall with 
      };
      if (!(stageSubLevel&&posx==1)) {    // not possible to leave maze untill end of sub stage level
        if (posx==1) LevelDone()    // when leaving maze to get to the bomb, level is done
        else GoUp();    // actually go up
      };
    };
  } else {
    if (game==5 || game==8) {    // change the alarm time
      DemoRun();    // perform one step of demo
      prefAlarmMin++;    // add a minute to alarm time
      if (prefAlarmMin==60) prefAlarmMin=0;    // adding a minute to 59 gets 0
      AlarmShowNum();    // show alarm time
    };
  };
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// erase all figures from screen
function AllPicturesClear () {
  AllPicturesClearTop();    // erase all figures from top screen
  AllPicturesClearBottom();    // erase all figures from bottom screen
};

// erase all figures from bottom screen
function AllPicturesClearBottom () {
  BombsHideAll();    // hide all bombs on screen  
  PicShow("Boom", 0);    // hide explotions
  HeroesHide();    // hide all john solvers on lower screen
  WallsHorHideAll();    // hide all horizontal walls on screen 
  WallsVertHideAll();    // hide all vertical walls on screen 
};

// erase all figures from top screen
function AllPicturesClearTop () {
  AlarmShow((alarmOn?"on":"off"));    // show if alarm is set on or not
  PicShow("BomberJack1", 0);    // hide bomber jack @ fence
  PicShow("BomberJack1TossBombDown", 0);    // hide bomb in bomber jack's hand @ fence
  PicShow("BomberJack1TossBombUp", 0);    // hide bomb, tossed by bomber jack @ fence
  PicShow("BomberJack2", 0);    // hide bomber jack @ vault entrance
  PicShow("BomberJack3", 0);    // hide bomber jack running away from vault exit
  PicShow("CongratsDown", 0);    // hide congratulating hands down
  PicShow("CongratsJohnSolver", 0);    // hide congratulating john solver
  PicShow("CongratsOfficer", 0);    // hide congratulating officer
  PicShow("CongratsUp", 0);    // hide congratulating hands up
  PicShow("Diver", 0);    // hide person diving in the vault
  PicShow("Diving", 0);    // hide diving in the vault animation puff
  PicShow("GameA", 0);    // hide game a tekst
  PicShow("GameB", 0);    // hide game b tekst
  PicShow("JohnSolverEmerge", 0);    // hide john's emerge animation puff
  PicShow("JohnSolverEmerging", 0);    // hide john solver emerging from life display case
  PicShow("JohnSolverEntrance", 0);    // hide john solver @ vault entrance
  PicShow("JohnSolverEntrancePointing", 0);    // hide john solver's pointing hand @ vault entrance
  PicShow("JohnSolverExit", 0);    // hide john solver's @ vault exit
  LivesHide();    // hide current lives left in the box
  OfficersHide();    // hide all officers except the congratulating officer
  SmokeHideAll();    // hide all smoke on screen 
};

// show all figures
function AllPicturesShow () {
  MainFiguresShow();   // show all alarm, john solver & game related figures
  NumShow(1,8);   // "8"
  NumShow(2,8);   // "8"
  NumShow(3,8);   // "8"
  NumShow(4,8);   // "8"
  PicShow("NumColon", 1);  // ":"
  PicShow("BellDown", 1); // hide alarm indicator on screen
};

// hide all bombs on screen 
function BombsHideAll () {
  for (bmb=1; bmb<57 ;bmb++) {    // all the bomb positions
    PicShow("Bomb"+(bmb<10?('0'+bmb):bmb)+"", 0);    // hide bomb @ this position on screen
  };
};

// show current bombs on screen 
function BombsShow () {
  for (bmb=1; bmb<57 ;bmb++) {    // all the bomb positions
    if (bombs[(bmb<10?('0'+bmb):bmb)]) PicShow("Bomb"+(bmb<10?('0'+bmb):bmb)+"", 1);    // show bomb @ this position on screen if present
  };
};

// show all bombs on screen 
function BombsShowAll () {
  for (bmb=1; bmb<57 ;bmb++) {    // all the bomb positions
    PicShow("Bomb"+(bmb<10?('0'+bmb):bmb)+"", 1);    // show bomb @ this position on screen
  };
};

// initiate bomb explosion
function Boom () {
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  PlaySound("boom_boom_wav", vlm);  // sound  for explosion  
  if (!stageSubLevel) PicShow("Boom", 1);    // show explosions on screen
  smokeSeq = 0;    // reset smoke animation sequence
  levelDoneID = window.setTimeout("BoomSmoke()",1500);    // show explosion smoke animation
};

// hide explosions
function BoomHide () {
  PicShow("Boom", 0);    // hide explosions on screen
};

// test function show current screen status from bottom to top
function FiguresScreenShowCurrent () {
  WallsHorShow();    // show current horizontal walls on screen 
  WallsVertShow();    // show current vertical walls on screen 
  BombsShow();    // show current bombs on screen 
  HeroShow();    // show john solver @ current position on screen
};

// hide all john solvers on lower screen
function HeroesHide () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<7 ; j++) {     // the rows
      PicShow("JohnSolver"+eval(i*10+j)+"", 0);   // hide the 24 john solvers
    };
  };
};

// show all john solvers
function HeroesShow () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<7 ; j++) {     // the rows
      PicShow("JohnSolver"+eval(i*10+j)+"", 1);   // show the 24 john solvers
    };
  };
};

// hide john solver @ current position
function HeroHide () {
  PicShow("JohnSolver"+(posx*10+posy)+"", 0);   // hide the john solver @ current position
};

// show john solver @ current position on screen
function HeroShow () {
  PicShow("JohnSolver"+(posx*10+posy)+"", 1);   // show the john solver @ current position
};

// hide current lives left in the box
function LivesHide () {
  for (var i=1 ; i<4 ; i++) PicShow("JohnSolverLife"+eval(i)+"", 0);   // hide the 3 small john solvers indicating lives left
};

// show current lives left in the box
function LivesShow () {
  LivesHide();    // hide current lives left in the box
  for (i=1 ; i<((life<4?life:3)+1) ; i++) PicShow("JohnSolverLife"+eval(i)+"", 1);   // show the according small john solvers showing lives left
};

// show all alarm, john solver & related figures
function MainFiguresShow () {
  HeroesShow();    // show all john solvers
  PicShow("BellDown", 0); // hide alarm indicator on screen
  if (!alarmOn) {    // if alarm is set to go off
    PicShow("Bell", 1);    // show alarm indicator on screen
    PicShow("BellUp", 1);    // show alarm indicator on screen
  }; // show alarm indicator on screen
  PicShow("BomberJack1", 1);    // show bomber jack @ fence
  PicShow("BomberJack1TossBombDown", 1);    // show bomb in bomber jack's hand @ fence
  PicShow("BomberJack1TossBombUp", 1);    // show bomb, tossed by bomber jack @ fence
  PicShow("BomberJack2", 1);    // show bomber jack @ vault entrance
  PicShow("BomberJack3", 1);    // show bomber jack running away from vault exit
  BombsShowAll();    // show all bombs
  PicShow("Boom", 1);    // show explotions
  PicShow("CongratsDown", 1);    // show congratulating hands down
  PicShow("CongratsJohnSolver", 1);    // show congratulating john solver
  PicShow("CongratsOfficer", 1);    // show congratulating officer
  PicShow("CongratsUp", 1);    // show congratulating hands up
  PicShow("Diver", 1);    // show person diving in the vault
  PicShow("Diving", 1);    // show diving in the vault animation puff
  PicShow("GameA", 1);    // show game a tekst
  PicShow("GameB", 1);    // show game b tekst
  PicShow("JohnSolverEmerge", 1);    // show john's emerge animation puff
  PicShow("JohnSolverEmerging", 1);    // show john solver emerging from life display case
  PicShow("JohnSolverEntrance", 1);    // show john solver @ vault entrance
  PicShow("JohnSolverEntrancePointing", 1);    // show john solver's pointing hand @ vault entrance
  PicShow("JohnSolverExit", 1);    // show john solver's @ vault exit
  LivesShow();    // show current lives left in the box
  PicShow("Officer1", 1);    // show top left officer
  PicShow("Officer2", 1);    // show top right officer
  PicShow("Officer3", 1);    // show first walking officer
  PicShow("Officer4", 1);    // show second walking officer
  PicShow("Officer5", 1);    // show third walking officer
  PicShow("Officer6", 1);    // show fourth walking officer @ vault entrance
  PicShow("Officer6EntrancePointing", 1);    // show fourth walking officer's pointing hand @ vault entrance
  SmokeShowAll()     // show all smoke on screen 
  WallsHorShowAll();    // show all horizontal walls on screen 
  WallsVertShowAll();    // show all vertical walls on screen 
};

// show most figures & "12:00"
function MainPicturesShow () {
  MainFiguresShow();   // show all alarm, john solver & game related figures
  NumShow(1,1);   // 1
  NumShow(2,2);   // 2
  NumShow(3,0);   // 0
  NumShow(4,0);   // 0
  PicShow("NumColon", 1);  // ":"
};

// show digital number on screen
function NumShow (place,number) {
  switch(number) {    // number to show
    case 0 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 0);   // digit 4
      PicShow("Num"+place+"5", 1);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 1 :
      PicShow("Num"+place+"1", 0);   // digit 1
      PicShow("Num"+place+"2", 0);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 0);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 0);   // digit 7
      break;
    case 2 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 0);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 1);   // digit 5
      PicShow("Num"+place+"6", 0);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 3 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 0);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 4 :
      PicShow("Num"+place+"1", 0);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 0);   // digit 7
      break;
    case 5 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 0);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 6 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 0);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 1);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 7 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 0);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 0);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 0);   // digit 7
      break;
    case 8 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 1);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    case 9 :
      PicShow("Num"+place+"1", 1);   // digit 1
      PicShow("Num"+place+"2", 1);   // digit 2
      PicShow("Num"+place+"3", 1);   // digit 3
      PicShow("Num"+place+"4", 1);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 1);   // digit 6
      PicShow("Num"+place+"7", 1);   // digit 7
      break;
    default :
      PicShow("Num"+place+"1", 0);   // digit 1
      PicShow("Num"+place+"2", 0);   // digit 2
      PicShow("Num"+place+"3", 0);   // digit 3
      PicShow("Num"+place+"4", 0);   // digit 4
      PicShow("Num"+place+"5", 0);   // digit 5
      PicShow("Num"+place+"6", 0);   // digit 6
      PicShow("Num"+place+"7", 0);   // digit 7
      break;
  };
};

// hide all officers except the congratulating officer
function OfficersHide () {
  for (off=1 ;off<7 ;off++) {    // all officer positions
    PicShow("Officer"+eval(off)+"", 0);    // hide officer @ this place
  };
  PicShow("Officer6EntrancePointing", 0);    // hide fourth walking officer's pointing hand @ vault entrance
};

// hide all smoke on screen 
function SmokeHideAll () {
  for (smoke=1 ;smoke<7 ;smoke++) {    // all smoke positions
    PicShow("Smoke"+eval(smoke)+"", 0);    // hide smoke @ this position
  };
};

// show all smoke on screen 
function SmokeShowAll () {
  for (smoke=1 ;smoke<7 ;smoke++) {    // all smoke positions
    PicShow("Smoke"+eval(smoke)+"", 1);    // show smoke @ this position
  };
};

// hide all horizontal walls on screen 
function WallsHorHideAll () {
  for (i=1 ; i<6 ; i++) {     // the lines
    for (j=1 ; j<7 ; j++) {     // the rows
      PicShow("WallHor"+eval(i*10+j)+"", 0);    // hide horizontal wall @ this position
    };
  };
};

// show current horizontal walls on screen 
function WallsHorShow () {
  for (i=1 ; i<6 ; i++) {     // the lines
    for (j=1 ; j<7 ; j++) {     // the rows
      if (wallHor[(eval(i*10+j))]) PicShow("WallHor"+eval(i*10+j)+"", 1);    // show horizontal wall @ this position if present
    };
  };
};

// show all horizontal walls on screen 
function WallsHorShowAll () {
  for (i=1 ; i<6 ; i++) {     // the lines
    for (j=1 ; j<7 ; j++) {     // the rows
      PicShow("WallHor"+eval(i*10+j)+"", 1);    // show horizontal wall @ this position
    };
  };
};

// hide all vertical walls on screen 
function WallsVertHideAll () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<8 ; j++) {     // the rows
      PicShow("WallVert"+eval(i*10+j)+"", 0);    // hide vertical wall @ this position
    };
  };
};

// show current vertical walls on screen 
function WallsVertShow () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<8 ; j++) {     // the rows
      if (wallVert[(eval(i*10+j))]) PicShow("WallVert"+eval(i*10+j)+"", 1);    // show vertical wall @ this position if present
    };
  };
};

// show all vertical walls on screen 
function WallsVertShowAll () {
  for (i=1 ; i<5 ; i++) {     // the lines
    for (j=1 ; j<8 ; j++) {     // the rows
      PicShow("WallVert"+eval(i*10+j)+"", 1);    // show vertical wall @ this position
    };
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all game ID's
function AllStop () {
  GameReset();  // clear game related ID's
  pause = true;
  if (!demo) TimerReset(); // stop the counter to show the current time
};

// ignore and clear all other keys that are/were pressed
function ClearPressedKeys () {
  AKeyPressed = false;  // indicates if a previuos hit "of the game A" keyboard key was already pressed to avoid double entries
  BKeyPressed = false;  // indicates if a previuos hit of the "game B" keyboard key was already pressed to avoid double entries
  keyPressed = false; // indicates if a previuos direction key was already pressed to avoid double entries
  TKeyPressed = false;  // indicates if a previuos hit of the "TIME" key was already pressed to avoid double entries
};  

// clear game related game ID's
function GameReset () {
  if (blinkID) { // if  blinking triggered
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (demoID) {     // if demo was planned or running
    window.clearTimeout(demoID);  // stop demo sequence from starting (again)
    demoID = null;  // reset demo ID
  };
  if (gameID) {     // if game was planned or running
    window.clearTimeout(gameID);  // stop the game
    gameID = null;  // reset game ID
  };
  if (gameSetID) {    // if a game set timer already/still active
    window.clearTimeout(gameSetID);  // stop the game set's possible double call
    gameSetID = null;    // reset game set ID
  };
  if (introID) {     // if game intro was planned or running
    window.clearTimeout(introID);  // stop the game intro
    introID = null;  // reset game intro ID
  };
  if (scoreID) {     // if score increase was planned or running
    window.clearTimeout(scoreID);  // stop the score increase
    scoreID = null;  // reset score increase ID
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  if (officerMoveID) {    // if level done officer move timer
    window.clearTimeout(officerMoveID);  // stop previous lofficer move timer
    officerMoveID = null;  // reset officer move ID 1
  };
  if (screenShiftID) {    // if screen shift animation timer
    window.clearTimeout(screenShiftID);  // stop previous screen shift timer
    screenShiftID = null;  // reset screen shift ID
  };
};

// clear all pictures & variables
function ResetAll () {
  AllStop();    // stop game if playing and reset all game ID's
  StopAllSound();
  alarmSetting = false;     // stop setting alarm
  game = 9;   // 9-idle;
  gameAPressed = false;
  gameBPressed = false;
  gameOver = 0;  // no game is over
  level = 1;    // reset levels
  life = 4;  // no lives left (4 = acl)
  stageDone = 0;    // stage not done yet
  AllPicturesClear();  // erase all figures
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
  if (aclID) {     // if acl timer for fast double click trigger is active
    window.clearTimeout(aclID); // stop the acl timer
    aclID = null;  // reset acl ID
  };
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (!RKeyPressed) {    // to avoid multiple call if key keeps being pressed
    if (gameSound) {    // if game played with no sound by double key
      gameSound = 0;    // set game not played with no sound by double key
      prefSound = 1;    // sound back on
      PrefSoundEval();  // Show sound volume settings according to current settings
    };
    pause = true;
    PlaySound("click_wav", vlm);  // click sound for pushing the reset button
    AlarmReset();  // reset all alarm settings
    ResetAll(); // clear all pictures & variables
    TimerReset();    // stop showing current time
    demo = false;
    if (alarm) TimeAlarmOff();  // stop alarm if running
    if (acl) AllPicturesShow()  // show all figures & "88:88" if "acl" clicked twice fast
    else MainPicturesShow(); // else show most figures & "12:00"
    acl = true; // indicates "acl" already clicked
    aclID = window.setTimeout("acl = false;", 130);   // disable "acl" clicked twice fast after 130 milliseconds
    demoID = window.setTimeout("MainTimeStart()", 60000);  // start demo after a minute  
  };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// let all present bombs blink
function BombsBlink (times) {  
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (times%2) BombsHideAll()     // hide bombs @ current position @ even times
  else BombsShow();    // show bombs @ current position @ odd times
  times--;    // one less time left to blink
  if (times) blinkID = window.setTimeout("BombsBlink("+times+");", 100);    // blink bombs a number of times if times left
};

// show demo
function Demo () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (game!=5&&game!=8) demo = true    // if alarm time is not being set, set auto demo run
  else demo = false;    // perform only one move
  level = 1;    // first level
  offDir = -1;    // officer's moving direction
  offPlace = 4;    // starting walking officer's place
  // john solver @ @the beginning of maze        
  posx = 1;
  posy = 1;
  AllPicturesClearTop();  // erase all figures
  GameSet();   // default game settings and figures
  demoID = window.setTimeout("DemoSet()", 10);  // next step after a tenth of a second  
};

// perform one step of demo
function DemoRun () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (demo||game==5||game==8) {    // if demo still running or alarm being set
    if (demoSequence<23) {    // if not last step of demo
      Move($moves_[1][demoSequence]);    // follow preset move
      OfficerMove();    // automated officer's moves
    } else {
      if (demoSequence==23) {    // if maze done
        BombsHideAll();    // hide all bombs on screen 
        HeroHide ();    // hide john solver @ current position
      } else {    // after maze done
        // john solver back @ @the beginning of maze        
        posx = 1;
        posy = 1;
        BombsShow();    // show current bombs on screen 
        HeroShow ();    // show john solver @ current position on screen
      };
    };
    if (demoSequence<24) {    // if not last step of demo
      demoSequence++;    // next step
    } else {
      demoSequence = 0;    // back to the beginning
    };
    if (demo&&game!=5&&game!=8) demoID = window.setTimeout("DemoRun()", 1000);  // perform next step after a second  if not alarm time being set
  };
};

// set demo 
function DemoSet () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  demoSequence = 0;    // demo starting sequence
  PicShow("Officer"+offPlace+"", 1);    // show officer @ current position
  pause = false;
  if (demo&&game!=5&&game!=8) demoID = window.setTimeout("DemoRun()", 1000);  // next step after a second if not alarm time being set
};

// next move of game
function GameGo () {
  if (gameID) {    // if a game timer already/still active
    window.clearTimeout(gameID);  // stop the game's possible double call
    gameID = null;    // reset game ID
  };
  if (!pause) {
    if (!timer) Miss()    // miss it out of time
    else { 
      ScoreShow(timer);    // show time left
      PlaySound("clock_wav", vlm);  // ticking clock sound      
      timer--;    // clock ticking one down
    }; 
  }; 
  gameID = window.setTimeout("GameGo()", gameSpeed);  // next step in gamespeed milliseconds
};

// resume game after pause or any game pausing event
function GameGoNext () {
  if (game==1||game==2) {   // if game a or b running
    if (gameID) {    // if a game timer already/still active
      window.clearTimeout(gameID);  // stop the game's possible double call
      gameID = null;    // reset game ID
    };
    if (officerMoveID) {    // if level done officer move timer
      window.clearTimeout(officerMoveID);  // stop previous lofficer move timer
      officerMoveID = null;  // reset officer move ID 1
    };
    pause = false;    // unpause game
    HeroShow();    // show john solver @ current position on screen
    pause = false;
    miss = false;
    timer = timerStart;    // set timer to countdown start to solve maze
    GameSet(); // default game level settings and figures
    officerMoveID = window.setTimeout("OfficerMove()",750);    // continue officer moving animation
    gameID = window.setTimeout("GameGo();", 750);  // next step of game in gamespeed milliseconds
  };
};

// default game level settings and figures
function GameSet () {
  GameReset();    // stop game if playing and reset all game ID's
  blinkNum = 2;  // number of blink animations
  $currentLevel_ = $levels_[(eval(level))];    // get current level
  if (!demo&&game==1) $currentLevel_ = get_flipped_level($currentLevel_);    // if
  if (levelDone) levelNew = true;  // new level started, all figures need to be reset
  levelDone = 0;    // level not done yet
  miss = false;
  pause = false;
  timer = timerStart;    // set timer to countdown start to solve maze
  AllPicturesClearBottom();  // erase all figures on bottom screen
  screenShift = 0;
  if (!stageDone) {    // if stage not done yet
    PlaySound("level_start_wav", vlm);  // sound  for succeeding this level            
    if (game==2) {    // if game B running
      gameID = window.setTimeout("GenerateCurrentLevelB();",1);    // load random generated level to screen
    } else {
      gameID = window.setTimeout("GenerateCurrentLevel ($currentLevel_);",1)    // load and generate current level to screen
    };
  } else { 
    PlaySound("sub_stage_wav", vlm);  // sound  for succeeding this level        
    posx = 4;    // put john @ last line
    posy = 6;    // put john @ last row
    GenerateCurrentLevel ($levels_[0]);   // load generated empty level to screen
  };
};

// let john solver blink @ miss position
function HeroBlink (times) {  
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (times%2) HeroHide()     // hide john solver @ current position @ even times
  else HeroShow();    // show john solver @ current position @ odd times
  times--;    // one less time left to blink
  if (times) blinkID = window.setTimeout("HeroBlink("+times+");", 100)    // blink john solver a number of times if times left
  else HeroShow();    // show john solver @ current position
};

// button pressed to play game A
function MainGameA () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (DkeyPressed) {    // if down key pressed
      gameSound = 1;    // set game played with no sound by double key
      prefSound = 0;    // sound off
      PrefSoundEval();  // Show sound volume settings according to current settings
    };
    demo = false;    // once this key is hit, the demo is turned off
    AllStop();  // stop game if playing and reset all game ID's
    gameAPressed = true;
    life = 3;    // number of lives left
    level = 1    // game A starts @ level 1
    offDir = 1;    // officer's moving direction
    offPlace = 6;    // starting walking officer's place
    score = 0;
    stageDone = 0;    // stage not done yet
    stageSubLevel = 0;    // to indicate stage sub level is comming up
    stageSubLevelEnd = 0;    // to indicate if end animation of sub stage to be played
    stageLevels = 0;    // no levels @ this stage played yet
    timerStart = 50;    // countdown start to solve maze
    AllPicturesClear();    // erase all figures
    HighScoreShow(1);    // show highest score since this browser tab was opened
  };
};

// "game A" button released so actually play game A
function MainGameAGo () {
  if (game!=1&&game!=2) {     // if not already game A or B playing
    if (!gameBPressed) {    // if not already pressed key for game B
      game = 1;   // game A
      ScoreShow(score);    // show current score
      StageIntro();   // animate intro of stage
    } else {
      Demo();    // start demo
    };
    gameAPressed = false;
  };
};

// button pressed to play game B
function MainGameB () {
  if (demoID) {  // if demo still planned to start stop that plan to avoid double run
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  if (alarm) TimeAlarmOff();    // stop alarm if running
  if (game!=1&&game!=2) {   // if not already game A or B playing
    if (DkeyPressed) {    // if down key pressed
      gameSound = 1;    // set game played with no sound by double key
      prefSound = 0;    // sound off
      PrefSoundEval();  // Show sound volume settings according to current settings
    };
    demo = false;    // once this key is hit, the demo is turned off
    AllStop();  // stop game if playing and reset all game ID's
    gameBPressed = true;
    life = 3;    // number of lives left
    level = 0;    // game B has no pre defined levels and starts randomizing levels from empty level 0
    offDir = 1;    // officer's moving direction
    offPlace = 6;    // starting walking officer's place
    score = 0;
    stageDone = 0;    // stage not done yet
    stageSubLevel = 0;    // to indicate stage sub level is comming up
    stageSubLevelEnd = 0;    // to indicate if end animation of sub stage to be played
    stageLevels = 0;    // no levels @ this stage played yet
    timerStart = 40;    // countdown start to solve maze
    AllPicturesClear();    // erase all figures
    HighScoreShow(2);    // show highest score since this browser tab was opened
  };
};

// game B" button released so actually play game B
function MainGameBGo () {
  if (game!=1&&game!=2) {     // if not already game A or B playing
    if (!gameAPressed) {    // if not already pressed key for game A
      game = 2;   // game B
      ScoreShow(score);    // show current score
      StageIntro(); // animate intro of stage
    } else {
      Demo();    // start demo
    };
    gameBPressed = false;
  };
};

// end game + start demo after a minute  
function MainGameOver () {
  gameOver = 1;  
  if (demoID) {    // if demo timer active
    window.clearTimeout(demoID);    // stop demo timer
    demoID = null;    // reset demo ID
  };
  AllStop();    // stop game if playing and reset all game ID's
  OfficersHide();    // hide all officers except the congratulating officer
  PlaySound("game_over_wav", vlm);    // game over sound 
  demoID = window.setTimeout("MainTimeStart()", 60000);    // start demo after a minute  
  game = 9;    // 9 = game is idle;
  if (gameSound) {    // if game played with no sound by double key
    gameSound = 0;    // set game not played with no sound by double key
    prefSound = 1;    // sound back on
    PrefSoundEval();  // Show sound volume settings according to current settings
  };
};
 
// miss : bomb not reached in time or john got caught between walls
function Miss () {
  if (!miss) {    // if miss not running yet
    if (levelDoneID) {    // if level done animation timer
      window.clearTimeout(levelDoneID);  // stop previous level done timer
      levelDoneID = null;  // reset level done ID 1
    };
    miss = true;
    AllStop();    // stop game if playing and reset all game ID's
    pause = true;
    ScoreShow(timer);    // show time left
    if (stageSubLevel) {    // if stage sub level running
      stageDone = 1;    // stage is done
    };
    BombsHideAll();    // hide all bombs
    HeroBlink(10);    // blink john solver twelve times 
    Boom();    // initiate bomb explosion
  };
};

// show leading zeroes
function n(n){
  return n>9?""+n:"0"+n;
};

// randomizer
function randomize(min,max) {
  return Math.floor(Math.random()*(max-min+1)+min);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

