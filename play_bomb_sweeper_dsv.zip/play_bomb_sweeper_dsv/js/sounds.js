/*------------------------------------------------------------------sound------------------------------------------------------------------*/

var prefSound = 1;    // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off
var prefAlarmSet;  // last saved alarm setting 1-on; 0-off
var prefAlarmMin;  // last saved alarm setting minutes
var prefAlarmHour;  // last saved alarm setting hours
var preVlm = 1;     // previous sound volume 0.01-1
var sound = true;  // to prevent click sound @ autostart
var soundSwitch = false;    // to show/hide the sound switch
var vlm = 1;  // sound volume 0.01-1

function PlaySoundAlways (name, vol) {
  var audio = document.getElementById(name);
  audio.currentTime = 0;
  var playPromise = document.getElementById(name).play();
  if (vol) { 
    audio.volume = vol;
    if (playPromise !== undefined) {
      playPromise.then(_ => {
      // playback started!
      })
      .catch(error => {
        // play was prevented
      });
    };
  };
};

// play sound "name" @ "vol" volume if sound is on & demo not playing
function PlaySound (name, vol){
  if ( prefSound&&!demo&&game!=5&&game!=8 ) {
    PlaySoundAlways (name, vol);  // play sound "name" @ "vol" volume
  }
}

// play sound "name" @ "vol" volume if sound is on, even if demo is playing
function PlaySoundEvenIfDemo (name, vol){
  if ( prefSound ) {
    PlaySoundAlways (name, vol);  // play sound "name" @ "vol" volume
  }
}

// stop playing sound "name" @ "vol" volume 
function StopSound (name, vol){
  var audio = document.getElementById(name);
  if (vol) { 
    audio.volume = vol;
  }
  audio.pause();
  audio.currentTime = 0;
}

/*------------------------------------------------------------------sound------------------------------------------------------------------*/

//extra sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//make beep-sound
function Beep () {
  PlaySound("beep_wav", vlm);
};

// swich sound on/off, dont preload here
function PrefSound () {
  prefSound = !prefSound;  // swich sound on/off
  PrefSoundEval();  // Show sound volume settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
  if (!prefSound) { // if sound is set to "off" 
    preVlm = vlm;   // remember last sound volume
    vlm = 0;    // set volume to 0
  } else {
    if (preVlm==0) preVlm = 0.01; // if no previous sound volume, set to minimum
    vlm = preVlm;   // set sound volume to previous setting
  };
  PrefSoundSettings();  // show sound on/off indication
  PrefSoundShow();  // show volume indicator on screen for testing purposes
  PlaySound("click_wav", vlm);  // click sound for slide button
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
  var vlmTxt = "";  // empty sound volume indicator picture
  $("#SoundStateInd").html("");  // empty/hide volume indicator on screen
  if (prefSoundShow) {    // if volume indicator is set to show
    if (vlm>0.00999) {
      // count number of sound indicator bars & translate to html
      for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
      $("#SoundStateInd").html(vlmTxt);  // show counted number of sound indicator bars
    } else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');  // hide volume indicator
  } else {
    $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');  // hide volume indicator
  };
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
  if (prefSound) $("#Sound").attr("src","\img/case/buttons/butOn.png")  // show sound on indication
  else $("#Sound").attr("src","\img/case/buttons/butOff.png");    // show sound off indication
};

// set sound on/off; dont preload here
function SetSound (setting) {
  prefSound = setting;    //  sound on is "true" or "false"
  PrefSoundSettings();  // show sound on/off indication
  PlaySound("click_wav", vlm);  // click sound for slide button
};

// hide/+show sound switch
function SoundSwitch() {
  if (soundSwitch) {
    $("#ButSound").addClass("gone");
    $("#ButSound_txt").addClass("gone");
    $("#SoundOn").addClass("gone");
    $("#SoundOff").addClass("gone");
    soundSwitch = false;
    $("#SoundButton").text("Show the SOUND button");
  } else {
    $("#ButSound").removeClass("gone");
    $("#ButSound_txt").removeClass("gone");
    $("#SoundOn").removeClass("gone");
    $("#SoundOff").removeClass("gone");
    soundSwitch = true;
    $("#SoundButton").text("Hide the SOUND button");
  };
};

// stop all playing sounds except the button click
function StopAllSound () {
  StopSound("alarm_wav", vlm);
  StopSound("beep_wav", vlm);
  StopSound("bomb_toss_wav", vlm);
  StopSound("boom_boom_wav", vlm);
  StopSound("click_wav", vlm);
  StopSound("clock_wav", vlm);
  StopSound("dynamite_jack_wav", vlm);
  StopSound("game_over_wav", vlm);
  StopSound("level_end_wav", vlm);
  StopSound("level_start_wav", vlm);
  StopSound("move_wav", vlm);
  StopSound("nothing_wav", vlm);
  StopSound("officer_move_wav", vlm);
  StopSound("push_wall_wav", vlm);
  StopSound("score_add_wav", vlm);
  StopSound("smoke_smoke_wav", vlm);
  StopSound("stage_clear_wav", vlm);
  StopSound("sub_stage_wav", vlm);
  StopSound("sub_stage_move_wav", vlm);
  StopSound("wall_move_wav", vlm);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end extra sound functions
