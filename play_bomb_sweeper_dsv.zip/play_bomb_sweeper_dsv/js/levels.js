/*------------------------------------------------------------------levels------------------------------------------------------------------*/

var level;    // current level
var levelDone;    // current level done
var levelDoneID    // ID for level done animation
var levelNew = false;  // new level, if started, all figures need to be reset
var levels = 45;    // number of levels
var screenShift;    // screen shifting count and row
var screenShiftID;    // ID for screen shift animation
var shiftDir = -1;    // default screen shift direction is left
var stageDone;    // indicating end of stage
var stageLevels;    // counted levels per stage level
var stageSubLevel = 0;    // to indicate stage sub level is comming up
var stageSubLevelEnd = 0;    // to indicate if end animation of sub stage to be played

var $rows = 11;    // number of rows of screen grid for flip purposes
var $columns = 15;    // number of columns of screen grid for flip purposes

var posx = 1;    // current horizontal row position hero
var posy = 1;    // current vertical line position hero
var wallHor = new Array();    // for all horizontal walls positions
for (i=0 ; i<7 ; i++) {    // the lines
  wallHor[i] = new Array();
  for (j=1 ; j<6 ; j++) {    // the rows
    wallHor[i][j] = 0;    // reset horizontal walls
  };
};
var wallVert = new Array();    // for all vertical walls positions
for (i=0 ; i<8 ; i++) {    // the lines
  wallVert[i] = new Array();
  for (j=1 ; j<5 ; j++) {    // the rows
    wallVert[i][j] = 0;    // reset vertical walls
  };
};

// remove the wall located @ this bomb
function BombWallOpen(bombLoc) {
  if (bombLoc<9) {
    wallHor[eval((bombLoc%10)+10)] = 0;
  } else {
    if (bombLoc>50) {
      wallHor[eval(bombLoc)] = 0;
    } else {
      wallVert[eval(bombLoc+(bombLoc%10?0:1))] = 0;
    }
  }
};

// mirror maze horizontally
function flip_hor($level_) {
  var $multip, $new_place;    // individual current places & new place
  var $temp = new Array();    // temporary maze constructor
  $.each( $level_, function($i, $value) {    // for each position of the maze
    $multip = Math.floor($i/($columns)) + 1;    // get it's collumn position
    $new_place = (2*$multip-1)*$columns-1-$i;    // put it in opposite collumn position
    $temp[$new_place] = $value;    // store position in temporary maze
  });
  return $temp;
}

// mirror maze vertically
function flip_vert($level_) {
  var $multip, $new_place;    // individual current places & new place
  var $temp = new Array();    // temporary maze constructor
  $.each( $level_, function($i, $value) {    // for each position of the maze
    $multip = Math.floor($i/($columns)) + 1;    // get it's collumn position
    $new_place = (($rows-1)-($multip-1)*2)*$columns+$i;    // put it in opposite row position
    $temp[$new_place] = $value;    // store position in temporary maze constructor
  });
  return $temp;
}

// reverse full maze
function flip_full($level_) {
  var $length = $level_.length;    // get full mazr length
  var $temp = new Array();    // temporary maze constructor
  $.each( $level_, function($i, $value) {    // for each position of the maze
    $temp[$length-$i-1] = $value;    // store @ opposite position in temporary maze constructor
  });
  return $temp;
}
  
// generate current level from maze array
function GenerateCurrentLevel ($thisLevel_) {
  var bmbPos;    // calculated bomb positions
  var currentBombs = new Array();    // for all current bomb positions
  var currentWallHor = new Array();    // for all current horizontal wall positions
  var currentWallVert = new Array();    // for all current vertical wall positions
  var heroPos;    // for current hero position position
  var $iNew;    // calculated linear screen position
  var $iPosx;    // calculated creen line sposition
  var $iPosy;    // calculated screen row position
  var wallHorPos;    // horizontal wall numbers/place
  var wallVertPos;    // vertical wall numbers/place
  $.each( $thisLevel_, function($i, $value) {    // for each position of the maze
    $iNew = ($i%15)+(parseInt($i/15)*100);    // from array position to linear screen position
    $iPosx = parseInt($iNew/100);    // from array position to screen line position 
    $iPosy = $iNew%100;    // from array position to screen row position 
    switch($i) {
      case 2: case 4: case 6: case 8: case 10: case 12: case 30: case 44: case 60: case 74: case 90: case 104: case 120: case 134: case 152: case 154: case 156: case 158: case 160: case 162:
        // bomb positions
        if ($value) {    // if bomb present @ this location
          bmbPos = ($iPosx/2*10+$iPosy/2)     // =line/2*10+row/2    // from screen positions to bomb position
          bmbPos = bmbPos<10?("0"+bmbPos):bmbPos;    // add leading zero to numbers under 10
          currentBombs[bmbPos] = 1;    // store bomb position
        };
        break;
      case 17: case 19: case 21: case 23: case 25: case 27: case 47: case 49: case 51: case 53: case 55: case 57: case 77: case 79: case 81: case 83: case 85: case 87: case 107: case 109: case 111: case 113: case 115: case 117: case 137: case 139: case 141: case 143: case 145: case 147:
        // wallHor positions
        if ($value) {    // if horizontal wall present @ this location
          wallHorPos = (($iPosx+1)/2*10+$iPosy/2)    // =(line+1)/2*10+row/2    // from screen positions to horizontal wall position
          currentWallHor[wallHorPos] = 1;    // store horizontal wall position
        };
       break;
      case 31: case 33: case 35: case 37: case 39: case 41: case 43: case 61: case 63: case 65: case 67: case 69: case 71: case 73: case 91: case 93: case 95: case 97: case 99: case 101: case 103: case 121: case 123: case 125: case 127: case 129: case 131: case 133:
        // wallVert positions
        if ($value) {    // if vertical wall present @ this location
          wallVertPos = ($iPosx/2*10+($iPosy+1)/2)     // =line/2*10+(row+1)/2    // from screen position to vertical wall position
          currentWallVert[wallVertPos] = 1;    // store horizontal wall position
        };
        break;
      case 32: case 34: case 36: case 38: case 40: case 42: case 62: case 64: case 66: case 68: case 70: case 72: case 92: case 94: case 96: case 98: case 100: case 102: case 122: case 124: case 126: case 128: case 130: case 132:
        // hero positions
        if ($value) {    // if bomb present @ this location
          heroPos = ($iPosx/2*10+($iPosy)/2)     // =line/2*10+row/2    // from screen position to bomb position
          posx = $iPosx/2;    // hero's line position on screen
          posy = $iPosy/2;    // hero's row position on screen
        };
        break;
      default :
        break;
    };
  });
  bombs = currentBombs;    // transfer all generated bomb positions
  wallHor = currentWallHor;    // transfer all generated horizontal wall positions
  wallVert = currentWallVert;    // transfer all generated vertical wall positions
  screenShift = 0;    // screen shifting count and row reset
  ShowCurrentLevel();  // show current game level  
}
  
// generate current random level for game B
function GenerateCurrentLevelB () {
  var adjusted = 0;    // to indicate an unsolvable situation was adjusted
  var blockedPossible = 0;    // to indicate the maze has an unsolvable part
  var bombPosx = randomize(1,5);    // random line of first bomb
  var bombPosy = randomize(0,1);    // random row of first bomb
  var bombLoc1;    // final first bomb location
  var bombLoc2;    // final seconnd bomb location
  var solved = 0;    // no unsolvable part permanently solved
  if (screenShiftID) {    // if screen shift animation timer
    window.clearTimeout(screenShiftID);  // stop previous screen shift timer
    screenShiftID = null;  // reset screen shift ID
  };
  posx = randomize(1,4);    // put john solver @ a random line
  posy = 0;    // put john solver left in labyrinth
  GenerateCurrentLevel ($levels_[0]);    // empty level
  for (row=1; row<7; row++) {    // the rows
    if (randomize(0,1)) {    // randomly choose on or two horizontal walls @ this row
      wallHor[eval(3*10+row)] = 1;    // horizontal wall @ third line of this row
    } else {  
      wallHor[eval(2*10+row)] = 1;    // horizontal wall @ second line of this row
      wallHor[eval(4*10+row)] = 1;    // horizontal wall @ fourth line of this row
    };  
  };    
  for (line=1; line<5; line++) {    // the lines
    if (randomize(0,1)) {    // randomly choose two or three vertical walls @ this line
      wallVert[eval(line*10+3)] = 1;    // vertical wall @ third row of this line
      wallVert[eval(line*10+5)] = 1;    // vertical wall @ fifth row of this line
    } else {  
      wallVert[eval(line*10+2)] = 1;    // vertical wall @ second row of this line
      wallVert[eval(line*10+4)] = 1;    // vertical wall @ fourth row of this line
      wallVert[eval(line*10+6)] = 1;    // vertical wall @ sixth row of this line
    };  
  };    
  //------------------------------------- start to avoid unsolvable random maze -------------------------------------
  if ( wallHor[22] &&  wallHor[23] && wallVert[22] && wallVert[32] &&  wallHor[42] && wallHor[43] ) {    // left possible block
    blockedPossible++;    // one more unsolvable part
    if (wallHor[31] && bombPosy==0) {    // if middle left horizontal wall present
      solved = 1;    // unsolvable part permanently solved, no further solution needed
      if (bombPosx==1) {    // if first bomb positioned @ top
        bombPosx = 2;    // place first bomb one place down
      } else {
        if (bombPosx==5) {    // if first bomb positioned @ bottom left place
            bombPosx = 4;    // place first bomb one place up
        }; 
      };
    } else {
      if ( bombPosy==0 ) {    // if bombs placed left
        adjusted = 1;    // big adjustment made
        if (randomize(0,1)) {
          bombPosy = 1    // place bombs @ other side
        } else {
          bombPosx = 3;    // place bombs in the horizonntal middle
          solved = 1;    // unsolvable part permanently solved, no further solution needed
        };
      };
    };
  };
  if ( wallHor[25] &&  wallHor[24] && wallVert[26] && wallVert[36] &&  wallHor[45] && wallHor[44] && ! solved) {    // right possible block & nno block solved
    blockedPossible++;    // one more unsolvable part
    if (wallHor[36] && bombPosy==1) {    // if middle right horizontal wall present
      if (bombPosx==1) {    // if first bomb positioned @ top
        bombPosx = 2;    // place first bomb one place down
      } else {
        if (bombPosx==5) {    // if first bomb positioned @ bottom left place
            bombPosx = 4;    // place first bomb one place up
        }; 
      };
    } else {
      if ( bombPosy==1 ) {    // if bombs placed right
        adjusted = 1;    // big adjustment made
        if (randomize(0,1)) {
          bombPosy = 0    // place bombs @ other side
        } else {
          bombPosx = 3;    // place bombs in the horizonntal middle
          solved = 1;    // unsolvable part permanently solved, no further solution needed
        };
      };
    };
  };
  if (!solved) {    // if no sollution made yet
    if (blockedPossible>1) {    // if unsolvable part @ both sides
      if (randomize(0,1)) {    // randomize left or right sollution
        bombPosx = 3;    // place bombs in the horizonntal middle
        bombPosy = 0;    // place bombs left
      } else {
        bombPosx = 3;    // place bombs in the horizonntal middle
        bombPosy = 1;    // place bombs right
      };
    };
  };
  //-------------------------------------  end to avoid unsolvable random maze  -------------------------------------
  bombLoc1 = (bombPosx-1)*10+bombPosy*7+(bombPosy?-1:1)*(bombPosx==1?1:0);    // calculate first final bomb position
  bombLoc2 = (bombPosx-1)*10+10+bombPosy*7+(bombPosy?-1:1)*((bombPosx==5)?1:0);    // calculate second final bomb position
  bombLoc1=bombLoc1<10?("0"+bombLoc1):bombLoc1;     // 
  if (!posy) posy = ((bombLoc1%10)>2)?1:6;    // put john solver @ the oposit row of the bombs
  bombs[bombLoc1] = 1;    // store bomb position 1
  bombs[bombLoc2] = 1;    // store bomb position 2
  BombWallOpen(bombLoc1);    // open the wall located @ this bomb
  BombWallOpen(bombLoc2);    // open the wall located @ this bomb
  ShowCurrentLevel();  // show current visible part of the game level  
}

// randomize maze flip
function get_flipped_level($level_) {
  $flippo = randomize(1,4);    // random flip indicator
  switch($flippo) {
    case 2:
      $level_ = flip_hor($level_);    // mirror maze horizontally
      break;
    case 3:
      $level_ = flip_vert($level_);    // mirror maze vertically
      break;
    case 4:
      $level_ = flip_full($level_);    // reverse full maze
      break;
    default:
      break;
  } 
  return $level_;
}

// end of level animation
function LevelDone () {
  var goNext = 90*timer+900;    // calculate resume time by time left after solving maze
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  pause = true;
  AllStop();    // stop game if playing and reset all game ID's
  levelDone = 1;
  BombsBlink(8);
  PlaySound("level_end_wav", vlm);  // sound  for succeeding this level        
  if (!stageSubLevelEnd) {    // if not end animation of sub stage to be played
    stageLevels++;    // add one to counted levels per stage level
    scoreID = window.setTimeout("ScoreAdd("+timer+");", 800);    // add remaining time to score in gamespeed milliseconds)
    if ((stageLevels>9&&game==1)||(stageLevels>14&&game==2)) {    // if number of levels per stage according to game reached
      if (game==1) {    // if game A
        stageDone = 1;     // indicating end of stage
        stageSubLevel = 1;    // to indicate stage has end sub stage reached
        levelDoneID = window.setTimeout("StageSubLevel()",goNext);    // run substage as generated level run between stages
      } else {    // if game B
        levelDoneID = window.setTimeout("StageSubLevelEnd()",goNext);    // congrats animation
      };
    } else {
      if (!demo) {
        if (game==1) {    // game A running
          if (level<levels) {    // if not last level
            level++;    // next level
          } else {
            level = 1;    // still first level
          };
        };
        levelDoneID = window.setTimeout("GameGoNext();", goNext);  // start running next level in calculated milliseconds
      };
    };
    blinkNum = 0;    // done blinking
  } else {
    levelDoneID = window.setTimeout("StageSubLevelEnd();", 800);     // congrats animation
  };
};

// substage as generated level run between stages
function StageSubLevel () {
  if (screenShiftID) {    // if screen shift animation timer
    window.clearTimeout(screenShiftID);  // stop previous screen shift timer
    screenShiftID = null;  // reset screen shift ID
  };
  stageLevels = 0;    // no levels @ this stage played yet
  GameSet();    // default game level settings and figures
  screenShiftID = window.setTimeout("StageSubLevelGo()",3000);    // start generated level run between stages
};

// congrats animation between stages
function StageSubLevelEnd () {
  if (officerMoveID) {    // if level done officer move timer
    window.clearTimeout(officerMoveID);  // stop previous lofficer move timer
    officerMoveID = null;  // reset officer move ID 1
  };
  if (screenShiftID) {    // if screen shift animation timer, used to start demo if not getting to the bomb after four minutes 
    window.clearTimeout(screenShiftID);  // stop previous screen shift timer
    screenShiftID = null;  // reset screen shift ID
  };
  stageLevels = 0;    // no levels @ this stage played yet
  stageSubLevel = 0;    // to indicate stage sub level is comming up
  stageSubLevelEnd = 0;    // to indicate if end animation of sub stage to be played
  AllPicturesClearBottom();    // erase all figures from bottom screen
  PlaySound("stage_clear_wav", vlm);  // sound  for start of substage 
  StageSubLevelEndAnimation(1);    // run congrats animation
};

// start generated level run between stages
function StageSubLevelGo () {
  if (posy==6&&wallVert[(eval(posx*10+posy))]&&wallVert[(eval(posx*10+posy-1))]) {    // if john solver caught between walls
    Miss();
  } else {
    if (!pause) {
      if (screenShiftID) {    // if screen shift animation timer
        window.clearTimeout(screenShiftID);  // stop previous screen shift timer
        screenShiftID = null;  // reset screen shift ID
      };
      if (!stageLevels) OfficerMove();    // if not start of sub stage level, move officer
      PlaySound("sub_stage_move_wav", vlm);  // sound  for next step of substage     
      stageLevels++;    // next stage level
      StageSubLevelScreenShift();    // generate and shift next random substage piece on screen
    };
    if (stageLevels<41) screenShiftID = window.setTimeout("StageSubLevelGo()",1350)    // next step of generated level run between stages
  }; 
}; 

// generate and shift next random substage piece on screen
function StageSubLevelScreenShift () {
  var newPosy = posy-shiftDir;    // horizontal position of john solver after screenshift
  var randHor1 = randomize(1,5);    // first random horizontal wall space
  var randHor2;    // second horizontal wall space
  var randVert1 = randomize(1,4);    // first random vertical walless space
  var randVert2;    // second vertical walless space
  var startValVert = stageLevels%2?1:0;    // odd or even start value to determin 1h3v or 2h2v walls
  ScoreShow(41-stageLevels);    // show sub stage levels left
  if (posy==6) {      // if john solver @ last place
   if (wallVert[(eval(posx*10+posy))]) {    // if vertical wall present @ john's place
     // move the wall one postiton back
      wallVert[(eval(posx*10+posy))] = 0;
      wallVert[(eval(posx*10+posy-1))] = 1;
      PlaySound("wall_move_wav", vlm);  // wall move sound 
    } else {
      PlaySound("move_wav", vlm);  // move/jump sound 
    };
  };
  for (row=7; row>1; row--) {    // the rows
    for (line=1; line<6; line++) {    // the lines
      wallVert[(eval(line*10+row))]  = wallVert[(eval(line*10+row-1))];    // move vertical wall @ this place one position to the right
      wallHor[(eval(line*10+row-1))] = wallHor[(eval(line*10+row-2))];    // move horizontal wall @ this place one position to the right
    };  
  };    
  for (line=1; line<6; line++) {    // the next lines
    wallVert[(eval(line*10+1))]  = (stageLevels<35?startValVert:0);    // if not end of sub stage, clear @ odd & fill @ even all vertical walls
    wallHor[(eval(line*10+1))] = 0;    // clear all horizontal walls
  };
  do {
    randHor2 = randomize(1,5);    // randomize second horizontal wall space
  } while (randHor1==randHor2);    // till it's different from first one
  do {
    randVert2 = randomize(1,4);    // randomize second vertical wall space
  } while (randVert1==randVert2);    //     // till it's different from first one
  if (stageLevels<35) {    // while sub stage running
    if (stageLevels%2) {    // if even sub stage progress
      wallHor[(eval(randHor1*10+1))] = 1;    // place wall @ first horizontal wall space
      wallVert[(eval(randVert1*10+1))]  = 0;    // hide wall @ first vertical wall space
    } else {
      wallHor[(eval(randHor1*10+1))] = 1;    // place wall @ first horizontal wall space
      wallHor[(eval(randHor2*10+1))] = 1;    // place wall @ second horizontal wall space
      wallVert[(eval(randVert1*10+1))]  = 1;    // place wall @ first vertical wall space
      wallVert[(eval(randVert2*10+1))]  = 1;    //place wall @ second vertical wall space
    };
  } else {
    if (stageLevels!=40) wallHor[11] = 1;    // if not @ bomb place @ end of sub stage level close first horizontal top wall 
    wallHor[51] = 1;    // close first horizontal bottom wall 
  };
  AllPicturesClearBottom();    // erase all figures from bottom screen
  WallsHorShow();    // show horizontal walls of maze
  WallsVertShow();    // show vertical walls of maze
  if (newPosy>0&&newPosy<7)  {    // if new position of john solver within screen
    HeroHide();    
    posy = newPosy;    // put john solver @ new position
  };
  if (stageLevels==41) {    // if end of sub stage level reached
    stageSubLevelEnd = 1;     // end animation of sub stage is to be played
    stageSubLevel = 0;    // to indicate no more stage sub level is comming up
    StageSubLevelEndWall();    // close end level with left vertical wall
    bombs["02"] = 1;    // put end bomb @ place
    PicShow("Bomb02", 1);    // show end bomb @ place
    screenShiftID = window.setTimeout("MainTimeStart()", 240000);  // start demo if not getting to the bomb after four minutes 
  };
  HeroShow();
}; 
  
// show current level on screen
function ShowCurrentLevel () {
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  AllPicturesClearBottom();    // erase all figures from bottom screen
  for (row=1; row<(screenShift+2); row++)  {    // the shifted rows
    for (line=1; line<6; line++) {    // the lines
      if (wallVert[(eval(line*10+6-screenShift+row))]) PicShow("WallVert"+eval(line*10+row)+"", 1)    // show vertical wall if present
      else PicShow("WallVert"+eval(line*10+row)+"", 0);    // hide vertical wall if not present
      if (wallHor[(eval(line*10+6-screenShift+row-1))]) PicShow("WallHor"+eval(line*10+row-1)+"", 1)    // show horizontal wall if present
      else PicShow("WallHor"+eval(line*10+row-1)+"", 0);    // hide horizontal wall if not present
    };  
  };    
  screenShift++;      // next screen shifting count and row to put level on screen
  // if screen shifting done
  if (screenShift<7) {
    levelDoneID = window.setTimeout("ShowCurrentLevel()",30);    // next step
  } else {
    if (demo||game==5||game==8) {    // if demo still running or alarm being set
      HeroShow();    // show john solver 
      BombsShow();    // show the bombs 
    } else {
      if (!intro) {    // if not stage intro running
        HeroBlink(10)    // blink hero when shift done
        if (stageDone) StageIntroOpenEmptyLevel()    // if end of stage, show empty level
        else BombsShow();    // show the bombs
        stageDone = 0;    // indicating end of stage
      }; 
    }; 
  }; 
}; 
