//alarm time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var alarm = false;    // alarm not running
var alarmID;    // ID for alarm ringing animation
var alarmOffID;     // ID to turn alarm off after some time
var alarmOn = false;    // for indication if alarm is set on or off      
var alarmRinging = false;    // to prevent alarm going off again after turning off
var alarmSetting = false;    // if alarm is at set mode to make changes
var prefAlarmMin = 0;    // last saved alarm setting minutes
var prefAlarmHour = 0    // last saved alarm setting hours

// reset all alarm settings
function AlarmReset () {
  window.clearTimeout(alarmID);    // stop running alarm sound from repeating
  alarmID = null;    // reset alarm ID
  window.clearTimeout(alarmOffID);    // stop running timer to turn off alarm @ running
  alarmOffID = null;    // reset alarm off ID
  alarm = false;    // alarm not running
  alarmOn = false;    // for indicationif alarm is set on or off      
  alarmRinging = false;    // to prevent alarm going off again after turning off
  alarmSetting = false;     // if alarm is no longer at set mode to make changes
  prefAlarmMin = 0;    // last saved alarm setting minutes
  prefAlarmHour = 0;    // last saved alarm setting hours
};

// show alarm time & on/off indication
function AlarmShow (ind) {
  if (game==5 || game==8) {    // change the alarm time
    AlarmShowNum();    // show alarm time
  };
  if (ind=="on") {
    alarmOn = true;
    PicShow("Bell", 1);   // show alarm indicator on screen
    PicShow("BellUp", 1);   // show alarm indicator head up on screen
    PicShow("BellDown", 0);   // hide alarm indicator head down on screen
  } else {
    alarmOn = false;
    PicShow("Bell", 0);   // hide alarm indicator on screen
    PicShow("BellUp", 0);   // hide alarm indicator head up on screen
    PicShow("BellDown", 0);   // hide alarm indicator head down on screen
  };
};

// show current alarm time setting
function AlarmShowNum () {
  TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
};

// set the alarm
function MainAlarm () {
  if (gameSound) {    // if game played with no sound by double key
    gameSound = 0;    // set game not played with no sound by double key
    prefSound = 1;    // sound back on
    PrefSoundEval();  // Show sound volume settings according to current settings
  };
  if (game==8) {
    game = 5;     // set alarm (on)
    AlarmShow("on");    // show alarm time & on indication
    TimeAlarmBackground();    // start checking if alarm time reached every half minute
  } else {
    if (game==5)  {
      game = 8;    // set alarm (off)
      AlarmShow("off");    // show alarm time & off indication
    } else {    // change the alarm time
      AllPicturesClear ();    // hide all figures
      StopAllSound();
      TimerReset();    // stop showing current time
      if (alarm) TimeAlarmOff();    // stop alarm if running
      if (demoID) {     // if demo was planned or running
        clearTimeout(demoID);     // stop demo sequence
        demoID = null;    // reset demo ID
      };
      if (!alarmSetting) {
        ResetAll();     // clear all pictures & variables
        alarm = false;     // alarm is not currently running
        keys = 7;     // alarm is been set
        demo = false;     // once the alarm key is hit, the demo is turned off
        PlaySound("click_wav", vlm);     // click sound for push button
        alarmSetting = true;     // if alarm is at set mode to make changes
      };
      game = 5;     // set alarm (on)
      AlarmShow("on");    // show alarm time & on indication
      TimeAlarmBackground();    // start checking if alarm time reached every half minute
      Demo();    // play demo one step every change made
      demoID = setTimeout("MainTimeStart()", 300000);    // show current time & demo in5 minutes
   };  
  };  
};

// check if its time for alarm
function TimeAlarm () {
  Time();    // get current time
  var alarmTime;
  if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) {    // if alarm is due the next minute
    if (alarmID) {
      clearTimeout(alarmID);    // if alarm was planned or running, stop sequence
      alarmID = null;    // reset alarm ID
    };
    alarm = true;
    // set start alarm at start next minute
    alarmTime = 60000-(sec*1000);
    // alarm rings at start next minute
    alarmID = setTimeout("TimeAlarmGo()", alarmTime);
    // stop alarm 30 seconds after start
    alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000));    // turn alarm off after half a minute
  };
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
  if (alarmOn) {    
    TimeAlarm();  // check if its time for alarm if alarmOn
    setTimeout("TimeAlarmBackground()", 30000)  ;     // check every half minute
  }; 
};

// alarm rings
function TimeAlarmGo () {
  if (alarmID) {
    clearTimeout(alarmID);    // if alarm was planned or running, stop sequence
    alarmID = null;    // reset alarm ID
  };
  Time();  // get current time
  PicShow("BellDown", 1);    // show head down
  PicShow("BellUp", 0);    // hide head up
  if (game!=1&&game!=2) PlaySoundEvenIfDemo("alarm_wav", vlm);    // sound for alarm if no game going on
  alarmID = setTimeout("PicShow('BellDown', 0); PicShow('BellUp', 1);", 500);    // head's up after half a second
  alarmID = setTimeout("TimeAlarmGo()", 1000);    // repeat after a second
};
  
// turn running alarm off
function TimeAlarmOff () {
  if (alarmID) {
    clearTimeout(alarmID);    // if alarm was planned or running, stop sequence
    alarmID = null;    // reset alarm ID
  };
  alarm = false;
  // alarmSetting = false;     // if alarm is at set mode to make changes
  AlarmShow((alarmOn?"on":"off"));    // show if alarm is set on or not
  if (game==0) {     // if acl show all bells
    PicShow("BellDown", 1);    // show alarm indicator on screen
  };
};
//end alarm time functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
