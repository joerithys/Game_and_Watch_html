/*------------------------------------------------------------------scores------------------------------------------------------------------*/

var highScore = new Array();  // to remember the highest score played for both games since opened in the browser
var points;    // resting points to add
var score = 0;  // score (all beneath 100) at init
var scoreID  // ID for counting score

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow (i) {
  ScoreShow(highScore[i]);
};

// add certain points to score
function ScoreAdd (points) {
  var scoreTimeEnd;
  var scoreTimeStart;
  var today;
  if (game==1||game==2) {
    if (scoreID) {     // if game was planned or running
      window.clearTimeout(scoreID);  // stop the game
      scoreID = null;  // reset game ID
    };
    if (points==100) {
      today = new Date();
      scoreTimeStart = today.getMilliseconds();
    };
    if (points) {
      PlaySound("score_add_wav", vlm)  // sound  for adding a point to score   
      score++;
      points--;
      scoreID = window.setTimeout("ScoreAdd ("+points+");", 85);
    } else {
      if (score>highScore[game]) highScore[game] = score;     // if passed highscore @ of this game, set new highscore
        today = new Date();
        scoreTimeEnd = today.getMilliseconds();
    };
    ScoreShow(score);
  };
};

// hide score from screen
function ScoreHide () {
  $("#Num1").addClass("hidden");
  $("#Num2").addClass("hidden");
  $("#Num3").addClass("hidden");
  $("#Num4").addClass("hidden");
};

// unhide score from screen
function ScoreUnHide () {
  $("#Num1").removeClass("hidden");
  $("#Num2").removeClass("hidden");
  $("#Num3").removeClass("hidden");
  $("#Num4").removeClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (scoreTS) {
  if (scoreTS>999)   NumShow("1", (Math.floor((scoreTS/1000)%10)+0));   // first digit
  else NumShow("1", "");
  if (scoreTS>99)   NumShow("2", (Math.floor(scoreTS%1000/100)+0));   // secdond digit
  else NumShow("2", "");
  if (scoreTS>9) NumShow("3", (Math.floor(scoreTS%100/10)+0));    // third digit
  else NumShow("3", "");
  NumShow("4", ((scoreTS%10)+0));  // fourth digit
  PicShow("NumColon", 0);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
