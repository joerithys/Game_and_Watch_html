// animation variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var introID    // ID for intro animation
var intro;    // indicating intro animation running
var introSeq;    // sequence step for stage intro animation
var officerMoveID;    // ID for animating the officer moving
var smokeSeq;    // sequence step for smoke animation

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end aimation variables

// animation functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// show explosion smoke animation
function BoomSmoke () {
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  smokeSeq++;    // next sequence to show explosion smoke animation
  switch(smokeSeq) {
    case 1 :    // Smoke1
      PlaySound("smoke_smoke_wav", vlm);  // sound  for explosion  
      BoomHide();    // hide explosions
      HeroHide();
      ScoreShow(score);
      PicShow("Officer"+offPlace+"", 0);    // hide officer @ current position
      PicShow("Officer2", 1);    // show officer @ lefdt top position
      offPlace = 2;
      PicShow("Smoke1", 1);   // show bottom smoke
      break;
    case 2 :    // Smoke2
      PicShow("Smoke1", 0);   // hide bottom smoke
      PicShow("Smoke2", 1);   // show second smoke
      break;
    case 3 :    // Smoke1+2
      PicShow("Smoke1", 1);   // show bottom smoke
      break;
    case 4 :    // Smoke1+3
      PicShow("Smoke2", 0);   // hide second smoke
      PicShow("Smoke3", 1);   // show third smoke
      break;
    case 5 :    // Smoke2+3
      PicShow("Smoke1", 0);   // hide bottom smoke
      PicShow("Smoke2", 1);   // show second smoke
      break;
    case 6 :    // Smoke1+2+3
      PicShow("Smoke1", 1);   // show bottom smoke
      break;
    case 7 :    // Smoke1+2+4
      PicShow("Smoke3", 0);   // hide third smoke
      PicShow("Smoke4", 1);   // show fourth smoke
      break;
    case 8 :    // Smoke1+3+4
      PicShow("Smoke2", 0);   // hide second smoke
      PicShow("Smoke3", 1);   // show third smoke
      break;
    case 9 :    // Smoke2+3+5
      PicShow("Smoke1", 0);   // hide bottom smoke
      PicShow("Smoke2", 1);   // show second smoke
      PicShow("Smoke4", 0);   // hide fourth smoke
      PicShow("Smoke5", 1);   // show fifth smoke
     break;
    case 10 :    // Smoke2+4+5
      PicShow("Smoke3", 0);   // hide third smoke
      PicShow("Smoke4", 1);   // show fourth smoke
      break;
    case 11 :    // Smoke3+4+5
      PicShow("Smoke2", 0);   // hide second smoke
      PicShow("Smoke3", 1);   // show third smoke
      break;
    case 12 :    // Smoke3+4+6
      PicShow("Smoke5", 0);   // hide fifth smoke
      PicShow("Smoke6", 1);   // show top smoke
      break;
    case 13 :    // Smoke3+5+6
      PicShow("Smoke4", 0);   // hide fourth smoke
      PicShow("Smoke5", 1);   // show fifth smoke
      break;
    case 14 :    // Smoke4+5+6
      PicShow("Smoke3", 0);   // hide third smoke
      PicShow("Smoke4", 1);   // show fourth smoke
      break;
    case 15 :    // Smoke4+5
      PicShow("Smoke6", 0);   // hide top smoke
      break;
    case 16 :    // Smoke4+6
      PicShow("Smoke5", 0);   // hide fifth smoke
      PicShow("Smoke6", 1);   // show top smoke
      break;
    case 17 :    // Smoke5+6
      PicShow("Smoke4", 0);   // hide fourth smoke
      PicShow("Smoke5", 1);   // showfifth smoke
      break;
    case 18 :    // Smoke5
      PicShow("Smoke6", 0);   // hide top smoke
      break;
    case 19 :    // Smoke6
      PicShow("Smoke5", 0);   // hide fifth smoke
      PicShow("Smoke6", 1);   // show top smoke
      break;
    case 20 :    // noSmoke
      PicShow("Smoke6", 0);   // hide top smoke
      introSeq = 0;    // first sequance of annimation resume game after miss
      if (life>0) GameGoPreNext()  // start game in 1500 milliseconds
      else MainGameOver();    // end game + start demo after a minute  
      break;
    default :    // hide all smoke
      SmokeHideAll();
      break;
  };
  if (smokeSeq<20) levelDoneID = window.setTimeout("BoomSmoke()",440);    // next step of explosion smoke animation
};

// animation resume game after miss
function GameGoPreNext () {
  if (gameSetID) {    // if a game set timer already/still active
    window.clearTimeout(gameSetID);  // stop the game set's possible double call
    gameSetID = null;    // reset game set ID
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  PlaySound("move_wav", vlm);  // sound for moving
  switch(introSeq) {    // intro animation sequence
    case 0: 
      AllPicturesClearBottom();    // erase all figures from bottom screen
      offDir = -1;    // officer's moving direction
      PicShow("Officer"+offPlace+"", 0);    // hide officer @ current place
      PicShow("Officer5", 1);    // show second walking officer
      offPlace = 5;    // new current place of officer
      PicShow("JohnSolverLife"+eval(introSeq+life)+"", 0);    // hide last life indication
      PicShow("JohnSolverLife"+eval(introSeq+life+1)+"", 1);    // show next life indication place
      if (life==2) introSeq++;    // if two lives left, next step is to be skipped
      break;
    case 1:   
      PicShow("JohnSolverLife2", 0);     // hide second life indication
      PicShow("JohnSolverLife3", 1);      // show third life indication
      break;
    case 2:   
      life--;
      PicShow("JohnSolverLife3", 0);      // hide third life indication
      PicShow("JohnSolverEmerge", 1);    // show john's emerge animation puff
      gameSetID = window.setTimeout('PicShow("JohnSolverEmerge", 0);',300);    // hide john's emerge animation puff after 300 milliseconds
      PicShow("JohnSolverEmerging", 1);    // show john solver emerging from life display case
      break;
    case 3:   
      PicShow("JohnSolverEmerging", 0);    // hide john solver emerging from life display case
      PicShow("JohnSolverEntrance", 1);    // show john solver's @ vault exit
      break;
    case 4:   
      PicShow("JohnSolverEntrance", 0);    // hide john solver's @ vault exit
      PicShow("Diver", 1);    // show person diving in the vault
      break;
    case 5:  
      PicShow("Diver", 0);    // hide person diving in the vault
      if (stageSubLevel) {    // if 10 levels solved
          StageSubLevel();    // substage as generated level run between stages
      } else {
        GameGoNext();    // resume game after pause or any game pausing event
      };
      break;
    default: 
      break;         // exit this handler for other values
  };
  introSeq++;    // next step
  if (introSeq<6) levelDoneID = window.setTimeout("GameGoPreNext();",630);    // next step of animation resuming game after miss
};

// move in given direction for automated demo
function Move (move) {
  switch(move) {
    case 4: // left
      GoLeft();
      break;
    case 5: // up
      GoUp();
      break;
    case 2: // right
      GoRight();
      break;
    case 3: // down
      GoDown();
      break;
    default: 
      break;         // exit this handler for other keys
  };
};

// automated officer's moves
function OfficerMove () {
  if (officerMoveID) {    // if level done officer move timer
    window.clearTimeout(officerMoveID);  // stop previous lofficer move timer
    officerMoveID = null;  // reset officer move ID 1
  };
  PicShow("Officer"+offPlace+"", 0);    // hide officer @ current position
  offDir = (offPlace==3 || offPlace==6)?-offDir:offDir;    // change officer's direction if @ end of path
  offPlace+=offDir;    // officer's new current position
  PicShow("Officer"+offPlace+"", 1);    // show officer @ new current position
  if (game==1||game==2) {   // if game a or b running
    if (!pause) {
      officerMoveID = window.setTimeout("OfficerMove()",900);    // continue officer moving animation
    };
  };
};

// animate intro of stage
function StageIntro () {
  if (blinkID) {    // if blink timer active
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (introID) {     // if intro was planned or running
    window.clearTimeout(introID);  // stop the intro
    introID = null;  // reset intro ID
  };
  intro = true;
  PlaySound("dynamite_jack_wav", vlm);  // sound  for succeeding this level        
  AllPicturesClearTop();    // erase all figures from top screen
  GenerateCurrentLevel ($levels_[0]);    // load generate empty level to screen
  blinkID = window.setTimeout('PicShow("Officer1", 1);',500)    // show top left officer after half a second
  LivesShow();    // show lives left
  PicShow("Game"+(game==1?"A":"B")+"", 1);    // show game a or b - tekst
  introID = window.setTimeout("StageIntroDynamiteJackBombToss(0);",2375);    // dynamite jack tossing
}

// remove left walls of empty level 
function StageIntroOpenEmptyLevel () {
  for (i=1 ; i<5 ; i++) {     // the lines
    PicShow("WallVert"+(eval(i*10+1))+"", 0);     // hide left walls @ this line
    wallVert[(eval(i*10+1))] = 0;    // remove left walls @ this line
  };
};

// animate dynamite jack tossing
function StageIntroDynamiteJackBombToss (tel) {
  if (blinkID) { // if  blinking triggered
    window.clearTimeout(blinkID);  // stop blink timer
    blinkID = null;  // reset blink ID 
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  if (tel<7) PlaySound("bomb_toss_wav", vlm);  // sound  for succeeding this level     
  switch(tel) {
    case 0: // dynamite Jack appears
      PicShow("BomberJack1", 1);    // show bomber jack @ fence
      PicShow("BomberJack1TossBombDown", 1);  
      break;
    case 1: case 2: case 3: case 4: // tdynamite Jack ossing bomb
      PicShow("BomberJack1TossBombDown", 0);    // hide bomb in bomber jack's hand @ fence
      PicShow("BomberJack1TossBombUp", 1);    // show bomb, tossed by bomber jack @ fence
      PicShow("Officer1", 0);    // hide top left officer
      PicShow("Officer2", 1);    // show top right officer
      offPlace = 2;
      break;
    case 5: // dynamite Jack going to entrance
      PicShow("BomberJack2", 1);    // show bomber jack @ vault entrance
      PicShow("BomberJack1", 0);    // hide bomber jack @ fence
      PicShow("BomberJack1TossBombDown", 0);    // hide bomb in bomber jack's hand @ fence
      break;
    case 6: // dynamite Jack jumping into entrance
      PicShow("BomberJack2", 0);    // hide bomber jack @ vault entrance
      PicShow("Diving", 1);    // show diving in the vault animation puff
      PicShow("Officer2", 0);    // hide top right officer
      PicShow("Officer4", 1);    // show second walking officer
      offPlace = 4;
      break;
    case 7: // dynamite Jack jumping into entrance
      StageIntroJonhSolver(0);
      break;
    default: 
      break;         // exit this handler for other keys
  };
  if (tel<5) blinkID = window.setTimeout('PicShow("BomberJack1TossBombDown", 1); PicShow("BomberJack1TossBombUp", 0);',200);    // reverse tossing if still tossing
  tel++;
  if (tel<8) levelDoneID = window.setTimeout("StageIntroDynamiteJackBombToss("+tel+");",630);    // next dynamite jack tossing annimation
}

// animate john solver comming up
function StageIntroJonhSolver (jtel) {
  if (introID) {     // if game was planned or running
    window.clearTimeout(introID);  // stop the game
    introID = null;  // reset game ID
  };
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  if (jtel<7)  PlaySound("officer_move_wav", vlm);  // sound for moving officer 
  introSeq =  0;    // last piece of intro done
  switch(jtel) {
    case 0: 
      PicShow("Diving", 0);    // hide diving in the vault animation puff
      PicShow("Officer4", 0);    // hide second walking officer
      PicShow("Officer5", 1);    // show third walking officer
      offPlace = 5;
      if (life<3) {
        PicShow("JohnSolverLife"+eval(introSeq+life)+"", 0);    // hide last life indication
        PicShow("JohnSolverLife"+eval(introSeq+life+1)+"", 1);    // show next life indication place
      };
      break;
    case 1: 
      PicShow("Officer4", 1);    // show second walking officer
      PicShow("Officer5", 0);    // hide third walking officer
      offPlace = 4;
      if (life<3) {
        PicShow("JohnSolverLife2", 0); 
        PicShow("JohnSolverLife3", 1); 
      };
      break;
    case 2: 
      PicShow("Officer4", 0);    // hide second walking officer
      PicShow("Officer5", 1);    // show third walking officer
      offPlace = 5;
      break;
    case 3: 
      PicShow("BomberJack3", 1);    // show bomber jack running away from vault exit
      PicShow("Officer4", 1);    // show second walking officer
      PicShow("Officer5", 0);    // hide third walking officer
      offPlace = 4;
      break;
    case 4: 
      life--;
      PicShow("BomberJack3", 0);    // hide bomber jack running away from vault exit
      PicShow("Officer4", 0);    // hide second walking officer
      PicShow("Officer5", 1);    // show third walking officer
      offPlace = 5;
      LivesShow();
      PicShow("JohnSolverLife3", 0); 
      PicShow("JohnSolverEmerge", 1);    // show john's emerge animation puff
      introID = window.setTimeout('PicShow("JohnSolverEmerge", 0);',300);    // hide john's emerge animation puff after 300 milliseconds
      PicShow("JohnSolverEmerging", 1);    // show john solver emerging from life display case
      break;
    case 5:
      PicShow("JohnSolverEmerge", 0);    // hide john's emerge animation puff
      PicShow("JohnSolverEmerging", 0);    // hide john solver emerging from life display case
      PicShow("JohnSolverEntrance", 1);    // show john solver's @ vault exit
      break;
    case 6: 
      PicShow("Officer5", 0);    // hide third walking officer
      PicShow("Officer6", 1);    // show fourth walking officer @ vault entrance
      offPlace = 6;
      break;
    case 7: 
      PicShow("JohnSolverEntrancePointing", 1);    // show john solver's pointing hand @ vault entrance
      break;
    case 8: 
      PicShow("Officer6EntrancePointing", 1);    // show fourth walking officer's pointing hand @ vault entrance
      break;
    case 9: 
      PicShow("JohnSolverEntrancePointing", 0);    // hide john solver's pointing hand @ vault entrance
      break;
    case 10: 
      PicShow("Officer6EntrancePointing", 0);    // hide fourth walking officer's pointing hand @ vault entrance
      break;
    case 11: 
      PlaySound("move_wav", vlm);  // sound for moving
      PicShow("JohnSolverEntrance", 0);    // hide john solver's @ vault exit
      PicShow("Diver", 1);    // show person diving in the vault
      break;
    case 12: 
      PicShow("Diver", 0);    // hide person diving in the vault      
      GameGoNext()     // resume game after pause or any game pausing event
      break;
    default: 
      break;     // exit this handler for other keys
  };
  jtel++;    // next step
  if (jtel<13) levelDoneID = window.setTimeout("StageIntroJonhSolver("+jtel+");",630)    // next john solver entrance animation
  else intro = false;
};

// end animation substage between stages
function StageSubLevelEndAnimation (animation) {
  if (levelDoneID) {    // if level done animation timer
    window.clearTimeout(levelDoneID);  // stop previous level done timer
    levelDoneID = null;  // reset level done ID 1
  };
  switch(animation) {    // sub level end animationn sequence
    case 1:
      PicShow("JohnSolverExit", 1);    // hide john solver's @ vault exit
      break;
    case 4:
      OfficersHide();
      PicShow("CongratsJohnSolver", 1);    // hide congratulating john solver
      PicShow("CongratsOfficer", 1);    // hide congratulating officer
      PicShow("CongratsUp", 1);    // hide congratulating hands up
      PicShow("JohnSolverExit", 0);    // hide john solver's @ vault exit
      break;
    case 5:
      PicShow("CongratsDown", 1);    // hide congratulating hands down
      PicShow("CongratsUp", 0);    // hide congratulating hands up
      break;
    case 6:
      PicShow("CongratsDown", 0);    // hide congratulating hands down
      PicShow("CongratsUp", 1);    // hide congratulating hands up
      break;
    case 7:
      PicShow("CongratsDown", 1);    // hide congratulating hands down
      PicShow("CongratsUp", 0);    // hide congratulating hands up
      break;
    case 8:
      PicShow("CongratsDown", 0);    // hide congratulating hands down
      PicShow("CongratsUp", 1);    // hide congratulating hands up
      break;
    case 9:
      PicShow("CongratsDown", 1);    // hide congratulating hands down
      PicShow("CongratsUp", 0);    // hide congratulating hands up
      break;
    case 10:
      PicShow("CongratsDown", 0);    // hide congratulating hands down
      PicShow("CongratsUp", 1);    // hide congratulating hands up
      break;
    case 11:
      PicShow("CongratsDown", 1);    // hide congratulating hands down
      PicShow("CongratsUp", 0);    // hide congratulating hands up
      break;
    case 13:
      ScoreAdd(100);    // add 100 stage points to score
      break;
    case 48:
      life++;
      if (game==1) {    // game A running
        if (level<levels) {    // if not last level
          level-=4;    // go four levels back
        } else {
          level = 1;    // still first level
          timerStart-=10;    // give next run 10 seconds less starting time
        };
      } else {    // game B running
        timerStart-=4;    // give next run 4 seconds less starting time
      };
      StageIntro();    // add 100 stage points to score
      break;
    default: 
  };
  animation++;    // next sequence
  if (animation<49) levelDoneID = window.setTimeout("StageSubLevelEndAnimation("+animation+");",250);    // animate next step
};

// close end level with wall
function StageSubLevelEndWall () {
  for (i=1 ; i<5 ; i++) {     // the lines
    PicShow("WallVert"+(eval(i*10+1))+"", 1);     // show left walls @ this line
    wallVert[(eval(i*10+1))] = 1;     // add left walls @ this line
  };
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end animation functions

