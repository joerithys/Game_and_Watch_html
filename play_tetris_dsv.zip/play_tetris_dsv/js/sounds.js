/*------------------------------------------------------------------sound------------------------------------------------------------------*/
var prefSound = 1;	  // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off
var prefAlarmSet;	// last saved alarm setting 1-on; 0-off
var prefAlarmMin;	// last saved alarm setting minutes
var prefAlarmHour;	// last saved alarm setting hours
var preVlm = 1;	   // previous sound volume 0.01-1
var sound = true;	// to prevent click sound @ autostart
var vlm = 1;	// sound volume 0.01-1


function PlaySound (name, vol) {
	if ( prefSound&&!demo ) {
		StopSoundLoop (name);
		PlaySoundAlways (name, vol);
	}
}

function PlaySoundAlways (name, vol) {
	var playPromise;	// play-preset indicator
	name+="wav";
	playPromise = document.getElementById(name).play();
	if (vol) { 
		document.getElementById(name).volume = vol;
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
			// playback started!
		})
		.catch(error => {
			// play was prevented
		});
	}
}
function PlaySoundEvenIfDemo (name, vol) {
	if ( prefSound ) {
		PlaySoundAlways (name, vol);
	}
}

function PlaySoundLoop (name, vol) {
	var playPromise;	// play-preset indicator
	if (!demo ) {
		name+="wav";
		if (typeof document.getElementById(name).loop == 'boolean') {
			document.getElementById(name).loop = true;
		} else {
			myAudio.addEventListener('ended', function() {
				this.currentTime = 0;
				this.play();
			}, false);
		}
		playPromise = document.getElementById(name).play();
		document.getElementById(name).volume = vol; // because is loop, keep following volume
		if (playPromise !== undefined) {
			playPromise.then(_ => {
				// playback started!
			})
			.catch(error => {
				// play was prevented
			});
		}
	}
}

function StopSound (name, vol) {
	var playPromise;	// play-preset indicator
	StopSoundLoop (name)
	name+="wav";
	playPromise = document.getElementById(name).pause();
	if (vol) { 
		document.getElementById(name).volume = vol;	 // only set volume if present
	}
	if (playPromise !== undefined) {
		playPromise.then(_ => {
			// playback stopped!
		})
		.catch(error => {
			// stopping was prevented
		});
	}
}

function StopSoundLoop (name) {
	name+="wav";
	if (typeof document.getElementById(name).loop == 'boolean') {
		document.getElementById(name).loop = false;
		document.getElementById(name).currentTime = 0;
	}; 
}

/*------------------------------------------------------------------sound------------------------------------------------------------------*/

//extra sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//make beep-sound
function Beep () {
	PlaySound("beep_", vlm);
};

// swich sound on/off; dont preload here
function PrefSound () {
	prefSound = !prefSound;
	PrefSoundEval();	// Show sound volume settings according to current settings
};

// Show sound settings according to current settings
function PrefSoundEval () {
	if (!prefSound) { // if sound is set to "off" 
		preVlm = vlm;   // remember last sound volume
		vlm = 0;		// set volume to 0
	} else {
		if (preVlm==0) preVlm = 0.01; // if no previous sound volume, set to minimum
		vlm = preVlm;   // set sound volume to previous setting
	};
	PrefSoundSettings();	// show sound on/off indication
	PrefSoundShow();	// show volume indicator on screen for testing purposes
	SetSoundVolume();
	PlaySound("click_", vlm);	// click sound for slide button
};

// show sound on/off indication according to settings
function PrefSoundSettings () {
	if (prefSound) PicShow("Sound", soundOnPre.src)	// show sond on indication
	else PicShow("Sound", soundOffPre.src);		// show sound off indication
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
	var vlmTxt = "";	// empty sound volume indicator picture
	$("#SoundStateInd").html("");	// empty/hide volume indicator on screen
	if (prefSoundShow) {	  // if volume indicator is set to show
		if (vlm>0.00999) {
			// count number of sound indicator bars & translate to html
			for(var i=1; i<=(vlm*100); i++) vlmTxt += '<img SRC="img/screen/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
			$("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
		} else $("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	} else {
		$("#SoundStateInd").html('<img SRC="img/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	};
};

// swich sound on/off; dont preload here
function SetSound (setting) {
	prefSound = setting;
	PrefSoundSettings();	// show sound on/off indication
	PlaySound("click_", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function SetSoundVolume () {
	var fileName;
	document.getElementById("congrats_wav").volume = vlm;
	document.getElementById("nut-6_wav").volume = vlm;
	document.getElementById("rocket_wav").volume = vlm;
	if (game==1 || game==2) {
		fileName = "tetris_theme_"+(game==1?"a":"b")+"_";
		document.getElementById((fileName+"wav")).volume = vlm;				
	};
};

// show/hide icons for sound & alarm as set
function ShowSndIcns () {
	if (!alarmOn && game!=9) {
		PicShow("AlarmStateInd", nullPre.src);
	} else {
		PicShow("AlarmStateInd", alarmStateIndPre.src);
	};
};

// stop all playing sounds except the button click
function StopAllSound () {
	StopSound("alarm_", vlm);
	StopSound("click_", vlm);
	StopSound("congrats_", vlm);
	StopSound("game_over_", vlm);
	StopSound("land_", vlm);
	StopSound("level_", vlm);
	StopSound("line_", vlm);
	StopSound("move_", vlm);
	StopSound("nothing_", vlm);
	StopSound("nut-6_", vlm);
	StopSound("pause_", vlm);
	StopSound("rocket_", vlm);
	StopSound("rotate_", vlm);
	StopSound("shift_", vlm);
	StopSound("stage_clear_", vlm);
	StopSound("tetris_", vlm);
	StopSound("tetris_theme_a_", vlm);
	StopSound("tetris_theme_b_", vlm);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end extra sound functions
