//Product:					G&W title HTML - New Wide Screen (Nintendo) Simulator
//Version:					1.1
//Started:					19.11.2021
//Last update:					09.05.2022
//Author/creator:			   Flyzy (Joeri Thys)
//Programmer					Flyzy (Joeri Thys)
//Original G&W prototype:	   Nintendo Co. Ltd

//Credits:
//Design, layout and artwork by Lee Robson (hydef)
//Based on scans by Sean Riddle

//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = 0;	   // indicates if demo is running or not
var demoID;	 // ID for timeout demo autostart after last handling & keeping cycling
var demoMoveID;	// for little delay on the movements of the figures to ensure single move
var demoMovesSet = new Array(6);	// set of corresponding moves for the demo
var sequence = 1;	// sequence to let figures move seperately per row

var acl = 0;	// for showing all pictures, all if "ACL" pressed twice fast
var aclID;	// ID to view all pictures @ fast double click
var actionPos;   // to indicate last action
var actionToggle = 1;   // to toggle action and Up controls
var congrats = 0;	// quotum not reached
var direction = 1;	  // direction of the current falling figure
var dropFinished = 1;	// no full drop in progress
var droppable = 1;	  // indication the figure can move down
var droppableFull = 26;	// for refresh full screen
var dropID = new Array(6);	  // for drop timing
var figure;	 // current falling figure
var figureDim = new Array(5);	  // current falling figure
for (var i=1; i<figureDim.length; i++) {
	figureDim[i] = new Array(5);	  // makes screen 2D
}
var figureDimFalling = new Array(11);	  // possible loose figures ready to fall after full line was removed
for (var j=1; j<figureDimFalling.length; j++) {
	figureDimFalling[j] = new Array(27);	  // makes screen 2D
	for (var i=1; i<figureDimFalling[j].length; i++) {
		figureDimFalling[j][i] = new Array(10);	  // 10 possible loose figures, ready to fall
	};
}
var figureDimFallingNumber = 0;	// number of loose figures after full line gone @ Game A
var figureDimFallingPrev = new Array(27);	  // for registring loose falling figures @ previous position
for (var i=1; i<figureDimFallingPrev.length; i++) {
	figureDimFallingPrev[i] = new Array(10);	  // makes screen 2D
}
var figureDimGrounded = new Array(27);	  // temperary part of stack of the blocks that aren't loose
for (var i=1; i<figureDimGrounded.length; i++) {
	figureDimGrounded[i] = new Array(10);	  // makes screen 2D
}
var figureDimTurned = new Array(5);	  // figure as it would have been turned one position
for (var i=1; i<figureDimTurned.length; i++) {
	figureDimTurned[i] = new Array(5);	  // makes screen 2D
}
var figureDimTurning = new Array(5);	  // scope of turning figure
for (var i=1; i<figureDimTurning.length; i++) {
	figureDimTurning[i] = new Array(5);	  // makes screen 2D
}
var figureFallableHeight = new Array(10);	// hight that loose figure can fall
var figureFullLinesStacked;	// number of full lines found in the stacked figures
var figureDropHeight = 0;	// count drop height to be able to calculate score accordingly 
var figureNext; // nex figure to drop
var figurePosX; // horizontal position of the top left corner of the figure on the figuresScreen
var figurePosXCor = 0;	// possible correction for "I" figure's right position
var figurePosY; // vertical position of the top left corner of the figure on the figuresScreen
var figuresDemo = new Array(11);	  // demo figures
var figuresScreen = new Array(30);	  // screen where the figures drop and stack
for (var i=1; i<figuresScreen.length; i++) {
	figuresScreen[i] = new Array(10);	  // makes screen 2D
}
var figureTurnPrev = 0;	// to show or not show current falling figure in next turned position in a ghostly way
var fit;	// turning figure fits grounded blocks
var game = 0;   // 0-no-game-acl-pictures; 1-gameA; 3-game-over; 4-clock; 5-alarm-on; 7-alarm-set; 8-alarm-off;
var gameGo = 0;	// game stopped;
var gameID;	// ID for timeout game sequence
var gameGoID;	// ID for timeout game restart for drop possibility
var gameOverID;	// ID for timeout game over animation
var gameOverTxtID;	// ID for timeout game over end text
var gameResetID;		// ID for return from action after 0,3 sec stationary
var gameSpeedMax = 200;	// maximum speed for game sequence timer
var gameSpeedMin = 350;	// minimum speed for game sequence timer
var gameSpeed = 500;	// speed for game sequence timer
var goLeftPossible = 1;
var goRightPossible = 1;
var highScore = new Array();
var gameOver = 1;   // game not running
var runTime = 5;	// times to run a blink function
var stacked = 0;	// indicates if falling figure got stacked
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var actionKeyPressed = 0; // indicates if a previuos action key was already pressed to avoid double entries
var keyDown = 0;
var keyLeft = 0;
var keyRight = 0;
var keyUp = 0;
var keyPressed = 0; // indicates if a previuos direction key was already pressed to avoid double entries
var RKeyPressed = 0;	// indicates if a previuos hit "ACL" key was already pressed to avoid double entries
var TKeyPressed = 0;	// indicates if a previuos hit "TIME" key was already pressed to avoid double entries

var prefSound = 1;	  // 1-on; 0-off
//var prefSoundShow = 0;  // show sound volume 1-on; 0-off

var pointsBonus = 0;
var score = 0;	// score (all beneath 100) at init
var scoreBonus = 0;	// score bonus not added
var scoreBonusID;	// ID for timeout bonus indication blinking score

var score = 0;
var levelTS = 0;
var linesTS = 0;

var alarm = 0;	// alarm not running
var alarmID;	// ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = 1;	 // for indicationif alarm is set on or off
var alarmSetting = 0;	   // if alarm is at set mode to make changes

var prefAlarmMin = 0;	// last saved alarm setting minutes
var prefAlarmHour = 0;	// last saved alarm setting hours

var timeID;	 // ID for timeout time indication @ demo
var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", function (e) {
	codeCurrent = e.keyCode;		// for reading game keys
	e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
	switch (e.key) {
		case "1": case"a": case"A":	 // if "1", "a" or "A" pressed
			// show game button pressed
			document.images['Game A'].src = 'img/case/buttons/black_1_flat.png';	 
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainGameA(); // show high score @ play Game A after button release
			keyPressed = 1;
			break;
		case "2": case"b": case"B":	 // if "2", "b" or "B" pressed
			// show game button pressed
			document.images['Game B'].src = 'img/case/buttons/black_2_flat.png';	 
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainGameB(); // show high score @ play Game B after button release
			keyPressed = 1;
			break;
		case "x": case "X": case "ArrowDown":	// down key released
			// show down button pressed
			document.images['Move Down'].src = 'img/case/buttons/down_flat.png';	 
			if (!keyPressed) {	// if no key pressed
				DownPressed();	  // function to move down
				keyPressed = 1;
			};
			break;
		case "s": case "S": case "ArrowLeft":	// left keys
			// show left button pressed
			document.images['Move Left'].src = 'img/case/buttons/left_flat.png';   
			if (!keyPressed) {			// if no key pressed
				LeftPressed();	  // function to move left
				keyPressed = 1;
			};
			break;
		case "d": case "D": case "ArrowRight":	// right keys
			// show right button pressed
			document.images['Move Right'].src = 'img/case/buttons/right_flat.png';	 
			if (!keyPressed) {			// if no key pressed
				RightPressed();	 // function to move right
				keyPressed = 1;
			};
			break;
		case "e": case "E": case "ArrowUp":	// up key released
			// show up button pressed
			document.images['Move Up'].src = 'img/case/buttons/up_flat.png';	 
			if (!keyPressed) {			// if no key pressed
				UpPressed();	 // function to move right
				keyPressed = 1;
			};
			break;
		case "Space": case " ": case "Enter":	// space or enter key
			// show action button pressed
			document.images['Action gb'].src = 'img/case/buttons/action_flat.png';	 
			if (!actionKeyPressed) {			// if no key pressed
				ActionPressed();	 // function to move right
				actionKeyPressed = 1;
			};
			break;
		case"r": case"R":	 // if "r" or "R" pressed
			// show acl button pressed
			RKeyPressed = 1;	// reset button is pressed
			document.images['Acl'].src = 'img/case/buttons/acl_push.png';
			TotalReset(); // show full sprites
			break;
		case"t": case"T":	 // if "t" or "T" pressed
			// show time button pressed
			document.images['Time'].src = 'img/case/buttons/black_3_flat.png';
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainTime(); // if no other key/button is pressed
			TKeyPressed = 1;	// time button pressed
			TimeShowOnScreen(prefAlarmMin, prefAlarmHour);	 // show time & demo
			break;
		case"w": case"W":	 // if "w" or "W" pressed
			// show alarm button pressed
			document.images['Alarm'].src = 'img/case/buttons/acl_push.png';
			if (!keyPressed&&!RKeyPressed&&!TKeyPressed) MainAlarm(); // set alarm
			break;
		//test case buttons 
		case "c": case "C":
			switchKey();
			break;
		case "p": case "P":
			FigureHide(figurePosX, figurePosY);	// hide figure @ current position
			// show next turn position ghostly
			figureTurnPrev = figureTurnPrev?0:1;
			FigureShow(figurePosX, figurePosY);	// show falling figure @ current position
			break;
		case "+":	// "+"-numpadkey
			if (vlm<1) {
				vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
				preVlm = vlm;   // current voluem becomes previus set @ next change of volume
			};
			if (vlm==0.01)  SetSound(1);	// show sound turned on
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			SetSoundVolume();
			break;
		case "-":	// "-"-key
			if (vlm>0) {
				vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
				preVlm = vlm;   // current voluem becomes previus set @ next change of volume
			};
			if (vlm==0) SetSound(0);	// show sound turned off
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			SetSoundVolume();
			break;
		case "/":	// "-"-key
			if (vlm==0.3) vlm = 0.03
			else vlm = 0.3;
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			SetSoundVolume();
			break;
		case "@": case String.fromCharCode(233):	// mac-"@"(at)-key/win-"é"(e-accent-egue)-key 
			prefSoundShow = !prefSoundShow;	 // show/hide indicator
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case ")": case String.fromCharCode(219):
			zoomed = zoomed?0:1;
			$(function () {
				CheckSizeZoom()
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);
			break;
		default:
			break;
	};
	console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'										 zoomed = "+zoomed+"   -   actionToggle = "+actionToggle);
}, 0);

window.addEventListener("keyup", function (e) {
	// game and arrow keys
	switch (e.key) {
		case "x": case "X": case "ArrowDown":	// down key released
			// show down button default
			document.images['Move Down'].src = 'img/case/buttons/down.png';	 
			keyPressed = 0;
			break;
		case "s": case "S": case "ArrowLeft":	// left key released
			// show left button default
			document.images['Move Left'].src = 'img/case/buttons/left.png';	 
			keyPressed = 0;
			break;
		case "d": case "D": case "ArrowRight":	// right key released
			// show right button default
			document.images['Move Right'].src = 'img/case/buttons/right.png';	 
			keyPressed = 0;
			break;
		case "e": case "E": case "ArrowUp":	// up key released
			// show up button default
			document.images['Move Up'].src = 'img/case/buttons/up.png';	 
			keyPressed = 0;
			break;
		case "Space": case " ": case "Enter":	// space or enter key
			// show action button default
			document.images['Action gb'].src = 'img/case/buttons/action.png';
			actionKeyPressed = 0;	 
			break;
		case "1": case"a": case"A":	 // if "1", "a" or "A" released
			document.images['Game A'].src = 'img/case/buttons/black_1.png';  
			MainGameAGo(); // start running Game A
			keyPressed = 0;
			break;
		case "2": case"b": case"B":	 // if "2", "b" or "B" released
			document.images['Game B'].src = 'img/case/buttons/black_2.png';  
			MainGameBGo(); // start running Game B
			keyPressed = 0;
			break;
		case"r": case"R":	 // if "r" or "R" pressed
			document.images['Acl'].src = 'img/case/buttons/acl.png';
			RKeyPressed = 0;
			break;
		case"t": case"T":	 // if "t" or "T" released
			document.images['Time'].src = 'img/case/buttons/black_3.png';
			TKeyPressed = 0;
			TimeShowOnScreen(min, hour);
			break;
		case"w": case"W":	 // if "w" or "W" pressed
			document.images['Alarm'].src = 'img/case/buttons/acl.png';
			break;
		default: 
			break;
	};
	//console.log("@keyup : demoID = "+demoID);
}, 0);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//
$(window).focus(function(){
	//focus log code
	console.log("\x1B[31mWindow focused ...				\x1B[36mRefreching sereen ...			 \x1B[32mWelcome back!	 \x1B[30m---	  "+(gameOver?"screen not refreshed because GAME OVER !!!":"\x1B[31m	 SCREEN REFRESHED !	 "));
	if (!gameOver) FiguresScreenShowCurrent(); // show current screen status from bottom to top
});

//when page loaded focus on game 
$(document).ready(function () {
	$(function () {
		CheckSizeZoom()
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);
	highScore[1] = 0;	// high score game A
	highScore[2] = 0;	// high score game B
	$("#game").focus(); // get focus on the game
	PicPreload();	// this function preloads all images to make them ready for use
	MainPicturesShow();	// show default figures
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
	console.log('\x1B[31mHello\x1B[34m World   \x1B[30m30 \x1B[31m31 \x1B[32m32 \x1B[33m33 \x1B[34m34 \x1B[35m35 \x1B[36m36 \x1B[37m37 \x1B[38m38 \x1B[39m39'); 	// color test
});

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// actually perform action
function Action () {
	if (((game==1||game==2)&&gameGo) || demo) {	// if game playing
		if (actionToggle) {
			FiguresRotate();		// rotate figure clockwise if possible
		} else {
			FigureDropFull();	// drop figure as low as it can
		}
	};
};

// action button or -key pressed
function ActionPressed () {
	if ((!demo&&!gameOver)||alarmSetting) {		// to avoid continious action @ running game or if alarm is set
		Action();	// action
	};
};

// go down @ game or change alarm hour if alarm is being set
function Down () {
	if ((game==1||game==2)&&gameGo) {	// if game playing
		GoDown();	// go position down
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmHour--;	// subtract an from hour alarm setting
			if (prefAlarmHour==-1) prefAlarmHour = 23;
			AlarmShowNum();	// show alarm time
		};
	};
};

// down button or -key pressed
function DownPressed () {
	if ((!keyPressed&&!demo&&!gameOver)||alarmSetting) {		// to avoid continious going down @ running game or if alarm is set
		Down();	// go down @ game or change alarm hour if alarm is being set
	};
};

// actually go down one step
function GoDown () {
	PlaySound("move_", vlm);
	if (!demo) GameGo();	// immediate next game move (down)
};

// actually go to the left
function GoLeft () {
	if (GoLeftPossible(figurePosX, figurePosY)) {	// if not totally left		PlaySound("move_", vlm);
		PlaySound("move_", vlm);
		FigureHide(figurePosX, figurePosY)	// hide figure @ this position
		figurePosX--;	// go position to the left
		if (figure=="I") figurePosXCor = 0;
		FigureShow(figurePosX, figurePosY);	// show figure @ new position
	};
};

// check if posible for figure to go to the left
function GoLeftPossible (x, y) {
	var goLeftPossible = 1;
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	for (i=1; i<5 ;i++) {
		for (j=4; j>0 ;j--) {	// figure scope
			// if there is block left from figure block, no can go left
			if (goLeftPossible && figureDim[j][i] && ((y+j)<1 || (x+i)<2 || figuresScreen[(y+j)][(x+i-1)]) ) goLeftPossible = 0;
		};
	};
	return goLeftPossible;
};

// actually go to the right
function GoRight () {
	if (GoRightPossible(figurePosX, figurePosY)) {	// if not totally right
		PlaySound("move_", vlm);
		FigureHide(figurePosX, figurePosY)	// hide figure @ this position
		figurePosX++;	// go position to the right 
		FigureShow(figurePosX, figurePosY);	// show figure @ new position
	};
};

// check if posible for figure to go to the right
function GoRightPossible (x, y) {
	var goRightPossible = 1;
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	for (i=4; i>0 ;i--) {
		for (j=4; j>0 ;j--) {	// figure scope
			// if there is block right from figure block, no can go right
			if (goRightPossible && figureDim[j][i] && ((y+j)<1 || (x+i)>9 || figuresScreen[(y+j)][(x+i+1)]) ) goRightPossible = 0;
		};
	};
	return goRightPossible;
};

// actually go up/rotate
function GoUp () {
	if (actionToggle) {
		FigureDropFull();	// drop figure as low as it can
	} else {
		FiguresRotate();		// rotate figure clockwise if possible
	}
};

// go left @ game or change alarm hour or minutes if alarm is being set
function Left () {
	if ((game==1||game==2)&&gameGo) {	// if game playing
		GoLeft();	// go position to the left
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmMin--;	// subtract a minute from alarm time
			if (prefAlarmMin==-1) prefAlarmMin = 59;
			AlarmShowNum();	// show alarm time
		};
	};
};

// left button or -key pressed
function LeftPressed () {
	if ((!keyPressed&&!demo&&!gameOver)||alarmSetting) {		// to avoid continious going left @ running game or if alarm is set
		Left();	// go left @ game or change alarm hour or minutes if alarm is being set
	};
};

// make an array
function MakeArray (size) {
	this.length = size;
	for(var i=1; i<=size; i++) this[i] = 0;	// empty
};

// show/hide figure on screen
function PicShow (id, name) {
	if (name) document.images[id].src = name;	// if picture given, assign it to the figure
};

// go right @ game or change alarm hour or minutes if alarm is being set
function Right () {
	if ((game==1||game==2)&&gameGo) {	// if game playing
		GoRight ();	// go position to the right
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmMin++;	// add a minute to alarm time
			if (prefAlarmMin==60) prefAlarmMin=0;
			AlarmShowNum();	// show alarm time
		};
	};
};

// right button or -key pressed
function RightPressed () {
	if ((!keyPressed&&!demo&&!gameOver)||alarmSetting) {		// to avoid continious going right @ running game or if alarm is set
		Right();	// go right @ game or change alarm hour or minutes if alarm is being set
	};
};

// switch "Up" & "Action" keys
function switchKey () {
	actionToggle = actionToggle?0:1;
	if (actionToggle) {
		$("#CurA_txt").html("TURN");
	} else {
		$("#CurA_txt").html("DROP");
	} ;
};

// go up @ game or change alarm hour if alarm is being set
function Up () {
	if ((game==1||game==2)&&gameGo) {	// if game playing
		GoUp ();	// go position up
	} else {
		if (game==5 || game==8) {	// change the alarm time
			prefAlarmHour++;	// add an hour to alarm setting
			if (prefAlarmHour==24) prefAlarmHour = 0;
			AlarmShowNum();	// show alarm time
		};
	};
};

// up button or -key pressed
function UpPressed () {
	if ((!keyPressed&&!demo&&!gameOver)||alarmSetting) {		// to avoid continious going up @ running game or if alarm is set
		Up();	// go up @ game or change alarm hour if alarm is being set
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function creates all block images (empty)
function BlockPreload () {
	var elem;	//	html element for image
	for (j=1 ; j<14 ; j++) for (i=1 ; i<11 ; i++) {	// top screen
		elem = '<img SRC="img/null.gif"  name="Block'+eval(j)+"-"+eval(i)+'" border=0 style="position: absolute; top: '+((j-1)*31)+'px; left: '+(((i-1)*31)+5)+'px;">'
		$("#BlocksTop").append(elem);
	}
	for (j=14 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// bottom screen
		elem = '<img SRC="img/null.gif"  name="Block'+eval(j)+"-"+eval(i)+'" border=0 style="position: absolute; top: '+((j-14)*31)+'px; left: '+(((i-1)*31)+5)+'px;">'
		$("#BlocksBottom").append(elem);
	}
	for (j=1 ; j<3 ; j++) for (i=1 ; i<5 ; i++) {	// preview / "next figure" screen
		elem = '<img SRC="img/null.gif"  name="Preview'+eval(j)+eval(i)+'" border=0 style="position: absolute; top: '+((j-1)*31)+'px; left: '+(((i-1)*31)+5)+'px;">'
		$("#Preview").append(elem);
	}
};

// this function clears all preview block images
function BlockPreviewClear () {
	for (j=1 ; j<3 ; j++) for (i=1 ; i<5 ; i++) PicShow("Preview"+eval(j)+eval(i)+"", nullPre.src);
};

// this function fills all preview block images
function BlockPreviewShowAll () {
	for (j=1 ; j<3 ; j++) for (i=1 ; i<5 ; i++) PicShow("Preview"+eval(j)+eval(i)+"", blockPre.src);
};

// this function preloads all images
function PicPreload () {
	alarmStateIndPre = new Image();
	alarmStateIndPre.src = "img/screen/alarmStateInd.png";	// to show if alarm is set on or off
	bellDownPre = new Image();
	bellDownPre.src = "img/screen/alarmStateInd.png";	// to show ringing bell in down-state @ alarm
	bellPre = new Image();
	bellPre.src = "img/screen/alarmStateInd.png";	// to show bell @ alarm
	bellUpPre = new Image();
	bellUpPre.src = "img/screen/alarmStateInd.png";	// to show ringing bell in up-state @ alarm
	bkgnd = new Image();
	bkgnd.src = "img/case/case.png";	// to refresh background
	blockPre = new Image();
	blockPre.src = "img/screen/block.png";	// to show normal blocks
	blockGrayPre = new Image();
	blockGrayPre.src = "img/screen/blockGray.png";	// to show light gray turned figure's free block
	blockOverlapPre = new Image();
	blockOverlapPre.src = "img/screen/blockOverlap.png";	// to show dark gray turned figure's figure overlay block
	blockRedPre = new Image();
	blockRedPre.src = "img/screen/blockRed.png";	// to show red turned figure's screen overlay block
	blockEmptyPre = new Image();
	blockEmptyPre.src = "img/screen/blockEmpty.png";	// to show innerblock
	blockHollowPre = new Image();
	blockHollowPre.src = "img/screen/blockHollow.png";	// to show outerblock
	BlockPreload();	// create all block images
	FiguresDemoSet();	// load set of ordered demo figures
	levelTxtPre = new Image();
	levelTxtPre.src = "img/screen/levelTxt.png";	// to show level text
	lineTxtPre = new Image();
	lineTxtPre.src = "img/screen/lineTxt.png";	// to show line text
	nullPre = new Image();
	nullPre.src = "img/null.gif";	// empty picture to hide any figure
	numPre = new Array();
	for (i=1 ; i<15 ; i++) { 	// to show the 10 numbers + 5 letters for time & "next" text
		numPre[i] = new Image();
		numPre[i].src = "img/screen/num"+eval(i-1)+".png";
	};
	numColonPre = new Image();
	numColonPre.src = "img/screen/num_colon.png";	// to show time splitter colon
	scoreTxtPre = new Image();
	scoreTxtPre.src = "img/screen/scoreTxt.png";	// to show score text
	snumPre = new Array();
	for (i=1 ; i<11 ; i++) { 	// to show the 10 numbers for score
		snumPre[i] = new Image();
		snumPre[i].src = "img/screen/snum"+eval(i-1)+".png";
	};
	soundOnPre = new Image();
	soundOnPre.src = "img/case/buttons/butOn.png";	// to show sound button in on-state
	soundOffPre = new Image();
	soundOffPre.src = "img/case/buttons/butOff.png";	// to show sound button in off-state
};

// hide all figures, text & numbers
function AllPicturesClear () {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) PicShow("Block"+eval(j)+"-"+eval(i)+"", nullPre.src);	// clear top & bottom screen
	PicShow("BellUp", nullPre.src);	// hide bell picture for upcoming alarm
	BlockPreviewClear();	// clears all preview block images
	PicShow("AlarmStateInd", nullPre.src);	// hide bell picture for alarm on/of indicator
	FiguresScreenClear();	// empty all the blocks on the screen and show the empty blocks
	PicShow("LevelTxt", nullPre.src);	// hide level text
	for (i=1 ; i<5 ; i++) PicShow("Level"+eval(i)+"", nullPre.src);	// hide level numbers
	PicShow("LineTxt", nullPre.src);	// hide line text
	for (i=1 ; i<5 ; i++) PicShow("Line"+eval(i)+"", nullPre.src);	// hide line numbers
	PicShow("NumColon", nullPre.src);	// hide time h - m seperator
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);	// hide time numbers / next text
	PicShow("ScoreTxt", nullPre.src);	// hide score text
	for (i=1 ; i<7 ; i++) PicShow("Score"+eval(i)+"", nullPre.src);	// hide score numbers
};

// show all figures
function AllPicturesShow () {
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);	// set all time numbers to "8"
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) PicShow("Block"+eval(j)+"-"+eval(i)+"", blockPre.src);	// show all blocks on screen
	PicShow("BellUp", bellUpPre.src);	// show bell picture for upcoming alarm
	BlockPreviewShowAll();	// show all preview block images
	PicShow("AlarmStateInd", alarmStateIndPre.src);	// show bell picture for alarm on/of indicator
	PicShow("LevelTxt", levelTxtPre.src);	// show level text
	for (i=1 ; i<5 ; i++) PicShow("Level"+eval(i)+"", snumPre[9].src);	// set all level numbers to "8"
	PicShow("LineTxt", lineTxtPre.src);	// show line text
	for (i=1 ; i<5 ; i++) PicShow("Line"+eval(i)+"", snumPre[9].src);	// set all line numbers to "8"
	PicShow("NumColon", numColonPre.src);	// show ":"
	PicShow("ScoreTxt", scoreTxtPre.src);	// show score text
	for (i=1 ; i<7 ; i++) PicShow("Score"+eval(i)+"", snumPre[9].src);		// set all score numbers to "8"
};

// show default pictures for demo
function MainPicturesDefault () {
	AllPicturesClear();	// hide all figures, text & numbers
	ShowSndIcns();	// show/hide icons for sound & alarm as set
};

// show all figures & "12:00"
function MainPicturesShow () {
	MainPicturesDefault();	// show default pictures for demo
	PicShow("AlarmStateInd", alarmStateIndPre.src);	// show bell picture for alarm on/of indicator
	PicShow("BellUp", bellUpPre.src);	// show bell picture for upcoming alarm
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) PicShow("Block"+eval(j)+"-"+eval(i)+"", blockPre.src);	// show all blocks on screen
	PicShow("LevelTxt", levelTxtPre.src);	// show level text
	for (i=1 ; i<5 ; i++) PicShow("Level"+eval(i)+"", snumPre[9].src);	// set all level numbers to "8"
	PicShow("LineTxt", lineTxtPre.src);	// show line text
	for (i=1 ; i<5 ; i++) PicShow("Line"+eval(i)+"", snumPre[9].src);	// set all line numbers to "8"
	PicShow("NumColon", numColonPre.src);	   // show ":"
	PicShow("Num1", numPre[2].src);	 // "1"
	PicShow("Num2", numPre[3].src);	 // "2"
	PicShow("Num3", numPre[1].src);	 // "0"
	PicShow("Num4", numPre[1].src);	 // "0"
	PicShow("ScoreTxt", scoreTxtPre.src);	// show score text
	for (i=1 ; i<7 ; i++) PicShow("Score"+eval(i)+"", snumPre[9].src);	// set all score numbers to "8"
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// stop game if playing and reset all ID's
function AllStop () {
	GameReset();	// clear gameID, gameResetID
	TimerReset(); // stop the counter to show the current time
};

// clear all dropping delays for loose/falling figures
function dropIDsClear () {
	for (x=1 ; x<6 ; x++) {	// max dropping loose figures
		window.clearTimeout(dropID[x]);	// stop drops from continueing
		dropID[x] = null;
	};
};

// reset hights how far loose figures can drop
function figureFallableHeightReset () {
	for (f=1; f<10; f++) {	// for the number of individual loose figures, ready to be dropped and grounded
		figureFallableHeight[f] = 0;	// reset calculated hight of this loose figure
	};
};

// reset all game and demo ID's
function GameReset () {
	if (demoID) {
		window.clearTimeout(demoID);	// stop demo from continueing
		demoID = null;
	};
	if (demoMoveID) {
		window.clearTimeout(demoMoveID);	// stop demo all moves 
		demoMoveID = null;
	};
	if (dropID[1]) dropIDsClear();	// clear all dropping delays for loose/falling figures
	if (gameID) {
		clearTimeout(gameID);	// stop the game progress
		gameID = null;
	};
	if (gameOverID) {
		clearTimeout(gameOverID);	// stop the game over animation
		gameOverID = null;
	};
	if (gameOverTxtID) {
		clearTimeout(gameOverTxtID);	// stop the game over text from showing
		gameOverTxtID = null;
	};
};

// clear all pictures & variables
function ResetAll () {
	AllStop();  // stop game if playing and reset all ID's
	if (!gameOver) AllPicturesClear ();		// hide all figures
	alarmSetting = 0;	   // no alarm running
	demo = 0;	// no demo running
	game = 3;   // game over
	gameOver = 1;
	// reset pressed keys...
	keyPressed = 0;
	RKeyPressed = 0;
	TKeyPressed = 0;
	sequence = 0;	   // game sequence reset
};

// stop showing current time
function TimerReset () {
	if (timeID) {
		clearTimeout(timeID);
		timeID = null;
	};
};

// "ACL" is pressed to clear all and reset all on going to default and show all figures
function TotalReset () {
	StopAllSound();
	PlaySound("click_", vlm);	// click sound for push button
	if (alarm) TimeAlarmOff();	// stop alarm if running
	AlarmReset();	// reset alarm time
	ResetAll(); // clear all pictures & variables
	if (acl) AllPicturesShow()	// show all figures & "88:88" if "acl" clicked twice fast
	else MainPicturesShow(); // show all figures & "12:00"
	acl = 1; // indicates "acl" already clicked
	if (alarmID) {
		alarmID = null;
		clearTimeout(alarmID);	// stop running alarm sound from repeating
	};
	if (alarmOffID) {
		alarmOffID = null;
		clearTimeout(alarmOffID);	// stop running timer to turn off alarm @ running
	};
	game = 0;   // no-game-all-pictures
	aclID = window.setTimeout("acl = 0;", 130);	 // ID to show all pictures if "acl" clicked twice in 130 milliseconds
	demoID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end set/reset functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// next move of game
function GameGo () {
	var counter = 0;	// loop counter to avoid loop from getting stuck by running for ever if last add was delayed
	if (gameID) {
		clearTimeout(gameID);	// stop the game's possible double call
		gameID = null;
	};
	if (!gameOver) {
		if (figure) {	// if figure present
			FigureDrop(figurePosX, figurePosY);	// drop figure one place if possible
		} else {
			figure = figureNext;	// go to next figure
			direction = 1;	// reset direction to starting position
			FigureDimSet();	// set dimensions of this next figure and its directions
			FigureShow(figurePosX, figurePosY);	// show new figure on screen
			figureNext = FigureChoose();	// choose next figure randomly
			FigureShowNext(figureNext);	// show next to come figure in preview/next-box
		};
		if (!FigureStackFull()) gameID = window.setTimeout("GameGo()", gameSpeed);	// next step in gameSpeed milliseconds
	};
};

// common settings games
function GameOver () {
	droppable = 1;	// for start game over animation from top to bottom
	gameGo = 0;	// no moves possible
	gameOver = 1;	// indicates game to be over
	PlaySound("game_over_", vlm);
	GameOverTxt();	// block out screen & show game over text
};

// set common settings games for next level
function GameBLevelSet () {
	if (gameID) {
		clearTimeout(gameID);	// stop the game's possible double call
		gameID = null;
	};
	FigureStackSetHeight(); // place two stacked lines per level @ game B with a minimum of 0 and a maximum of 14 lines
	FiguresScreenShowCurrent(); // show current screen status from bottom to top
	FigureShow(figurePosX, figurePosY);	// show current falling figure on screen
	gameID = window.setTimeout("GameGo();", gameSpeed);	// continue game
};

// common settings games
function GameSet () {
	ResetAll();	// reset all screen settings
	StopAllSound();
	MainPicturesDefault();	// show default start pictures
	levelTS = 0;
	score = 0;
	ScoreShow(score);	// show current score
	LevelShow(levelTS);	// show level number
	figure = FigureChoose();	// choose current falling figure randomly
	congrats = 0;	// quotum not reached
	direction = 1;	// reset direction to starting position
	PicShow("NumColon", nullPre.src);	// hide time seperator
	// show next text
	PicShow("Num1", numPre[11].src);	 // n
	PicShow("Num2", numPre[12].src);	 // e
	PicShow("Num3", numPre[13].src);	 // x
	PicShow("Num4", numPre[14].src);	 // t
	FigureDimSet();	// set dimensions of current figure and its directions
	figurePosX = 4;	 // = x (center-ish)
	figurePosY = 0;	 // = y (top)
	FiguresScreenClear(); // empty all the blocks on the screen and show the empty blocks
	FiguresDimGroundedClear();	// clear previous dimension set of grounded (not able to fall) blocks.
	figureNext = FigureChoose();	// choose next falling figure randomly
	FigureShowNext(figureNext);	// show next to come figure in preview/next-box
	gameGo = 0;
	stacked = 0;
	gameOver = 0;
};

// button pressed to play the game
function MainGameA () {
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (game!=1 && game!=2) {   // if not already game A or B playing
		if (gameOverID) {
			gameOver = 0;	// reset game over if still indicated
			clearTimeout(gameOverID);	// stop the game's possible double call for MainTimeStart() after game over
			gameOverID = null;
		};
		if (demo||demoID) {
			demo = 0;		// once this key is hit, the demo is turned off
			clearTimeout(demoID);   // prevent demo from restarting if planned
			demoID = null;
		};
		gameSpeed = 855;	   // in milliseconds
		gameSpeedMax = 75;	   // in milliseconds
		FiguresScreenClear();	// empty all the blocks on the screen and show the empty blocks
		GameSet(); // variables reset
		ShowSndIcns();	  // show alarm indicator if alarm is set to on
		HighScoreShow(1);		// show highest score since this browser tab was opened
	};
};

// "game A" button released so actually play game A
function MainGameAGo () {
	if (game!=1 && game!=2) {   // if not already game playing
		if (gameID) {
			clearTimeout(gameID);	// stop the game's possible double call
			gameID = null;
		};
		PlaySound("click_", vlm);	// click sound for push button
		linesTS = 0;
		LinesShow(linesTS);		// show the number of full lines already made
		game = 1; // game A
		ScoreShow(score);
		FigureShow(figurePosX, figurePosY);	 // show first dropping figure
		gameGo=1;  // allow start running game
		gameID = window.setTimeout("GameGo()", gameSpeed);	// start running game
		PlaySoundLoop("tetris_theme_a_", vlm);	// theme sound for game A
	};
};


// button pressed to play the game
function MainGameB () {
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (game!=1 && game!=2) {   // if not already game A or B playing
		if (gameOverID) {
			gameOver = 0;	// reset game over if still indicated
			clearTimeout(gameOverID);	// stop the game's possible double call for MainTimeStart() after game over
			gameOverID = null;
		};
		if (demo||demoID) {
			demo = 0;		// once this key is hit, the demo is turned off
			clearTimeout(demoID);   // prevent demo from restarting if planned
			demoID = null;
		};
		gameSpeed = 855;	   // in milliseconds
		gameSpeedMax = 75;	   // in milliseconds
		FiguresScreenClear();	// empty all the blocks on the screen and show the empty blocks
		GameSet(); // variables reset
		ShowSndIcns();	  // show alarm indicator if alarm is set to on
		HighScoreShow(2);		// show highest score since this browser tab was opened
	};
};

// "game A" button released so actually play game A
function MainGameBGo () {
	if (game!=1 && game!=2) {   // if not already game playing
		if (gameID) {
			clearTimeout(gameID);	// stop the game's possible double call
			gameID = null;
		};
		PlaySound("click_", vlm);	// click sound for push button
		droppable = 1;	// for start game over animation from top to bottom
		linesTS = 25;	// lines left to make before next level
		LinesShow(linesTS);		// show the number of full lines left to make before next level
		FiguresScreenFill();	// fill screen with blocks animated from top to bottom
		gameOverID = window.setTimeout("GameBLevelSet();", 500);
		game = 2; // game B
		gameGo = 1;  // allow start running game
		gameID = window.setTimeout("GameGo()", 1300);	// start running game B in about a second
		PlaySoundLoop("tetris_theme_b_", vlm);	// theme sound for game B
	};
};

// show leading zeroes
function n(n){
	return n>9?""+n:"0"+n;
};

// speeds up the game with given value
function SpeedUp () {
	var prevSpeed = gameSpeed;  // for logging...
	if (gameSpeed>gameSpeedMax) gameSpeed -= SpeedUpCalc(); // if not @ max speed, speed up
};

// speeds up the game according to level
function SpeedUpCalc () {
	var speedUp = 0;
	switch (levelTS) {
		case 1 :  case 2 :  case 3 :  case 4 :  case 5 : 
			speedUp = 60;
			break;
		case 6 :  case 7 :  case 8 :  case 9 :
			speedUp = 90;
			break;
		case 10 : 
			speedUp = 20;
			break;
		case 11 :  case 12 :  case 13 :
			speedUp = 15;
			break;
		case 14 :  case 15 :  case 16 :  case 17 : 
			speedUp = 10;
			break;
		case 18 :   case 19 :  case 20 :
			speedUp = 5;
			break;
		default :
			break;
	}; // if not @ max speed, speed up
	return speedUp;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions