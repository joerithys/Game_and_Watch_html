//figure functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// randomly choose next figure
function FigureChoose () {
	var figureNum = Math.floor(7*Math.random())+1;	// randomised choice
	var figureChoice;
	switch (figureNum) {	// translatre choice to corresponding figure
		case 1:
			figureChoice = "I";
			break;
		case 2  :
			figureChoice = "J";
			break;
		case 3 :
			figureChoice = "L";
			break;
		case 4 :
			figureChoice = "O";
			break;
		case 5 :
			figureChoice = "S";
			break;
		case 6 :
			figureChoice = "T";
			break;
		case 7 :
			figureChoice = "Z";
			break;
		default:
			break;
	};
	direction = 1;	// reset direction to starting position
	if (figure==figureNext&&figureNext==figureChoice) {	//	if this chosen figure already appeared twice in a row
		return FigureChoose();	// choose another figure
	} else return figureChoice;	// send out result of chosen figure
};

// clear dimensions of current figure and accompanying turned figure and turning scope.
function FigureDimClear () {
	for (j=1 ; j<5 ; j++) for (i=1 ; i<5 ; i++) {	// figure dimensions
		figureDim[j][i] = 0;	// empty figure block
		figureDimTurned[j][i] = 0;	// empty turned figure block
		figureDimTurning[j][i] = 0;	// empty scope of turning figure
	};
};

// clear current dimension set of current loose figures.
function FigureDimFallingClear () {
	for (n=1 ; n<11 ; n++) for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// screen dimensions for maximum 10 loose figure
		figureDimFalling[n][j][i] = 0;	// empty this loose figure block
	};
};

// check if this loose figure has blocks present
function FigureFallingIsEmpty (number) {
	var blocksPresent = 0;	// 
	for (j=1 ; j<26 ; j++) {
		for (i=1 ; i<11 ; i++) {	// screen scope
			if (figureDimFalling[number][j][i]) blocksPresent++;	// add a present block to this figure
		};
	};
	return !blocksPresent;
};

// see if falling figure not yet part of currently registered one
function FigureDimFallingExists (number, line, row) {
	var figureDimFallingExists = 0;	// not already noted 
	// if in at least 1 of 4 directions has noted sibling, block is part of already noted figure
	if (figureDimFalling[number][line+1][row] || figureDimFalling[number][line-1][row] || figureDimFalling[number][line][row+1] || figureDimFalling[number][line][row-1]) figureDimFallingExists = 1;	
	return figureDimFallingExists; 
};

// count number of individual loose figures, ready to be dropped and grounded
function FigureDimFallingNumber () {
	var figureDimFallingNumber = 0;	// no loose figures discovered yet
	for (tel=1; tel<10; tel++) {	// whole line
		if (!FigureFallingIsEmpty(tel)) figureDimFallingNumber++	// if this loose figure has blocks present count it
		else break;	//	stop loop because this empty loose figure was last one
	};
	return figureDimFallingNumber;
};

// get most left position of falling figure with number
function FigureDimFallingGetLeft (number) {
	for (i=1; i<11; i++) {
		for (j=1 ; j<26 ; j++) {	// screen scope
			if (figureDimFalling[number][j][i]) {	// if block present @ this position of falling figure
				return i;	// state its most left position
				break;	// stop loop because first position of loose figure has been found
			};
		};
	};
};

// remove all loose figures from stack, after full line disappeared, so they can fall
function FigureDimFallingRemoveFromScreen (number) {
	for (i=1; i<11; i++) {
		for (j=1 ; j<26 ; j++) {	// screen scope
			if (figureDimFalling[number][j][i] && figuresScreen[j][i]) {	// if stacked block has become loose part
				figuresScreen[j][i] = 0;	// remove from stack
			};
		};
	};
};

// get most right position of falling figure with number
function FigureDimFallingGetRight (number) {
	for (i=10; i>0; i--) {
		for (j=1 ; j<26 ; j++) {	// screen scope
			if (figureDimFalling[number][j][i]) {	// if block present @ this position of falling figure
				return i;	// state its most right position
				break;	// stop loop because last position of loose figure has been found 
			};
		};
	};
};

// set dimensions of current figure and its turned variant
function FigureDimSet () {
	FigureDimClear();	// clear current dimension of current figure.
	switch (figure) {
		case "I":
			if (direction==1 || direction==3) {
				// figure
				figureDim[2][1] = 2;
				figureDim[2][2] = 2;
				figureDim[2][3] = 2;
				figureDim[2][4] = 2;
				// figure turned one step
				figureDimTurned[1][2] = 2;
				figureDimTurned[2][2] = 2;
				figureDimTurned[3][2] = 2;
				figureDimTurned[4][2] = 2;
			} else {
				// figure 
				figureDim[1][2] = 2;
				figureDim[2][2] = 2;
				figureDim[3][2] = 2;
				figureDim[4][2] = 2;
				// figure turned one step
				figureDimTurned[2][1] = 2;
				figureDimTurned[2][2] = 2;
				figureDimTurned[2][3] = 2;
				figureDimTurned[2][4] = 2;
			};
			// complete figure turning scope
			figureDimTurning[2][2] = 2;
			figureDimTurning[2][3] = 2;
			figureDimTurning[3][2] = 2;
			figureDimTurning[3][3] = 2;
			break;
		case "J" : 
			switch (direction) {
				case 1 : 
					// figure 
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					figureDim[3][3] = 2;
					// figure turned one step
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[3][2] = 2;
					figureDimTurned[3][1] = 2;
					break;
				case 2 : 
					// figure 
					figureDim[1][2] = 2;
					figureDim[2][2] = 2;
					figureDim[3][2] = 2;
					figureDim[3][1] = 2;
					// figure turned one step
					figureDimTurned[1][1] = 2;
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					break;
				case 3 : 
					// figure 
					figureDim[1][1] = 2;
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					// figure turned one step
					figureDimTurned[1][3] = 2;
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[3][2] = 2;
					break;
				case 4 : 
					// figure 
					figureDim[1][3] = 2;
					figureDim[1][2] = 2;
					figureDim[2][2] = 2;
					figureDim[3][2] = 2;
					// figure turned one step
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					figureDimTurned[3][3] = 2;
					break;
				default :
			};
			break;
		case "L" : 
			switch (direction) {
				case 1 : 
					// figure 
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					figureDim[3][1] = 2;
					// figure turned one step
					figureDimTurned[1][1] = 2;
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[3][2] = 2;
					break;
				case 2 : 
					// figure
					figureDim[1][1] = 2;
					figureDim[1][2] = 2;
					figureDim[2][2] = 2;
					figureDim[3][2] = 2;
					// figure turned one step
					figureDimTurned[1][3] = 2;
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					break;
				case 3 : 
					// figure 
					figureDim[1][3] = 2;
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					// figure turned one step
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[3][2] = 2;
					figureDimTurned[3][3] = 2;
					break;
				case 4 : 
					// figure 
					figureDim[1][2] = 2;
					figureDim[2][2] = 2;
					figureDim[3][2] = 2;
					figureDim[3][3] = 2;
					// figure turned one step
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					figureDimTurned[3][1] = 2;
					break;
				default :
			};
			break;
		case "O" : 
			// figure 
			figureDim[2][2] = 2;
			figureDim[2][3] = 2;
			figureDim[3][2] = 2;
			figureDim[3][3] = 2;
			break;
		case "S" : 
			if (direction==1 || direction==3) {
				// figure 
				figureDim[2][2] = 2;
				figureDim[2][3] = 2;
				figureDim[3][1] = 2;
				figureDim[3][2] = 2;
				// figure turned one step
				figureDimTurned[1][1] = 2;
				figureDimTurned[2][1] = 2;
				figureDimTurned[2][2] = 2;
				figureDimTurned[3][2] = 2;
			} else {
				// figure 
				figureDim[1][1] = 2;
				figureDim[2][1] = 2;
				figureDim[2][2] = 2;
				figureDim[3][2] = 2;
				// figure turned one step
				figureDimTurned[2][2] = 2;
				figureDimTurned[2][3] = 2;
				figureDimTurned[3][1] = 2;
				figureDimTurned[3][2] = 2;
			};
			break;
		case "T" : 
			switch (direction) {
				case 1 : 
					// figure 
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					figureDim[3][2] = 2;
					// figure turned one step
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[3][2] = 2;
					break;
				case 2 : 
					// figure
					figureDim[1][2] = 2;
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[3][2] = 2;
					// figure turned one step
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					break;
				case 3 : 
					// figure 
					figureDim[1][2] = 2;
					figureDim[2][1] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					// figure turned one step
					figureDimTurned[1][2] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					figureDimTurned[3][2] = 2;
					break;
				case 4 : 
					// figure 
					figureDim[1][2] = 2;
					figureDim[2][2] = 2;
					figureDim[2][3] = 2;
					figureDim[3][2] = 2;
					// figure turned one step
					figureDimTurned[2][1] = 2;
					figureDimTurned[2][2] = 2;
					figureDimTurned[2][3] = 2;
					figureDimTurned[3][2] = 2;
					break;
				default :
			};
			break;
		case "Z" : 
			if (direction==1 || direction==3) {
				// figure 
				figureDim[2][1] = 2;
				figureDim[2][2] = 2;
				figureDim[3][2] = 2;
				figureDim[3][3] = 2;
				// figure turned one step
				figureDimTurned[1][2] = 2;
				figureDimTurned[2][1] = 2;
				figureDimTurned[2][2] = 2;
				figureDimTurned[3][1] = 2;
			} else {
				// figure 
				figureDim[1][2] = 2;
				figureDim[2][1] = 2;
				figureDim[2][2] = 2;
				figureDim[3][1] = 2;
				// figure turned one step
				figureDimTurned[2][1] = 2;
				figureDimTurned[2][2] = 2;
				figureDimTurned[3][2] = 2;
				figureDimTurned[3][3] = 2;
			};
			break;
		default:
			break;
	};
};

// drop figure one place if possible
function FigureDrop (x, y) {
	droppable = FigureDroppable(x, y);	// check if figure can be dropped
	if (droppable) {
		figurePosY++;	// position figure one place lower
		FigureDropExec(x, y);	// execute one place drop
	} else {
		dropFinished = 1;	// no full drop in progress
		demoMovesSeq = 0;	// reset moves for demo
		FigureStack(x, y);	// stack the landed figure
	};
};

// check if figure can be dropped 
function FigureDroppable (x, y) {
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	var droppable = 1;	// drop currently possible
	for (j=4; j>0 ;j--) {	// height of figure dimension
		if ((y+j)<27) {	// figure not @ bottom
			for (i=1; i<5 ;i++) {	// width of figure dimension
				// if block @ the bottom or a block is underneath it or figure can't fall
				if (((y+j)==26 || figuresScreen[(y+j+1)][(x+i)]) && droppable && figureDim[j][i]) droppable = 0;	// drop impossible
			};
		};
	};
	return droppable;
};

// execute one place drop
function FigureDropExec (x, y) {
	if (figure) {	// if there is a falling figure
		FigureHide(x, y);	// hide figure @ current position
		FigureShow(x, y+1);	 // show dropping figure one place lower
	};
};

// drop figure as low as it can
function FigureDropFull () {
	dropFinished = 0;	// full drop not finished yet
	figureDropHeight = 0;	// drop height not yet set
	if (dropID[1]) dropIDsClear();	// clear possible previous sceduled drop attempts
	FigureDropGo(5);	// execute full drop
};

// execute full drop
function FigureDropGo (figureDropGoSpeed) {
	if (figure) {	// if there is a falling figure
		FigureDrop(figurePosX, figurePosY);	// drop figure one place if possible
		// if there is no reason to stop falling
		if (!dropFinished &&!gameOver && (demo || game==1 || game==2)) {
			figureDropHeight++;	// count drop height to be able to calculate score accordingly
			dropID[1] = window.setTimeout("FigureDropGo("+figureDropGoSpeed+")", figureDropGoSpeed);	 // next dropping step
		};
	};
};

// hide current figure at position figurePosX figurePosY on screen
function FigureHide (x, y) {
	var xTurned = FigurePosX()-1;	// x-position  for turned figure
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	for (j=1 ; j<5 ; j++) {
		for (i=1; i<5 ;i++) {	// dimention range of figure
			// if position is within in screen range & current figure has a block @ that position
			// actual figure
			if ((x+i)<11&&(x+i)>0&&(y+j)<27&&(y+j)>0&&figureDim[j][i]) PicShow("Block"+(y+j)+"-"+(x+i)+"", nullPre.src);
			// virtually turned figure
			if (figureTurnPrev) {	// if turned preview is set
				if (figure!='O'&&figureDimTurned[j][i]) {	// if figure is no "O" and block is present @ turned figure
					if ((xTurned+i)<11&&(xTurned+i)>0&&(y+j)<27&&(y+j)>0){	// if position is within the turned figure scope
						if (y>0&&figuresScreen[(y+j)][(xTurned+i)]) {	// if a grounded block is present
							PicShow("Block"+(y+j)+"-"+(xTurned+i)+"", blockPre.src)	// already present screen block
						} else {
							PicShow("Block"+(y+j)+"-"+(xTurned+i)+"", nullPre.src);	// hide previous shown block
						};
					};
				};
			};
		};
	};
};

// draw kosak in dancemove left
function FigureKosakLeft (screen) {
	figuresScreen[1+screen][5] = 2;
	figuresScreen[1+screen][6] = 2;
	figuresScreen[1+screen][7] = 2;
	figuresScreen[2+screen][5] = 2;
	figuresScreen[2+screen][6] = 2;
	figuresScreen[2+screen][7] = 2;
	figuresScreen[3+screen][5] = 1;
	figuresScreen[3+screen][7] = 1;
	figuresScreen[4+screen][4] = 1;
	figuresScreen[4+screen][6] = 1;
	figuresScreen[4+screen][8] = 1;
	figuresScreen[4+screen][9] = 1;
	figuresScreen[4+screen][10] = 1;
	figuresScreen[5+screen][3] = 1;
	figuresScreen[5+screen][8] = 1;
	figuresScreen[5+screen][10] = 2;
	figuresScreen[6+screen][3] = 1;
	figuresScreen[6+screen][4] = 1;
	figuresScreen[6+screen][5] = 1;
	figuresScreen[6+screen][6] = 2;
	figuresScreen[6+screen][8] = 1;
	figuresScreen[7+screen][4] = 1;
	figuresScreen[7+screen][8] = 1;
	figuresScreen[8+screen][4] = 1;
	figuresScreen[8+screen][5] = 2;
	figuresScreen[8+screen][6] = 2;
	figuresScreen[8+screen][7] = 2;
	figuresScreen[9+screen][1] = 2;
	figuresScreen[9+screen][3] = 1;
	figuresScreen[9+screen][8] = 1;
	figuresScreen[10+screen][1] = 2;
	figuresScreen[10+screen][2] = 2;
	figuresScreen[10+screen][3] = 1;
	figuresScreen[10+screen][4] = 1;
	figuresScreen[10+screen][5] = 1;
	figuresScreen[10+screen][6] = 1;
	figuresScreen[10+screen][8] = 1;
	figuresScreen[11+screen][7] = 1;
	figuresScreen[11+screen][8] = 1;
	figuresScreen[12+screen][7] = 2;
	figuresScreen[13+screen][7] = 2;
	figuresScreen[13+screen][8] = 2;
};

// draw kosak in dancemove right
function FigureKosakRight (screen) {
	figuresScreen[1+screen][4] = 2;
	figuresScreen[1+screen][5] = 2;
	figuresScreen[1+screen][6] = 2;
	figuresScreen[2+screen][4] = 2;
	figuresScreen[2+screen][5] = 2;
	figuresScreen[2+screen][6] = 2;
	figuresScreen[3+screen][4] = 1;
	figuresScreen[3+screen][6] = 1;
	figuresScreen[4+screen][1] = 1;
	figuresScreen[4+screen][2] = 1;
	figuresScreen[4+screen][3] = 1;
	figuresScreen[4+screen][5] = 1;
	figuresScreen[4+screen][7] = 1;
	figuresScreen[5+screen][1] = 2;
	figuresScreen[5+screen][3] = 1;
	figuresScreen[5+screen][8] = 1;
	figuresScreen[6+screen][3] = 1;
	figuresScreen[6+screen][5] = 2;
	figuresScreen[6+screen][6] = 1;
	figuresScreen[6+screen][7] = 1;
	figuresScreen[6+screen][8] = 1;
	figuresScreen[7+screen][3] = 1;
	figuresScreen[7+screen][7] = 1;
	figuresScreen[8+screen][4] = 2;
	figuresScreen[8+screen][5] = 2;
	figuresScreen[8+screen][6] = 2;
	figuresScreen[8+screen][7] = 1;
	figuresScreen[9+screen][3] = 1;
	figuresScreen[9+screen][8] = 1;
	figuresScreen[9+screen][10] = 2;
	figuresScreen[10+screen][3] = 1;
	figuresScreen[10+screen][5] = 1;
	figuresScreen[10+screen][6] = 1;
	figuresScreen[10+screen][7] = 1;
	figuresScreen[10+screen][8] = 1;
	figuresScreen[10+screen][9] = 2;
	figuresScreen[10+screen][10] = 2;
	figuresScreen[11+screen][3] = 1;
	figuresScreen[11+screen][4] = 1;
	figuresScreen[12+screen][4] = 2;
	figuresScreen[13+screen][3] = 2;
	figuresScreen[13+screen][4] = 2;
}

// position correction for I-figure @ second place from the right
function FigurePosX () {
	var figurePosXNew = figurePosX;	// start corrected position from current
	if (figure=="I") {	// if the figure "I"
		if ((figurePosX==7 && figurePosXCor) || figurePosX==8) {	// if correction already exists or the figure is located @ x-position 8
			figurePosXCor = 1;  // correction needed
		} else {
			figurePosXCor = 0;  // no correction
		};
		if (direction==2 || direction==4) {	// if the figure is turned horizontally, apply this correction
			figurePosXNew -= figurePosXCor;
		} else {	// if the figure is turned vertically, apply this correction
			figurePosXNew += figurePosXCor;
		};
	};
	return figurePosXNew;
};

// clear previous dimension set of grounded (not able to fall) blocks.
function FiguresDimGroundedClear () {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// screen dimensions
		figureDimGrounded[j][i] = 0;	// empty grounded block
	};
};

// check if figure no longer can fall
function FiguresFallableDone () {
	figuresFallableDone = 1;	// done falling
	for (f=1; f<(figureDimFallingNumber+1); f++) {	// for the number of individual loose figures, ready to be dropped and grounded
		if (figureFallableHeight[f]) figuresFallableDone = 0;	// if stil a falling height present, not done falling
	};
	return figuresFallableDone;
};

// rotate figure clockwise if possible
function FiguresRotate () {
	if (figure!="O" && FigureTurnable()) {	// if figure not "O" & no blocks in the way
		PlaySound("rotate_", vlm);
		FigureHide (figurePosX, figurePosY);	// hide figure @ this state
		figurePosX = FigurePosX();	// position correction for I-figure @ second place from the right if needed 
		if (figurePosY==0) figurePosY++;	// if turned figure above screen, shift one position down
		direction = direction<4?direction+1:1;	// turn figure clockwise
		FigureDimSet();	// set dimensions of current figure and its directions
		FigureShow(figurePosX, figurePosY);	// show figure @ next state
	} else fit = 0;	// no turn possible
};

// empty all the blocks on the screen and show an empty space
function FiguresScreenClear () {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// screen dimensions
		figuresScreen[j][i] = 0;	// empty screen block
		PicShow("Block"+eval(j)+"-"+eval(i)+"", nullPre.src);	// show empty on screen
	};
};

// fill screen with blocks animated from top to bottom
function FiguresScreenFill () {
	if (droppable<27 && droppable>0) {	// if not all lines done
		for (i=1; i<11; i++) PicShow("Block"+droppable+"-"+i+"", blockPre.src);	// fill current line with blocks
		droppable++; // count to next line
		gameOverID = window.setTimeout("FiguresScreenFill()", (game==2?10:50));	// next step (line) in 50 ms, 10 ms if game B is running
	};
};

// show current screen status from bottom to top
function FiguresScreenShowCurrent () {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// screen dimension
		if (figuresScreen[j][i]==1) {	//	if screen indicator is 1 (hollow)
			PicShow("Block"+eval(j)+"-"+eval(i)+"", blockHollowPre.src)	// hollow block for figure drawing
		} else {
			if (figuresScreen[j][i]==2) {	//	if screen indicator is 2 (full)
				PicShow("Block"+eval(j)+"-"+eval(i)+"", blockPre.src)	// full block
			} else{
				if (figuresScreen[j][i]==3) PicShow("Block"+eval(j)+"-"+eval(i)+"", blockEmptyPre.src)	//  small block for deleting full line
				else PicShow("Block"+eval(j)+"-"+eval(i)+"", nullPre.src);	// empty (no block)
			};
		};
	};
};

// store falling loose figure @ previous position
function FiguresSetPrevFalling (number) {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// dimension of screen
		figureDimFallingPrev[j][i] = figureDimFalling[number][j][i];	// previous is current before the fall
	};
};

// hide falling loose figures @ previous position
function FiguresScreenHidePrevFalling () {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// dimension of figure
		if (figureDimFallingPrev[j][i]) PicShow("Block"+eval(j)+"-"+eval(i)+"", nullPre.src);	// remove block from previous falling figure
	};
};

// show falling loose figure number @ current position
function FiguresScreenShowFalling (number) {
	for (j=1 ; j<27 ; j++) for (i=1 ; i<11 ; i++) {	// dimension of figure
		if (figureDimFalling[number][j][i]) PicShow("Block"+eval(j)+"-"+eval(i)+"", blockPre.src);	// show the block
	};
};

// show current figure at position figurePosX figurePosY on screen during normal fall
function FigureShow (x, y) {
	var xPrev;	// position correction for turned figure
	var xTurned = FigurePosX();	// x-position  for turned figure
	fit = 1;	// turning figure fits on position screen
	if (figureTurnPrev) xPrev = x==xTurned?0:1;   // indicate correction
	xTurned--;	// figure starts @ x = "1" but needs to be counted from "0"
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	for (j=1 ; j<5 ; j++) {
		for (i=1; i<5 ;i++) {	// dimention range of figure
			if ((x+i)<11&&(x+i)>0&&(y+j)<27&&(y+j)>0) {		// if position is within in screen range & current figure has a block @ that position
				// actual figure
				if (figureDim[j][i]) {	// if block is present in figure @ this position
					PicShow("Block"+(y+j)+"-"+(x+i)+"", blockPre.src);	// show figure block if present
				};
				// virtually turned figure
				if (figure!='O'&&figureDimTurned[j][i]) {	// if figure is no "O" and block is present @ turned figure
					if ((xTurned+i)<11&&(xTurned+i)>0&&(y+j)<27&&(y+j)>0){	// if position is within the turned figure scope
						if (y>=-1&&figuresScreen[(y+j)][(xTurned+i)]) {	// if a grounded block is present
							if (figureTurnPrev) PicShow("Block"+(y+j)+"-"+(xTurned+i)+"", blockRedPre.src)	// if turned preview is set show red collision block
							fit = 0;	// turning figure doesn't fit on position screen
						} else {
							if (figureTurnPrev) {	// if turned preview is set
								if (figureDim[j][i-xPrev]) PicShow("Block"+(y+j)+"-"+(xTurned+i)+"", blockOverlapPre.src)	// if turned preview is set show dark gray overlap block
								else PicShow("Block"+(y+j)+"-"+(xTurned+i)+"", blockGrayPre.src);	// if turned preview is set show very light gray block (seems white)
							};
						};
					};
				};
			};
		};
	};
};

// show next to come figure in preview/next-box
function FigureShowNext (figure) {
	BlockPreviewClear();	// remove previous preview
	switch (figure) {	// construct blocks corresponding to next figure
		case "I" : 
			for (i=1 ; i<5 ; i++) PicShow("Preview2"+eval(i)+"", blockPre.src);
			break;
		case "J" : 
			PicShow("Preview"+"1"+"1", blockPre.src);
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"1"+"3", blockPre.src);
			PicShow("Preview"+"2"+"3", blockPre.src);
			break;
		case "L" : 
			PicShow("Preview"+"1"+"1", blockPre.src);
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"1"+"3", blockPre.src);
			PicShow("Preview"+"2"+"1", blockPre.src);
			break;
		case "O" : 
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"1"+"3", blockPre.src);
			PicShow("Preview"+"2"+"2", blockPre.src);
			PicShow("Preview"+"2"+"3", blockPre.src);
			break;
		case "S" : 
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"1"+"3", blockPre.src);
			PicShow("Preview"+"2"+"1", blockPre.src);
			PicShow("Preview"+"2"+"2", blockPre.src);
			break;
		case "T" : 
			PicShow("Preview"+"1"+"1", blockPre.src);
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"1"+"3", blockPre.src);
			PicShow("Preview"+"2"+"2", blockPre.src);
			break;
		case "Z" : 
			PicShow("Preview"+"1"+"1", blockPre.src);
			PicShow("Preview"+"1"+"2", blockPre.src);
			PicShow("Preview"+"2"+"2", blockPre.src);
			PicShow("Preview"+"2"+"3", blockPre.src);
			break;
		default :
	};
};

// land falling figure, and integrate in current screen setting (grounded)
function FigureStack (x, y) {
	var figurePre = figureNext;	// preset current figure to next figure
	gameGo = 0;
	if (demoID) {	// if demo still planned to start stop that plan to avoid double run
		clearTimeout(demoID);	// stop the demo's possible double call
		demoID = null;
	};
	if (gameID) {	// if game planned for next step
		clearTimeout(gameID);	// stop the game's possible double call
		gameID = null;
	};
	x--;		// figure starts @ x = "1" but needs to be counted from "0"
	y--;		// figure starts @ y = "1" but needs to be counted from "0"
	for (j=1 ; j<5 ; j++) {
		for (i=1; i<5 ;i++) {	// Figure dimension
			if (figureDim[j][i]) figuresScreen[y+j][x+i] = 2;	// set full figure block for screen
		};
	};
	PlaySound("land_", vlm);
	figureFullLinesStacked = FigureStackCheckFullLines();	// check for full lines in stack
	direction = 1;	// reset direction to starting position
	if (!demo) ScoreAdd(figureDropHeight);	// add score according to height the figure was dropped from
	if (FigureStackFull()) {	// if screen is stacked to the top
		StopAllSound();
		GameOver()	// start game over animation
	} else {
		figurePosX = 4;	 // = x (center)
		figurePosY = 0;	 // = y (top)
		droppable = 0	// figure can't move down
		if (demo) {		// if demo running
			sequence = (sequence+1)<21?sequence+1:1;	// determine next demo figure & movements
			figureNext = figuresDemo[sequence];	// set next figure to come for demo
		} else {
			figureNext = FigureChoose();	// randomly choose next figure to come for the game
		};
		figure = figurePre;	// figure can be finally set now, no longer needed for tripple comparison
		FigureDimSet();	// set dimensions of new current figure and its directions
		FigureShowNext(figureNext);	// show next figure in box on screen
		if (!figureFullLinesStacked) {	// if no more full lines present
			FigureShow(figurePosX, figurePosY);	// show falling figure @ current position
			if (demo) DemoRun()	// continue demo
			else {
				if (FigureStuck()){	// first figure already overlaps current figure stack
					gameGoID = window.setTimeout("StopAllSound();", (60));
					gameID = window.setTimeout("GameOver();", gameSpeed);	// start game over animation in gameSpeed milliseconds	
				} else {
					gameGoID = window.setTimeout("gameGo = 1;", (60));	// continue in 60 milliseconds to avoid double full drop if to late	
					gameID = window.setTimeout("GameGo();", gameSpeed);	// continue in gameSpeed milliseconds		
				};
			};
		};
	};
	figureDropHeight = 0;	// figure has been stacked, no drop height left
};

// check for full lines in stack
function FigureStackCheckFullLines () {
	var figureStackCheckFullLines = new Array(5);	// to store location of found full lines
	var figureStackFullLine = 0;	// 0 stacked full lines found
	if (dropID[0]) dropIDsClear();	// if another drop still initiated, reset drop
	for (j=1 ; j<27 ; j++) {	// all lines on screen
		// if full line occupied
		if(figuresScreen[j][1] && figuresScreen[j][2] && figuresScreen[j][3] && figuresScreen[j][4] && figuresScreen[j][5] && figuresScreen[j][6] && figuresScreen[j][7] && figuresScreen[j][8] && figuresScreen[j][9] && figuresScreen[j][10]) {
			figureStackCheckFullLines[figureStackFullLine] = j;	// record location of full line
			figureStackFullLine++;	// next to record
			FigureStackEmptyFullLines(j);	// show the full line with the innerblocks just before they are removed
			dropID[figureStackFullLine] = window.setTimeout("FigureStackDropTopLines("+j+")", (2*gameSpeed/5));	// drop lines above removed full line @ position "line"
		};
	};
	if (!figureStackFullLine) {	// if no full lines found
		FiguresScreenShowCurrent();	// show current screen status from bottom to top
	} else {
		if (figureStackFullLine==4) {	// if 4 full lines @ once = TETRIS
			PlaySound("tetris_", vlm);
		} else {
			PlaySound("line_", vlm);
		};
	};
	return figureStackFullLine;
};

// drop lines above removed full line @ position "line"
function FigureStackDropTopLines (line) {
	FigureDimFallingClear(); // clear previous dimension set of grounded (not able to fall) blocks.
	for (j=line ; j>0 ; j--) {	// from the deleted full line to the top
		if (j==1) {	// clear top line @ the end of the loop
			for (i=1; i<11; i++) {	// for every (previuos) block of top line
				figuresScreen[j][i] = 0;	// empty
			};
		} else {
			for (i=1; i<11; i++) {	// for every (next) block of that line
				figuresScreen[j][i] = figuresScreen[j-1][i];	// copy all blocks from 1 line above
			};
		};
	};
	PlaySound("shift_", vlm);
	FiguresScreenShowCurrent();	// show current screen status from bottom to top
	if (!demo) {
		if (figureFullLinesStacked) {	// if full lines present in stack
			ScoreAdd(ScoreCalc());	// add calculated score
			gameResetID = window.setTimeout("FigureStackSetFigureDimGrounded("+line+");", 100);	// constructing grounded blocks
		} else {
			FigureShow(figurePosX, figurePosY);	// show falling figure @ current position
		};
		if (game==1) { // if game A
			linesTS++;	// one full line added
			LinesShow(linesTS);	// show the number of full lines already made
			if (!(linesTS%10)&&levelTS<20) {	// level up every 10 full lines up to max 20
				PlaySound("level_", vlm);	// click sound for push button
				levelTS++;	// add level
				LevelShow(levelTS);	// show current level
				SpeedUp();	// set speed according to level
			};
		};
		if (game==2) {	// if game B
			linesTS--;	// one full line less to go untill next level
			LinesShow(linesTS);	// show the number of lines left to go untill next level
			if (gameID) {
				clearTimeout(gameID);	// stop the game's possible double call
				gameID = null;
			};
			if (linesTS==0) {	// if all 25 lines made
				if (levelTS<20) {	// if not yet @ highest level
					PlaySound("level_", vlm);	// click sound for push button
					levelTS++;	// add level
					LevelShow(levelTS);	// show current level
					linesTS = 25;	// full set of lines left to complete till level ends
					LinesShow(linesTS);	// show lines left to complete till level ends
					SpeedUp();	// set speed according to level
					FiguresScreenFill();	// fill screen with blocks animated from top to bottom
					gameOverID = window.setTimeout("GameBLevelSet();", 500);	// set common settings games for next level
				} else {
					gameID = window.setTimeout("GameOver();", gameSpeed);	// reset common settings games & show game is over after gameSpeed milliseconds
				};
			} else {
				FigureShow(figurePosX, figurePosY);	// show current falling figure @ current position
				gameID = window.setTimeout("GameGo();", gameSpeed);	// continue game
			};
		};
	} else {
		if (figureFullLinesStacked) {	// if full lines present in stack
			gameResetID = window.setTimeout("FigureStackSetFigureDimGrounded("+line+");", 100);	// constructing grounded blocks
		};
	};
};

// show the full line with the innerblocks
function FigureStackEmptyFullLines (line) {
	for (i=1; i<11; i++) {	// whole line
		PicShow("Block"+eval(line)+"-"+eval(i)+"", blockEmptyPre.src);	//  small block for deleting full line
	};
};

// check if horizontal surrounding blocks are empty or part of loose or grounded figure
function FigureStackLooseCheckSiblingsHor (j,i,grounded) {
	if (figuresScreen[j][(i+1)] && !figureDimGrounded[j][(i+1)]) {	// if right neighbour block on screen not yet in grounded blocks
		if (!grounded) {	// if searching for grounded siblings
			figureDimGrounded[j][(i+1)] = 1;	// add right neighbour block to grounded bloks
			FigureStackLooseCheckSiblingsHor(j,(i+1), 0);	// check if horizontal surrounding blocks are empty or part of grounded figure
			FigureStackLooseCheckSiblingsVert(j,(i+1),0);	// check if vertical surrounding blocks are empty or part of grounded figure
		} else {
			if (!figureDimFalling[grounded][j][(i+1)]) {	// if right neighbour block is not yet part of falling block
				figureDimFalling[grounded][j][(i+1)] = 1	// add right neighbour block to falling block
				FigureStackLooseCheckSiblingsHor(j,(i+1), grounded);	// check if horizontal surrounding blocks are empty or part of loose figure
				FigureStackLooseCheckSiblingsVert(j,(i+1), grounded);	// check if vertical surrounding blocks are empty or part of loose figure
			}; 
		};
	}; 
	if (figuresScreen[j][(i-1)] && !figureDimGrounded[j][(i-1)]) {	// if left neighbour block on screen not yet in grounded blocks
		if (!grounded) {	// if searching for grounded siblings
			figureDimGrounded[j][(i-1)] = 1;	// add left neighbour block to grounded bloks
			FigureStackLooseCheckSiblingsHor(j,(i-1), 0);	// check if horizontal surrounding blocks are empty or part of grounded figure
			FigureStackLooseCheckSiblingsVert(j,(i-1),0)	// check if vertical surrounding blocks are empty or part of grounded figure
		} else {
			if (!figureDimFalling[grounded][j][(i-1)]) {	// if left neighbour block is not yet part of falling block
				figureDimFalling[grounded][j][(i-1)] = 1	// add left neighbour block to falling block
				FigureStackLooseCheckSiblingsHor(j,(i-1), grounded);	// check if horizontal surrounding blocks are empty or part of loose figure
				FigureStackLooseCheckSiblingsVert(j,(i-1), grounded);	// check if vertical surrounding blocks are empty or part of loose figure
			};
		};
	}; 
};

// check if vertical surrounding blocks are empty or part of loose or grounded figure
function FigureStackLooseCheckSiblingsVert (j,i,grounded) {
	if (figuresScreen[j+1][i] && !figureDimGrounded[j+1][i]) {	// if bottom neighbour block on screen not yet in grounded blocks
		if (!grounded) {	// if searching for grounded siblings
			figureDimGrounded[j+1][i] = 1;	// add right neighbour block to grounded bloks
			FigureStackLooseCheckSiblingsHor((j+1),i,0);	// check if horizontal surrounding blocks are empty or part of grounded figure
			FigureStackLooseCheckSiblingsVert((j+1),i,0);	// check if vertical surrounding blocks are empty or part of grounded figure
		} else {
			if (!figureDimFalling[grounded][j+1][i]) {	// if right neighbour block is not yet part of falling block
				figureDimFalling[grounded][j+1][i] = 1	// add right neighbour block to falling block
				FigureStackLooseCheckSiblingsHor((j+1),i,grounded);	// check if horizontal surrounding blocks are empty or part of loose figure
				FigureStackLooseCheckSiblingsVert((j+1),i,grounded);	// check if vertical surrounding blocks are empty or part of loose figure
			}; 
		};
	}; 
	if (figuresScreen[j-1][i] && !figureDimGrounded[j-1][i]) {	// if top neighbour block on screen not yet in grounded blocks
		if (!grounded) {	// if searching for grounded siblings
			figureDimGrounded[j-1][i] = 1;	// add left neighbour block to grounded bloks
			FigureStackLooseCheckSiblingsHor((j-1),i,0);	// check if horizontal surrounding blocks are empty or part of grounded figure
			FigureStackLooseCheckSiblingsVert((j-1),i,0);	// check if vertical surrounding blocks are empty or part of grounded figure
		} else {
			if (!figureDimFalling[grounded][j-1][i]) {	// if left neighbour block is not yet part of falling block
				figureDimFalling[grounded][j-1][i] = 1	// add left neighbour block to falling block
				FigureStackLooseCheckSiblingsHor((j-1),i,grounded);	// check if horizontal surrounding blocks are empty or part of loose figure
				FigureStackLooseCheckSiblingsVert((j-1),i,grounded);	// check if vertical surrounding blocks are empty or part of loose figure
			}; 
		};
	}; 
};

// let loose figures fall till grounded
function FigureStackLooseFreeFall (number) {
	var thisNumber = number;	// remember initial given number
	var repeatSpeed = 0;	// set no delay for next step
	FiguresSetPrevFalling (thisNumber);	// store falling loose figure @ previous position
	if (gameID) {
		clearTimeout(gameID);	// stop the game's next step for now
		gameID = null;
	};
	if (demoID) {
		window.clearTimeout(demoID);	// stop demo's next step for now
		demoID = null;
	};
	if (figureFallableHeight[thisNumber]) {	// if loose figure @ initial given number has a falling height left
		for (j=25 ; j>1 ; j--) {
			for (i=1 ; i<11 ; i++) {	// screen scope
				if (!figuresScreen[j+1][i]) {	// if place below is void
					figureDimFalling[thisNumber][j+1][i] = figureDimFalling[thisNumber][j][i];	// lower block of loose figure one position
				};
			};
		};
		if (number<figureDimFallingNumber) {	// if not all falling figures are done
			repeatSpeed = 0;	// no delay for next step
			number++;	// next loose figure
		} else {
			repeatSpeed = 50	// 50 ms delay for next step
			number = 1;	// back to first loose figure
		};
		figureFallableHeight[thisNumber]--;	// loose figure @ initial given number can fall one less position
		if (!figureFallableHeight[thisNumber]) FigureStackLooseStack(thisNumber);	// stack the loose figure @ thisNumber if done falling
		gameID = window.setTimeout("FigureStackLooseFreeFall("+number+");", repeatSpeed);	// let next loose figute fall
		FiguresScreenHidePrevFalling(thisNumber);	//	hide falling loose figure @ previous position
		FiguresScreenShowFalling(thisNumber);	//	show falling loose figure @ new position
	} else {
		PlaySound("land_", vlm);
		if (FiguresFallableDone()) {	// if all falling loose figures landed
			figureFullLinesStacked = FigureStackCheckFullLines();	// check again for full lines in stack
			if (!figureFullLinesStacked) {	// if no full lines present in stack
				FigureShow(figurePosX, figurePosY);
				if (!demo) {
					gameGoID = window.setTimeout("gameGo = 1;", (60));	// continue in 60 milliseconds to avoid double full drop if to late	
					gameID = window.setTimeout("GameGo();", gameSpeed);	// continue in gameSpeed milliseconds		
				} else DemoRun();	// continue demo's next step immediately
			};
		} else {
			if (number<figureDimFallingNumber) {	// if not all falling figures are done
				number++;	// next loose figure
			} else {
				number = 1;	// back to first loose figure
			};
			FigureStackLooseFreeFall(number);	// let next loose figure fall	
		};
	};
};

// stack landed loose free figure
function FigureStackLooseStack (f) {
	for (j=26 ; j>1 ; j--) {
		for (i=1 ; i<11 ; i++) {	// scope of screen
			if (figureDimFalling[f][j][i]) figuresScreen[j][i] = 2	// stack loose block of figure (f) @ this position if present
		};
	};
};

// check if free parts in remaining stack can fall
function FigureStackLooseFallCheck (line) { 
	var number = 0;	// no loose figures yet
	if (gameID) {
		clearTimeout(gameID);	// stop the game's possible double call
		gameID = null;
	};
	figureFallableHeightReset();	// reset each loose figure's fallable height to zero
	for (i=1; i<11; i++) {	// the whole line
		// if found loose figure, not already noted
		if (figuresScreen[line][i] && (!figuresScreen[line][i-1] && !figureDimGrounded[line][i] && (!number || !FigureDimFallingExists(number, line, i)))) {	
			number +=1;	// count new found loose figure
			FigureStackLooseFigureDimGrounded(number, line, i);	// record full loose figure, to let it drop and be grounded
		} else {
			if (!figuresScreen[line][i]) {	// if no stacked figure present @ that place
				// if found loose figure below line, not already noted
				if (figuresScreen[line+1][i] && (!figureDimGrounded[line+1][i] && (!number || !FigureDimFallingExists(number, line+1, i)))) {	
					number +=1;	// count new found loose figure
					FigureStackLooseFigureDimGrounded(number, (line+1), i);	// record full loose figure, to let it drop and be grounded
				} else {
					// if found loose figure above line, not already noted
					if (figuresScreen[line-1][i] && (!figureDimGrounded[line-1][i] && (!number || !FigureDimFallingExists(number, line-1, i)))){	
						number +=1;	// count new found loose figure
						FigureStackLooseFigureDimGrounded(number, (line-1), i);	// record full loose figure, to let it drop and be grounded
					};
				};			
			};
		};
	};
	figureDimFallingNumber = FigureDimFallingNumber();	// count number of individual loose figures, ready to be dropped and grounded 
	if (figureDimFallingNumber) {	// if loose figures present
		for (f=1; f<(figureDimFallingNumber+1); f++) {	// for the number of individual loose figures, ready to be dropped and grounded
			FigureDimFallingRemoveFromScreen(f);	// remove all loose figures from stack so they can fall
			figureFallableHeight[f] = FigureStackLooseFreeFallGetHeight(f);	// get falling height of figure with this number
		};
		 FigureStackLooseFreeFall(1);	// let loose figures fall till grounded
	} else {
		FigureShow(figurePosX, figurePosY);
		if (!demo) {
			gameGoID = window.setTimeout("gameGo = 1;", (60));	// continue in 60 milliseconds to avoid double full drop if to late	
			gameID = window.setTimeout("GameGo();", gameSpeed);	// continue in gameSpeed milliseconds		
		} else DemoRun();	// next demo step
	};
};

// first figure already overlaps current figure stack
function FigureStuck () {
	var figureStuck = 0;	// no indication yet of overlaps
	for (i=1; i<5; i++) {
		if ((figuresScreen[1][figurePosX+i]&&figureDim[2][i])||(figuresScreen[2][(figurePosX+i)]&&figureDim[3][i])) figureStuck = 1;	// overlaps is a fact
	};
	return figureStuck;
};

// get falling height of figure with this number
function FigureStackLooseFreeFallGetHeight (number) {
	var figureStackLooseFreeFallGetHeight = 26;	// set @ maximum hight possible
	var tempHeight;	// temperary hight mearured per line
	var figureDimFallingLeft = FigureDimFallingGetLeft(number);	// get most left position of falling figure with number
	var figureDimFallingRight = FigureDimFallingGetRight(number);	// get most right position of falling figure with number
	for (i=1; i<11; i++) {
		for (j=1 ; j<26 ; j++) {	// screen scope
			if (figureDimFalling[number][j][i] && !figureDimFalling[number][j+1][i]) {	// if loose figure has block @ this place with void below
				for (h=1; h<(27-j); h++) {	//	check hight of void below (from that point)
					if (!figuresScreen[(j+h)][i]) {	// as long as line has no block stacked
						tempHeight = h;	// this is the hight the loose figure can fall
					} else {
						break;	// end loop because hight of void below is done measuring
					};
				};
				// the lowest void below is the maximum hight the loose figure can possible fall
				figureStackLooseFreeFallGetHeight = (figureStackLooseFreeFallGetHeight<tempHeight)?figureStackLooseFreeFallGetHeight:tempHeight;
			};
		};
	};
	return figureStackLooseFreeFallGetHeight;
};

// record full loose figure, to let it drop and be grounded
function FigureStackLooseFigureDimGrounded (number, j, i) {
	if (number<6) {	// maximum 5 loose figures possible
		if (!figureDimGrounded[j][i] && !figureDimFalling[number][j][i]) {	// block not grounded & not yet part of current falling figure
			figureDimFalling[number][j][i] = 1;	// block is part of this falling figure
			FigureStackLooseCheckSiblingsHor(j,i,number);	// check if horizontal surrounding blocks are empty or part of loose figure
			FigureStackLooseCheckSiblingsVert(j,i,number);	// check if vertical surrounding blocks are empty or part of loose figure
		};
	};
};

// constructing grounded blocks
function FigureStackSetFigureDimGrounded (line) {
	var empty = 1;	// no grounded figures recorded yet
	if (gameResetID) {	// if reset triggered
		clearTimeout(gameResetID);	// stop the game's possible double call
		gameResetID = null;
	};
	FiguresDimGroundedClear();	// clear previous dimension set of grounded (not able to fall) blocks.
	for (i=1 ; i<11 ; i++) {	// whole (bottom) line (can't have loose blocks)
		if (figuresScreen[26][i]) figureDimGrounded[26][i] = 1;	// if there is a bottom block on the screen, ground it
	};
	for (j=25 ; j>1 ; j--) {
		for (i=1 ; i<11 ; i++) {	// the rest of the screen scope
			if (figuresScreen[j][i] && figureDimGrounded[j+1][i]) {	// if on this position a supported block
				figureDimGrounded[j][i] = 1;	// ground block
				empty = 0;	// grounded block recorded
				FigureStackLooseCheckSiblingsHor(j,i,0);	// check if horizontal surrounding blocks are empty or part of grounded figure
			};
		};
	};
	if (line&&game!=2) gameResetID = window.setTimeout("FigureStackLooseFallCheck("+line+");", 300)	// check if free parts in remaining stack can fall
	else gameGo = 1; // game can continue now
};

// check if screen fully stacked up to the top line
function FigureStackFull () {
	var figureStackFull = 0;	// stack not yet full
	for (i=4; i<8; i++) if (figuresScreen[1][i]) figureStackFull = 2;	// if top line has a block stacked @ figure, stack is full 
	return figureStackFull;
};

// place two stacked lines per level @ game B with a maximum of 14 lines
function FigureStackSetHeight () {
	var fulLine;	// to prevent full preset line @ start of level
	var lines = 0;	// no preset lines put on screen yet
	var maxLine = (26-(levelTS*2))>12?(26-(levelTS*2)):12;	// calculated line to put blocks upto on screen, minimum till line 12
	FiguresScreenClear(); // empty all the blocks on the screen and show the empty blocks
	for (j=26; j>maxLine; j--) {
		fulLine = 1;	// full line, no empty space detected
		lines++;	// next line
		for (i=1; i<11; i++) {
			if (Math.floor(3*Math.random())) {
				figuresScreen[j][i] = 2;	// put a block @ this place
			} else {
				figuresScreen[j][i] = 0;	// no block @ this place
				fulLine = 0;	// no full line, at least one empty space present
			};
		};
		if (fulLine) figuresScreen[j][(Math.floor(9*Math.random())+1)] = 0;	// if full line, randomly empty one space
	};
};

// Check if turning scope doesn't hit a grounded block
function FigureTurnable () {
	var xTurned = FigurePosX();	// x-position  for turning figure
	x = figurePosX-1;		// figure starts @ x = "1" but needs to be counted from "0"
	y = figurePosY-1;		// figure starts @ y = "1" but needs to be counted from "0"
	if ((figurePosX<1 && (figure!="S" && figure!="Z")) || figurePosX>8) fit = 0;	// is the figure not to close to the edge
	if (fit&&figure=='I') {	// extra turning fit condition for figure "I"
		for (j=1 ; j<5 ; j++) {
			for (i=1; i<5 ;i++) {	// scope figure
				if ((x+i)<11&&(x+i)>0&&(y+j)<27&&(y+j)>0) {	//	screen scope
					if (figureDimTurning[j][i]&&figuresScreen[(y+j)][(xTurned+i)]) {	// if within rotation occupation a screen block is present
						fit = 0;	// turning figure doesn't fit on position screen
					};
				};
			};
		};
	};
	return fit;
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end figure functions