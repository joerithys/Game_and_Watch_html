var rocketWarmUp = 25;	// number of animation steps of the rocket / Buran shuttle warming up

// start lift-off Buran shuttle
function CongratsBuranShuttle () {
    StopAllSound();
    FiguresScreenClear();	// clear screen from blocks @ once
    gameOverTxtID = window.setTimeout("CongratsBuranShuttleShow()", 500);	// show Buran shuttle in 0,5 seconds
};

// Constructing Buran shuttle
function CongratsBuranShuttleShow () {
    PlaySound("rocket_", vlm);
    //towers
    figuresScreen[19][2] = 2;
    figuresScreen[19][3] = 2;
    figuresScreen[19][9] = 2;
    figuresScreen[20][2] = 2;
    figuresScreen[20][3] = 2;
    figuresScreen[20][4] = 1;
    figuresScreen[20][9] = 2;
    figuresScreen[21][2] = 2;
    figuresScreen[21][3] = 2;
    figuresScreen[21][9] = 2;
    figuresScreen[22][2] = 2;
    figuresScreen[22][3] = 2;
    figuresScreen[22][4] = 2;
    figuresScreen[22][9] = 2;
    figuresScreen[23][2] = 2;
    figuresScreen[23][3] = 2;
    figuresScreen[23][9] = 2;
    figuresScreen[24][2] = 2;
    figuresScreen[24][3] = 2;
    figuresScreen[24][9] = 2;
    figuresScreen[25][2] = 2;
    figuresScreen[25][3] = 2;
    figuresScreen[25][9] = 2;
    figuresScreen[26][1] = 2;
    figuresScreen[26][2] = 2;
    figuresScreen[26][3] = 2;
    figuresScreen[26][4] = 2;
    figuresScreen[26][5] = 2;
    figuresScreen[26][6] = 2;
    figuresScreen[26][7] = 2;
    figuresScreen[26][8] = 2;
    figuresScreen[26][9] = 2;
    figuresScreen[26][10] = 2;
    // Buran Shuttle
    figuresScreen[18][6] = 2;
    figuresScreen[19][5] = 2;
    figuresScreen[19][6] = 2;
    figuresScreen[19][7] = 2;
    figuresScreen[20][5] = 2;
    figuresScreen[20][6] = 1;
    figuresScreen[20][7] = 2;
    figuresScreen[21][5] = 1;
    figuresScreen[21][6] = 1;
    figuresScreen[21][7] = 1;
    figuresScreen[22][5] = 1;
    figuresScreen[22][6] = 1;
    figuresScreen[22][7] = 1;
    figuresScreen[23][5] = 1;
    figuresScreen[23][6] = 1;
    figuresScreen[23][7] = 1;
    figuresScreen[24][5] = 1;
    figuresScreen[24][6] = 1;
    figuresScreen[24][7] = 1;
    figuresScreen[25][5] = 1;
    figuresScreen[25][7] = 1;
    FiguresScreenShowCurrent();	// show construted screen
    rocketWarmUp = 3;	// launch initiation
    gameOverTxtID = window.setTimeout("CongratsRocketShuttleWarmUp()", 300);	// start warming up the Buran shuttle and let it start smoking
    gameOverID = window.setTimeout("CongratsRocketShuttleLaunch()", 7200);	// launch rocket / Buran shuttle after 7,2 seconds  
};

// animate dancing Kosaks a set number of times
function CongratsKosaksDance (times) {
    times--;	// count back number of times
    FiguresScreenClear();	// clear screen from blocks @ once
    FigureKosakLeft ((times%2?0:13));	// show left Kosak @ even times on top @ odd times on bottom screen
    FigureKosakRight ((times%2?13:0));	// show right Kosak @ even times on bottom @ odd times on top screen
    FiguresScreenShowCurrent(); // show construted screen
    if (times) gameOverTxtID = window.setTimeout("CongratsKosaksDance("+times+")", 365)         // animate next step
    else gameOverTxtID = window.setTimeout("FiguresScreenClear(); CongratsBuranShuttleShow();", 700);	// start lift-off Buran shuttle
};

// show two Kosaks and let them dance
function CongratsKosaksShow () {
    StopAllSound();
    FiguresScreenClear();	// clear screen from blocks @ once
    PlaySound("nut-6_", vlm);	// Kosaks song ;)
    CongratsKosaksDance(33);	// animate dancing Kosaks a set number of times
};

// start lift-off rocket
function CongratsRocket (size) {
    StopAllSound();
    FiguresScreenClear();	// clear screen from blocks @ once
    gameOverTxtID = window.setTimeout("CongratsRocketShow('"+size+"')", 500);	// show rocket according to size, let it warm up and eventually launch in 0,5 seconds
};

// show rocket according to size, let it warm up and eventually launch
function CongratsRocketShow (size) {
    PlaySound("rocket_", vlm);
    //tower
    figuresScreen[19][9] = 2;
    figuresScreen[20][9] = 2;
    figuresScreen[21][9] = 2;
    figuresScreen[22][9] = 2;
    figuresScreen[23][9] = 2;
    figuresScreen[24][9] = 2;
    figuresScreen[25][9] = 2;
    figuresScreen[26][1] = 2;
    figuresScreen[26][2] = 2;
    figuresScreen[26][3] = 2;
    figuresScreen[26][4] = 2;
    figuresScreen[26][5] = 2;
    figuresScreen[26][6] = 2;
    figuresScreen[26][7] = 2;
    figuresScreen[26][8] = 2;
    figuresScreen[26][9] = 2;
    figuresScreen[26][10] = 2;
    // Rocket
    figuresScreen[23][7] = 1;
    figuresScreen[24][7] = 1;
    figuresScreen[25][7] = 1;
    if (size=="big") {
        figuresScreen[19][6] = 1;
        figuresScreen[20][6] = 1;
        figuresScreen[21][6] = 1;
        figuresScreen[22][6] = 1;
        figuresScreen[23][5] = 1;
        figuresScreen[23][6] = 1;
        figuresScreen[24][5] = 1;
        figuresScreen[24][6] = 1;
        figuresScreen[25][5] = 1;
    } else {		
        if (size=="medium") {
            figuresScreen[20][7] = 1;
            figuresScreen[21][7] = 1;
        };
        figuresScreen[22][7] = 1;
    };
    FiguresScreenShowCurrent();	// show construted screen
    rocketWarmUp = 3;	// launch initiation
    gameOverTxtID = window.setTimeout("CongratsRocketShuttleWarmUp('"+size+"')", 300);	// start warming up the rocket and let it start smoking
    gameOverID = window.setTimeout("CongratsRocketShuttleLaunch('"+size+"')", 7200);	// launch rocket after 7,2 seconds  
};

// launch the rocket / Buran shuttle with exhaust
function CongratsRocketShuttleLaunch (size) {
    var prevSequence = sequence;	// inherrit sequence from warm-up
    if (sequence==1) {
        // remove the shuttle holders if present
        figuresScreen[20][4] = 0;
        figuresScreen[22][4] = 0;
        // hide the middle rocket exhaust
        figuresScreen[25][6] = 0;
        // indicate next step (becomes negative for lanching)
        rocketWarmUp--;
        // move the rocket / Buran shuttle one place up
        for (j=1; j<26; j++) {
            for (i=5; i<8; i++) {
                if (figuresScreen[j+1][i] && j<25) figuresScreen[j][i] = figuresScreen[j+1][i]
                else figuresScreen[j][i] = 0;
            };
        };
    };
    // engine exhaustion animation
    if (rocketWarmUp<1) {	// if launch started, set animation sequence
        if (sequence==0) sequence = 3
        else sequence--;
    };
    if (rocketWarmUp>-24) {
        if (size!="small"&&size!="medium") {	// extra for second engine @ big rocket & Buran shuttle
            if (rocketWarmUp>-23) figuresScreen[23+rocketWarmUp][5] = sequence;
            if (rocketWarmUp<1) figuresScreen[24+rocketWarmUp][5] = prevSequence;
        };
        // first engine exhaust animation
        if (rocketWarmUp>-23) figuresScreen[23+rocketWarmUp][7] = sequence;
        if (rocketWarmUp<1) figuresScreen[24+rocketWarmUp][7] = prevSequence;
        gameOverTxtID = window.setTimeout("CongratsRocketShuttleLaunch('"+size+"')", 100);	// next step of animation
    } else {
        CongratsTxt();	// congratulate @ end of animation
    };
    //end engine exhaustion
    if (rocketWarmUp<1) FiguresScreenShowCurrent();	// show construted screen
};

// start warming up the rocket / Buran shuttle and let it start smoking
function CongratsRocketShuttleWarmUp (size) {
    if (sequence==0) sequence = 3	// animation sequence
    else sequence--;
    if (size!="small"&&size!="medium") figuresScreen[25][4] = sequence;	// rocket size adjustment 
    figuresScreen[25][6] = sequence;
    figuresScreen[25][8] = sequence;
    FiguresScreenShowCurrent();	// show construted screen
    if (rocketWarmUp) demoMoveID = window.setTimeout("CongratsRocketShuttleWarmUp('"+size+"')", 100)	// animate next step
    else {	// remove smoke @ lift-off
        figuresScreen[25][4] = 0;
        figuresScreen[25][6] = 0;
        figuresScreen[25][8] = 0;
    };
};

// game over text
function CongratsTxt () {
    FiguresScreenClear();	// clear screen from blocks @ once
    gameOverTxtID = window.setTimeout("CongratsTxtShow()", 500);	//show congrats text in 0,5 seconds
};

// show congrats text
function CongratsTxtShow () {
    StopSound("rocket_", vlm);
    PlaySound("congrats_",vlm);
    // start "C"
    PicShow("Block"+1+"-"+2+"", blockPre.src);
    PicShow("Block"+1+"-"+3+"", blockPre.src);
    PicShow("Block"+1+"-"+4+"", blockPre.src);
    PicShow("Block"+2+"-"+1+"", blockPre.src);
    PicShow("Block"+2+"-"+5+"", blockPre.src);
    PicShow("Block"+3+"-"+1+"", blockPre.src);
    PicShow("Block"+4+"-"+1+"", blockPre.src);
    PicShow("Block"+5+"-"+1+"", blockPre.src);
    PicShow("Block"+5+"-"+5+"", blockPre.src);
    PicShow("Block"+6+"-"+2+"", blockPre.src);
    PicShow("Block"+6+"-"+3+"", blockPre.src);
    PicShow("Block"+6+"-"+4+"", blockPre.src);
    // start "O"
    PicShow("Block"+1+"-"+8+"", blockPre.src);
    PicShow("Block"+1+"-"+9+"", blockPre.src);
    PicShow("Block"+2+"-"+7+"", blockPre.src);
    PicShow("Block"+2+"-"+10+"", blockPre.src);
    PicShow("Block"+3+"-"+7+"", blockPre.src);
    PicShow("Block"+3+"-"+10+"", blockPre.src);
    PicShow("Block"+4+"-"+7+"", blockPre.src);
    PicShow("Block"+4+"-"+10+"", blockPre.src);
    PicShow("Block"+5+"-"+7+"", blockPre.src);
    PicShow("Block"+5+"-"+10+"", blockPre.src);
    PicShow("Block"+6+"-"+8+"", blockPre.src);
    PicShow("Block"+6+"-"+9+"", blockPre.src);
    // start "N"
    PicShow("Block"+8+"-"+1+"", blockPre.src);
    PicShow("Block"+8+"-"+5+"", blockPre.src);
    PicShow("Block"+9+"-"+1+"", blockPre.src);
    PicShow("Block"+9+"-"+2+"", blockPre.src);
    PicShow("Block"+9+"-"+5+"", blockPre.src);
    PicShow("Block"+10+"-"+1+"", blockPre.src);
    PicShow("Block"+10+"-"+3+"", blockPre.src);
    PicShow("Block"+10+"-"+5+"", blockPre.src);
    PicShow("Block"+11+"-"+1+"", blockPre.src);
    PicShow("Block"+11+"-"+4+"", blockPre.src);
    PicShow("Block"+11+"-"+5+"", blockPre.src);
    PicShow("Block"+12+"-"+1+"", blockPre.src);
    PicShow("Block"+12+"-"+5+"", blockPre.src);
    PicShow("Block"+13+"-"+1+"", blockPre.src);
    PicShow("Block"+13+"-"+5+"", blockPre.src);
    // start "G"
    PicShow("Block"+8+"-"+8+"", blockPre.src);
    PicShow("Block"+8+"-"+9+"", blockPre.src);
    PicShow("Block"+9+"-"+7+"", blockPre.src);
    PicShow("Block"+9+"-"+10+"", blockPre.src);
    PicShow("Block"+10+"-"+7+"", blockPre.src);
    PicShow("Block"+11+"-"+7+"", blockPre.src);
    PicShow("Block"+11+"-"+9+"", blockPre.src);
    PicShow("Block"+11+"-"+10+"", blockPre.src);
    PicShow("Block"+12+"-"+7+"", blockPre.src);
    PicShow("Block"+12+"-"+10+"", blockPre.src);
    PicShow("Block"+13+"-"+8+"", blockPre.src);
    PicShow("Block"+13+"-"+9+"", blockPre.src);
    // start "R"
    PicShow("Block"+14+"-"+1+"", blockPre.src);
    PicShow("Block"+14+"-"+2+"", blockPre.src);
    PicShow("Block"+14+"-"+3+"", blockPre.src);
    PicShow("Block"+14+"-"+4+"", blockPre.src);
    PicShow("Block"+15+"-"+1+"", blockPre.src);
    PicShow("Block"+15+"-"+5+"", blockPre.src);
    PicShow("Block"+16+"-"+1+"", blockPre.src);
    PicShow("Block"+16+"-"+2+"", blockPre.src);
    PicShow("Block"+16+"-"+3+"", blockPre.src);
    PicShow("Block"+16+"-"+4+"", blockPre.src);
    PicShow("Block"+17+"-"+1+"", blockPre.src);
    PicShow("Block"+17+"-"+3+"", blockPre.src);
    PicShow("Block"+18+"-"+1+"", blockPre.src);
    PicShow("Block"+18+"-"+4+"", blockPre.src);
    PicShow("Block"+19+"-"+1+"", blockPre.src);
    PicShow("Block"+19+"-"+5+"", blockPre.src);
    // start "A"
    PicShow("Block"+14+"-"+8+"", blockPre.src);
    PicShow("Block"+14+"-"+9+"", blockPre.src);
    PicShow("Block"+15+"-"+7+"", blockPre.src);
    PicShow("Block"+15+"-"+10+"", blockPre.src);
    PicShow("Block"+16+"-"+7+"", blockPre.src);
    PicShow("Block"+16+"-"+10+"", blockPre.src);
    PicShow("Block"+17+"-"+7+"", blockPre.src);
    PicShow("Block"+17+"-"+8+"", blockPre.src);
    PicShow("Block"+17+"-"+9+"", blockPre.src);
    PicShow("Block"+17+"-"+10+"", blockPre.src);
    PicShow("Block"+18+"-"+7+"", blockPre.src);
    PicShow("Block"+18+"-"+10+"", blockPre.src);
    PicShow("Block"+19+"-"+7+"", blockPre.src);
    PicShow("Block"+19+"-"+10+"", blockPre.src);
    // start "T"
    PicShow("Block"+21+"-"+1+"", blockPre.src);
    PicShow("Block"+21+"-"+2+"", blockPre.src);
    PicShow("Block"+21+"-"+3+"", blockPre.src);
    PicShow("Block"+21+"-"+4+"", blockPre.src);
    PicShow("Block"+21+"-"+5+"", blockPre.src);
    PicShow("Block"+22+"-"+3+"", blockPre.src);
    PicShow("Block"+23+"-"+3+"", blockPre.src);
    PicShow("Block"+24+"-"+3+"", blockPre.src);
    PicShow("Block"+25+"-"+3+"", blockPre.src);
    PicShow("Block"+26+"-"+3+"", blockPre.src);
    // start "S"
    PicShow("Block"+21+"-"+8+"", blockPre.src);
    PicShow("Block"+21+"-"+9+"", blockPre.src);
    PicShow("Block"+22+"-"+7+"", blockPre.src);
    PicShow("Block"+23+"-"+8+"", blockPre.src);
    PicShow("Block"+23+"-"+9+"", blockPre.src);
    PicShow("Block"+24+"-"+10+"", blockPre.src);
    PicShow("Block"+25+"-"+10+"", blockPre.src);
    PicShow("Block"+26+"-"+7+"", blockPre.src);
    PicShow("Block"+26+"-"+8+"", blockPre.src);
    PicShow("Block"+26+"-"+9+"", blockPre.src);
    //game = 0;
    droppable = 1;	// for start game over animation from top to bottom
    gameOverID = window.setTimeout("GameOverTxt ()", 10000);	// start demo after a minute  	
};

// block out screen & show game over text
function GameOverTxt () {
    var wait;	// waiting time according to congrats animation or not
    if ((game==1&&score>999999)||(game==2&&levelTS==20)) wait = 1200 
    else wait = 1800;
    FiguresScreenFill();	// fill screen with blocks animated from top to bottom
    gameOverTxtID = window.setTimeout("GameOverTxtShow()", wait);	//show "game over" text in 1,6 seconds
};

// show "game over" text
function GameOverTxtShow () {
    // start "G"
    PicShow("Block"+1+"-"+2+"", nullPre.src);
    PicShow("Block"+1+"-"+3+"", nullPre.src);
    PicShow("Block"+2+"-"+1+"", nullPre.src);
    PicShow("Block"+2+"-"+4+"", nullPre.src);
    PicShow("Block"+3+"-"+1+"", nullPre.src);
    PicShow("Block"+4+"-"+1+"", nullPre.src);
    PicShow("Block"+4+"-"+3+"", nullPre.src);
    PicShow("Block"+4+"-"+4+"", nullPre.src);
    PicShow("Block"+5+"-"+1+"", nullPre.src);
    PicShow("Block"+5+"-"+4+"", nullPre.src);
    PicShow("Block"+6+"-"+2+"", nullPre.src);
    PicShow("Block"+6+"-"+3+"", nullPre.src);
    // start "A"
    PicShow("Block"+1+"-"+8+"", nullPre.src);
    PicShow("Block"+2+"-"+7+"", nullPre.src);
    PicShow("Block"+2+"-"+9+"", nullPre.src);
    PicShow("Block"+3+"-"+6+"", nullPre.src);
    PicShow("Block"+3+"-"+10+"", nullPre.src);
    PicShow("Block"+4+"-"+6+"", nullPre.src);
    PicShow("Block"+4+"-"+7+"", nullPre.src);
    PicShow("Block"+4+"-"+8+"", nullPre.src);
    PicShow("Block"+4+"-"+9+"", nullPre.src);
    PicShow("Block"+4+"-"+10+"", nullPre.src);
    PicShow("Block"+5+"-"+6+"", nullPre.src);
    PicShow("Block"+5+"-"+10+"", nullPre.src);
    PicShow("Block"+6+"-"+6+"", nullPre.src);
    PicShow("Block"+6+"-"+10+"", nullPre.src);
    // start "M"
    PicShow("Block"+8+"-"+1+"", nullPre.src);
    PicShow("Block"+8+"-"+5+"", nullPre.src);
    PicShow("Block"+9+"-"+1+"", nullPre.src);
    PicShow("Block"+9+"-"+2+"", nullPre.src);
    PicShow("Block"+9+"-"+4+"", nullPre.src);
    PicShow("Block"+9+"-"+5+"", nullPre.src);
    PicShow("Block"+10+"-"+1+"", nullPre.src);
    PicShow("Block"+10+"-"+3+"", nullPre.src);
    PicShow("Block"+10+"-"+5+"", nullPre.src);
    PicShow("Block"+11+"-"+1+"", nullPre.src);
    PicShow("Block"+11+"-"+5+"", nullPre.src);
    PicShow("Block"+12+"-"+1+"", nullPre.src);
    PicShow("Block"+12+"-"+5+"", nullPre.src);
    PicShow("Block"+13+"-"+1+"", nullPre.src);
    PicShow("Block"+13+"-"+5+"", nullPre.src);
    // start "E"
    PicShow("Block"+8+"-"+7+"", nullPre.src);
    PicShow("Block"+8+"-"+8+"", nullPre.src);
    PicShow("Block"+8+"-"+9+"", nullPre.src);
    PicShow("Block"+8+"-"+10+"", nullPre.src);
    PicShow("Block"+9+"-"+7+"", nullPre.src);
    PicShow("Block"+10+"-"+7+"", nullPre.src);
    PicShow("Block"+10+"-"+8+"", nullPre.src);
    PicShow("Block"+10+"-"+9+"", nullPre.src);
    PicShow("Block"+11+"-"+7+"", nullPre.src);
    PicShow("Block"+12+"-"+7+"", nullPre.src);
    PicShow("Block"+13+"-"+7+"", nullPre.src);
    PicShow("Block"+13+"-"+8+"", nullPre.src);
    PicShow("Block"+13+"-"+9+"", nullPre.src);
    PicShow("Block"+13+"-"+10+"", nullPre.src);
    // start "O"
    PicShow("Block"+14+"-"+2+"", nullPre.src);
    PicShow("Block"+14+"-"+3+"", nullPre.src);
    PicShow("Block"+15+"-"+1+"", nullPre.src);
    PicShow("Block"+15+"-"+4+"", nullPre.src);
    PicShow("Block"+16+"-"+1+"", nullPre.src);
    PicShow("Block"+16+"-"+4+"", nullPre.src);
    PicShow("Block"+17+"-"+1+"", nullPre.src);
    PicShow("Block"+17+"-"+4+"", nullPre.src);
    PicShow("Block"+18+"-"+1+"", nullPre.src);
    PicShow("Block"+18+"-"+4+"", nullPre.src);
    PicShow("Block"+19+"-"+2+"", nullPre.src);
    PicShow("Block"+19+"-"+3+"", nullPre.src);
    // start "V"
    PicShow("Block"+14+"-"+6+"", nullPre.src);
    PicShow("Block"+14+"-"+10+"", nullPre.src);
    PicShow("Block"+15+"-"+6+"", nullPre.src);
    PicShow("Block"+15+"-"+10+"", nullPre.src);
    PicShow("Block"+16+"-"+6+"", nullPre.src);
    PicShow("Block"+16+"-"+10+"", nullPre.src);
    PicShow("Block"+17+"-"+6+"", nullPre.src);
    PicShow("Block"+17+"-"+10+"", nullPre.src);
    PicShow("Block"+18+"-"+7+"", nullPre.src);
    PicShow("Block"+18+"-"+9+"", nullPre.src);
    PicShow("Block"+19+"-"+8+"", nullPre.src);
    // start "E"
    PicShow("Block"+21+"-"+1+"", nullPre.src);
    PicShow("Block"+21+"-"+2+"", nullPre.src);
    PicShow("Block"+21+"-"+3+"", nullPre.src);
    PicShow("Block"+21+"-"+4+"", nullPre.src);
    PicShow("Block"+22+"-"+1+"", nullPre.src);
    PicShow("Block"+23+"-"+1+"", nullPre.src);
    PicShow("Block"+23+"-"+2+"", nullPre.src);
    PicShow("Block"+23+"-"+3+"", nullPre.src);
    PicShow("Block"+24+"-"+1+"", nullPre.src);
    PicShow("Block"+25+"-"+1+"", nullPre.src);
    PicShow("Block"+26+"-"+1+"", nullPre.src);
    PicShow("Block"+26+"-"+2+"", nullPre.src);
    PicShow("Block"+26+"-"+3+"", nullPre.src);
    PicShow("Block"+26+"-"+4+"", nullPre.src);
    // start "R"
    PicShow("Block"+21+"-"+6+"", nullPre.src);
    PicShow("Block"+21+"-"+7+"", nullPre.src);
    PicShow("Block"+21+"-"+8+"", nullPre.src);
    PicShow("Block"+21+"-"+9+"", nullPre.src);
    PicShow("Block"+22+"-"+6+"", nullPre.src);
    PicShow("Block"+22+"-"+10+"", nullPre.src);
    PicShow("Block"+23+"-"+6+"", nullPre.src);
    PicShow("Block"+23+"-"+7+"", nullPre.src);
    PicShow("Block"+23+"-"+8+"", nullPre.src);
    PicShow("Block"+23+"-"+9+"", nullPre.src);
    PicShow("Block"+24+"-"+6+"", nullPre.src);
    PicShow("Block"+24+"-"+8+"", nullPre.src);
    PicShow("Block"+25+"-"+6+"", nullPre.src);
    PicShow("Block"+25+"-"+9+"", nullPre.src);
    PicShow("Block"+26+"-"+6+"", nullPre.src);
    PicShow("Block"+26+"-"+10+"", nullPre.src);
    if (game==1) {		// for game A
        switch (true) {		// if case statement is true
            case (score < 100000): 
                ResetAll();   // reset to default
                gameOverID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
                break;
            case (score < 150000): 
                congrats = 1;	// quotum reached
                demoID = window.setTimeout('CongratsRocket("small");', 3000);	// start lift-off small rocket after 3 seconds
                break;
            case (score < 200000):
                congrats = 1;	// quotum reached
                demoID = window.setTimeout('CongratsRocket("medium");', 3000);	// start lift-off medium rocket after 3 seconds
                break;
            case (score < 1000000): 
                congrats = 1;	// quotum reached
                demoID = window.setTimeout('CongratsRocket("big");', 3000);	// start lift-off big rocket after 3 seconds
                break;
            default:
                break;
        };
    } else 	{	// game B
        if (game==2&&levelTS==20) {
            congrats = 1;	// quotum reached
            if (score==999999) {
                CongratsKosaksShow();	// show two Kosaks and let them dance
            } else {
                CongratsBuranShuttleShow();	// start lift-off Buran shuttle
            };
        } else {
            if (congrats) {	// quotum reached
                StopSound("congrats_", vlm);	// stop previous sound
                PlaySound("stage_clear_", vlm);
            };
            gameOverID = window.setTimeout("MainTimeStart()", 60000);	// start demo after a minute  
        };
    };
    game = 0;		// no game running
};
