/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//score functions

// show highest score since this browser tab was opened
function HighScoreShow (game) {
	PicShow("ScoreTxt", scoreTxtPre.src);
	ScoreShow(highScore[game]);
};

// translate current level to the digits on screen
function LevelShow (levelTS) {
	var digits = 4;	
	PicShow("LevelTxt", levelTxtPre.src);
	NumberToPic (levelTS,digits,"Level",snumPre);
};

// translate current lines to the digits on screen
function LinesShow (linesTS) {
	var digits = 4;
	PicShow("LineTxt", lineTxtPre.src);
	NumberToPic (linesTS,digits,"Line",snumPre);
};

// translate a number to the number pictures on screen
function NumberToPic (number,digits,element,picture) {
	var range = Math.pow(10,digits);
	var max = (10 * range) - 1;
	if (number>max) number = Math.floor((number%range));
	for (i=1 ; i<(digits+1) ; i++) {
		if ((Math.floor(number / (Math.pow(10,digits-i)))) || i==digits) PicShow(element+i+"", picture[(Math.floor((number % (Math.pow(10,digits+1-i))) / (Math.pow(10,digits-i)))+1)].src)
		else PicShow(element+i+"", nullPre.src);
	};
};

// add certain points to score
function ScoreAdd (points) {
	if (points) {
		for (var a=0 ; a<points ; a++) {
			if (score<999999) score++;
		};
		if (score>highScore[game]) highScore[game] = score;	   // if passed highscore @ normal game set new highscore
		ScoreShow(score);
	};
};

//calculate Tetris score to add
function ScoreCalc () {
	scoreCalc = 0;
	switch (figureFullLinesStacked) {
		case 1 :
			scoreCalc = 40 * (levelTS + 1);
			break;
		case 2 :
			scoreCalc = 100 * (levelTS + 1);
			break;
		case 3 :
			scoreCalc = 300 * (levelTS + 1);
			break;
		case 4 :
			scoreCalc = 1200 * (levelTS + 1);
			break;
		default :
			break;
	};
	figureFullLinesStacked = 0;
	return scoreCalc;
};

// hide score from screen
function ScoreHide () {
	$("#ScoreTxt").addClass("hidden");
	for (i=1 ; i<7 ; i++) $("#Score"+i+"").addClass("hidden");
};

// translate current score to the digits on screen
function ScoreShow (score) {
	var digits = 6;	
	PicShow("ScoreTxt", scoreTxtPre.src);
	NumberToPic (score,digits,"Score",snumPre);
};

// unhide score from screen
function ScoreUnHide () {
	$("#ScoreTxt").RemoveClass("hidden");
	for (i=1 ; i<7 ; i++) $("#Score"+i+"").removeClass("hidden");
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end score functions
