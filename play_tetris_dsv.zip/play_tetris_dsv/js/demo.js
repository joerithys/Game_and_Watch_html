//demo functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// start demo
function Demo () {
	StopAllSound();
	GameReset();
	sequence = 2; // equals number of figureNext
	DemoMovesSet();	// load set of demo moves for this figure
	demo = 1;	// indicates demo is running
	demoMovesSeq = 0;	// start of demo sequens
	direction = 1;	  // 1 = up, 2 = right, 3 = down, 4 = left
	figure = figuresDemo[1];	// take first demo figure
	FigureDimSet();	// set dimensions of current figure and its directions
	figurePosX = 4;	  // = x
	figurePosY = 0;	  // = Y
	FigureShow(figurePosX, figurePosY);	// show current falling figure
	figureNext = figuresDemo[sequence];	// set dimensions of next figure and its directions
	FigureShowNext(figureNext);	// show next figure to come in the box
	FiguresDimGroundedClear();	// clear all grounded blocks
	game = 4;	// clock & demo shown
	gameSpeed = 1000;
	gameOver = 0;
	stacked = 0;
	demoID = window.setTimeout("DemoRun()", (gameSpeed/2));	// next step after a second  
};

// load set of demo moves for this figure
function DemoMovesSet () {
	switch (sequence) {
		case 1 : 	// last figure, "O"
			demoMovesSet = ["R", "A"];
			break;
		case 2 :	// first figure, "L"
			demoMovesSet = ["R", "R", "R", "R", "U", "U", "A"];
			break;
		case 3 : 		// next figure, "T"
			demoMovesSet = ["R", "U", "U", "A"];
			break;
		case 4 : 		// next figure, "O"
			demoMovesSet = ["L", "L", "A"];
			break;
		case 5 : 		// next figure, "L"
			demoMovesSet = ["L", "L", "L", "U", "U", "U", "L", "A"];
			break;
		case 6 : 		// next figure, "S"
			demoMovesSet = ["R", "R", "R", "R", "A"];
			break;
		case 7 : 		// next figure, "T"
			demoMovesSet = ["L", "L", "L", "U", "U", "U", "A"];
			break;
		case 8 : 		// next figure, "Z"
			demoMovesSet = ["L", "L", "L", "U", "A"];
			break;
		case 9 : 		// next figure, "J"
			demoMovesSet = ["L", "A"];
			break;
		case 10 : 		// next figure, "L"
			demoMovesSet = ["R", "R", "R", "A"];
			break;
		case 11 : 		// next figure, "Z"
			demoMovesSet = ["R", "R", "U", "A"];
			break;
		case 12 : 		// next figure, "J"
			demoMovesSet = ["L", "L", "A"];
			break;
		case 13 : 		// next figure, "I"
			demoMovesSet = ["R", "R", "A"];
			break;
		case 14 : 		// next figure, "L"
			demoMovesSet = ["R", "R", "R", "R", "U", "R", "A"];
			break;
		case 15 : 		// next figure, "T"
			demoMovesSet = ["L", "L", "L", "U", "U", "U", "L", "A"];
			break;
		case 16 : 		// next figure, "T"
			demoMovesSet = ["U", "U", "U", "A"];
			break;
		case 17 : 		// next figure, "O"
			demoMovesSet = ["L", "L", "A"];
			break;
		case 18 : 		// next figure, "J"
			demoMovesSet = ["R", "R", "R", "U", "U", "U", "A"];
			break;
		case 19 : 		// next figure, "J"
			demoMovesSet = ["R", "R", "R", "R", "A"];
			break;
		case 20 : 		// next figure, "L"
			demoMovesSet = ["L", "U", "U", "A"];
			break;
		default:
			break;
	};
};

// demo loop
function DemoRun () {
	if (demoID) {	// if demo still planned to start stop that plan to avoid double run
		clearTimeout(demoID);
		demoID = null;
	};
	if (droppable) {	// if figure not stuck or stacked
		FigureDrop(figurePosX, figurePosY);	// drop figure one place
		// move or turn figure according to its set of moves
		switch (demoMovesSet[demoMovesSeq]) {
			case "L" :
				demoMoveID = window.setTimeout("GoLeft()", (gameSpeed/2));
				break;
			case "R" :
				demoMoveID = window.setTimeout("GoRight()", (gameSpeed/2));
				break;
			case "U" :
				demoMoveID = window.setTimeout("FiguresRotate();", (gameSpeed/2));
				break;
			case "A" :
				demoMoveID = window.setTimeout("FigureDropFull();", (gameSpeed/2));
				break;
			default:
				break;
		};
		demoMovesSeq++;	// next move
	} else {	// figure got stuck or stacked, next figure should now be loaded
		DemoMovesSet();	// load set of demo moves for this figure
		demoMovesSeq = 0;	// reset move sequence to start
		droppable = 1;	// figure not stuck or stacked yet
	};
	if (!FigureStackFull()) demoID = window.setTimeout("DemoRun();", gameSpeed);	// next step after a second  
};

// load set of ordered demo figures
function FiguresDemoSet () {
	figuresDemo[1] = "L";	  // demo figure 1
	figuresDemo[2] = "T";	  // demo figure 2
	figuresDemo[3] = "O";	  // demo figure 3
	figuresDemo[4] = "L";	  // demo figure 4
	figuresDemo[5] = "S";	  // demo figure 5
	figuresDemo[6] = "T";	  // demo figure 6
	figuresDemo[7] = "Z";	  // demo figure 7
	figuresDemo[8] = "J";	  // demo figure 8
	figuresDemo[9] = "L";	  // demo figure 9
	figuresDemo[10] = "Z";	  // demo figure 10
	figuresDemo[11] = "J";	  // demo figure 11
	figuresDemo[12] = "I";	  // demo figure 12
	figuresDemo[13] = "L";	  // demo figure 13
	figuresDemo[14] = "T";	  // demo figure 14
	figuresDemo[15] = "T";	  // demo figure 15
	figuresDemo[16] = "O";	  // demo figure 16
	figuresDemo[17] = "J";	  // demo figure 17
	figuresDemo[18] = "J";	  // demo figure 18
	figuresDemo[19] = "L";	  // demo figure 19
	figuresDemo[20] = "O";	  // demo figure 20
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end figure functions
