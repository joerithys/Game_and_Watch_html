//Product:	Donkey Kong HTML - Multi Screen (Nintendo) Simulator
//Version:	4.4
//Started:	27.05.2000
//Last update:	06.02.2003
//Last update Flyzy: 04.05.2020
//Author:	Andrzej Czyz (andrzej.czyz@blindfold.z.pl)
//Website:	www.blindfold.z.pl
//Original:	Nintendo Co. Ltd
//Modified by Flyzy

// local file cookies only work on firefox!!!  (2019)


//initialise variables
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var demo = false;	   // indicates if demo is running or not
var demoID;	 // ID for timeout demo autostart after last handling

var barrels = new MakeArray(27);	// array of barrel figures
var barrelsPause = false;
var barrelsRandom = 4;  // random number for barrels at init
var fourOnRow = false;
var threeOnRow = false;

var segments = new MakeArray(5);		// array of segment figures
var segmentsPause = false;
var segmentsRandomOrg = 7;	  // initial random number for segments at init
var segmentsRandom = segmentsRandomOrg; // random number for segments at init

var kong = 2;	// kong stands in the middle
var kongThrow = false;	// Kong is holding up a barrel, ready to throw, if he doesn't have to follow Mario
var kongThrowInd;	// defines frequency of barrels thrown
var kongThrowPrev = false;	// true when kong should have thrown previous timen but had to follow Mario
var kongPause = false;
var kongRandom; //0 1 2	random number for kong throwing barrels varying according to game
var kongRandomOrg;	// initial random number for kong throwing barrels
var kongDirection;	// direction to move kong

var hook;	// hook position
var hookTest;	// test for position hook @ screen switch
var hookSpeed;  // speed for hook movement
var hookSpeedMario;	// speed Mario swigning on hook
var hookID;	 // ID for timeout moving hook
var hookEndComplete = true;	// indicator end of hook sequence
var hookMarioID;		// ID for timeout mario swinging on hook
var leverSpeed = 150;	// speed for flipping lever
var leverOn = false;	// indicates if hook is active	
var leverOffID; // time to wait for turning off lever

var mario;	// position Mario
var marioPause = false;
var marioJump = false;
var marioSpeedJump;	 // speed for letting Mario jump
var marioSpeedFall;	 // speed for letting Mario fall
var marioSpeedKill;	 // speed for Mario getting killed
var marioTime;  // speed for letting Mario jump up
var marioKill = false;  // if mario was killed
var marioKillPlace;	 // where mario was killed....
var marioTimeID;		// ID for timeout mario jumping
var marioJumpID;		// ID for timeout mario jumping down
var marioFallID;		// ID for timeout mario falling
var marioKillID;		// ID for timeout mario getting killed

var beeps;	  // for amount of beeps in mario gained bonus loop
var score = 0;	// score (all beneath 10000) at init
var demoScore = 150;	// dummy score for demo to simmulate score level
var scorePause = false;
var scoreSpeed; // speed for score count
var scoreID;	// ID for timeout score count
var gameCode;	//	Indicates if score was made @ game A or B
var gamePause;	
var gameID;	// ID for timeout game sequence
var gameSpeedMinimum;	// minimum speed for game sequence
var gameSpeedMaximum = 200;	// maximum speed for game sequence
var gameSpeed;	// speed for game sequence
var highScore = new Array();	// for highest scores for games a & b
var sequence = 1;	// m=1234/b=24/k=1234/s=1
var seq = 1;	//	sequence being odd
var blinkSpeed = 500;  // blinking speed while bonus play
var blinkID;	// ID for timeout blinking score
var loveSpeed;	// speed love hearts animation
var loveID;	 // ID for timeout princess kisses when freed
var bonusTime = 470;	// blinking speed to indicate extra gained Mario
var bonusID;	// ID for timeout bonus indication time
var bonusDone = false;  // indicates when bonus count is done
var bonusScore; // bonus for removing a holder
var pointsBonus = false;		// 300 points reached with 4 marios remaining
var Life3 = 1;  // for blinking extra Mario
var allLifes;	// for animation life indication if 1 life less
var allLifesID;	// ID for timeout animation life indication
var allLifesSpeed;	// for animation life indication if 1 life less
var runTime;	// shows how long it took to get to the holder
var runTimeID;	// ID for timeout runTime count
var timer = 0;	// game runTime test count
var timerID;	// ID for game runTime test count
var colonID;	// ID for game runTime test colon blink

var infoID;	// ID for timeout info message
var infoPos = 0;		// first position info banner
var infoMsg = "Joeri Thys";	 // shown while loading
var infoMsgBlur = "Joeri Thys";	 // shown while loading

var hi = new MakeArray(10);	// high score top 10 list
var chars = new MakeArray(26);	// valid name input characters A-Z
for ( i=1 ; i<27 ; i++ ) {
	chars[i] = String.fromCharCode(64+i);	   // array of all alphabet letters
}

var name = '';  // name player starts empty
var nameID;	// ID for timeout high score name input
var nameFlash = false;	// show name for input

var keys;	   // number of input or characters for name player
var keysID;	// ID for timeout key remap input
var keysFlash = false;	// show remapping keys
var keysRemapRep = 0;	// once the name input has started demo count down starts

var bonus = 0;	// bonus gained
var hold;	// number of holders left
var life;	// number of lives left
var animated = true;	// animated life indication required
var game = 9;   // 0-no game-all pictures; 1-gameA; 2-gameB; 3-game over; 4-clock; 5-set alarm (on); 6-high score; 7-keys; 8-set alarm (off);
var timeID;	 // ID for timeout time indication
var gamerInterrupt = false;	// when user aborts present action

var alarm = false;	// alarm set off
var alarmID;	// ID for timeout for starting the alarm
var alarmOffID; // ID for timeout for stopping the alarm
var alarmOn = true;	 // if alarm is set
var alarmSetting = false;	   // if alarm is at set mode

var today = new Date();
var hour = today.getHours();
var min = today.getMinutes();
var sec = today.getSeconds();
var expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);	// 28 days for cookie to expire

var img_on = 'img/play_donkey_kong_multi_org_bkgnd.png';	// image background for realistic view
var img_off = 'gfx/tile.gif';	// plain orange background for compact view
var vlm = 1;	// sound volume 0.01-1
var preVlm = vlm;	   // previous sound volume 0.01-1
var prefSound = 1;	  // 1-on; 0-off
var prefSoundShow = 0;  // show sound volume 1-on; 0-off
var prefBlur;   // 1-on (detailed view) ; 0-off (compact view)
var prefAlarmSet;	// last saved alarm setting 1-on; 0-off
var prefAlarmMin;	// last saved alarm setting minutes
var prefAlarmHour;	// last saved alarm setting hours
var sound = true;	// to prevent click sound @ autostart
var zoomed = 1;		// default screen auto adapted to window size

// reset pressed keys to none pressed
var keyUp = false;
var keyDown = false;
var keyLeft = false;
var keyRight = false;
var keyJump = false;

// programmable keys preset
var codeUp = 122;
var codeUpChar = "z";
var codeDown = 119;
var codeDownChar = "w";
var codeLeft = 113;
var codeLeftChar = "q";
var codeRight = 115;
var codeRightChar = "s";
var codeJump = 13;
var codeJumpChar = "Enter";
var codeGameA = 97;
var codeGameAChar = "a";
var codeGameACharUp;
var codeGameB = 98;
var codeGameBChar = "b";
var codeGameBCharUp;
var codeCurrent = 0;	// "0" = no key pressed
var codeCurrentChar = "";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end initialise variables

//read pushed buttons & act accordingly
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Permanent & programmable direction & jump buttons
window.addEventListener("keydown", function (e) {
	codeCurrent = e.keyCode;		// for reading names & game keys
	codeCurrentAlarm = e.keyCode;		// for reading key to stop alarm sound
	codeCurrentChar = e.key;		// current character of key pressed 
	e.preventDefault();		// prevent some browsers to shift, scroll, go page back or do other stuff when key pressed
	// space and arrow keys
	switch (e.key) {
		case " ": case codeJumpChar:	//	space key or jump key
			document.images['Jump'].src = 'gfx/curj_in.png'; 
			if (!keyJump) { // Jump
				keyJump = true;
				if (!marioPause) MarioButtonJump();	// press jump button
			};
			break;
		case "ArrowLeft": case codeLeftChar:	//arrow left key
			document.images['Move Left'].src = 'gfx/curl_in.png'; 
			if (!keyLeft) { // Left
				keyLeft = true;
				if (!marioPause) MarioButtonLeft();	// press left button
			};
			break;
		case "ArrowUp": case codeUpChar:	//arrow up key
			document.images['Move Up'].src = 'gfx/curu_in.png'; 
			if (!keyUp) { // Up
				keyUp = true;
				if (!marioPause) MarioButtonUp();	// press up button
			};
			break;
		case "ArrowRight": case codeRightChar:	//arrow right key
			document.images['Move Right'].src = 'gfx/curr_in.png'; 
			if (!keyRight) { // Right
				keyRight = true;
				if (!marioPause) MarioButtonRight();	// press right button
			};
			break;
		case "ArrowDown": case codeDownChar:	//arrow down key
			document.images['Move Down'].src = 'gfx/curd_in.png'; 
			if (!keyDown) { // Down
				keyDown = true;
				if (!marioPause) MarioButtonDown();	// press down button
			};
			break;
		//test case buttons
		case "(":	//"("-key to un/hide the timer for test purposes
			TimerHider();
			break;
		case "+":	//"+"-numpadkey
			if (vlm<1) {
				vlm = (parseFloat(vlm) + 0.01).toFixed(2);	// increase volume for test purposes
				preVlm = vlm;
				if (vlm==0.01)  SetSound(true);	// show sound turned on
			};
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "-":	//"-"-key
			if (vlm>0) {
				vlm = (parseFloat(vlm) - 0.01).toFixed(2);	// decrease volume for test purposes
				preVlm = vlm;
			};
			if (vlm==0) SetSound(false);	// show sound turned off
				PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case "@": case String.fromCharCode(233):	//mac-"@"(at)-key/win-"é(e-accent-egue)-key 
			prefSoundShow = !prefSoundShow;
			PrefSoundShow();	// show volume indicator on screen for testing purposes
			break;
		case ")": case String.fromCharCode(219):
			zoomed = zoomed?0:1;
			$(function () {
				CheckSizeZoom();
				$('#divWrap').css('visibility', 'visible');
			});
			$(window).resize(CheckSizeZoom);
			break;
		default:
	};
	if (game!=6 && game!=7) {
		eKeyUp = e.key.toLowerCase();
		// if programmed code game a (standard"a"), regular "1" of numeric pad "1"
		if (e.key==codeGameAChar || e.key=="1" || eKeyUp==codeGameACharUp) {
			document.images['Game A'].src = 'gfx/butset_in.png';
			MainGameA(); // play Game A
		};
		// if programmed code game b (standard"b"), regular "2" of numeric pad"2"
		if (e.key==codeGameBChar || e.key=="2" || eKeyUp==codeGameBCharUp) {
			document.images['Game B'].src = 'gfx/butset_in.png';
			MainGameB(); // play Game B
		};
	};
	console.log("You pressed e.keyCode : " + e.keyCode + " <==> '" + e.key + "'");
}, false);

window.addEventListener("keyup", function(e) {
	// space and arrow keys
	codeGameACharUp = codeGameAChar.toUpperCase();
	codeGameBCharUp = codeGameBChar.toUpperCase();
	switch (e.key) {
		case "Enter":  // else "Enter" is not released!!!
			keyJump = false;
			// reset all key pics "Enter" can be used for
			document.images['Jump'].src = 'gfx/curj.png';	
			document.images['Move Left'].src = 'gfx/curl.png';
			document.images['Move Up'].src = 'gfx/curu.png';
			document.images['Move Right'].src = 'gfx/curr.png';
			document.images['Move Down'].src = 'gfx/curd.png';
			break;
		case " ": case codeJumpChar:	// space key released
			keyJump = false; // Jump released;
			document.images['Jump'].src = 'gfx/curj.png';
			break;
		case "ArrowLeft": case codeLeftChar:	// arrow left key released
			keyLeft = false; // Left released;
			document.images['Move Left'].src = 'gfx/curl.png';
			// if mario top left, release lever
			if (mario==13) leverOffID=setTimeout("LeverOff()", leverSpeed);
			break;
		case "ArrowUp": case codeUpChar:	// arrow up key released
			keyUp = false; // Up released;
			document.images['Move Up'].src = 'gfx/curu.png';
			break;
		case "ArrowRight": case codeRightChar:	// arrow right key released
			keyRight = false; // Right released;
			document.images['Move Right'].src = 'gfx/curr.png';
			break;
		case "ArrowDown": case codeDownChar:	// arrow down key released
			keyDown = false; // Down released;
			document.images['Move Down'].src = 'gfx/curd.png';
			break;
		case "1": case codeGameAChar: case codeGameACharUp :	// if "1", programmed key released
			MainGameAGo();
			document.images['Game A'].src = 'gfx/butset.png';
			break;
		case "2": case codeGameBChar: case codeGameBCharUp :	  // if "2", programmed key released
			MainGameBGo();
			document.images['Game B'].src = 'gfx/butset.png';
			break;
		default:
	};
}, false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end read pushed buttons & act accordingly

//when page loaded focus on game & initiate info banner resize
$(document).ready(function () {
	$(function () {
		CheckSizeZoom();
		$('#divWrap').css('visibility', 'visible');
	});
	$(window).resize(CheckSizeZoom);
	$("#game").focus(); // get focus on the game
	$("#input").hover(function () {	// enlarge tekst of info banner on hover
		$(this).css("fontSize", "18px");
	},
	function () {	// normal tekst size of info banner if no hover
		$(this).css("fontSize", "10px");
	});	
	$("#Banner").hover(function () {	// enlarge tekst of info banner on hover
		$(this).css("fontSize", "18px");
	},
	function () {	// normal tekst size of info banner if no hover
		$(this).css("fontSize", "10px");
	});	
	$("#Kong1").focus(); // get focus on the game
	Loaded();	// set game to standard settings, load info text and show all figures	
});

// this function is started when page is opened
// set game to standard settings, load info text and show all figures
function Loaded () {
	PrefsLoad();	// set game according to button settings
	if (infoID) {	 // if info bannrer was planned or running, stop sequence
		clearTimeout(infoID);
		infoID = null;
	};
	InfoTextClear();	// empty info banner
	InfoTextLoading();	// add loading text to info banner
	InfoTextRoll();	// add ending spaces to info banner
	Info();	// run info banner
	PicPreload();	// this function preloads all images according to the blur setting
	PrefSoundEval();	// Show sound settings according to current or cookie settings
	TimeAlarmBackground();	// function runs all the time and checks the alarm on the background
	MainPicturesShow();	// show all figures
	MainLoaded();	// set game to standard settings and show all figures
	demoID = setTimeout("MainTime()", 120000);	// start demo after 2 minutes
};

//standard functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// make an array
function MakeArray (size) {
	this.length = size;
	for (var i=1; i<=size; i++) this[i] = 0;
};

// actual down function to let Mario go down
function LetMarioDown () {
	if (game==1 || game==2) {
		if (mario==6 || mario==11 || mario==12 || mario==13) {
			PicShow("Mario"+eval(mario--)+"", nullPre.src);
			PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
			PlaySound("step", vlm);	// sound for Mario moving
			SegmentsCollision();		// check if Mario collides with a segment
		};
	} else {
		if (game==5 || game==8) {	// subtract an hour from alarm time
			prefAlarmHour--;	// subtract an from hour alarm setting
			if (prefAlarmHour==-1) prefAlarmHour = 23;
			AlarmShowNum();	// show alarm time
		};
	};
};

// actual jump function
function LetMarioJump () {
	if (game==1 || game==2) {
		clearTimeout(marioTimeID);
		marioTimeID = null;
		if (!marioJump) {
			 // jump to the hook
			if (mario==15) {
				mario = 24; 
				PicShow("Mario15", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				MarioEdge();	// mario is jumping to the hook; check if he reaches; at start mario=24
			};
			// just jump
			if (mario==1 || mario==4 || mario==7 || mario==8) MarioJump();	// let Mario jump
			// mario init
			if (mario==0 || mario==-1) {
				mario = 0;
				bonusScore = 20;
				MarioUpInit();	// mario init when jump pressed the first time
			};
		};
	};
};

// actual left function to let Mario go left
function LetMarioLeft () {
	if (game==1 || game==2) {
		// swich on the hook
		if (mario==13) {
			PicShow("Mario13", marleveronPre.src);
			if (demo) leverOffID=setTimeout("LeverOff()", ((gameSpeed + 100)/2) );
			if (hook==0 && hookEndComplete) HookStart();	// initiate hook to move
		};
		// move right near swich
		if (mario==14) {
			mario--;
			PicShow("Mario14", nullPre.src);
			PicShow("Mario13", marioPre[13].src);
			BarrelsCollisionUp();	// barrels check collision - when mario can get hit from falling barrel
			if (!marioKill) PlaySound("step", vlm);	// sound for Mario moving
		};
		if (!marioJump) {
			// move left on the upper platform
			if (mario==15) {
				PicShow("Mario"+eval(mario--)+"", nullPre.src);
				PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
				BarrelsCollisionUp();	// barrels check collision - when mario can get hit from falling barrel
				if (!marioKill) PlaySound("step", vlm);	// sound for Mario moving
			};
			// move left on the lower platform
			if (mario>1 && mario<6) {
				BarrelsCollisionBack();	// barrels check collision- when mario is going back
				if (!marioKill) {
					PicShow("Mario"+eval(mario--)+"", nullPre.src);
					PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
					PlaySound("step", vlm);	// sound for Mario moving
				};
			};
			// move left on the mid platform
			if (mario>5 && mario<10) {
				BarrelsCollisionFront();	// barrels check collision - when mario is moving along
				if (!marioKill) {
					PicShow("Mario"+eval(mario++)+"", nullPre.src);
					PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
					PlaySound("step", vlm);	// sound for Mario moving
				};
			};
		};
	} else
		if (game==5 || game==8) {	// subtract a minute from alarm time
			prefAlarmMin--;	// subtract a minute from alarm time
			if (prefAlarmMin==-1) prefAlarmMin = 59;
			AlarmShowNum();	// show alarm time
		};
};

// actual right function to let Mario go right
function LetMarioRight () {
	if (game==1 || game==2) {
		if (!marioJump) {
			// falling from the edge
			if (mario==15) {
				mario = 34;
				PlaySound("fall", vlm);	// sound for falling Mario
				PauseAll();
				MarioFall();	// Mario falls missing the hook
			};
			// move right on the lower platform - front
			if (mario>0 && mario<5) {
				BarrelsCollisionFront();	// barrels check collision - when mario is moving along
				if (!marioKill) {
					PicShow("Mario"+eval(mario++)+"", nullPre.src);
					PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
					PlaySound("step", vlm);	// sound for Mario moving
				};
			};
			// move right on the upper platform - front - up barrels
			if (mario>12 && mario<15) {
				PicShow("Mario"+eval(mario++)+"", nullPre.src);
				PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
				BarrelsCollisionUp();	// barrels check collision - when mario can get hit from falling barrel
				if (!marioKill) {
					PlaySound("step", vlm);	// sound for Mario moving
				};
			};
			// move right on the mid platform - back
			if (mario>6 && mario<11) {
				BarrelsCollisionBack();	// barrels check collision- when mario is going back
				if (!marioKill) {
					PicShow("Mario"+eval(mario--)+"", nullPre.src);
					PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
					PlaySound("step", vlm);	// sound for Mario moving
				};
			};
		};
	} else {
		if (game==5 || game==8) {	// add a minute to alarm time
			prefAlarmMin++;	// add a minute to alarm time
			if (prefAlarmMin==60) prefAlarmMin=0;
			AlarmShowNum();	// show alarm time
		};
	};
};

// actual up function to let Mario go up
function LetMarioUp () {
	if (game==1 || game==2) {
		// move up near swich
		if (mario==12) {
			mario++;
			PicShow("Mario12", nullPre.src);
			PicShow("Mario13", marioPre[13].src);
			PlaySound("step", vlm);	// sound for Mario moving
			BarrelsCollisionUp();	// check if Mario collides with a thrown barrel
		};
		// move up
		if (mario==5 || mario==10 || mario==11) {
			PicShow("Mario"+eval(mario++)+"", nullPre.src);
			PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
			PlaySound("step", vlm);	// sound for Mario moving
			SegmentsCollision();	// check if Mario collides with a segment
		};
	} else {
		if (game==5 || game==8) {	// add an hour to alarm time
			prefAlarmHour++;	// add an hour to alarm setting
			if (prefAlarmHour==24) prefAlarmHour = 0;
			AlarmShowNum();	// show alarm time
		};
	};
};

// down button or -key pressed
function MarioButtonDown () {
	if (!demo) LetMarioDown();
};

// jump button or -key pressed
function MarioButtonJump () {
	if (!demo) LetMarioJump();
};

// left button or -key pressed
function MarioButtonLeft () {
	if (!demo) LetMarioLeft();
};

// right button or -key pressed
function MarioButtonRight () {
	if (!demo) LetMarioRight();
};

// up button or -key pressed
function MarioButtonUp () {
	if (!demo) LetMarioUp();
};

// show or hide picture on the game screen
function PicShow (id, name) {
	if (name) document.images[id].src = name;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end standard functions

//preload screen figures & show/hide all of them
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this function preloads all images according to the blur setting
function PicPreload () {
	var ext;	// pic's extension/format
	nullPre = new Image();
	nullPre.src = "gfx/null.gif";	// empty picture to hide the figure
	barPre = new Array();
	if (prefBlur) {
		ext = ".png"	;// if blur use png-pics, else gif-pics
		$("#full_screen_button a img").removeClass("adapted");
		$("#Info_button a img").removeClass("adapted");
	} else {
		ext = ".gif";
		$("#full_screen_button a img").addClass("adapted");
		$("#Info_button a img").addClass("adapted");
	};
	for (i=1 ; i<29 ; i++) {	// to show the barrels
		barPre[i] = new Image();
		barPre[i].src = "gfx/bar"+eval(i)+ext;
	};
	bellPre = new Image();
	bellPre.src = "gfx/bell"+ext;	// to show the alarm bell
	hookPre = new Array();
	for (i=1 ; i<9 ; i++) {	// to show the hooks
		hookPre[i] = new Image();
		hookPre[i].src = "gfx/hook"+eval(i)+ext;
	};
	segPre = new Array();
	for (i=1 ; i<6 ; i++) {	// to show the passing i-beams
		segPre[i] = new Image();
		segPre[i].src = "gfx/seg"+eval(i)+ext;
	};
	lifePre = new Image();
	lifePre.src = "gfx/life"+ext;	// to show the remaining lives 
	holPre = new Array();
	for (i=1 ; i<5 ; i++) {	// to show the bridge holders
		holPre[i] = new Image();
		holPre[i].src = "gfx/hol"+eval(i)+ext;
	};
	lovePre = new Array();
	for (i=1 ; i<3 ; i++) {	// to show the love signs
		lovePre[i] = new Image();
		lovePre[i].src = "gfx/love"+eval(i)+ext;
	};
	donkeyPre = new Array();
	for (i=1 ; i<3 ; i++) {
		donkeyPre[i] = new Image();	// to show kong
		donkeyPre[i].src = "gfx/donkey"+eval(i)+ext;
	};
	gamePre = new Array();
	for (i=1 ; i<3 ; i++) {
		gamePre[i] = new Image();	// to show which game is playing
		gamePre[i].src = "gfx/game"+eval(i)+ext;
	};
	dayamPre = new Image();
	dayamPre.src = "gfx/dayam"+ext;	// to show the "AM" indicator
	daypmPre = new Image();
	daypmPre.src = "gfx/daypm"+ext;	// to show the "PM" indicator
	bridgeupPre = new Array();
	for (i=1 ; i<4 ; i++) {	// to show the bridge segments
		bridgeupPre[i] = new Image();
		bridgeupPre[i].src = "gfx/bridgeup"+eval(i)+ext;
	};
	bridgedownPre = new Array();
	for (i=1 ; i<4 ; i++) {	// to show the broken bridge segments
		bridgedownPre[i] = new Image();
		bridgedownPre[i].src = "gfx/bridgedown"+eval(i)+ext;
	};
	kongwalkPre = new Array();
	for (i=1 ; i<5 ; i++) {	// to show walking kong
		kongwalkPre[i] = new Image();
		kongwalkPre[i].src = "gfx/kongwalk"+eval(i)+ext;
	};
	kongallPre = new Array();
	for (i=1 ; i<4 ; i++) {	// to show full kong
		kongallPre[i] = new Image();
		kongallPre[i].src = "gfx/kongall"+eval(i)+ext;
	};
	kongThrowPre = new Array();
	for (i=1 ; i<4 ; i++) {	// to show throwing kong
		kongThrowPre[i] = new Image();
		kongThrowPre[i].src = "gfx/kongThrow"+eval(i)+ext;
	};
	numPre = new Array(); // czy od zera???
	for (i=1 ; i<11 ; i++) {	// to show the numbers
		numPre[i] = new Image();
		numPre[i].src = "gfx/num"+eval(i-1)+ext;
	};
	colonPre = new Image();
	colonPre.src = "gfx/colon"+ext;	// to show time splitter colon
	leveronPre = new Image();
	leveronPre.src = "gfx/leveron"+ext;	// to show lever up
	leveroffPre = new Image();
	leveroffPre.src = "gfx/leveroff"+ext;	// to show lever down
	leverallPre = new Image();
	leverallPre.src = "gfx/leverall"+ext;	// to show lever up & down
	marioPre = new Array();
	for (i=1 ; i<22 ; i++) {	// to show the Marios
		marioPre[i] = new Image();
		marioPre[i].src = "gfx/mario"+eval(i)+ext;
	};
	// sory for such a waste, better idea next time to show the jumping Marios (Andrzej Czyz)
	marjumpPre = new Array();
	marjumpPre[1] = new Image();
	marjumpPre[1].src = "gfx/marjump1"+ext;	// to show mario jumping @ 1st position
	marjumpPre[4] = new Image();
	marjumpPre[4].src = "gfx/marjump4"+ext;	// to show mario jumping @ 4th position
	marjumpPre[7] = new Image();
	marjumpPre[7].src = "gfx/marjump7"+ext;	// to show mario jumping @ 7th position
	marjumpPre[8] = new Image();
	marjumpPre[8].src = "gfx/marjump8"+ext;	// to show mario jumping @ 8th position
	marleveronPre = new Image();
	marleveronPre.src = "gfx/marleveron"+ext;	// to show mario for lever up
	marleverallPre = new Image();
	marleverallPre.src = "gfx/marleverall"+ext;	// to show mario for lever up & down
	soundOnPre = new Image();
	soundOnPre.src = "gfx/soundOn"+ext;	// to show sound-on indication
	soundOffPre = new Image();
	soundOffPre.src = "gfx/soundOff"+ext;	// to show sound-off indication
	switchScreen = false;
};

// show present barrels
function BarrelsShow () {
	for (var i=1 ; i<=28 ; i++) {
		if (barrels[i]==0) PicShow("Bar"+eval(i)+"", nullPre.src)	// hidden barrels
		else PicShow("Bar"+eval(i)+"", barPre[i].src);	// shown barrels
	};
};

// show the current segments
function SegmentsShow () {
	for (var i=1 ; i<=5 ; i++) {
		if (segments[i]==0) PicShow("Seg"+eval(i)+"", nullPre.src) 
		else PicShow("Seg"+eval(i)+"", segPre[i].src);
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end preload screen figures & show/hide all of them

//sound functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich sound on/off; dont preload here
function PrefSound () {
	prefSound = !prefSound;
	PrefSoundEval();
};

// Show sound settings according to current (or cookie) settings
function PrefSoundEval () {
	if (!prefSound) {
		preVlm = vlm;
		vlm = 0;
	} else {
		if (preVlm==0) preVlm = 0.01;
		vlm = preVlm;
	};
	PrefSoundSettings();	// show sound on/off indication
	PrefSoundShow();	// show volume indicator on screen for testing purposes
	PlaySound("penclick", vlm);	// click sound for slide button
};

// show sound on/off indication
function PrefSoundSettings () {
	if (prefSound) {
		PicShow("SoundState", soundOnPre.src);	// show sond on indication
		document.images["Sound"].src = "gfx/buton.png";	// set sound button to "on"
	} else {
		PicShow("SoundState", soundOffPre.src);		// show sound off indication
		document.images["Sound"].src = "gfx/butoff.png";	// set sound button to "off"
	};
};

// show/hide volume indicator for testing purposes
function PrefSoundShow () {
	var vlmTxt = "";
	$("#SoundStateInd").html("");	// empty hide volume indicator
	if (prefSoundShow) {
		$("#SoundStateIndBkgnd").removeClass("hidden");		
		if (vlm>0.00999) {
			for (var i=1; i<=(vlm*100); i++) {	// load counted number of sound indicator bars
				vlmTxt += '<img SRC="gfx/volume/SoundStateInd.png" name="SoundStateInd" border=0 style="float:left">';
			};
			$("#SoundStateInd").html(vlmTxt);	// show counted number of sound indicator bars
		} else $("#SoundStateInd").html('<img SRC="gfx/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	} else {
		$("#SoundStateIndBkgnd").addClass("hidden");
		$("#SoundStateInd").html('<img SRC="gfx/null.gif" name="SoundStateInd" border=0>');	// hide volume indicator
	};
};

// swich sound on/off; dont preload here
function SetSound (setting) {
	prefSound = setting;
	PrefSoundSettings();	// show sound on/off indication
	PlaySound("penclick", vlm);	// click sound for slide button
};

// stop all playing sounds except the button click
function StopAllSound () {
	StopSound("barrel", vlm);
	StopSound("bonus", vlm);
	StopSound("fall", vlm);
	StopSound("hit", vlm);
	StopSound("jump", vlm);
	StopSound("nothing", vlm);
	StopSound("over", vlm);
	StopSound("step", vlm);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end sound functions

//screen functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// swich small game / full game view; dont preload here
function PrefBlur () {
	PlaySound("penclick", vlm);	// click sound for slide button
	switchScreen = true;
	prefBlur = !prefBlur;
	SetPrefBlurSettings();	// set environment to blur settings
	PicPreload();	// this function preloads all images according to the blur setting
	switch (game) {
		case 0: case 9: //no game-all pictures;
			MainPicturesShow();	// show all figures
			game = 9; //prevents not reloading pics @ screenswitch because of previous "acl"
			break;
		case 1: case 2: case 3: case 6: //gameA, gameB, game over or high score;
			ShowCurrentView();	//show screen according to current state 
			break;
		case 5: case 8: //set alarm (on/off);
			AlarmShowNum();
			break;
		case 7: //set sound (on/off);
			ShowSndIcns();
			break;
		default:
	};
};

// set environment to blur settings
function SetPrefBlurSettings () {
	var gameTag = document.getElementById('game');
	if ( prefBlur ) {	// move buttons & change pictures for smaller game size
		document.images["Blur"].src = "gfx/buton.png";
		document.images["BackU"].src = "gfx/backublur.png";
		document.images["BackD"].src = "gfx/backdblur.png";
		document.images["TimerBkgnd"].src = "img/timer.png";
		document.images["SoundStateIndBkgnd"].src = "img/vlm_bkgnd.png";
		gameTag.style.backgroundImage = 'url('+img_on+')';
		gameTag.style.height = '1127px';
		$('#DkLogo').removeClass('dk_logo_min');
		$('#NinLogo').removeClass('nin_logo_min');
		$('#info_button').removeClass('nin_logo_min');
		$('#Info').removeClass('dk_info_min');
		$('.multi_bottom').removeClass('multi_bottom_min');
		$('.multi_edge').removeClass('multi_edge_min');
		$('.multi_top').removeClass('multi_top_min');
		$('.t_multi_bottom').removeClass('t_multi_bottom_min');
		$('#Info').addClass('hidden');
		$('#Banner').removeClass('hidden');
	} else {	// move buttons & change pictures for full presentation
		document.images["Blur"].src = "gfx/butoff.png";
		document.images["BackU"].src = "gfx/backu.gif";
		document.images["BackD"].src = "gfx/backd.gif";
		document.images["TimerBkgnd"].src = nullPre.src;
		document.images["SoundStateIndBkgnd"].src = nullPre.src;
		gameTag.style.backgroundImage = 'url('+img_off+')';
		gameTag.style.height = '720px';
		$('#DkLogo').addClass('dk_logo_min');
		$('#NinLogo').addClass('nin_logo_min');
		$('#info_button').addClass('nin_logo_min');
		$('#Info').addClass('dk_info_min');
		$('.multi_top').addClass('multi_top_min');
		$('.multi_edge').addClass('multi_edge_min');
		$('.multi_bottom').addClass('multi_bottom_min');
		$('.t_multi_bottom').addClass('t_multi_bottom_min');
		$('#Banner').addClass('hidden');
		$('#Info').removeClass('hidden');
	};
};

// set game according to button saved settings 
function PrefsLoad () {
	var tmp;
	tmp = GetCookie("sound");
	if (tmp==null || tmp==1) {
		prefSound = true;
		SetCookie("sound","1", expiry);
	} else {
		prefSound = false;
		SetCookie("sound","0", expiry);
	};
	tmp = GetCookie("blur");
	if (tmp==null || tmp==1) {
		prefBlur = true;
		SetCookie("blur","1", expiry);
	} else {
		prefBlur = false;
		SetCookie("blur","0", expiry);
	};
	for (var i=1 ; i<10 ; i++) {
		tmp = GetCookie("hi"+eval(i));
		if (tmp==null) hi[i] = "...00000"
		else hi[i] = tmp;
	};
	tmp = GetCookie("alarmH");
	if (tmp==null) {
		prefAlarmHour = 0;	// no saved alarm setting hours
		prefAlarmSet = false;
	} else {
		prefAlarmHour = parseInt(tmp);	// last saved alarm cookie hours
		prefAlarmSet = true;
	};
	tmp = GetCookie("alarmM");
	if (tmp==null) prefAlarmMin = 0	// no saved alarm setting minutes
	else prefAlarmMin = parseInt(tmp);	// last saved alarm cookie minutes
};

// save game settings
function PrefsSave () {
	today = new Date();	// get system date
	// set cookie expiration to 28 days
	expiry = new Date(today.getTime() + 28 * 24 * 60 * 60 * 1000);
	if (prefSound) SetCookie("sound","1", expiry)
	else SetCookie("sound","0", expiry);
	if (prefBlur) SetCookie("blur","1", expiry)
	else SetCookie("blur","0", expiry);
	for (i=1 ; i<10 ; i++) SetCookie("hi"+eval(i), hi[i], expiry);
	SetCookie("alarmH", prefAlarmHour, expiry);	// save alarm cookie hours
	SetCookie("alarmM", prefAlarmMin, expiry);	// save alarm cookie minutes
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end screen functions

//set/reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// random barrels reset for begin game 2 for game A 4 for game B
function BarrelsReset () {
	BarrelsClearAll();	// remove all barrels
	if (demo) for (var i=0 ; i<barrelsRandom ; i++) barrels[Math.floor(15*Math.random()+4)] = 1	// for demo, set barrels ramdomly @ begin
	else {
		if (game==1) {
			// set begin barrels game A
			barrels[6] = 1;
			barrels[9] = 1;
			barrels[23] = 1;
		} else 	if (game==2) {
			// set begin barrels game B
			barrels[6] = 1;
			barrels[9] = 1;
			barrels[13] = 1;
			barrels[23] = 1;
		};
	};
};

// remove all barrels
function BarrelsClearAll () {
	for (var i=1 ; i<=28 ; i++) barrels[i] = 0;
};

// barrels remove last row (after successfull removing bridge holder) for begin next run
function BarrelsClearLastRow () {
	for (var i=1 ; i<=3 ; i++) {
		barrels[i] = 0;
		PicShow("Bar"+eval(i)+"", nullPre.src);
	};
};

// remove all segments
function SegmentsReset () {
	for (var i=1 ; i<=5 ; i++) segments[i] = 0;
};

// reset speed according to the current score
function speedReset () {
	gameSpeed = gameSpeedMinimum - Math.round(score%1000/5) - Math.floor(score/50) - Math.floor(score/1000);
	if (gameSpeed<gameSpeedMaximum) gameSpeed = gameSpeedMaximum;
	marioSpeedJump = gameSpeed * 11/6;
};

// check & show highest score on screen
function HighScoreShow (game) {
	pause = true;
	highScore[game] = ((highScore[game]>score)?highScore[game]:score);  // if game interrupted & score was highest
	ScoreShow(highScore[game]); // translate highest score of current game to the digits on screen
};

// translate score to the digits on screen
function ScoreShow (score) {
	if (score>999) {
		if (Math.floor((score/1000)%10)==0) PicShow("Num1", nullPre.src)
		else PicShow("Num1", numPre[Math.floor((score/1000)%10)+1].src);
	} else PicShow("Num1", nullPre.src);
	if (score>99) {
		if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0) PicShow("Num2", nullPre.src)
		else PicShow("Num2", numPre[Math.floor(score%1000/100)+1].src);
	} else PicShow("Num2", nullPre.src);
	if (score>9) {
		if (score>9999 && Math.floor((score/1000)%10)==0 && Math.floor(score%1000/100)==0  && Math.floor(score%100/10)==0) PicShow("Num3", nullPre.src)
		else PicShow("Num3", numPre[Math.floor(score%100/10)+1].src);
	} else PicShow("Num3", nullPre.src);
	PicShow("Num4", numPre[(score%10)+1].src);
};

// let timer start counting
function TimerGo () {
	TimerShow();
	timer++
	timerID = setTimeout("TimerGo()", 1000);	// start next second
};

// translate timer to the digits on screen
function TimerShow () {
	if (timer>35999) PicShow("Timer1", numPre[Math.floor((timer/36000)%10)+1].src)
	else PicShow("Timer1", numPre[1].src);
	if (timer>3599) PicShow("Timer2", numPre[Math.floor((timer/3600)%10)+1].src)
	else PicShow("Timer2", numPre[1].src);
	PicShow("T-Colon1", nullPre.src);
	colonID = setTimeout("PicShow('T-Colon1', colonPre.src)", 500);	// set back colon next half second
	if (timer>599) PicShow("Timer3", numPre[Math.floor((timer%3600)/600)+1].src)
	else PicShow("Timer3", numPre[1].src);
	if (timer>59) PicShow("Timer4", numPre[Math.floor((timer/60)%10)+1].src)
	else PicShow("Timer4", numPre[1].src);
	PicShow("T-Colon2", nullPre.src);
	colonID = setTimeout("PicShow('T-Colon2', colonPre.src)", 500);	// set back colon next half second
	if (timer>9) PicShow("Timer5", numPre[Math.floor((timer%60)/10)+1].src)
	else PicShow("Timer5", numPre[1].src);
	PicShow("Timer6", numPre[(timer%10)+1].src);
};

function ScoreHide () {
	$("#Num1").addClass("hidden");
	$("#Num2").addClass("hidden");
	$("#Num3").addClass("hidden");
	$("#Num4").addClass("hidden");
};

function ScoreUnHide () {
	$("#Num1").removeClass("hidden");
	$("#Num2").removeClass("hidden");
	$("#Num3").removeClass("hidden");
	$("#Num4").removeClass("hidden");
};

function TimerHider () {
	if ($(".t_multi_bottom").is(".hidden")) $(".t_multi_bottom").removeClass("hidden")
	else $(".t_multi_bottom").addClass("hidden")
};

function InfoHider () {
	if ($("#ProgressInfo").is( ".hidden")) $("#ProgressInfo").removeClass("hidden");
	else $("#ProgressInfo").addClass("hidden")
};

function BonusHide (life) {
	PicShow("Life"+life, nullPre.src);
};

function BonusUnHide (life) {
	PicShow("Life"+life, lifePre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end reset functions

// show different pieces of the game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show which game is running
function GameShow () {
	if (!demo) {
		if (game==1) PicShow("Game1", gamePre[1].src)
		else if (game==2) PicShow("Game2", gamePre[2].src);
	};
};

// show how many lives are left
function LivesShow () {
	for (i=1 ; i<(life<5?life:4) ; i++) PicShow("Life"+eval(i)+"", lifePre.src);
};

// show bridge holder
function HoldersShow () {
	if (mario!=42 ) for (i=1 ; i<=hold ; i++) PicShow("Hol"+eval(i)+"", holPre[i].src)
	else for (i=1 ; i<hold ; i++) PicShow("Hol"+eval(i)+"", holPre[i].src);
};

// show bridge segments
function BridgeShow () {
	if (mario>50 && mario<53) for (i=1 ; i<4 ; i++) PicShow("BridgeDown"+eval(i)+"", bridgedownPre[i].src)
	else if (kong<4) for (i=1 ; i<4 ; i++) PicShow("BridgeUp"+eval(i)+"", bridgeupPre[i].src);
};

// show hook accordingly to current status
function HookShow () {
	if (hook>24) hookTest = 0	// hook just finished sequence
	else hookTest = hook;	// hook in certain position
	PicShow("Lever", leveroffPre.src);	leverOn = false;
	switch (hookTest) {
		case 0:
			if (mario<15 || mario>101)	PicShow("Hook3", hookPre[3].src)	// hook @ rest in bottom position
			else {
				if (mario<42 || mario>100) {	// Mario jumping or swinging @ hook
					PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
					if (mario==39 || mario==40) PicShow("Hook4", hookPre[4].src)	// Mario jumped @ hook in time
					else PicShow("Hook6", hookPre[6].src);	// hook in lowest position
				} else PicShow("Hook1", hookPre[1].src);	// crane arm & hooh in top position
			}
			break;
		case 1: case 2: case 3: case 4: case 5: case 20: case 21: case 23:
			PicShow("Hook3", hookPre[3].src);	// hook @ rest in bottom position
			break;
		case 6:
			leverOn = true;
			PicShow("Lever", leveronPre.src);	
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook4", hookPre[4].src);	// hook in most left position
			break;
		case 7: case 17: case 22:
			if (mario<25) {
				leverOn = true;
				PicShow("Lever", leveronPre.src);
				PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
				PicShow("Hook4", hookPre[4].src);	// hook in most left position
			}
			break;
		case 8: case 15: case 18:
			leverOn = true;
			PicShow("Lever", leveronPre.src);
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook5", hookPre[5].src);	// hook in second position from the left
			break;
		case 9: case 14: case 19:
			leverOn = true;
			PicShow("Lever", leveronPre.src);
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook6", hookPre[6].src);	// hook in lowest position
			break;
		case 10: case 13:
			leverOn = true;
			PicShow("Lever", leveronPre.src);
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook7", hookPre[7].src);	// hook in fourth position from the left
			break;
		case 11: case 12:
			leverOn = true;
			PicShow("Lever", leveronPre.src);
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook8", hookPre[8].src);	// hook in most right position
			break;
		case 16:
			leverOn = true;
			PicShow("Lever", leveronPre.src);
			PicShow("Hook2", hookPre[2].src);	// crane arm in middle position
			PicShow("Hook4", hookPre[4].src);	// hook in most left position
			break;
		default:
	};
};

// show Kong @ present position
function KongShow () {
	if (kong==4) {	
		PicShow("Kong4", kongwalkPre[4].src);	// Kong falling
		kongThrow = false;
	} else {
		if (kongThrow) PicShow("Kong"+eval(kong)+"", kongThrowPre[kong].src)	// Kong holding barrel @ position
		else PicShow("Kong"+eval(kong)+"", kongwalkPre[kong].src);	// Kong walking @ position
	};
};

// show how many lives mario has left unanimated
function LifeShow () {
	if (life>1)	PicShow("Life1", lifePre.src)
	else PicShow("Life1", nullPre.src);
	if (life>2)	PicShow("Life2", lifePre.src)
	else PicShow("Life2", nullPre.src);
	if (life>3)	PicShow("Life3", lifePre.src)
	else PicShow("Life3", nullPre.src);
};

// show animated how many lives mario has left
function LifeShowAnimated () {
	if (life>2) LifeShowReduced (7)	// show how many lives mario has left animated
	else	if (life==2) LifeShowReduced (2)	// show how many lives mario has left animated
			else LifeShowReduced (0);	// show how many lives mario has left	
};

// show animation progress how many lives mario has left in 'allLifes' steps
function LifeShowReduced (allLifes) {
	var lifes1, lifes2, lifes3;
	if (allLifes>0 && allLifes!=2 && allLifes!=7) {
		PicShow("Life1", lifePre.src);
		lifes1 = 1;
	} else {
		PicShow("Life1", nullPre.src);
		lifes1 = 0;
	};
	if (allLifes>0 && allLifes!=1 && allLifes!=6) {
		PicShow("Life2", lifePre.src);
		lifes2 = 1;
	} else {
		PicShow("Life2", nullPre.src);
		lifes2 = 0;
	};
	if (allLifes>5) {
		PicShow("Life3", lifePre.src);
		lifes3 = 1;
	} else {
		PicShow("Life3", nullPre.src);
		lifes3 = 0;
	};
	if (allLifes>0 && allLifes!=1 && allLifes!=4) {
		allLifes--;
		allLifesID = setTimeout("LifeShowReduced("+allLifes+")", 500);	// start next LifeShow after half a second
	} else {
		if (life>3) {
			PicShow("Life3", lifePre.src);
			lifes3 = 1;
		};
	};
};

// set game to start situation
function MainPicturesGame () {
	PicShow("Hook3", hookPre[3].src);	// bottom crane arm & hook
	PicShow("Lever", leveroffPre.src);	leverOn = false;	// lever in off position
	for (i=1 ; i<4 ; i++) PicShow("BridgeUp"+eval(i)+"", bridgeupPre[i].src);	// show bridge
	for (i=1 ; i<=hold ; i++) PicShow("Hol"+eval(i)+"", holPre[i].src);	// show bridge holders
	PicShow("Kong2", kongwalkPre[2].src);	// Kong in the middle
	BarrelsShow();	// show starting barrels
	if (!demo) {
		for (i=1 ; i<=(life<4?life:3) ; i++) PicShow("Life"+eval(i)+"", lifePre.src);	// show all lives
		// show chose game
		if (game==1) PicShow("Game1", gamePre[1].src)
		else if ( game==2 ) PicShow("Game2", gamePre[2].src);
	};
};

// show all figures
function MainPicturesShow () {
	SetPrefBlurSettings();	// set to normal view
	PrefSoundSettings();
	for (i=1 ; i<9 ; i++) PicShow("Hook"+eval(i)+"", hookPre[i].src);
	PicShow("Lever", leverallPre.src);
	for (i=1 ; i<22 ; i++) PicShow("Mario"+eval(i)+"", marioPre[i].src);
	PicShow("MarJump1", marjumpPre[1].src);
	PicShow("MarJump4", marjumpPre[4].src);
	PicShow("MarJump7", marjumpPre[7].src);
	PicShow("MarJump8", marjumpPre[8].src);
	PicShow("Mario13", marleverallPre.src);
	for (i=1 ; i<4 ; i++) PicShow("BridgeUp"+eval(i)+"", bridgeupPre[i].src);
	for (i=1 ; i<4 ; i++) PicShow("BridgeDown"+eval(i)+"", bridgedownPre[i].src);
	for (i=1 ; i<4 ; i++) PicShow("Kong"+eval(i)+"", kongallPre[i].src);
	PicShow("Kong4", kongwalkPre[4].src);
	for (i=1 ; i<4 ; i++) PicShow("Life"+eval(i)+"", lifePre.src);
	for (i=1 ; i<5 ; i++) PicShow("Hol"+eval(i)+"", holPre[i].src);
	for (i=1 ; i<6 ; i++) PicShow("Seg"+eval(i)+"", segPre[i].src);
	for (i=1 ; i<29 ; i++) PicShow("Bar"+eval(i)+"", barPre[i].src);
	PicShow("Colon", colonPre.src);
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", numPre[9].src);
	PicShow("DayAM", dayamPre.src);
	PicShow("DayPM", daypmPre.src);
	PicShow("Game1", gamePre[1].src);
	PicShow("Game2", gamePre[2].src);
	for (i=1 ; i<3 ; i++) PicShow("Love"+eval(i)+"", lovePre[i].src);
	for (i=1 ; i<3 ; i++) PicShow("Donkey"+eval(i)+"", donkeyPre[i].src);
	ShowSndIcns();
};

// Mario @ current position on building
function MarioShow () {
	if (mario<1) mario = 1;
	if ((mario==1 || mario==4 || mario==7 || mario==8) && marioJump) PicShow("MarJump"+eval(mario)+"", marjumpPre[mario].src)
	else	if (mario<16) PicShow("Mario"+eval(mario)+"", marioPre[mario].src)
			else	if (mario==35) PicShow("Mario"+eval(20)+"", marioPre[20].src)
					else MarioHookShow();
};

// Mario swinging on the hook
function MarioHookShow () {
	switch (mario) {
		case 24: case 39: case 40:
			PicShow("Mario16", marioPre[16].src);	// Mario jumping @ hook
			break;
		case 41:
			PicShow("Mario17", marioPre[17].src);	// Mario hanging on hokk in bottom position
			break;
		case 42: case 43: case 44: case 45: case 46: case 47: 
		case 48: case 49: case 50: case 51: case 52: case 96: 
		case 97: case 98: case 99:
			PicShow("Mario18", marioPre[18].src);	// Mario at the top picking off a bridge holder
			break;
		case 53: case 54: case 55: case 56: case 57: case 100:
			PicShow("Mario18", marioPre[18].src);	// Mario at the top picking off a bridge holder
			break;
		case 101:
			PicShow("Mario17", marioPre[17].src);	// Mario decending after picking off a bridge holder
			break;
		case 102:
			PicShow("Mario19", marioPre[19].src);	// Mario landing after decending
			break;
		default:
	};
};

//show screen according to current state
function ShowCurrentView () {
	MainPicturesClear();	// hide all figures
	PicPreload();	// this function preloads all images according to the blur setting
	ShowSndIcns();
	BarrelsShow();
	BridgeShow();
	GameShow();
	LivesShow();
	HoldersShow();
	SegmentsShow();
	BridgeShow();
	HookShow();
	KongShow();
	MarioShow();
	TimerShow();
	if (demo) timeID = setTimeout("TimeShow()", 1000)
	else ScoreShow(score);
};

// show/hide icons for sound & alarm as set
function ShowSndIcns () {
	if (!alarmOn && game!=0 && game!=9) PicShow("Bell", nullPre.src)
	else PicShow("Bell", bellPre.src);
	if (prefSound) PicShow("SoundState", soundOnPre.src)
	else PicShow("SoundState", soundOffPre.src);	
};

// hide all figures
function MainPicturesClear () {
	for (i=1 ; i<9 ; i++) PicShow("Hook"+eval(i)+"", nullPre.src);
	PicShow("Lever", nullPre.src);
	for (i=1 ; i<22 ; i++) PicShow("Mario"+eval(i)+"", nullPre.src);
	PicShow("MarJump1", nullPre.src);
	PicShow("MarJump4", nullPre.src);
	PicShow("MarJump7", nullPre.src);
	PicShow("MarJump8", nullPre.src);
	for (i=1 ; i<4 ; i++) PicShow("BridgeUp"+eval(i)+"", nullPre.src);
	for (i=1 ; i<4 ; i++) PicShow("BridgeDown"+eval(i)+"", nullPre.src);
	for (i=1 ; i<5 ; i++) PicShow("Kong"+eval(i)+"", nullPre.src);
	for (i=1 ; i<4 ; i++) PicShow("Life"+eval(i)+"", nullPre.src);
	for (i=1 ; i<5 ; i++) PicShow("Hol"+eval(i)+"", nullPre.src);
	for (i=1 ; i<6 ; i++) PicShow("Seg"+eval(i)+"", nullPre.src);
	for (i=1 ; i<29 ; i++) PicShow("Bar"+eval(i)+"", nullPre.src);
	PicShow("Colon", nullPre.src);
	for (i=1 ; i<5 ; i++) PicShow("Num"+eval(i)+"", nullPre.src);
	PicShow("DayAM", nullPre.src);
	PicShow("DayPM", nullPre.src);
	PicShow("Game1", nullPre.src);
	PicShow("Game2", nullPre.src);
	for (i=1 ; i<3 ; i++) PicShow("Donkey"+eval(i)+"", nullPre.src);
	for (i=1 ; i<3 ; i++) PicShow("Love"+eval(i)+"", nullPre.src);
	if (!alarmOn) PicShow("Bell", nullPre.src);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end show different pieces of the game functions

// time/alarm functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// show current time
function TimeShow () {
	Time();	// get current time if 
	if (!$('#ButTime:active').length) {	// if time button no longer pressed (else show alarm time)
		TimeShowOnScreen(min, hour);	// show the current time
	};
	timeID = setTimeout("TimeShow()", 1000);
};

// show required time and indicators on screen
function TimeShowOnScreen(min, hour) {
	if (hour>=12 && min>=1 || hour>=13) { // show PM
		hour-= 12;
		PicShow("DayAM", nullPre.src);
		PicShow("DayPM", daypmPre.src);
	} else { // show AM
		PicShow("DayAM", dayamPre.src);
		PicShow("DayPM", nullPre.src);
	};
	if (hour==0) hour = 12;
	// set integer to time digits
	if (hour<10) PicShow("Num1", nullPre.src)
	else PicShow("Num1", numPre[Math.floor(hour/10)+1].src);
	PicShow("Num2", numPre[(hour%10)+1].src);
	PicShow("Num3", numPre[Math.floor(min/10)+1].src);
	PicShow("Num4", numPre[(min%10)+1].src);
	PicShow("Colon", colonPre.src);
};

// get current time
function Time () {
	today = new Date();
	hour = today.getHours();
	min = today.getMinutes();
	sec = today.getSeconds();
};

// show alarm time & on/off indication
function AlarmShow (ind) {
	AlarmShowNum();	// show alarm time
	if (ind=="on") {
		TimeAlarmBackground();//added
		alarmOn = true;
		PicShow("Bell", bellPre.src);
	} else {
		alarmOn = false;
		PicShow("Bell", nullPre.src);
	};
};

// show alarm time
function AlarmShowNum () {
	TimeShowOnScreen(prefAlarmMin, prefAlarmHour);
	ShowSndIcns();
};

// check if its time for alarm
function TimeAlarm () {
	codeCurrentAlarm = 0;
	Time();	// get current time
	var alarmTime;
	if (hour==prefAlarmHour && min==(prefAlarmMin-1) && !alarm && alarmOn) { 
		alarm = true;
		// set start alarm at start next minute
		alarmTime = 60000-(sec*1000);
		// alarm rings at start next minute
		alarmID = setTimeout("TimeAlarmGo()", alarmTime);
		// stop alarm 30 seconds after start
		alarmOffID = setTimeout("TimeAlarmOff()", (alarmTime + 30000));
	};
};

// alarm rings
function TimeAlarmGo () {
	Time();	// get current time
	if ((sec%2)==1) {	// let Jr. jump up and down @ alarm
		PicShow("Donkey1", nullPre.src);
		PicShow("Donkey2", donkeyPre[2].src);
		if (codeCurrentAlarm==0) PlaySoundEvenIfDemo("over", vlm);	// sound for game over or alarm if no key pressed
	} else {
		PicShow("Donkey1", donkeyPre[1].src);
		PicShow("Donkey2", nullPre.src);
	}
	alarmID = setTimeout("TimeAlarmGo()", 1000);
};

// turn running alarm off
function TimeAlarmOff () {
	if (alarmID) {	 // if alarm was planned or running, stop sequence
		clearTimeout(alarmID);
		alarmID = null;
	};
	alarm = false;
	if (game==0) {	// if acl
		PicShow("Donkey1", donkeyPre[1].src);
		PicShow("Donkey2", donkeyPre[2].src);
	} else {
		PicShow("Donkey1", nullPre.src);
		PicShow("Donkey2", nullPre.src);
	};
};

// function runs all the time and checks the alarm on the background
function TimeAlarmBackground () {
	if (alarmOn) {		
		TimeAlarm();	// check if its time for alarm if alarmOn
		setTimeout("TimeAlarmBackground()", 30000)	;
	};
};

// 0-no game-all pictures; 1-gameA; 2-gameB; 3-game over; 4-clock; 5-set alarm (on); 6-high score; 7-keys; 8-set alarm (off);
// set the alarm
function MainAlarm () {
	if (demoID) {	 // if demo was planned or running, stop sequence
		clearTimeout(demoID);
		demoID = null;
	};
	if (!alarmSetting) {
		Reset();
		alarmSetting = true;
		keys = 7;	// no remapping keys
		demo = false;		// once the alarm key is hit, the demo is turned off
		marioPause = false;
		PlaySound("click", vlm);	// click sound for push button
		if (game==6) HighScoreSort(name, score); // sort name in high score if entered
		if (game==7) KeysRemapExit();	// stop remapping keys // enter
		InfoTextClear();	// empty info banner
		InfoTextAlarm();	// add alarm setting instructions to info banner
		InfoTextRoll();	// add ending spaces to info banner
		GameStop();	// stop game if playing
		MainPicturesClear();	// hide all figures
	};
	if (game!=5) {
		game = 5; // set alarm (on)
		AlarmShow("on");	// show alarm time & on indication
	} else {
		game = 8; // set alarm (off)
		AlarmShow("off");	// show alarm time & off indication
	};	
	demoID = setTimeout("MainTime()", 300000);	// start demo after 5 minutes
};


// "time" is pressed, stop all and show time
function MainTime () {  
	if (alarm) TimeAlarmOff();	// stop alarm if running
	if (demoID) {	 // if demo was planned or running, stop sequence
		clearTimeout(demoID);
		demoID = null;
	};
	alarmSetting = false;
	keys = 7;	// no remapping keys
	if (game!=4 && !demo) {
		PlaySound("click", vlm);	// click sound for push button
		StopAllSound();
		if (game==6) HighScoreSort(name, score); // sort name in high score if entered
		if (game==7) KeysRemapExit();	// stop remapping keys // enter
		Reset();	// reset all on going to default and show all figures
		InfoTextTime();		// add alarm status to info banner
		game = 4; // setting clock
		MainTimeStart(); // actual MainTime
	};
};
	
// actual part to stop all and show time
function MainTimeStart () {
	if (leverOn) gamerInterrupt = true	// if hook is still active, deactivate
	else gamerInterrupt = false;
	if (game>2 || game==0) {
		if (game==6) HighScoreSort(name, score); // sort name in high score if entered
		if (game==7) KeysRemapExit();	// stop remapping keys
		demo = true;
		TimeShow();	// show current time
		if (game==5 || game==7) NewInfo();	// run primal info banner
		GameA();
		MainGameAGo();
	};
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end time/alarm functions

// reset functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// reset all on going to default and show all figures
function Reset () {
	if (game!=0) {
		gameCode = null;
		if (game==6) HighScoreSort(name, score); // sort name in high score if entered
		if (game==7) KeysRemapExit();	// stop remapping keys
		GameStop();	// stop game if playing
		BarrelsReset();	// random barrels reset for begin game 2 for game A 4 for game B
		SegmentsReset();	// remove all segments
		if (!demo) InfoTextClear();	// empty info banner
		MainPicturesShow();	// show all figures
	};
};

// "ACL" is pressed to clear any game and reset all on going to default and show all figures
function TotalReset () {
	if (demoID) {	 // if demo was planned or running, stop sequence
		clearTimeout(demoID);
		demoID = null;
	};
	if (game!=9) {
		Reset();
		clearTimeout(hookID);	// stop hook if moving
		hookID = null;
		hook = 0; 
		gamerInterrupt = false;
		alarmSetting = false;
		keys = 7;	// no remapping keys
		PlaySound("click", vlm);	// click sound for push button
		if (game!=9 && game!=0) {
			demo = false;		// once this key is hit, the demo is turned off
			MainLoaded();
			life = 0;	
			game = 0; // no game-all pictures
		};
	};
	demoID = setTimeout("MainTime()", 120000);	// start demo after 2 minutes
};

// set Kong & holders to begin settings after Kong fell down
function KongReset () {	
	for (i=1 ; i<5 ; i++) PicShow("Kong"+eval(i)+"", nullPre.src);	// hide all Kong figures
	kongThrow = false;
	kong = Math.floor(Math.random() * 3) + 1;	// random new Kong position
	KongShow();	// show Kong @ new position
	hold = 4;	//	all holders present
	HoldersShow();	// show current left holders
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end reset functions

// key set functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// "keys" button pressed to remap keys
function MainKeys () {
	if (demoID) {	 // if demo was planned or running, stop sequence
		clearTimeout(demoID);
		demoID = null;
	};
	if (!keys || keys>6) {
		if (game==6) HighScoreSort(name, score); // sort name in high score if entered
		if (game==7) KeysRemapExit();	// stop remapping keys // enter
		if ((game==1 || game==2) && !demo) return	   // no remapping during gameplay
		else {
			alarmSetting = false;
			demo = false;
			GameStop();	// stop game if playing
			MainPicturesClear();	// hide all figures
			clearTimeout(infoID);	// stop info banner
			infoID = null;
			InfoTextClear();	// empty info banner
			infoMsg = '';
			document.Info.text.value = infoMsg;	// show infoMsg on screen for info purposes
			$("#Banner").html(infoMsg);
			codeCurrent = 0;	// empty input to start recording keys
			game = 7;	// no remapping keys
			keys = 0;	// no key pushed
			PlaySound("click", vlm);	// click sound for push button
			KeysRemap();	// let the user choose new controlling keys
		};
	};
};

// let the user choose new controlling keys
function KeysRemap () {
	var tmpCode = codeCurrent;	// last pressed e.keyCode from window.addEventListener
	var tmpCodeChar = codeCurrentChar	// last pressed e.key from window.addEventListener
	keysRemapRep++;	// once the name input has started demo count down starts
	if (tmpCode!=0) {	// if key pressed
		if (tmpCode==27) // "escape" key pressed
			KeysRemapExit();	// stop remapping keys 
		else {
			document.Info.text.value = infoMsgBlur;	// show infoMsg on screen for info purposes
			$("#Banner").html(infoMsg);
			switch (keys) {	// new input to key number
				case 0 :
					codeUp = tmpCode; 
					codeUpChar = tmpCodeChar;
					keys++;	// next key
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 1 :
					if (tmpCode!=codeUp) {	  // if no previous used key hit
						codeDown = tmpCode; 
						codeDownChar = tmpCodeChar;
						keys++;	// next key
					};
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 2 :
					if (tmpCode!=codeUp && tmpCode!=codeDown) {	  // if no previous used key hit
						codeLeft = tmpCode; 
						codeLeftChar = tmpCodeChar;
						keys++;	// next key
					};
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 3 :
					if (tmpCode!=codeUp && tmpCode!=codeDown && tmpCode!=codeLeft) {	  // if no previous used key hit
						codeRight = tmpCode; 
						codeRightChar = tmpCodeChar;
						keys++;	// next key
					};
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 4 :
					if (tmpCode!=codeUp && tmpCode!=codeDown 
						&& tmpCode!=codeLeft && tmpCode!=codeRight) {	  // if no previous used key hit
						codeJump = tmpCode; 
						codeJumpChar = tmpCodeChar;
						keys++;	// next key
					};
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 5 :
					if (tmpCode!=codeUp && tmpCode!=codeDown && tmpCode!=codeLeft
						&& tmpCode!=codeRight && tmpCode!=codeJump) {	  // if no previous used key hit
						codeGameA = tmpCode; 
						codeGameAChar = tmpCodeChar;
						keys++;	// next key
					};
					keysID = setTimeout("KeysRemap()", 200);
					break;
				case 6 :
					if (tmpCode!=codeUp && tmpCode!=codeDown && tmpCode!=codeLeft
						&& tmpCode!=codeRight && tmpCode!=codeJump && tmpCode!=codeGameA) {	  // if no previous used key hit
						codeGameB = tmpCode; 
						codeGameBChar = tmpCodeChar;
						keys++;	// next key
					};
					UpdateInfoText();	// update info box controller information text
					KeysRemapExit();	// stop remapping keys
					break;
				default:	
			};
			// empty last recorded key stroke
			codeCurrent = 0;	// empty input to start recording keys
			codeCurrentChar = "";
		};
	} else {	// no next key pressed yet
		if (keysFlash) {	// ifo text hide for blinking while no next key pressed yet
			keysFlash = false	
			infoMsg = '';
		} else {	// ifo text show for blinking while no next key pressed yet
			keysFlash = true;
			infoMsg+= '&nbsp;'.repeat(3);
			switch (keys) {
				case 0 :
					infoMsg+= 'Press key for UP:';
					break;
				case 1 :
					infoMsg+= 'Press key for DOWN:';
					break;
				case 2 :
					infoMsg+= 'Press key for LEFT:';
					break;
				case 3 :
					infoMsg+= 'Press key for RIGHT:';
					break;
				case 4 :
					infoMsg+= 'Press key for JUMP:';
					break;
				case 5 :
					infoMsg+= 'Press key for START GAME A:';
					break;
				case 6:
					infoMsg+= 'Press key for START GAME B:';	
					break;
				default:
			};
		};
		infoMsgBlur = '&nbsp;'.repeat(42);
		infoMsgBlur = infoMsgBlur.replace(/&nbsp;/g, " ");
		infoMsgBlur+= infoMsg.replace(/&nbsp;/g, " ");
		$("#Banner").html(infoMsg);
		document.Info.text.value = infoMsgBlur;	// show infoMsg on screen for info purposes
		UpdateInfoText();	// update info box controller information text
		keysID = setTimeout("KeysRemap()", 200);
	};
	if (keysRemapRep==1) {	// once the name input has started demo count down starts
		if (demoID) {	 // if demo was running, stop next sequence
			clearTimeout(demoID);
			demoID = null;
		};
		demoID = setTimeout("MainTime()", 300000);	// start demo after 5 minutes
	};
};

// reset after keys are remapped
function KeysRemapExit () {
	if (keysID) {	 // if key mapping was running, stop next sequence
		clearTimeout(keysID);
		keysID = null;
	};
	if (demoID) {	 // if demo was running, stop next sequence
		clearTimeout(demoID);
		demoID = null;
	};
	keysRemapRep = 0;	// once the name input has started demo count down starts
	if(!demo) {
		InfoTextClear();	// empty info banner
		InfoTextKeys();		// add controlling keys to info banner
		InfoTextRoll();	// add ending spaces to info banner
		Info();	// run info banner
	};
	MainPicturesClear();	// hide all figures because key-up triggered game A
//	game = 3; // game over
	demoID = setTimeout("MainTime()", 120000);	// start demo after 2 minutes
};

// perform backspace and remove last inputted character
function RemoveLastChar (str) {
	return str.slice(0, -1);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end key set functions

//game functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// hide last mario; run all; set up mario to go again
function AllInit () {
	mario = 0;
	runTime = 0;
	UnPauseAll();
	marioTimeID = setTimeout("LetMarioJump()", marioTime);
};

// barrels check collision - when barrels would move
function BarrelsCollision () {
	BarrelsCollisionFront();
	BarrelsCollisionUp();	
};

// barrels check collision - when mario is moving along
function BarrelsCollisionFront () {
	// barrels check if mario has jumped the barrel
	for (i=2 ; i<7 ; i++) if (barrels[i]==1 && mario==(i-1))  BarrelsCollisionKillPoints();	
	// barrels check if mario has jumped the barrel
	for (i=8 ; i<13 ; i++) if (barrels[i]==1 && mario==(i-2))  BarrelsCollisionKillPoints();	
};

// barrels check collision- when mario is going back
function BarrelsCollisionBack () {
	// barrels check if mario has jumped the barrel
	for (i=1 ; i<6 ; i++) if (barrels[i]==1 && mario==i)  BarrelsCollisionKillPoints();	
	// barrels check if mario has jumped the barrel
	for (i=7 ; i<12 ; i++) if (barrels[i]==1 && mario==(i-1))  BarrelsCollisionKillPoints();	
};

// barrels check collision - when mario can get hit from falling barrel
function BarrelsCollisionUp () {
	// barrels check if mario has moved in the path of the barrel
	if (barrels[15]==1 && mario==12) BarrelsCollisionKillPoints();	
	if (barrels[27]==1 && mario==13) BarrelsCollisionKillPoints();	
	if (barrels[24]==1 && mario==14) BarrelsCollisionKillPoints();	
	if (barrels[21]==1 && mario==15) BarrelsCollisionKillPoints();	
};

// barrels check if mario has jumped the barrel
function BarrelsCollisionKillPoints () {
	if (!marioJump)  MarioKill()	// Mario gets killed and blinks at hit place
	else {
		if (!demo) {
			if (mario<7) ScoreAddFastCheck(1)	// add point fast while checking if bonus score is reached
			else ScoreAddFastCheck(2);	// add 2 points fast while checking if bonus score is reached			}
		};
	};
};

// let barrels go; 
function BarrelsGo () {
	if (!barrelsPause) {
		if (!(sequence&1)) {	// actual move every other sequence
			BarrelsCollision();	// barrels check collision - when barrels are moving
			PlaySound("barrel", vlm);	// sound for barrels move
		};
		if (!marioKill) {	// kongThrow game A starts between barrel moves, game B & barrel move
			BarrelsMove();	// barrels move; kong throw barrel init
			BarrelsShow();	// show present barrels
			if (gameSpeed>400) SpeedUp(2)	// let barrels roll faster x 2
			else { 
				if (gameSpeed>300) SpeedUp(1)	// let barrels roll faster x 2
				else {
					if (gameSpeed<250 && sequence%4) SpeedUp(1)	// let barrels roll faster
					else if (sequence%2) SpeedUp(1);	// let barrels roll faster
				};
			};
		};
	};
};

// barrels move; kong throw barrel init
function BarrelsMove () {
	if ((!(sequence&1) && game==2) || (!(sequence&1) && game==1)) {
		for (var i=1 ; i<22 ; i++) barrels[i] = barrels[i+1];	// rolling barrels
		if (barrels[15]==0) barrels[15] = barrels[26];	// falling barrels row 1 landing
		if (barrels[17]==0) barrels[17] = barrels[23];	// falling barrels row 2 landing
		for (var i=23 ; i<25 ; i++) barrels[i] = barrels[i+1];	// falling barrels row 1
		for (var i=26 ; i<28 ; i++) barrels[i] = barrels[i+1];	// falling barrels row 2
		// clear first row
		barrels[22] = 0;
		barrels[25] = 0;
		barrels[28] = 0;
	}; 
	if (((sequence&1) && game==2) || (!(sequence&1) && game==1)) {
		if (kongThrow) {	// if kong is holding a barrel to throw
			// first barrel down game A synchro, game B asynchro
			if (kong==1) barrels[28] = 1;
			if (kong==2) barrels[25] = 1;
			if (kong==3) barrels[22] = 1;
			// kong's arms go down to trhow barrel
			PicShow("Kong"+eval(kong)+"", kongwalkPre[kong].src);
			kongThrow = false;
		};
	};
};

// blink extra gained Mario a few times @ 3rd place
function BonusIndicator () { 
	if (game!=0) {	// if not reset
		PauseAll();
		beeps++;
		BonusHide(3)
		BonusUnHide(3);
		PlaySound("bonus", vlm);
		if (beeps<4) { 	// blink first 3 times
			bonusID = setTimeout('BonusHide(3)', bonusTime/3);
			bonusID = setTimeout('BonusIndicator(life)', bonusTime);
		} else {	// final blink 
			if (mario<42) UnPauseAll()	// move on with game
			else scorePause = false;	// move on with score count
			bonusID = setTimeout('BonusHide(3)', bonusTime);
			setTimeout('BonusUnHide(3)', bonusTime)
		};
	};
};

// show score & check if high score exceeded
function CheckAndShow () {
	CheckScoreHundreds();	// reset speed every 100 points
	segmentsRandom = Math.floor(score/1000)<4?segmentsRandomOrg - Math.floor(score/1000):3;	// increase segment probability every 1000 points
	ScoreShow(score);	// translate score to the digits on screen
	highScore[game] = (((highScore[game]>score))?highScore[game]:score);		// if current score higheer than recorded, record
	CheckScore3Hundreds();
};

// reset speed every 100 points
function CheckScoreHundreds () {
	if (score%100==0) speedReset();
};

// extra life and bonus points if 3 lives left @ 300 points
function CheckScore3Hundreds () {
	if ((score%1000)==300 && (tmpScore%1000)<300) {	// if score just reached 300 (minus the thousends)
		life++;
		if (life>3) {
			pointsBonus = true;
			Scoreblink();
			life = 3;
		};
		beeps = 0;
		scorePause = true;
		BonusIndicator();	// blink extra gained Mario
	};
};

// started when user navigates away from page (clicking link, submitting form, closing browser window, etc.).
function Closed () {
	PrefsSave();	// save game settings
};

//count seconds needed for run from start to removal holder
function CountRunTime () {
	if (!marioPause) {
		runTime++;
		if (runTime>10 && runTime<29 && !(runTime%2)) {
			bonusScore--	// between 10 & 30 sec runtime, loose 1 bonus point every 2 seconds
		} else if (runTime>10 && !((runTime-30)%20) && bonusScore>5) {
			bonusScore--	// after 30 sec runtime, loose 1 bonus point every 20 seconds with minimum of 5 bonus points left
		};
	};
	runTimeID = setTimeout("CountRunTime()", 1000);
};

// check if 4 barrels already on row @ previous throw
function FourOnRow () {
	switch (kong) {
		case 1:	// possible fifth barrel if Kong @ lever
			if (   (barrels[15] && (barrels[16]||barrels[26]) && (barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]))
					|| ((barrels[16]||barrels[26]) && (barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]) && (barrels[20]||barrels[25])) 
					|| ( (barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]) && (barrels[20]||barrels[25]) && barrels[21] ) 
					|| ( (barrels[18]||barrels[23]||barrels[28]) && (barrels[20]||barrels[25]) && barrels[21] && barrels[22] ) 
				) fourOnRow = true;
			break;
		case 2:	//possible fifth barrel if Kong in middle
			if (   ((barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]) && (barrels[19]||barrels[24]) && (barrels[20]||barrels[25]))
					|| ( (barrels[18]||barrels[23]||barrels[28]) && (barrels[19]||barrels[24]) && (barrels[20]||barrels[25]) && barrels[22]) 
				) fourOnRow = true;
			break;
		case 3:	//possible fifth barrel if Kong @ hook
			if ((barrels[19]||barrels[24]) && (barrels[20]||barrels[25]) && barrels[21] && barrels[22]) fourOnRow = true;
			break;
		default :
	};
	return fourOnRow;
};

// play game A
function GameA () {
	if (game==6 && !demo) HighScoreSort(name, score); // sort name in high score if entered
	if (game==7 && !demo) KeysRemapExit();	// stop remapping keys // enter
	alarmSetting = false;
	keys = 7;	// no remapping keys
	barrelsRandom = 2; // random at init
	game = 1; // gameA
	Reset();	// reset all on going to default and show all figures
	// variables reset
	kong = 2;
	kongThrow = false;
	bonus = 0;
	hold = 4;	//	all holders present
	score = 0;
	runTime = 0;
	marioKill = false; // mario not yet killed
	marioJump = false;
	hook = 0;
	marioSpeedKill = 260;
	marioTime = 10000; // time to go mario
	// init all functions
	MainPicturesClear();	// hide all figures
	if (demo) {
		kongRandomOrg = 11;
		kongRandom = kongRandomOrg;
		life = 0;
		gameSpeedMinimum = 500;	// minimum speed for game sequence
		gameSpeed = gameSpeedMinimum;	// speed for game sequence
		hookSpeed = gameSpeed;
		hookSpeedMario = gameSpeed*3/2;
		marioSpeedJump = gameSpeed*11/6;
		marioSpeedFall = gameSpeed;
		TimeShow();
	} else { 
		kongRandomOrg = 10	// 0 1 2 3
		kongRandom = kongRandomOrg;
		InfoTextClear();	// empty info banner
		InfoTextIngame();	// add game story to info banner
		InfoTextRoll();	// add ending spaces to info banner
		life = 3;
		gameSpeedMinimum = 550;	// minimum speed for game sequence
		gameSpeed = gameSpeedMinimum;	// speed for game sequence
		hookSpeed = gameSpeed*0.982;
		hookSpeedMario = gameSpeed*1.091;
		marioSpeedFall = gameSpeed;
		marioTimeID = setTimeout("LetMarioJump()", marioTime);
	};
	scoreSpeed = 60;
	loveSpeed = 180;
	MainPicturesGame();	// set game to start situation 
	UnPauseAll();
	bonusScore = 20;	// Initial extra bonus when holder removed, between 10 & 30 sec runtime, loose 1 bonus point every 2 seconds
	mario = -1;	// Mario is waiting below to enter the arena
	CountRunTime();	//count seconds needed for run from start to removal holder
	HighScoreShow(1);	   // show highest score for game a
};

// play game B
function GameB () {
	if (game==6) HighScoreSort(name, score); // sort name in high score if entered
	if (game==7) KeysRemapExit();	// stop remapping keys // enter
	alarmSetting = false;
	keys = 7;	// no remapping keys
	barrelsRandom = 4; // random at init
	segmentsRandomOrg = 6; // random at init
	game = 2; // gameB
	Reset();	// reset all on going to default and show all figures
	InfoTextClear();	// empty info banner
	InfoTextIngame();	// add game story to info banner
	InfoTextRoll();	// add ending spaces to info banner
	// variables reset
	kong = 2;
	kongThrow = false;
	bonus = 0;
	hold = 4;	//	all holders present
	life = 3;
	score = 0;
	runTime = 0;
	marioKill = false; // if mario was killed
	mario = -1;	// Mario is waiting below to enter the arena
	marioJump = false;
	hook = 0;
	marioSpeedKill = 260;
	kongRandomOrg = 11 ; // 0 1 2 3
	kongRandom = kongRandomOrg;
	gameSpeedMinimum = 450;	// minimum speed for game sequence
	gameSpeed = gameSpeedMinimum;	// speed for game sequence
	hookSpeed = gameSpeed*0.982;
	hookSpeedMario = gameSpeed*1.091;
	marioSpeedFall = gameSpeed;
	marioTime = 7000; // time to go mario
	scoreSpeed = 60;
	loveSpeed = 180;
	// init all functions
	MainPicturesClear();	// hide all figures
	MainPicturesGame();	// set game to start situation 
	UnPauseAll();
	bonusScore = 20;
	gamePause = false;	
	marioTimeID = setTimeout("LetMarioJump()", marioTime);
	CountRunTime();	//count seconds needed for run from start to removal holder
	HighScoreShow(2);	   // show highest score for game a
};

// synchronise all moves
function GameGo () {
	if(demoID){	 // if demo was planned or running, stop sequence
		clearTimeout(demoID);	// stop demo from startin
		demoID = null;
	};
	if (timer==0) TimerGo();
	if (!gamePause) GameMove();	// kong move; kong throw
	if (game!=3) gameID=setTimeout("GameGo()", gameSpeed);	// next sequence
};

// synchronise all moves
function GameMove () {
	if (demo) MarioAutoMove();
	KongGo();	// let Kong move & throw barrels
	BarrelsGo();	// barrels go, move show and repeat 
	if (sequence==1) SegmentsGo(); // segments go, move show and repeat
	if (sequence<4) sequence++	// count every 4 sequences
	else sequence = 1;
};

// all Marios are killed in action
function GameOver () {
	PlaySound("over", vlm);	// sound for game over or alarm
	GameStop();	// stop game if playing
	// check if I have a high score
	if (!demo && (score>parseInt(hi[9].match(/\d+/)))) {
		game = 6; // input high score
		HighScoreEdit();	// indicate user to enter name for high scores list
	} else MainGameOver();	// prepare & run info banner after game over
};

// stop game if playing
function GameStop () {
	clearTimeout(timerID);	// stop game timer
	timerID = null;
	clearTimeout(gameID);	// stop game
	gameID = null;
	clearTimeout(hookID);	// stop hook if moving
	hookID = null;
	clearTimeout(colonID);	// stop moving colons
	colonID = null;
	clearTimeout(hookMarioID);	// stop Mario if at hook
	hookMarioID = null;
	clearTimeout(marioTimeID);	// stop Mario if jumping
	marioTimeID = null;
	clearTimeout(marioJumpID);	// stop Mario if jumping down
	marioJumpID = null;
	clearTimeout(marioFallID);	// stop Mario if falling from edge
	marioFallID = null;
	clearTimeout(marioKillID);	// stop Mario kill count
	marioKillID = null;
	clearTimeout(allLifesID);	// stop LifeShow
	allLifesID = null;
	clearTimeout(scoreID);	// stop score count
	scoreID = null;
	clearTimeout(blinkID);	// stop score blinking
	blinkID = null;
	clearTimeout(bonusID);	// stop indicating bonus life
	bonusID = null;
	clearTimeout(nameID);	// stop name entry
	nameID = null;
	clearTimeout(loveID);	// stop loves from princess
	loveID = null;
	clearTimeout(timeID);	// stop time indication
	timeID = null;
	clearTimeout(alarmID);	// stop running alarm sound from repeating
	alarmID = null;
	clearTimeout(alarmOffID);	// stop running alarm sound from repeating
	alarmOffID = null;
	clearTimeout(demoID);	// stop demo from starting after 2 minutes no action
	demoID = null;
	clearTimeout(runTimeID);	// stop runTime
	rinTimeID = null;
	clearTimeout(leverOffID);	// stop turning lever off
	leverOffID = null;
	clearTimeout(keysID);	// stop keys input
	keysID = null;
	TimeAlarmOff();	// turn running alarm off
	hookEndComplete = true;
	timer = 0;
	pointsBonus = false;
};

// indicate user to enter name for high scores list
function HighScoreEdit () {
  if (demoID) {	 // if demo was planned or running, stop sequence
	clearTimeout(demoID);	// stop demo from starting after 2 minutes no action
	demoID = null;
  };
  if (infoID) {	 // if info banner was planned or running, stop sequence
	clearTimeout(infoID);
	infoID = null;
  };
  InfoTextClear();	// empty info banner
  name = '';
  codeCurrent = 0;	// empty input to start recording keys
  HighScoreEditGo();	// let user input next letter of name for high scores list
};

// let user input next letter of name for high scores list
function HighScoreEditGo () {
	var tmpCode=codeCurrent;	// last pressed e.keyCode from window.addEventListener
	if (tmpCode!=0) {
		if (tmpCode==13 || name.length>9) {  // enter or name reached 10 characters
			name+= "..(Game "+gameCode+")";
			HighScoreSort(name, score); // sort name in high score if entered
		} else {
			var codeLetter = tmpCode-64; // now 1 is a
			if (codeLetter>0 && codeLetter<27) name+=chars[codeLetter];
			if (tmpCode==8 || tmpCode==27) name = RemoveLastChar(name);  // @ backspace or esc
			if (tmpCode==32) name+= " ";  // space
			codeCurrent = 0;	// empty input to start recording keys
			infoMsg = '&nbsp;'.repeat(8-(name.length/2));  //40 leading spaces for placement message near center
			infoMsg+= 'Name: '+name;
			infoMsgBlur = '&nbsp;'.repeat(48);
			infoMsgBlur = infoMsgBlur.replace(/&nbsp;/g, " ");
			infoMsgBlur+= infoMsg.replace(/&nbsp;/g, " ");
			document.Info.text.value = infoMsgBlur;	// show infoMsg on screen for info purposes
			$("#Banner").html(infoMsg);
			nameID = setTimeout("HighScoreEditGo()", 200);	// let user input next letter of name for high scores list
		};
	} else {
		if (name.length==0) {	// if no input given
			if (nameFlash) {	// if message not hidden
				nameFlash = false	// to show next cycle
				infoMsg = '';	// hide message to simmulate blinking
			} else {
				nameFlash = true;	// to hide next cycle
				infoMsg = '&nbsp;'.repeat(8);  // 35 leading spaces for placement message in center
				infoMsg+= 'Enter your name:';	// show message to simmulate blinking
			};
			infoMsgBlur = '&nbsp;'.repeat(42);
			infoMsgBlur = infoMsgBlur.replace(/&nbsp;/g, " ");
			infoMsgBlur+= infoMsg.replace(/&nbsp;/g, " ");
			document.Info.text.value = infoMsgBlur;	// show infoMsg on screen for info purposes
			$("#Banner").html(infoMsg);
		};
		nameID = setTimeout("HighScoreEditGo()", 200);	// let user input next letter of name for high scores list
	};
};

// my score -> high score; I assume that I'm at least on last position
function HighScoreSort (hname, hscore) {
	var tmp;
	if (nameID) {	 // if name input was running, stop next sequence
		clearTimeout(nameID);
		nameID = null;
	};
	// add leading zeroes according to score length
	if (hscore<10) var insert = hname+"...0000"+eval(hscore)
	else	if ( hscore<100 ) var insert = hname+"...000"+eval(hscore)
			else	if ( hscore<1000 ) var insert = hname+"...00"+eval(hscore)
					else	if ( hscore<10000 ) var insert = hname+"...0"+eval(hscore)
							else var insert = hname+"..."+eval(hscore);
	hi[9] = insert;
	for (i=9 ; i>1 ; i--)
		if (parseInt(hi[i].match(/\d+/))	// get high score on place i out of string
			>
			parseInt(hi[i-1].match(/\d+/))	// get high score on place befgore i out of string
			) {
				tmp = hi[i];
				hi[i] = hi[i-1];
				hi[i-1] = tmp;
		};
	MainGameOver();	// prepare & run info banner after game over
	if (!demo) {
		if (infoID) {	 // if info banner was running, stop next sequence
			clearTimeout(infoID);
			infoID = null;
		};
		Info();	// run info banner
	};
};

// close up hook movement to rest status
function HookEnd () {
	PicShow("Hook3", hookPre[3].src);
	PicShow("Hook2", nullPre.src);
	PicShow("Hook6", nullPre.src);
	PicShow("Lever", leveroffPre.src);	leverOn = false;
	hookEndComplete = true;
	if (keyLeft) hookID=setTimeout("HookStart()",hookSpeed/2);	// restart hook movement
};

// move hook
function HookGo () {
	if (hook!=0 && !gamerInterrupt) {
		HookMove();	// full hook movement
		hookID=setTimeout("HookGo()", hookSpeed);
	};
};

// full hook movement
function HookMove () {
	hookEndComplete = false;
	if (hook<5) hook = 5;
	hook++;
	if (!(hook&1)) marioHookSpeed =  hookSpeed/4 // not if hook odd
	else marioHookSpeed =  hookSpeed/2;
	switch (hook) {
		case 6: // lever just switched as hook still down
			PicShow("Lever", leveronPre.src);	leverOn = true;
			leverOn = true;
			PicShow("Hook3", nullPre.src);	// lower crane arm
			PicShow("Hook2", hookPre[2].src);	// middle crane arm
			PicShow("Hook4", hookPre[4].src);	// first pos hook middle arm
			if (mario==25 || mario==24) {	// Mario jumped @ hook or caught it
				clearTimeout(hookID);	// stop hook if moving (to get Mario up)
				hookID = null;
				mario = 40;	// Mario is catching the hook
				hook = 26;	// hook has Mario hanging on it
			};		
			break;
		case 7: // hook up first position
			if (mario==25 || mario==24) {	// Mario jumped @ hook or caught it
				clearTimeout(hookID);	// stop hook if moving (to get Mario up)
				hookID = null;
				mario = 40;	// Mario is catching the hook
				hook = 26;	// hook has Mario hanging on it
			};
			break;
		case 8: case 18: // hook up second position
			if (mario==25) {	// Mario caught hook
				clearTimeout(hookID);	// stop hook if moving (to get Mario up)
				hookID = null;
				mario = 39;	// Mario is reaching for the hook
				hook = 25;	// hook is approaching Mario
			} else {		
				PicShow("Hook4", nullPre.src);	// hide previous hook swing position
				PicShow("Hook5", hookPre[5].src);	// show next hook swing position
			};
			break;
		case 9: case 19: 
			PicShow("Hook5", nullPre.src);	// hide previous hook swing position
			PicShow("Hook6", hookPre[6].src);	// show next hook swing position
			break;
		case 10: 
			PicShow("Hook6", nullPre.src)	// hide previous hook swing position
			PicShow("Hook7", hookPre[7].src);	// show next hook swing position
			break;
		case 11: 
			PicShow("Hook7", nullPre.src)	// hide previous hook swing position
			PicShow("Hook8", hookPre[8].src);	// show next hook swing position
			break;
		case 13: 
			PicShow("Hook8", nullPre.src)	// hide previous hook swing position
			PicShow("Hook7", hookPre[7].src);	// show next hook swing position
			break;
		case 14: 
			PicShow("Hook7", nullPre.src)	// hide previous hook swing position
			PicShow("Hook6", hookPre[6].src);	// show next hook swing position
			break;
		case 15: 
			PicShow("Hook6", nullPre.src)	// hide previous hook swing position
			PicShow("Hook5", hookPre[5].src);	// show next hook swing position
			break;
		case 16: 
			PicShow("Hook5", nullPre.src)	// hide previous hook swing position
			PicShow("Hook4", hookPre[4].src);	// show next hook swing position
			if (mario==25 || mario==24) {	// Mario jumped @ hook or caught it
				clearTimeout(hookID);	// stop hook if moving (to get Mario up)
				hookID = null;
				mario = 39;	// Mario is reaching for the hook
				hook = 25;	// hook is approaching Mario
			}
			break;
		case 17: 
			if (mario==25 || mario==24) {	// Mario jumped @ hook or caught it
				clearTimeout(hookID);	// stop hook if moving (to get Mario up)
				hookID = null;
				mario = 40;	// Mario is catching the hook
				hook = 26;	// hook has Mario hanging on it
			}
			break;
		case 20: 
			clearTimeout(hookID);	// stop hook if moving
			hookID = null;
			hook = 0; 
			hookID=setTimeout("HookEnd()",hookSpeed);	// close up hook movement
			break;
		default:
	};
};

// initiate hook to move
function HookStart () {
	hook = 1;
	HookGo();	// move hook
};

// let Kong move & throw barrels
function KongGo () {
	if (!kongPause) KongMove();	// kongs next move;
};

// kong move; kong throw
function KongMove () {
	var followMario;	// follow Mario half of the time
	var scoreLimit = ((1000%score?score:demoScore) / 100) < 3	// after 300 points (if not demo) Kong will follow Mario more to the hook
	demoScore = 50;	// dummy score for demo to simmulate score level
	seq = sequence&1;	// kongthrow sequence is synchronously to barrels moving
	if (game==2) seq = !seq;	// kongthrow sequence is asynchronously to barrels moving
	if (kong!=4 && !kongThrow) {
		// determine how often Kong is going to throw
		if (!demo) {
			kongThrowInd = kongRandom+Math.floor((score/100)%10)+Math.floor((score/1000)%10)+Math.floor((score/10000)%10);
		} else {
			kongThrowInd = kongRandom+Math.floor(((1000%demoScore)/100))+Math.floor(demoScore/1000);
		};
		i = Math.floor(kongThrowInd*Math.random());
		if (i>7) kongThrowPrev = true;	// prepare for possible barrel holding to throw
		if (mario<12) {	// if Mario till on bottom screen
			if (i==3 && kong!=3) KongMoveDirection("right")	// if kong left, kong go right when indicated
			else if (i==2 && kong!=1) KongMoveDirection("left");	// if kong right, kong go left when indicated
			if (i>(7+(score>700?2:1)) || (RowEmpty() && sequence==1)) KongThrow(kong);	// let kong stand by to throw
		} else {
			followMario = !Math.floor(3*Math.random());	// follow Mario half of the time
			switch (mario) {
				case 12 : case 13 :	// Mario is at the left or coming up
					if (followMario && kong!=1 ) KongMoveDirection("left")	// if kong not left, kong go left when following Mario	
					else {
						if (kongThrowPrev) KongThrow(kong)	// let kong stand by to throw
						else	if (i==2 && kong!=1 && !leverOn) KongMoveDirection("left")	// if kong not left, kong go left when indicated
								else if (followMario) KongThrow(kong);		// throw barrel when indicated	
					};
					break;
				case 14 :	// Mario in the middle
					if (followMario) {
						if (kong==1) KongMoveDirection("right");	// if kong left, kong go right when following Mario
						if (kong==3) KongMoveDirection("left")	// if kong right, kong go left when following Mario
			else KongThrow(kong);	// throw barrel when following Mario
					} else {
						if (kongThrowPrev) KongThrow(kong);	// let kong stand by to throw
						else	if ((i==3 || leverOn) && kong!=3) KongMoveDirection("right")	// if kong not right, kong go right when indicated
								else if (((i==2 && !(kong==3 && barrels[25] == 1)) || !leverOn) && kong!=1) KongMoveDirection("left");	// if kong not left, kong go left when indicated
					};
					break;
				case 15 :	// Mario is at the right
					if (followMario) {		
						if (kong!=1 && !leverOn) KongMoveDirection("left");	// if kong not left, kong go left when following Mario
						if (kong==1 && !leverOn)  KongThrow(kong)	// if kong left, throw barrel when following Mario
						else	if (kong!=3 && leverOn) KongMoveDirection("right")	// if kong not right, kong go right when following Mario
								else if (kong==3 && leverOn)  KongThrow(kong);	// if kong right, let kong stand by to throw when following Mario
					} else {
						if (kongThrowPrev) KongThrow(kong)// let kong stand by to throw
						else	if (i==3 && kong!=3 && leverOn) KongMoveDirection("right") // if kong not right, kong go right when indicated	
								else 	if (!scoreLimit && kong==3) KongMoveDirection("left");	// if more than indicated score & kong not left, kong go left
										else if (kong==2 && !Math.floor(3*Math.random())) KongMoveDirection("right");	// if kong in middle & Mario right, kong sometimes go right
					};
					break;
				default :				
			};
		};
	};
};
			
// let kong move to direction
function KongMoveDirection (kongDirection) {
	// kong is moving left
	if (kongDirection=="left" && kong!=1) {
		PicShow("Kong"+eval(kong--)+"", nullPre.src);	//hide previous Kong
		if (kongThrow) PicShow("Kong"+eval(kong)+"", kongThrowPre[kong].src)	// show Kong throwing
		else PicShow("Kong"+eval(kong)+"", kongwalkPre[kong].src);	// show Kong walking
	};
	// kong is moving right
	if (kongDirection=="right" && kong!=3) {
		PicShow("Kong"+eval(kong++)+"", nullPre.src);	//hide previous Kong
		if (kongThrow) PicShow("Kong"+eval(kong)+"", kongThrowPre[kong].src)	// show Kong throwing
		else PicShow("Kong"+eval(kong)+"", kongwalkPre[kong].src);	// show Kong walking
	};
};

// let kong stand by to throw
function KongThrow (kong) {
	if (seq && kong!=4 && !kongThrow) {	// if right sequence, and kong not falling or already throwing
		if (ToMuchOnRow()) {	// if already thrown to many barrels after eachother
			ToMuchOnRowKongAlt();	// do an alternative movement
			if (mario<7) {	// if Mario stuck @ bottom level
				if (kongRandom>3 && fourOnRow) kongRandom--;	// decrease random if not @ minimum, & 4 barrels on row thrown
			} else {
				kongRandom = kongRandomOrg;	// else reset to default
			};
		} else {
			kongRandom = kongRandomOrg;	// else reset to default
			if	(mario<13 ||	// if Mario not on top screen
				(kong==1 && (barrels[15]==0 || segments[1]==0)) || //if kong @ lever & no barrel or segment & ladder
				kong==2 ||	// if kong in the middle
				(kong==3 && barrels[25]==0)) { // Kong @ hook & no barrel @ in the middle to trap Mario
					kongThrow = true;
					PicShow("Kong"+eval(kong)+"", kongThrowPre[kong].src);	// Kong holding barrel to throw
					kongThrowPrev = false;
			} else {
				kongDirection = (Math.floor(3*Math.random())==1?"left":"right");
				KongMoveDirection(kongDirection); // move Kong randomly left or right
			};
		};
	};
};

// put lever back in rest state
function LeverOff () {
	if (mario==13) PicShow("Mario13", marioPre[13].src);
};

// rescued princess throws love kisses to Mario
function LoveGo () {
	if (bonus>0) {
		if ( (bonus%4)<2 ) {
			PicShow("Love1", lovePre[1].src);
			PicShow("Love2", nullPre.src);
		} else {
			PicShow("Love1", nullPre.src);
			PicShow("Love2", lovePre[2].src);
		};
		loveID=setTimeout("LoveGo()", loveSpeed); 
	} else {
		PicShow("Love1", nullPre.src);
		PicShow("Love2", nullPre.src);
	};
};

// button pressed to play game A
function MainGameA () {
  if (alarm) TimeAlarmOff();	// stop alarm if running
  if ((game!=1 && game!=2 && game!=7) || demo) {   // if not already game A or B playing or game A playing @ demo or keys been set
	if (demo) {
	  demo = false;		// once this key is hit, the demo is turned off
	  MainGameOver();	// stop demo if running + clear all
	};
	GameA();
  };
};

// "game A" button released so actually play game A
function MainGameAGo () {
  if (game!=7){	// if not setting controle keys
	if (!gameCode) {
		PlaySound("click", vlm)	// click sound for push button
		gameCode = "A";
	};
	pause = false;
	ScoreShow(score);
	if (!gameID) gameID = window.setTimeout("GameGo()", 500);	// start next game step in half a second
  };
};

// button pressed to play game B
function MainGameB () {
  if (alarm) TimeAlarmOff();	// stop alarm if running
  if ((game!=1 && game!=2 && game!=7) || demo) {   // if not already game A or B playing or game A playing @ demo or keys been set
	if (demo) {
	  demo = false;		// once this key is hit, the demo is turned off
	  MainGameOver();	// stop demo if running + clear all
	};
	GameB();
  };
};

// "game B" button released so actually play game B
function MainGameBGo () {
  if (game!=7){	// if not setting controle keys
	if (!gameCode) {
		PlaySound("click", vlm)	// click sound for push button
		gameCode = "B";
	};
	pause = false;
	ScoreShow(score);
	if (!gameID) gameID = window.setTimeout("GameGo()", 500);	// start next game step in half a second
  } else game = 3;	// game over
};

// prepare info banner
function MainGameOver () {
	game = 3; // game over
	if (!demo) {
		InfoTextClear();	// empty info banner
		InfoTextHighScores();	// add high scores to info banner
		InfoTextRoll();	// add ending spaces to info banner
		if (demoID) {	 // if demo was planned or running, stop sequence
			clearTimeout(demoID);
			demoID = null;
		};
		if (gameID) {	 // if demo was planned or running, stop sequence
			clearTimeout(gameID);
			gameID = null;
		};
		sound = false;
		demoID = setTimeout("MainTime()", 120000);	// start demo after 2 minutes
	} else GameA();
};

// move mario automatically for the demo without points
function MarioAutoMove () {
	var marioNervous = ((Math.floor(5*Math.random())) ? false : true);
	switch (mario) {
		case -1 :
			mario = 0;
		case 0 :
			if (!barrels[2]) LetMarioJump()
			else mario = 0;
			break;
		case 1 :
			if (barrels[2]) LetMarioJump()
			else if (!barrels[3]) LetMarioRight();
			break;
		case 2 :
			if (barrels[3]) LetMarioLeft()
			else if (!barrels[4]) LetMarioRight();
			break;
		case 3 :
			if (barrels[4]) LetMarioLeft()
			else if (!barrels[5]) LetMarioRight();
			break;
		case 4 :
			if (barrels[5]) LetMarioJump()
			else if (!barrels[6]) LetMarioRight();
			break;
		case 5 :
			if (barrels[6] && (barrels[10] || barrels[9] || barrels[8])) LetMarioLeft()
			else if (!barrels[8]) LetMarioUp();
			break;
		case 6 :
			if ( barrels[8] ) LetMarioDown()
			else if ( !barrels[9]) LetMarioLeft();
			break;
		case 7 :
			if (barrels[9]) {
				if (segments[4] || segments[5] && !barrels[8]) LetMarioRight()
				else LetMarioJump();
			} else if (!barrels[10]) LetMarioLeft();
			break;
		case 8 :
			if (barrels[10]) {
				if (segments[3] || segments[4] && !barrels[9]) LetMarioRight()
				else LetMarioJump();
			} else if (!barrels[11] ) LetMarioLeft();
			break;
		case 9 :
			if (barrels[11]) LetMarioRight()
			else if (!barrels[12]) LetMarioLeft();
			break;
		case 10 :
			if (segments[1] || segments[2]) {
				if (marioNervous || barrels[12]) LetMarioRight();
			} else LetMarioUp();
			break;
		case 11 :
			if (barrels[15]) {
				if ( segments[2] ) LetMarioDown();
			} else LetMarioUp();
			break;
		case 12 :
			if (!(barrels[27] || barrels[28])) LetMarioUp()
			else if (barrels[15] && !segments[1]) LetMarioDown();
			break;
		case 13 :
			if (!(barrels[27] || barrels[28])) {
				if (hook==0 && hookEndComplete) LetMarioLeft ()
				else if (!(barrels[24] || barrels[25])) LetMarioRight();
			} else {
				if (!(barrels[24] || barrels[25])) LetMarioRight()
				else LetMarioDown();
			};
			break;
		case 14 :
			if (hook==0 && hookEndComplete) {
				if (!(barrels[27] || barrels[28])) LetMarioLeft()
				else if (barrels[24] || barrels[25]) LetMarioRight();
			} else {
				if (!(barrels[21] || barrels[22])) LetMarioRight()
				else if (barrels[24] || barrels[25]) LetMarioLeft();
			};
			break;
		case 15 :
//			console.log("@  : hook = "+hook+" - hookEndComplete = "+hookEndComplete);  // game sometimes gets stuck - solved
			if (hook==0 && hookEndComplete) {
				if (!(barrels[24] || barrels[25])) LetMarioLeft()
				else if ((barrels[21] || barrels[22]) && !barrels[24]) LetMarioLeft();
			} else {
				if (hook==6 || hook==7 || ((hook==8) && demo) || hook==15 || hook==16 || hook==17 || ((hook==18)&&demo)) {
					LetMarioJump();
				} else if ((barrels[21] || barrels[22]) || (marioNervous && !(barrels[24] || barrels[25]))) {
					LetMarioLeft();
				};
			};
			break;
		default :
	};
};

// mario is jumping to the hook; check if he reaches; at start mario=24
function MarioEdge () {
	if (mario==24) {
		PicShow("Mario16", marioPre[16].src);
		if (hook==6 || hook==7 || hook==15 || hook==16 || hook==17) {
			if (hook==15) mario = 39	// Mario is reaching for the hook
			else mario = 40;	// Mario is catching the hook
			hook = 25;
			PauseAll();
			hookID=setTimeout("MarioHook()", hookSpeed)  // if sequence???
		} else {
			mario++;
			marioJumpID = setTimeout("MarioEdge()", (marioSpeedJump/2));
		};
	} else {	// Mario missed thr hook
		if (mario==25) {
			PicShow("Mario16", nullPre.src);
			mario = 34;
			PlaySound("fall", vlm);	// sound for falling Mario
			PauseAll();
			MarioFall();	// Mario falls missing the hook
		}  else {
			mario++;
			marioJumpID = setTimeout("MarioEdge()", (marioSpeedJump/2));
		};
	};
};

// Mario falling after walking to far or missing the hook while jumping at it
function MarioFall () {
	mario++;
	if (mario==35) {	// Mario falling
		PicShow("Mario20", marioPre[20].src);
		PicShow("Mario15", nullPre.src);
	} else {
		if (mario==36) {	// Mario hitting the floor
			PlaySound("hit", vlm);	// sound for Mario hitting floor
			PicShow("Mario21", marioPre[21].src);
			PicShow("Mario20", nullPre.src)
		} else if (mario==37) PicShow("Mario21", nullPre.src);
	}
	if (mario<39)  marioFallID = setTimeout("MarioFall()", marioSpeedFall)
	else MarioLifeLost();	// mario losts his life; check for game over; reset kills; init
};

// mario swings with the hook 
function MarioHook () {
	var reduce;  // reduce speed by 200 (max) after successfull run
	mario++;
	if (mario<105 && !gamerInterrupt) {
		switch (mario) {
			case 40:	// Mario caught the hook
				PicShow("Mario16", marioPre[16].src);	// jumping Mario catching hook
				PicShow("Hook5", nullPre.src);	// hide hook at approaching position to Mario
				PicShow("Hook4", hookPre[4].src);	// show hook at closest position to Mario
				PicShow("Hook2", hookPre[2].src)	// crane arm 1 up	
				break;
			case 41:
				PicShow("Mario16", nullPre.src);	// hide jumping Mario
				PicShow("Mario17", marioPre[17].src);	// Mario swinging down
				PicShow("Hook4", nullPre.src);	// hide previous hook
				PicShow("Hook6", hookPre[6].src);	// lowest hook position
				PicShow("Hook2", hookPre[2].src);	// crane arm 1 up
				PlaySound("step", vlm);	// sound for Mario moving
				break;
			case 42:
				PicShow("Mario17", nullPre.src);	// hide previous Mario
				PicShow("Mario18", marioPre[18].src);	// Mario at the top picking off a bridge holder
				PicShow("Hook2", nullPre.src);	// hide previous crane arm
				PicShow("Hook6", nullPre.src);	// hide previous hook position
				PicShow("Hook1", hookPre[1].src);	// show top crane arm with hook
				PicShow("Hol"+eval(hold)+"", nullPre.src);	// hide taken bridge holder
				PlaySound("step", vlm);	// sound for Mario moving
				if (demo) {
					hold--;
					if (hold!=0) mario = 100	// if holders left Mario comes down to make another run
					else mario = 48;	// else Mario waits for falling bridge
				} else ScoreAddCount(bonusScore);
				break;
			case 43:
				hold--;
				if (hold!=0) {
					if (bonusDone) {	// if bonus count finished go to next step
						mario = 100;	// Mario comes down to make another run
						bonusDone = false;
					} else {	// if bonus count not finished go 1 step back and recheck
						mario = 42;	// else Mario waits till bonus compleeted
						hold++;	// to prevent negative holders while waiting
					};
				};
				break;
			case 44:	// bridge blinking...
				if (!bonusDone) mario = 43	// if bonus count not finished go 1 step back and recheck
				else {	// blink bridge
					PicShow("BridgeUp1", nullPre.src);
					PicShow("BridgeUp2", nullPre.src);
					PicShow("BridgeUp3", nullPre.src);
					PlaySound("barrel", vlm);	// sound for barrels move
				};
				break;
			case 45:	// bridge blinking...
				PicShow("BridgeUp1", bridgeupPre[1].src);
				PicShow("BridgeUp2", bridgeupPre[2].src);
				PicShow("BridgeUp3", bridgeupPre[3].src);
				break;
			case 46:	// bridge blinking...
				PicShow("BridgeUp1", nullPre.src);
				PicShow("BridgeUp2", nullPre.src);
				PicShow("BridgeUp3", nullPre.src);
				PlaySound("barrel", vlm);	// sound for barrels move
				break;
			case 47:	// bridge blinking...
				PicShow("BridgeUp1", bridgeupPre[1].src);
				PicShow("BridgeUp2", bridgeupPre[2].src);
				PicShow("BridgeUp3", bridgeupPre[3].src);
				break;
			case 48:	// bridge blinking...
				PicShow("BridgeUp1", nullPre.src);
				PicShow("BridgeUp2", nullPre.src);
				PicShow("BridgeUp3", nullPre.src);
				PlaySound("barrel", vlm);	// sound for barrels move
				break;
			case 49:	// bridge falls
				if (demo) {
					PicShow("BridgeUp1", nullPre.src);
					PicShow("BridgeUp2", nullPre.src);
					PicShow("BridgeUp3", nullPre.src);
					PicShow("Kong"+eval(kong)+"", nullPre.src);	// hide Kong on bridge
					PicShow("Kong4", kongwalkPre[4].src);	// show Kong falling
					kong = 4;	// Kong falling
					mario = 101;	// Mario
				};
				PicShow("BridgeDown1", bridgedownPre[1].src);
				PicShow("BridgeDown2", bridgedownPre[2].src);
				PicShow("BridgeDown3", bridgedownPre[3].src);
				break;
			case 50:
				PicShow("BridgeDown1", nullPre.src);
				PicShow("BridgeDown2", nullPre.src);
				PicShow("BridgeDown3", nullPre.src);
				PicShow("Kong"+eval(kong)+"", nullPre.src);
				PicShow("Kong4", kongwalkPre[4].src);
				kong = 4;
				PlaySound("hit", vlm);	// sound for Mario colliding with barrel or segment
				break;
			case 51:
				ScoreAddCount(20);	// extra 20 bonuspoints
				break;
			case 52:	// move hook to normal
				if (bonusDone) {
					mario = 100;
					bonusDone = false;
				} else {
					mario = 51;
					hold++;
				};
				break;
			case 101:	// Mario comming down
				if (!demo) {	// in Demo Mario comes down in one move
					PicShow("Mario18", nullPre.src);	// hide unhooking Mario
					PicShow("Mario17", marioPre[17].src);	//	Show decending Mario
					PicShow("Hook1", nullPre.src);	// hide top crane arm & hook
					PicShow("Hook2", hookPre[2].src);	// show middle crane arm
					PicShow("Hook6", hookPre[6].src);	// lowest hook position
				};
				break;
			case 102:
				if (demo) {	// in Demo Mario comes down in one move
					PicShow("Mario18", nullPre.src);	// hide unhooking Mario
					PicShow("Hook1", nullPre.src);	// hide top crane arm & hook
				};
				PicShow("Mario17", nullPre.src);	// hide decending Mario
				PicShow("Mario19", marioPre[19].src);	// show landed Mario
				PicShow("Hook2", nullPre.src);	// hide middle crane arm
				PicShow("Hook6", nullPre.src);	// hide lowest hook position
				PicShow("Hook3", hookPre[3].src);	// bottom crane arm & hook
				hook = 0; 
				HookEnd();// not sooner!
				break;
			case 103:
				PicShow("Mario19", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario moving
				if (kong==4) {	
					PicShow("Kong4", nullPre.src);	// hide fallen Kong
					PicShow("BridgeUp1", bridgeupPre[1].src);	// reset bridge
					PicShow("BridgeUp2", bridgeupPre[2].src);
					PicShow("BridgeUp3", bridgeupPre[3].src);
					KongReset();	// set kong to begin settings
				};
				if (demo) {
					mario = 105;	// let Mario begin without waiting another sequence
					PicShow("BridgeDown1", nullPre.src);	// reset fallen bridge
					PicShow("BridgeDown2", nullPre.src);
					PicShow("BridgeDown3", nullPre.src);
				};
				break;
			default:
		};
		hookID=setTimeout("MarioHook()", hookSpeed)
	} else {	// Mario taken hook or died, so reset to next sequence
		gamerInterrupt = false;
		mario = 200;
		AllInit();	// put mario at begonposition & go
		BarrelsClearLastRow();	// remove last 3 barrels after succesfull run
		if (!demo) speedReset();	// demo has no speed up
		clearTimeout(runTimeID);	// stop runtime
		runTimeID = null;
		CountRunTime();	//count seconds needed for run from start to removal holder
		animated = false;	// no life lost, no animated life indication required
		MarioButtonJump();	// press jump button
		runTime = 0;
	};
};

// mario is going to first place
function MarioInit () {
	if (mario==-1) mario = 0;
	else mario = 1;
	PlaySound("jump", vlm);	// sound for Mario jumping
	PicShow("Mario1", marioPre[1].src);
	if (animated) LifeShowAnimated()
	else LifeShow();
};

// let Mario jump
function MarioJump () {
	PicShow("Mario"+eval(mario)+"", nullPre.src);
	PicShow("MarJump"+eval(mario)+"", marjumpPre[mario].src);
	marioJump = true;
	PlaySound("jump", vlm);	// sound for Mario jumping
	SegmentsCollision();		// check if Mario collides with a segment
	// landing after jump if no collision with passing beam
	marioJumpID = setTimeout("MarioJumpDown()", marioSpeedJump);
};

// landing after jump
function MarioJumpDown () {	
	if (!marioPause) {
		if (!marioKill) {
			marioJump = false;
			PicShow("MarJump"+eval(mario)+"", nullPre.src);
			PicShow("Mario"+eval(mario)+"", marioPre[mario].src);
		};
	} else if (!marioKill) marioJumpID = setTimeout("MarioJumpDown()", 200);	// land after bonus indication
};

// Mario gets killed and blinks at hit place
function MarioKill () {
	PauseAll();
	marioKillPlace = mario;
	mario = 100;
	marioKill = true;
	PauseAll();
	PlaySound("hit", vlm);	// sound for Mario colliding with barrel or segment
	if (!marioJump) MarioKillGo()	// let Mario blink at kill
	else MarioKillGoJump();	// let jumping Mario blink at kill
};

// let Mario blink at kill
function MarioKillGo () {
	mario++;
	if (mario<106) {
		switch (mario) {	// blinking Mario
			case 102:
				PicShow("Mario"+eval(marioKillPlace)+"", nullPre.src); 
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 103:
				PicShow("Mario"+eval(marioKillPlace)+"", marioPre[marioKillPlace].src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 104:
				PicShow("Mario"+eval(marioKillPlace)+"", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 105:
				PicShow("Mario"+eval(marioKillPlace)+"", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			default:
		}
		marioKillID=setTimeout("MarioKillGo()", marioSpeedKill);
	} else MarioLifeLost();	// mario losts his life; check for game over; reset kills; init
};

// let jumping Mario blink at kill
function MarioKillGoJump () {
	marioJump = false;
	mario++;
	if (mario<108) {
		switch (mario) {	// Mario blinking
			case 102:
				PicShow("MarJump"+eval(marioKillPlace)+"", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 103:
				PicShow("MarJump"+eval(marioKillPlace)+"", marjumpPre[marioKillPlace].src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 104:
				PicShow("MarJump"+eval(marioKillPlace)+"", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
			case 105:
				PicShow("Mario"+eval(marioKillPlace)+"", nullPre.src);
				PlaySound("jump", vlm);	// sound for Mario jumping
				break;
		};
		marioKillID=setTimeout("MarioKillGoJump()", marioSpeedKill);
	} else MarioLifeLost();	// mario losts his life; check for game over; reset kills; init
};

// mario losts his life; check for game over; reset kills; init
function MarioLifeLost () {
	var reduce;  // reduce speed by 200 (max) after Mario was killed
	clearTimeout(runTimeID);	// stop runtime
	runTimeID = null;
	pointsBonus = false;
	animated = true;	// animated life indication required
	if (!demo) speedReset();
	if (life==1) GameOver()	// all Marios are killed in action
	else {
		life--;
		marioKill = false;
		AllInit();	// put mario at begonposition & go
	};
};

// mario init when jump pressed the first time
function MarioUpInit () {
	clearTimeout(marioTimeID);
	marioTimeID = null;
	if (game==1 || game==2) MarioInit();	// mario is going to first place
};

// check for empty row lower screen
function RowEmpty() {
	if ( !barrels[10] && !barrels[11] && !barrels[12] && !barrels[13] && !barrels[14] && !barrels[15] ) return true;
}

// add points (x points) to score with sound each count
function ScoreAddCount (points) {
	bonus = points;
	bonusDone = false;
	ScoreGo();	// add a point to score
};

// add multiple points fast while checking if bonus is reached for bonus indicating pause
function ScoreAddFastCheck (points) {
	if (game!=0) {	// if not reset
		// add points fast (x points) while checking if bonus score is reached
		if (!marioPause || !scorePause) ScoreAddFast(points)
		else scoreID = setTimeout("ScoreAddFastCheck("+points+")", 2*bonusTime);	
	};
};

// add multiple points fast
function ScoreAddFast (points) {
	tmpScore = score;
	for (var sci=1 ; sci<(points+1) ; sci++) {
		if (pointsBonus) {
			score++;
			CheckAndShow();
		};
		score++;
		CheckAndShow();
	};
};

// add a point to score
function ScoreGo () {
	if (game!=0) {	// if not reset
		if (!scorePause) {
			ScoreAddFast(1);	// add 1 point fast
			bonus--;
			PlaySound("bonus", vlm);
			if (bonus>0) scoreID = setTimeout("ScoreGo()", scoreSpeed) 
			else bonusDone = true;
		} else scoreID = setTimeout("ScoreGo()", 2*bonusTime);	// add a point to score
	};
};

// let score blink while score over 300 and no life lost
function Scoreblink () {
	if (game!=0) {	// if not reset
		if (pointsBonus) {
			ScoreHide();
			blinkID = setTimeout("ScoreUnHide()", blinkSpeed);
			blinkID = setTimeout("Scoreblink()", 2*blinkSpeed);
		} else ScoreUnHide();
	};
};

// segments check collision with mario
function SegmentsCollision () {
	if (segments[1]==1 && mario==11)  MarioKill();	// Mario gets killed and blinks at hit place
	if (marioJump) {
		if (segments[3]==1 && mario==8)  MarioKill();	// Mario gets killed and blinks at hit place
		if (segments[4]==1 && mario==7)  MarioKill();	// Mario gets killed and blinks at hit place
	};
};

// exceeds number of segments
function SegmentsExceeded (number) {
	for (var i=1 ; i<=5 ; i++) if (segments[i]) number--; 
	if (number<0) return 1
	else return 0;
};

// segments go, move show and repeat
function SegmentsGo () {
	if (!segmentsPause) {
		SegmentsMove();	// segments move; init first
		SegmentsShow();	// show the moving segments
		SegmentsCollision();		// check if Mario collides with a segment
	};
};

// segments move init first
function SegmentsMove () {
	var randy = Math.floor(segmentsRandom*Math.random())==0;
	for (var i=1 ; i<5 ; i++) segments[i] = segments[i+1];
	if (game==1) {
			if (((mario>5 && ((score<300 && !SegmentsExceeded(0)) || (score>300 && score<1000 && !SegmentsExceeded(1)))) || score>1000) && randy && segments[4]==0) segments[5] = 1;
			else segments[5] = 0;
	// check game b if no previous segment for randomly add new segment
	} else {
			if (((score<300 && !SegmentsExceeded(1)) || (score>300 && score<1000 && !SegmentsExceeded(2)) || score>1000) && randy && segments[4]==0) segments[5] = 1;
			else segments[5] = 0;
	};
};

// Speeds up the game
function SpeedUp (speed) {
	if (gameSpeed>gameSpeedMaximum && !demo) {
		gameSpeed -= speed; 
		marioSpeedJump = gameSpeed * 11/6;
	};
};

// check if 3 barrels already on row @ previous throw
function ThreeOnRow () {
	threeOnRow = false;
	switch (kong) {
		case 1:	//possible fourth barrel if Kong @ lever
			if (   ((barrels[16]||barrels[26]) && (barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]))
					|| ((barrels[17]||barrels[27]) && (barrels[18]||barrels[23]||barrels[28]) && (barrels[20]||barrels[25])) 
					|| ((barrels[18]||barrels[23]||barrels[28]) && (barrels[20]||barrels[25]) && barrels[21]) 
					|| ((barrels[20]||barrels[25]) && barrels[21] && barrels[22]) 
				) threeOnRow = true;
			break;
		case 2:	//possible fourth barrel if Kong  in middle
			if (   ((barrels[18]||barrels[23]||barrels[28]) && (barrels[19]||barrels[24]) && (barrels[20]||barrels[25]))
					|| ((barrels[19]||barrels[24]) && (barrels[20]||barrels[25]) && barrels[22]) 
				) threeOnRow = true;
			break;
		case 3:	//possible fourth barrel if Kong @ hook
			if ((barrels[20]||barrels[25]) && barrels[21] && barrels[22]) threeOnRow = true;
			break;
		default :
	};
	return threeOnRow;
};

// check if to many barrels already on row @ previous throw
function ToMuchOnRow () {
	if (score<999 || mario<12) return ThreeOnRow()
	else {
		threeOnRow = false;		
		return FourOnRow();
	};
};

// let kong move if not can throw when four on row 
function ToMuchOnRowKongAlt () {
	fourOnRow = false;	// reset for next move
	if (leverOn && mario>12) {	// if Mario on top screen & hook is working
		if (kong==3 && mario<15) KongMoveDirection("left")	// if Kong @ hook & Mario not
		else if (kong!=3 ) KongMoveDirection("right");	// if Kong not @ hook
	} else  if (kong==1) KongMoveDirection("right")	// if Kong @ lever
		else KongMoveDirection("left");	
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end game functions

//banner functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// run info banner
function Info () {
	if (game!=6) {
		document.Info.text.value = infoMsgBlur.substring(infoPos, infoPos+120);	// show infoMsg on screen for info purposes
		infoPos++;	  // move banner a position to the left
		if (infoPos==infoMsgBlur.length-20) infoPos = 0;	// if banner ended, restart from position zero
		infoID = setTimeout("Info()", 100);	// run info banner
	};
};

// set initial banner for demo
function InfoInitStart () {
  InfoTextClear();	// empty info banner
  InfoTextStart();	// add game instructions to info banner
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextKeys();		// add controlling keys to info banner
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextHighScores();	// add high scores to info banner
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextIngame();	// add game story to info banner
  InfoTextRoll();	// add ending spaces to info banner
};

// show instructions to set the alarm
function InfoTextAlarm () {
  infoMsg+= '&nbsp;'.repeat(5);
  infoMsg = 'Press Up/Down to change alarm hour. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Press Left/Right to change alarm minute. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Press the "Alarm" button to toggle on/off. ';
};

// show alarm setting
function InfoTextAlarmInfo () {
  infoMsg+= '&nbsp;'.repeat(5);
  if (!alarmOn) infoMsg+= 'Alarm is not set!';
  else infoMsg+= 'Alarm is set at '+(eval(prefAlarmHour)).pad()+":"+(eval(prefAlarmMin)).pad()+"";
  infoMsg+= '&nbsp;'.repeat(90);
};

// empty info banner
function InfoTextClear () {
  infoMsg = '';
  infoPos = 0;
  $("#Banner").html("");
};

// show the current high scores
function InfoTextHighScores () {
  infoMsg+= '&nbsp;'.repeat(5);
  infoMsg+= 'High scores so far...';
  infoMsg+= '&nbsp;'.repeat(16);
  for (i=1 ; i<10 ; i++) infoMsg+= '#'+eval(i)+'...'+hi[i]+'&nbsp;'.repeat(8);
};

// show game story
function InfoTextIngame () {
  infoMsg+= '&nbsp;'.repeat(5);
  infoMsg+= 'Donkey Kong captured a beautiful girl and carries her into a building under construction. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'The brave carpenter, Mario comes to rescue her following them over the girders. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Donkey Kong throws barrels at Mario to stop him. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Knock the girder out from under Donkey Kong to save the girl. ';
};

// show controlling keys
function InfoTextKeys () {
  infoMsg+= 'Keys momentarily mapped as follows...';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Up: "'+codeUpChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Down: "'+codeDownChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Left: "'+codeLeftChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Right: "'+codeRightChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Jump: "'+codeJumpChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Start game A: "'+codeGameAChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Start game B: "'+codeGameBChar+'"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Permanent keys to play...';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Up: "'+'\u25B2'+'"';	// arrow up
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Down: "'+'\u25BC'+'"';	// arrow down
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Left: "'+'\u25C0'+'"';	// arrow left
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Right: "'+'\u25B6'+'"';	// arrow right
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Jump: "spacebar"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Start game A: "1"';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Start game B: "2"';
  infoMsg+= '&nbsp;'.repeat(8);
};

// info text shown while loading page, probably never visible
function InfoTextLoading () {
  infoMsg+= '&nbsp;'.repeat(5);
  infoMsg+= 'Please wait while loading... You may continue, although there may be some graphics slowdowns. ';
};

// add 20 spaces to banner after info banner text and translate to info text
function InfoTextRoll () {
  $("#Banner").html('<marquee behavior="scroll" direction="left" scrollamount="5">'+infoMsg+'</marquee>');
  infoMsg+= '&nbsp;'.repeat(20);
  infoPos = 0;
  infoMsgBlur = '&nbsp;'.repeat(112);
  infoMsgBlur = infoMsgBlur.replace(/&nbsp;/g, " ");
  infoMsgBlur+= infoMsg.replace(/&nbsp;/g, " ");
};

// show game instructions
function InfoTextStart () {
  infoMsg+= '&nbsp;'.repeat(5);
  infoMsg+= 'Welcome to Donkey Kong HTML written by Andrzej Czyz, modified by Flyzy. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Based on Game&Watch Multi Screen "Donkey Kong", ';
  infoMsg+= 'released in June 1982 by Nintendo. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Press the "' +codeGameAChar+ '" button or "' +codeGameAChar.toUpperCase()+ '" to play Game A, ';
  infoMsg+= 'press the "' +codeGameBChar+ '" button or "' +codeGameBChar.toUpperCase()+ '" to play Game B. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Press the "Time" button for Time mode. ';
  infoMsg+= '&nbsp;'.repeat(8);
  infoMsg+= 'Press the "Reset" button to reset the game, ';
  infoMsg+= 'press the "Alarm" button to set the alarm, ';
  infoMsg+= 'press the "Keys" button to remap the control keys. ';
};

// this function shoxs how the alarm has been set
function InfoTextTime () {
  InfoTextClear();	// empty info banner
  InfoTextAlarmInfo();  // show alarm setting
  InfoTextStart();
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextKeys();
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextHighScores();
  infoMsg+= '&nbsp;'.repeat(90);
  InfoTextIngame ();
  InfoTextRoll();
};

// set game to standard settings and show all figures
function MainLoaded () {
  Reset();	// reset all on going to default and show all figures
  InfoTextClear();	// empty info banner
  InfoTextStart();
  InfoTextRoll();
};

// (re)initialise the info banner
function NewInfo () {
	if ( infoID ) {	 // if info banner was running, stop next sequence
		clearTimeout(infoID);
		infoID = null;
	};
	InfoInitStart();	// reset info banner to start settings
	Info();	// run info banner
};

// update info box controller information text
function UpdateInfoText () {
  $("#pk").text('Programmable keys to play : "'+ 
  codeLeftChar+'" for left, "'+ 
  codeRightChar+'" for right, "'+ 
  codeUpChar+'" for up & "'+ 
  codeDownChar+'" for down, "'+ 
  codeJumpChar+'" for jump, "'+ 
  codeGameAChar+'" for game A, "'+ 
  codeGameBChar+'" for game B.');
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//end banner functions

//extra functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this shows the leading zero(s) - no size given = 2 digits for example (9).pad() returns "09"
Number.prototype.pad = function(size) {
	var s = String(this);
	while (s.length<(size || 2)) {s = "0" + s;}
	return s;
};

// name - name of the cookie
// value - value of the cookie
// [expires] - expiration date of the cookie (defaults to end of current session)
// [path] - path for which the cookie is valid (defaults to path of calling document)
// [domain] - domain for which the cookie is valid (defaults to domain of calling document)
// [secure] - Boolean value indicating if the cookie transmission requires a secure transmission
// * an argument defaults when it is assigned null as a placeholder
// * a null placeholder is not required for trailing omitted arguments
function SetCookie (name, value, expires, path, domain, secure) {
	var curCookie = name + "=" + escape(value) +
		((expires) ? "; expires=" + expires.toGMTString() : "") +
		((path) ? "; path=" + path : "/") +
		((domain) ? "; domain=" + domain : "") +
		"; SameSite=Lax" +
		((secure) ? "; secure" : "");
	document.cookie = curCookie;
};

// name - name of the desired cookie
// * return string containing value of specified cookie or null if cookie does not exist
function GetCookie (name) {
	var dc = document.cookie;
	var prefix = name + "=";
	var begin = dc.indexOf("; " + prefix);
	var end;
	if (begin==-1) {
		begin = dc.indexOf(prefix);
		if (begin!=0) return null;
	} else begin += 2;
	end = document.cookie.indexOf(";", begin);
	if (end==-1) end = dc.length;
	return unescape(dc.substring(begin + prefix.length, end));
};

// pause all but hook
function PauseAll () {
	gamePause = true;
	barrelsPause = true;
	segmentsPause = true;
	kongPause = true;
	marioPause = true;
};

// unpause all but hook
function UnPauseAll () {
	marioPause = false;
	gamePause = false;
	segmentsPause = false;
	kongPause = false;
	scorePause = false;
	barrelsPause = false;
};
